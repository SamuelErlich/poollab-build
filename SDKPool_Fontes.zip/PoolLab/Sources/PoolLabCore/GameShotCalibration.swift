import Foundation

/// Conversion between the verified 56.31.0 cue-control curve and this
/// simulator's linear speed fraction. This does not calibrate spin, pockets,
/// cushions or cloth, and is not a guarantee of identical game physics.
public enum GameShotCalibration {
    /// Native: speed = maximumSpeed * (1 - sqrt(1 - controlPower)).
    /// The equivalent expression below avoids cancellation near zero.
    public static func simulationPower(fromControlPower power: Double) throws -> Double {
        try validate(power)
        return power / (1 + sqrt(1 - power))
    }

    /// Inverse of simulationPower: controlPower = q * (2 - q).
    public static func controlPower(fromSimulationPower power: Double) throws -> Double {
        try validate(power)
        return power * (2 - power)
    }

    private static func validate(_ value: Double) throws {
        guard value.isFinite, (0...1).contains(value) else {
            throw BilliardsError.invalidShot
        }
    }
}
