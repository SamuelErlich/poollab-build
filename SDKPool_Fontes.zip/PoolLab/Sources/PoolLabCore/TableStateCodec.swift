import Foundation

/// Versioned interchange for explicitly provided local table snapshots.
/// No code, URLs, external game access or actions are executed by importing a scene.
public enum TableStateCodec {
    public static let maximumBytes = 65_536
    private struct Envelope: Codable {
        let format: String
        let version: Int
        let state: TableState
    }

    public enum CodecError: Error, LocalizedError, Equatable {
        case oversized, unsupportedFormat
        public var errorDescription: String? {
            switch self {
            case .oversized: return "O arquivo da mesa deve ter no máximo 64 KB."
            case .unsupportedFormat: return "Este arquivo não usa o formato PoolLab versão 1."
            }
        }
    }

    public static func encode(_ state: TableState) throws -> Data {
        try BilliardsEngine.validate(state, requireCue: false)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(Envelope(format: "PoolLab.TableState", version: 1, state: state))
        guard data.count <= maximumBytes else { throw CodecError.oversized }
        return data
    }

    public static func decode(_ data: Data) throws -> TableState {
        guard data.count <= maximumBytes else { throw CodecError.oversized }
        let envelope = try JSONDecoder().decode(Envelope.self, from: data)
        guard envelope.format == "PoolLab.TableState", envelope.version == 1 else {
            throw CodecError.unsupportedFormat
        }
        try BilliardsEngine.validate(envelope.state, requireCue: false)
        return envelope.state
    }
}
