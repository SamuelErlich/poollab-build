import CryptoKit
import Foundation

struct KeyAuthResponseVerifier: Sendable {
    // Published by KeyAuth in its official 1.3 examples. No public override exists.
    static let officialPublicKeyHex = "5586b4bc69c7a4b487e4563a4cd96afd39140f919bd31cea7d1c6a1e8439422b"
    let publicKeyBytes: Data
    let now: @Sendable () -> Date

    func verify(_ response: KeyAuthHTTPResponse) throws {
        guard let timestamp = response.headers["x-signature-timestamp"],
              !timestamp.isEmpty,
              timestamp.utf8.allSatisfy({ (48...57).contains($0) }),
              let epoch = Int64(timestamp),
              let signatureHex = response.headers["x-signature-ed25519"],
              let signature = Self.decodeHex(signatureHex), signature.count == 64,
              let publicKey = try? Curve25519.Signing.PublicKey(rawRepresentation: publicKeyBytes) else {
            throw KeyAuthError.invalidSignature
        }
        let age = now().timeIntervalSince1970 - Double(epoch)
        guard age >= -5, age <= 25 else { throw KeyAuthError.staleResponse }
        var signedMessage = Data(timestamp.utf8)
        signedMessage.append(response.body)
        guard publicKey.isValidSignature(signature, for: signedMessage) else {
            throw KeyAuthError.invalidSignature
        }
    }

    static func decodeHex(_ string: String) -> Data? {
        let bytes = Array(string.utf8)
        guard bytes.count.isMultiple(of: 2) else { return nil }
        func nibble(_ byte: UInt8) -> UInt8? {
            switch byte {
            case 48...57: return byte - 48
            case 65...70: return byte - 65 + 10
            case 97...102: return byte - 97 + 10
            default: return nil
            }
        }
        var output = Data(capacity: bytes.count / 2)
        for index in stride(from: 0, to: bytes.count, by: 2) {
            guard let high = nibble(bytes[index]), let low = nibble(bytes[index + 1]) else { return nil }
            output.append((high << 4) | low)
        }
        return output
    }
}
