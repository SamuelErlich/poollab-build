import Foundation

/// Deterministic, independent estimate. Equal masses, circular balls and pockets,
/// normal restitution and drag. A supplied native response profile adds sliding,
/// rolling and spin. Validated native geometry adds finite cushion edges, pocket
/// attraction and capture boundaries. Inputs are copied; no game-state mutation.
public enum BilliardsEngine {
    public static let maximumDuration: Double = 30
    public static let maximumSteps = 60_000
    public static let maximumEvents = 4_096
    public static let maximumFrames = 902
    /// Absolute input bound for captured velocities, in table units per second.
    /// This is independent of the currently selected cue's launch-speed limit.
    public static let maximumLiveBallSpeed: Double = 2_000
    public static let maximumAngularSpeed: Double = 10_000
    private static let stopSpeed: Double = 0.025
    private static let timeTolerance: Double = 1e-10
    private static let contactTolerance: Double = 1e-7

    public static func validate(_ state: TableState, requireCue: Bool = true) throws {
        try validate(state, requireCue: requireCue, allowMotion: false)
    }

    /// A continuation may contain moving object balls after the cue was pocketed.
    /// Invalid/overlapping captures are rejected; their positions are not repaired.
    public static func validateContinuation(_ state: TableState) throws {
        try validate(state, requireCue: false, allowMotion: true)
    }

    private static func validate(
        _ state: TableState, requireCue: Bool, allowMotion: Bool
    ) throws {
        try Task.checkCancellation()
        let t = state.table
        let values = [t.width, t.height, t.ballRadius, t.pocketRadius,
                      t.ballRestitution, t.cushionRestitution,
                      t.rollingDeceleration, t.maximumShotSpeed]
        guard values.allSatisfy({ $0.isFinite }),
              (60...1_000).contains(t.width), (40...1_000).contains(t.height),
              (1...10).contains(t.ballRadius),
              t.ballRadius <= min(t.width, t.height) / 12,
              t.pocketRadius >= t.ballRadius * (t.nativeGeometry == nil ? 1.1 : 1),
              t.pocketRadius <= min(t.ballRadius * 3.5, min(t.width, t.height) / 6),
              (0...1).contains(t.ballRestitution),
              (0...1).contains(t.cushionRestitution),
              (0...100).contains(t.rollingDeceleration),
              (1...2_000).contains(t.maximumShotSpeed) else { throw BilliardsError.invalidTable }
        if let native = t.nativeDynamics {
            let values = [native.slidingDeceleration, native.equilibriumTimeFactor,
                          native.spinDeceleration, native.slidingFrictionCoefficient,
                          native.cushionSpinCoupling, native.logicalFrameTime]
            guard values.allSatisfy(\.isFinite),
                  (0.001...2_000).contains(native.slidingDeceleration),
                  (1e-8...100).contains(native.equilibriumTimeFactor),
                  (0...10_000).contains(native.spinDeceleration),
                  (0...1).contains(native.slidingFrictionCoefficient),
                  (0...2).contains(native.cushionSpinCoupling),
                  (0.0005...0.02).contains(native.logicalFrameTime) else {
                throw BilliardsError.invalidTable
            }
        }
        if let geometry = t.nativeGeometry {
            guard (4...192).contains(geometry.cushionVertices.count), geometry.pockets.count == 6,
                  Set(geometry.pockets.map(\.id)) == Set(0...5) else { throw BilliardsError.invalidTable }
            let margin = t.ballRadius * 12
            func bounded(_ point: Vector2) -> Bool {
                point.isFinite && (-margin...t.width + margin).contains(point.x)
                    && (-margin...t.height + margin).contains(point.y)
            }
            guard geometry.cushionVertices.allSatisfy(bounded),
                  geometry.pocketAttraction.isFinite, (0...10_000).contains(geometry.pocketAttraction),
                  geometry.pockets.allSatisfy({ bounded($0.center) && bounded($0.aimPoint)
                    && $0.radius.isFinite && (t.ballRadius...t.ballRadius * 4).contains($0.radius)
                    && $0.attractionRadius.isFinite && ($0.radius...t.ballRadius * 6).contains($0.attractionRadius) }) else {
                throw BilliardsError.invalidTable
            }
            var twiceArea = 0.0
            for index in geometry.cushionVertices.indices {
                let a = geometry.cushionVertices[index]
                let b = geometry.cushionVertices[(index + 1) % geometry.cushionVertices.count]
                guard a.distance(to: b) > 1e-6 else { throw BilliardsError.invalidTable }
                twiceArea += a.x * b.y - b.x * a.y
            }
            guard abs(twiceArea) >= t.width * t.height else { throw BilliardsError.invalidTable }
        }
        guard state.balls.count <= 16,
              Set(state.balls.map(\.id)).count == state.balls.count else {
            throw BilliardsError.invalidBalls
        }
        let r = t.ballRadius
        for ball in state.balls {
            guard (0...15).contains(ball.id), ball.position.isFinite,
                  ball.velocity.isFinite, validSpin(ball.spin) else { throw BilliardsError.invalidBalls }
            if ball.pocketed { continue }
            if let geometry = t.nativeGeometry {
                // Actual pocket mouths extend beyond the nominal cloth bounds.
                // Keep captured coordinates unchanged and validate their envelope.
                let points = geometry.cushionVertices + geometry.pockets.map(\.center)
                guard ball.position.x >= points.map(\.x).min()! - r,
                      ball.position.x <= points.map(\.x).max()! + r,
                      ball.position.y >= points.map(\.y).min()! - r,
                      ball.position.y <= points.map(\.y).max()! + r else {
                    throw BilliardsError.invalidBalls
                }
            } else {
                guard ball.position.x >= r - contactTolerance,
                      ball.position.x <= t.width - r + contactTolerance,
                      ball.position.y >= r - contactTolerance,
                      ball.position.y <= t.height - r + contactTolerance else {
                    throw BilliardsError.invalidBalls
                }
            }
            if allowMotion {
                guard ball.velocity.lengthSquared <= maximumLiveBallSpeed * maximumLiveBallSpeed else {
                    throw BilliardsError.invalidBalls
                }
                guard t.nativeDynamics != nil || ball.spin == .zero else { throw BilliardsError.invalidBalls }
            } else {
                guard ball.velocity == .zero, ball.spin == .zero else { throw BilliardsError.movingBalls }
            }
        }
        for a in state.balls.indices where !state.balls[a].pocketed {
            for b in state.balls.indices where b > a && !state.balls[b].pocketed {
                if state.balls[a].position.distance(to: state.balls[b].position) < 2 * r - contactTolerance {
                    throw BilliardsError.overlappingBalls
                }
            }
        }
        if requireCue && state.cueBall == nil { throw BilliardsError.missingCueBall }
    }

    public static func simulate(
        state: TableState, shot: ShotParameters, recordFrames: Bool = true
    ) throws -> ShotResult {
        try validate(state)
        let initialSpin = shot.initialSpin ?? .zero
        guard shot.angleRadians.isFinite, shot.power.isFinite, (0...1).contains(shot.power),
              validSpin(initialSpin), state.table.nativeDynamics != nil || initialSpin == .zero else {
            throw BilliardsError.invalidShot
        }
        // Sorting makes collision tie breaking independent of caller array order.
        var balls = state.balls.sorted { $0.id < $1.id }
        let cueIndex = balls.firstIndex { $0.id == 0 && !$0.pocketed }!
        let angle = shot.angleRadians.truncatingRemainder(dividingBy: 2 * .pi)
        balls[cueIndex].velocity = Vector2(x: cos(angle), y: sin(angle)) * (shot.power * state.table.maximumShotSpeed)
        balls[cueIndex].spin = initialSpin
        return try simulateValidated(table: state.table, balls: balls, recordFrames: recordFrames)
    }

    /// Estimates the remaining motion from a captured position/velocity snapshot.
    /// Time zero is the capture, not the original shot. No cue impulse is applied,
    /// and the caller's value-typed state remains unchanged. Future paths are an
    /// estimate of this model, not final positions read from the running game.
    public static func simulateContinuation(
        state: TableState, recordFrames: Bool = true
    ) throws -> ShotResult {
        try validateContinuation(state)
        return try simulateValidated(table: state.table,
                                     balls: state.balls.sorted { $0.id < $1.id },
                                     recordFrames: recordFrames)
    }

    /// Geometric cue-center ray used by the short aim guide. Shares the exact
    /// ball, finite cushion and pocket contact queries with the full simulation.
    public static func firstContactPoint(state: TableState, direction: Vector2) throws -> Vector2? {
        try validate(state)
        guard direction.isFinite, direction.length > 1e-12 else { throw BilliardsError.invalidShot }
        var balls = state.balls.sorted { $0.id < $1.id }
        let cue = balls.firstIndex { $0.id == 0 && !$0.pocketed }!
        let vector = direction.normalized()
        balls[cue].velocity = vector
        guard let contact = firstContact(balls: balls, table: state.table, pockets: state.table.pockets,
                                         boundary: makeBoundary(state.table), within: max(state.table.width, state.table.height) * 4) else { return nil }
        return balls[cue].position + vector * contact.time
    }

    /// Broad-phase planner check against the actual pocket jaws. The final
    /// candidate is still replayed with collisions, spin and pocket attraction.
    static func directPocketPathClear(from start: Vector2, pocket: PoolPocket, table: PoolTable) -> Bool {
        let direction = (pocket.aimPoint - start).normalized()
        guard direction.lengthSquared > 0 else { return false }
        let ball = PoolBall(id: 0, position: start, velocity: direction)
        guard let contact = firstContact(balls: [ball], table: table, pockets: table.pockets,
                                         boundary: makeBoundary(table), within: max(table.width, table.height) * 4) else { return false }
        if case let .pocket(_, id) = contact.kind { return id == pocket.id }
        return false
    }

    private static func simulateValidated(
        table: PoolTable, balls initialBalls: [PoolBall], recordFrames: Bool
    ) throws -> ShotResult {
        var balls = initialBalls
        for index in balls.indices where balls[index].pocketed {
            balls[index].velocity = .zero; balls[index].spin = .zero
        }
        var events: [ShotEvent] = []
        var frames: [SimulationFrame] = []
        var tracePoints = [[Vector2]](repeating: [], count: balls.count)
        if recordFrames {
            frames.reserveCapacity(512)
            for index in balls.indices where !balls[index].pocketed {
                tracePoints[index] = [balls[index].position]
            }
        }
        events.reserveCapacity(64)
        let pockets = table.pockets
        let boundary = makeBoundary(table)
        // A manually positioned ball in a pocket opening is captured immediately.
        captureInsidePockets(&balls, pockets: pockets, events: &events)
        stopSlowBalls(&balls, table: table)
        var time: Double = 0
        var nextFrame: Double = 1.0 / 30
        var steps = 0
        var wasTruncated = false
        if recordFrames { frames.append(SimulationFrame(time: 0, balls: balls)) }

        while balls.contains(where: { !$0.pocketed && isInMotion($0, table: table) }) {
            if steps % 32 == 0 { try Task.checkCancellation() }
            guard time < maximumDuration - timeTolerance, steps < maximumSteps,
                  events.count < maximumEvents else { wasTruncated = true; break }
            let fastest = balls.filter { !$0.pocketed }.map { $0.velocity.length }.max() ?? 0
            // Continuous collision detection prevents tunneling. The displacement
            // bound also limits drag integration error and dense-rack work.
            var dt = table.nativeDynamics?.logicalFrameTime
                ?? min(1.0 / 180, table.ballRadius / max(2 * fastest, 1))
            dt = min(dt, maximumDuration - time)
            // Keep step boundaries identical for prediction and replay. Recording
            // changes storage only, never drag integration or collision timing.
            if table.nativeDynamics == nil {
                dt = min(dt, max(timeTolerance, nextFrame - time))
            }
            var remaining = dt
            var contacts = 0
            while remaining > timeTolerance {
                if contacts % 16 == 0 { try Task.checkCancellation() }
                guard contacts < 64, events.count < maximumEvents else {
                    wasTruncated = true
                    break
                }
                if table.nativeGeometry != nil {
                    applyNativePockets(&balls, table: table, pockets: pockets, elapsed: remaining, events: &events)
                }
                guard let contact = firstContact(balls: balls, table: table, pockets: pockets, boundary: boundary,
                                                 includePocketEntry: table.nativeGeometry == nil, within: remaining) else {
                    advance(&balls, by: remaining)
                    remaining = 0
                    break
                }
                let elapsed = max(0, min(remaining, contact.time))
                advance(&balls, by: elapsed)
                remaining -= elapsed
                resolve(contact.kind, balls: &balls, table: table, events: &events)
                contacts += 1
            }
            let elapsed = dt - remaining
            if table.nativeDynamics != nil {
                // The native response updates cloth after all contacts in the
                // logical frame. Replay deadlines must not subdivide that step.
                for index in balls.indices where !balls[index].pocketed {
                    applyNativeCloth(to: &balls[index], table: table, elapsed: elapsed)
                }
            } else {
                applyDrag(&balls, deceleration: table.rollingDeceleration, elapsed: elapsed)
            }
            stopSlowBalls(&balls, table: table)
            guard balls.allSatisfy({ $0.position.isFinite && $0.velocity.isFinite && validSpin($0.spin) }) else {
                throw BilliardsError.invalidBalls
            }
            time += elapsed
            steps += 1
            if time + timeTolerance >= nextFrame {
                if recordFrames {
                    recordFrame(time: time, balls: balls, frames: &frames,
                                traces: &tracePoints, minimumDistance: table.ballRadius * 0.15)
                }
                nextFrame += 1.0 / 30
            }
            if wasTruncated { break }
        }
        if recordFrames {
            recordFrame(time: time, balls: balls, frames: &frames,
                        traces: &tracePoints, minimumDistance: 0)
        }
        let settled = !wasTruncated && balls.allSatisfy { $0.pocketed || !isInMotion($0, table: table) }
        return ShotResult(
            finalState: TableState(table: table, balls: balls), frames: frames,
            traces: recordFrames ? balls.indices.compactMap { index in
                tracePoints[index].isEmpty ? nil : BallTrace(id: balls[index].id, points: tracePoints[index])
            } : [], events: events, duration: time, settled: settled
        )
    }

    private enum ContactKind {
        case pocket(Int, Int)
        case ball(Int, Int)
        case cushion(Int, Int) // 0 left, 1 right, 2 top, 3 bottom
        case nativeCushion(Int, Vector2, Vector2) // ball, corrected center, inward normal
    }
    private struct Contact { let time: Double; let kind: ContactKind }
    private struct CushionSegment {
        let a: Vector2
        let b: Vector2
        let tangent: Vector2
        let normal: Vector2
        let length: Double
        init(a: Vector2, b: Vector2) {
            self.a = a; self.b = b
            length = a.distance(to: b)
            tangent = (b - a) / length
            normal = Vector2(x: -tangent.y, y: tangent.x)
        }
    }

    private static func makeBoundary(_ table: PoolTable) -> [CushionSegment]? {
        table.nativeGeometry.map { geometry in
            geometry.cushionVertices.indices.map { index in
                CushionSegment(a: geometry.cushionVertices[index],
                               b: geometry.cushionVertices[(index + 1) % geometry.cushionVertices.count])
            }
        }
    }

    private static func firstContact(
        balls: [PoolBall], table: PoolTable, pockets: [PoolPocket], boundary: [CushionSegment]?,
        includePocketEntry: Bool = true, within limit: Double
    ) -> Contact? {
        var best: Contact?
        func consider(_ time: Double?, _ kind: ContactKind) {
            guard let t = time, t >= -timeTolerance, t <= limit + timeTolerance else { return }
            let bounded = max(0, min(limit, t))
            // Keep the first exact tie: pockets take precedence over collisions,
            // then ball IDs and wall order define a reproducible result.
            if best == nil || bounded < best!.time - timeTolerance {
                best = Contact(time: bounded, kind: kind)
            }
        }
        if includePocketEntry {
            for a in balls.indices where !balls[a].pocketed && balls[a].velocity.lengthSquared > 1e-16 {
                for pocket in pockets {
                    consider(circleEntry(position: balls[a].position - pocket.center,
                                         velocity: balls[a].velocity, radius: pocket.radius,
                                         captureWhenInside: true), .pocket(a, pocket.id))
                }
            }
        }
        for a in balls.indices where !balls[a].pocketed {
            for b in balls.indices where b > a && !balls[b].pocketed {
                consider(circleEntry(position: balls[b].position - balls[a].position,
                                     velocity: balls[b].velocity - balls[a].velocity,
                                     radius: 2 * table.ballRadius,
                                     captureWhenInside: false), .ball(a, b))
            }
        }
        let r = table.ballRadius
        if let boundary {
            for a in balls.indices where !balls[a].pocketed && balls[a].velocity.lengthSquared > 1e-16 {
                let p = balls[a].position, v = balls[a].velocity
                let end = p + v * limit
                for edge in boundary {
                    // Swept AABB rejects distant edges before the capsule tests.
                    if max(p.x, end.x) < min(edge.a.x, edge.b.x) - r || min(p.x, end.x) > max(edge.a.x, edge.b.x) + r
                        || max(p.y, end.y) < min(edge.a.y, edge.b.y) - r || min(p.y, end.y) > max(edge.a.y, edge.b.y) + r { continue }
                    let signedDistance = (p - edge.a).dot(edge.normal)
                    let inward = edge.normal * (signedDistance >= 0 ? 1 : -1)
                    let approach = v.dot(inward)
                    if approach < -1e-10 {
                        let time = max(0, (r - abs(signedDistance)) / approach)
                        if time <= limit + timeTolerance {
                            let point = p + v * time
                            let along = (point - edge.a).dot(edge.tangent)
                            if along >= 0 && along <= edge.length {
                                let center = edge.a + edge.tangent * along + inward * r
                                consider(time, .nativeCushion(a, center, inward))
                            }
                        }
                    }
                    // Every polygon vertex is handled once, including the jaws.
                    if let time = circleEntry(position: p - edge.a, velocity: v, radius: r, captureWhenInside: false),
                       time <= limit + timeTolerance {
                        let delta = p + v * max(0, time) - edge.a
                        let inward = delta.normalized()
                        if inward.lengthSquared > 0, v.dot(inward) < -1e-10 {
                            consider(time, .nativeCushion(a, edge.a + inward * r, inward))
                        }
                    }
                }
            }
            return best
        }
        for a in balls.indices where !balls[a].pocketed {
            let p = balls[a].position, v = balls[a].velocity
            if v.x < -1e-10 { consider(max(0, (r - p.x) / v.x), .cushion(a, 0)) }
            if v.x > 1e-10 { consider(max(0, (table.width - r - p.x) / v.x), .cushion(a, 1)) }
            if v.y < -1e-10 { consider(max(0, (r - p.y) / v.y), .cushion(a, 2)) }
            if v.y > 1e-10 { consider(max(0, (table.height - r - p.y) / v.y), .cushion(a, 3)) }
        }
        return best
    }

    /// First entry of a moving point into a circle. Using the stable quadratic
    /// root avoids subtracting nearly equal values for near-touching balls.
    private static func circleEntry(
        position: Vector2, velocity: Vector2, radius: Double, captureWhenInside: Bool
    ) -> Double? {
        let separation = position.lengthSquared - radius * radius
        let approach = position.dot(velocity)
        if separation <= 1e-8 {
            return captureWhenInside || approach < -1e-9 ? 0 : nil
        }
        let speedSquared = velocity.lengthSquared
        guard speedSquared > 1e-16, approach < 0 else { return nil }
        let discriminant = approach * approach - speedSquared * separation
        guard discriminant >= 0 else { return nil }
        let denominator = -approach + sqrt(discriminant)
        guard denominator > 0 else { return nil }
        return separation / denominator
    }

    private static func resolve(
        _ kind: ContactKind, balls: inout [PoolBall], table: PoolTable, events: inout [ShotEvent]
    ) {
        switch kind {
        case let .pocket(index, pocket):
            balls[index].pocketed = true
            balls[index].velocity = .zero
            balls[index].spin = .zero
            events.append(.pocket(ball: balls[index].id, pocket: pocket))
        case let .cushion(index, wall):
            let e = table.cushionRestitution, r = table.ballRadius
            let normal: Vector2
            switch wall {
            case 0: balls[index].position.x = r; normal = Vector2(x: 1, y: 0)
            case 1: balls[index].position.x = table.width - r; normal = Vector2(x: -1, y: 0)
            case 2: balls[index].position.y = r; normal = Vector2(x: 0, y: 1)
            default: balls[index].position.y = table.height - r; normal = Vector2(x: 0, y: -1)
            }
            if table.nativeDynamics != nil {
                // Native edge/point collision angles face the obstacle: an
                // approaching ball has positive velocity along this normal.
                applyNativeCushion(to: &balls[index], table: table, outwardNormal: normal * -1)
            } else {
                if normal.x != 0 { balls[index].velocity.x = normal.x * abs(balls[index].velocity.x) * e }
                else { balls[index].velocity.y = normal.y * abs(balls[index].velocity.y) * e }
            }
            events.append(.cushion(ball: balls[index].id))
        case let .nativeCushion(index, center, inward):
            balls[index].position = center
            if table.nativeDynamics != nil {
                applyNativeCushion(to: &balls[index], table: table, outwardNormal: nativeQuantizedNormal(inward * -1))
            } else {
                let normalSpeed = balls[index].velocity.dot(inward)
                balls[index].velocity = balls[index].velocity - inward * ((1 + table.cushionRestitution) * normalSpeed)
            }
            events.append(.cushion(ball: balls[index].id))
        case let .ball(a, b):
            let delta = balls[b].position - balls[a].position
            let distance = delta.length
            let normal = distance > 1e-12 ? delta / distance : Vector2(x: 1, y: 0)
            let penetration = 2 * table.ballRadius - distance
            if penetration > 0 {
                let correction = normal * (penetration / 2)
                balls[a].position = balls[a].position - correction
                balls[b].position = balls[b].position + correction
            }
            let relativeNormal = (balls[b].velocity - balls[a].velocity).dot(normal)
            if relativeNormal < 0 {
                let impulse = normal * (-(1 + table.ballRestitution) * relativeNormal / 2)
                balls[a].velocity = balls[a].velocity - impulse
                balls[b].velocity = balls[b].velocity + impulse
                events.append(.ballCollision(first: balls[a].id, second: balls[b].id))
            }
        }
    }

    private static func advance(_ balls: inout [PoolBall], by time: Double) {
        for index in balls.indices where !balls[index].pocketed {
            balls[index].position = balls[index].position + balls[index].velocity * time
        }
    }

    private static func validSpin(_ spin: BallSpin) -> Bool {
        spin.isFinite && abs(spin.x) <= maximumAngularSpeed
            && abs(spin.y) <= maximumAngularSpeed && abs(spin.z) <= maximumAngularSpeed
    }

    private static func isInMotion(_ ball: PoolBall, table: PoolTable) -> Bool {
        ball.velocity != .zero || (table.nativeDynamics != nil && ball.spin != .zero)
    }

    /// Reconstructed local cloth response; inputs are copied values, never game
    /// objects. Kept internal so numerical invariants can be tested directly.
    static func applyNativeCloth(to ball: inout PoolBall, table: PoolTable, elapsed: Double) {
        guard let native = table.nativeDynamics, elapsed > 0 else { return }
        let radius = table.ballRadius
        let slip = Vector2(x: -ball.velocity.x - radius * ball.spin.y,
                           y: radius * ball.spin.x - ball.velocity.y)
        let slipSpeed = slip.length
        let equilibriumTime = native.equilibriumTimeFactor * slipSpeed
        if equilibriumTime > 1e-11, slipSpeed > 0 {
            let delta = slip * (native.slidingDeceleration * min(equilibriumTime, elapsed) / slipSpeed)
            ball.velocity = ball.velocity + delta
            ball.spin.x -= 2.5 * delta.y / radius
            ball.spin.y += 2.5 * delta.x / radius
        }
        if equilibriumTime < elapsed {
            let speed = ball.velocity.length
            if speed > 0 {
                ball.velocity = ball.velocity * max(0, 1 - table.rollingDeceleration * (elapsed - equilibriumTime) / speed)
            }
            ball.spin.x = ball.velocity.y / radius
            ball.spin.y = -ball.velocity.x / radius
        }
        let decay = native.spinDeceleration * elapsed
        if ball.spin.z > 0 { ball.spin.z = max(0, ball.spin.z - decay) }
        else { ball.spin.z = min(0, ball.spin.z + decay) }
    }

    /// Recovered native normal/tangential response. Native polygon contacts round
    /// the geometric basis before this call, including contact with pocket jaws.
    static func applyNativeCushion(to ball: inout PoolBall, table: PoolTable, outwardNormal n: Vector2) {
        guard let native = table.nativeDynamics else { return }
        let tangent = Vector2(x: n.y, y: -n.x)
        let normalSpeed = ball.velocity.dot(n)
        let tangentSpeed = ball.velocity.dot(tangent)
        let spinXY = Vector2(x: ball.spin.x, y: ball.spin.y)
        let normalSpin = spinXY.dot(n)
        let tangentSpin = spinXY.dot(tangent)
        let radius = table.ballRadius
        let slip = tangentSpeed - radius * ball.spin.z
        let magnitude = min(abs(slip) / 2.5,
                            2 * native.slidingFrictionCoefficient * abs(normalSpeed))
        let impulse = slip > 0 ? -magnitude : magnitude
        ball.velocity = tangent * (tangentSpeed + impulse / 2.5)
            + n * (-table.cushionRestitution * normalSpeed)
        let nextSpin = tangent * (tangentSpin - native.cushionSpinCoupling * normalSpeed / radius)
            + n * normalSpin
        ball.spin.x = nextSpin.x
        ball.spin.y = nextSpin.y
        ball.spin.z -= 2.5 * impulse / radius
    }

    /// The supported binary rounds the geometric angle and then the sine/cosine
    /// basis to four decimals (0x1002fcafc, 0x1002fc858..878). The resulting basis
    /// is intentionally not normalized a second time. Convert through native Y
    /// handedness so point-jaw rebounds use the same rounding as straight rails.
    private static func nativeQuantizedNormal(_ outward: Vector2) -> Vector2 {
        let edge = Vector2(x: -outward.y, y: -outward.x)
        let nativeAngle: Double
        if edge.x != 0 {
            nativeAngle = (atan(edge.y / edge.x) * 10_000).rounded() / 10_000 + (edge.x < 0 ? .pi : 0)
        } else { nativeAngle = edge.y >= 0 ? .pi / 2 : -.pi / 2 }
        let angle = -nativeAngle
        return Vector2(x: (sin(angle) * 10_000).rounded() / 10_000,
                       y: -(cos(angle) * 10_000).rounded() / 10_000)
    }

    private static func applyDrag(_ balls: inout [PoolBall], deceleration: Double, elapsed: Double) {
        guard deceleration > 0, elapsed > 0 else { return }
        for index in balls.indices where !balls[index].pocketed {
            let speed = balls[index].velocity.length
            if speed > 0 {
                balls[index].velocity = balls[index].velocity * (max(0, speed - deceleration * elapsed) / speed)
            }
        }
    }

    private static func stopSlowBalls(_ balls: inout [PoolBall], table: PoolTable) {
        // Native cloth clamps rolling speed to zero itself. Cutting translation
        // early while leaving angular velocity would create artificial motion.
        guard table.nativeDynamics == nil else { return }
        for index in balls.indices where balls[index].velocity.length < stopSpeed {
            balls[index].velocity = .zero
        }
    }

    private static func captureInsidePockets(
        _ balls: inout [PoolBall], pockets: [PoolPocket], events: inout [ShotEvent]
    ) {
        for index in balls.indices where !balls[index].pocketed {
            if let pocket = pockets.first(where: { balls[index].position.distance(to: $0.center) <= $0.radius }) {
                balls[index].pocketed = true
                balls[index].velocity = .zero
                balls[index].spin = .zero
                events.append(.pocket(ball: balls[index].id, pocket: pocket.id))
            }
        }
    }

    /// Native pocket logic runs before collision search/movement, with cloth
    /// response applied after the remaining logical frame has been consumed.
    /// Attraction and capture use distinct radii. Capture is checked at a
    /// logical step, not where the trajectory first touches the attraction ring.
    private static func applyNativePockets(
        _ balls: inout [PoolBall], table: PoolTable, pockets: [PoolPocket], elapsed: Double,
        events: inout [ShotEvent]
    ) {
        guard let geometry = table.nativeGeometry else { return }
        for index in balls.indices where !balls[index].pocketed {
            for pocket in pockets {
                let delta = pocket.center - balls[index].position
                let distanceSquared = delta.lengthSquared
                if distanceSquared < pocket.attractionRadius * pocket.attractionRadius {
                    balls[index].velocity = balls[index].velocity + delta * (elapsed * geometry.pocketAttraction)
                    if distanceSquared < pocket.radius * pocket.radius {
                        balls[index].pocketed = true
                        balls[index].velocity = .zero
                        balls[index].spin = .zero
                        events.append(.pocket(ball: balls[index].id, pocket: pocket.id))
                    }
                    break
                }
            }
        }
    }

    private static func recordFrame(
        time: Double, balls: [PoolBall], frames: inout [SimulationFrame],
        traces: inout [[Vector2]], minimumDistance: Double
    ) {
        let frame = SimulationFrame(time: time, balls: balls)
        if let last = frames.last, abs(last.time - time) < timeTolerance {
            frames[frames.count - 1] = frame
        } else if frames.count < maximumFrames {
            frames.append(frame)
        } else {
            frames[frames.count - 1] = frame
        }
        for index in balls.indices where !traces[index].isEmpty {
            if traces[index].last! != balls[index].position,
               traces[index].last!.distance(to: balls[index].position) >= minimumDistance {
                if traces[index].count < maximumFrames { traces[index].append(balls[index].position) }
                else { traces[index][traces[index].count - 1] = balls[index].position }
            }
        }
    }
}
