import Foundation

struct KeyAuthHTTPResponse: Sendable {
    let statusCode: Int
    let headers: [String: String]
    let body: Data
}

protocol KeyAuthTransport: Sendable {
    func send(_ request: URLRequest, maximumResponseBytes: Int) async throws -> KeyAuthHTTPResponse
}

/// One ephemeral session per request. System TLS validation is left intact.
struct KeyAuthURLSessionTransport: KeyAuthTransport {
    func send(_ request: URLRequest, maximumResponseBytes: Int) async throws -> KeyAuthHTTPResponse {
        let operation = BoundedRequest(request: request, maximumBytes: maximumResponseBytes)
        return try await withTaskCancellationHandler(operation: {
            try Task.checkCancellation()
            return try await withCheckedThrowingContinuation { continuation in
                operation.start(continuation)
            }
        }, onCancel: {
            operation.cancel()
        })
    }
}

/// Delegate callbacks and cancellation can arrive on different queues; all mutable
/// fields are protected by lock. A cancellation before start is also remembered.
private final class BoundedRequest: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let lock = NSLock()
    private let request: URLRequest
    private let maximumBytes: Int
    private var continuation: CheckedContinuation<KeyAuthHTTPResponse, Error>?
    private var result: Result<KeyAuthHTTPResponse, Error>?
    private var session: URLSession?
    private var task: URLSessionDataTask?
    private var response: HTTPURLResponse?
    private var body = Data()

    init(request: URLRequest, maximumBytes: Int) {
        self.request = request
        self.maximumBytes = maximumBytes
        super.init()
    }

    func start(_ continuation: CheckedContinuation<KeyAuthHTTPResponse, Error>) {
        lock.lock()
        if let result {
            lock.unlock()
            continuation.resume(with: result)
            return
        }
        self.continuation = continuation
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 25
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCredentialStorage = nil
        let session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        let task = session.dataTask(with: request)
        self.session = session
        self.task = task
        lock.unlock()
        task.resume()
    }

    func cancel() { finish(.failure(CancellationError())) }

    private func finish(_ result: Result<KeyAuthHTTPResponse, Error>) {
        lock.lock()
        guard self.result == nil else { lock.unlock(); return }
        self.result = result
        let continuation = self.continuation
        let session = self.session
        self.continuation = nil
        self.session = nil
        self.task = nil
        lock.unlock()
        session?.invalidateAndCancel()
        continuation?.resume(with: result)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        // No redirection, including same-host redirection: form credentials stay
        // at the one configured HTTPS endpoint.
        completionHandler(nil)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
                    didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let http = response as? HTTPURLResponse,
              http.url?.scheme?.lowercased() == "https",
              http.url?.host?.lowercased() == request.url?.host?.lowercased() else {
            completionHandler(.cancel)
            finish(.failure(KeyAuthError.invalidResponse))
            return
        }
        guard response.expectedContentLength <= Int64(maximumBytes) else {
            completionHandler(.cancel)
            finish(.failure(KeyAuthError.responseTooLarge))
            return
        }
        lock.lock()
        let active = result == nil
        if active { self.response = http }
        lock.unlock()
        completionHandler(active ? .allow : .cancel)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        lock.lock()
        guard result == nil else { lock.unlock(); return }
        let oversized = data.count > maximumBytes - body.count
        if !oversized { body.append(data) }
        lock.unlock()
        if oversized { finish(.failure(KeyAuthError.responseTooLarge)) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error { finish(.failure(error)); return }
        lock.lock()
        let response = self.response
        let body = self.body
        lock.unlock()
        guard let response else { finish(.failure(KeyAuthError.invalidResponse)); return }
        var headers: [String: String] = [:]
        for (key, value) in response.allHeaderFields {
            guard let key = key as? String else { continue }
            headers[key.lowercased()] = String(describing: value)
        }
        finish(.success(KeyAuthHTTPResponse(statusCode: response.statusCode, headers: headers, body: body)))
    }
}
