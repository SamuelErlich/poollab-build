import Foundation

public extension Vector2 {
    static let zero = Vector2(x: 0, y: 0)
    static func + (lhs: Vector2, rhs: Vector2) -> Vector2 { Vector2(x: lhs.x + rhs.x, y: lhs.y + rhs.y) }
    static func - (lhs: Vector2, rhs: Vector2) -> Vector2 { Vector2(x: lhs.x - rhs.x, y: lhs.y - rhs.y) }
    static func * (lhs: Vector2, rhs: Double) -> Vector2 { Vector2(x: lhs.x * rhs, y: lhs.y * rhs) }
    static func / (lhs: Vector2, rhs: Double) -> Vector2 { Vector2(x: lhs.x / rhs, y: lhs.y / rhs) }
    var lengthSquared: Double { x * x + y * y }
    var length: Double { lengthSquared.squareRoot() }
    var isFinite: Bool { x.isFinite && y.isFinite }
    func dot(_ other: Vector2) -> Double { x * other.x + y * other.y }
    func distance(to other: Vector2) -> Double { (self - other).length }
    func normalized() -> Vector2 { length > 1e-12 ? self / length : .zero }
}

/// Angular velocity in radians/second, using the same handedness as the table.
public struct BallSpin: Codable, Equatable, Sendable {
    public var x: Double
    public var y: Double
    public var z: Double
    public init(x: Double, y: Double, z: Double) { self.x = x; self.y = y; self.z = z }
    public static let zero = BallSpin(x: 0, y: 0, z: 0)
    public var isFinite: Bool { x.isFinite && y.isFinite && z.isFinite }
}

/// Opt-in response coefficients recovered from the supported native build.
/// This does not imply equivalence of pocket geometry or collision ordering.
public struct NativeDynamics: Codable, Equatable, Sendable {
    public var slidingDeceleration: Double
    public var equilibriumTimeFactor: Double
    public var spinDeceleration: Double
    public var slidingFrictionCoefficient: Double
    public var cushionSpinCoupling: Double
    public var logicalFrameTime: Double
    public init(slidingDeceleration: Double, equilibriumTimeFactor: Double,
                spinDeceleration: Double, slidingFrictionCoefficient: Double,
                cushionSpinCoupling: Double, logicalFrameTime: Double) {
        self.slidingDeceleration = slidingDeceleration
        self.equilibriumTimeFactor = equilibriumTimeFactor
        self.spinDeceleration = spinDeceleration
        self.slidingFrictionCoefficient = slidingFrictionCoefficient
        self.cushionSpinCoupling = cushionSpinCoupling
        self.logicalFrameTime = logicalFrameTime
    }
}

public struct PoolBall: Identifiable, Codable, Equatable, Sendable {
    public var id: Int
    public var position: Vector2
    public var velocity: Vector2
    public var pocketed: Bool
    public var spin: BallSpin
    public init(id: Int, position: Vector2, velocity: Vector2 = .zero, pocketed: Bool = false,
                spin: BallSpin = .zero) {
        self.id = id; self.position = position; self.velocity = velocity; self.pocketed = pocketed; self.spin = spin
    }
    private enum CodingKeys: String, CodingKey { case id, position, velocity, pocketed, spin }
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(Int.self, forKey: .id)
        position = try values.decode(Vector2.self, forKey: .position)
        velocity = try values.decode(Vector2.self, forKey: .velocity)
        pocketed = try values.decode(Bool.self, forKey: .pocketed)
        spin = try values.decodeIfPresent(BallSpin.self, forKey: .spin) ?? .zero
    }
}

public struct PoolPocket: Identifiable, Equatable, Sendable {
    public let id: Int
    public let center: Vector2
    public let name: String
}

/// The default is an independent practice model. Native response coefficients
/// are used only when the caller supplies a complete `nativeDynamics` profile.
public struct PoolTable: Codable, Equatable, Sendable {
    public var width: Double = 200
    public var height: Double = 100
    public var ballRadius: Double = 2.85
    public var pocketRadius: Double = 6.2
    public var ballRestitution: Double = 0.96
    public var cushionRestitution: Double = 0.82
    public var rollingDeceleration: Double = 12
    public var maximumShotSpeed: Double = 180
    public var nativeDynamics: NativeDynamics?
    public init() {}
    public var pockets: [PoolPocket] {
        [PoolPocket(id: 0, center: Vector2(x: 0, y: 0), name: "Superior esquerda"),
         PoolPocket(id: 1, center: Vector2(x: width / 2, y: 0), name: "Superior central"),
         PoolPocket(id: 2, center: Vector2(x: width, y: 0), name: "Superior direita"),
         PoolPocket(id: 3, center: Vector2(x: 0, y: height), name: "Inferior esquerda"),
         PoolPocket(id: 4, center: Vector2(x: width / 2, y: height), name: "Inferior central"),
         PoolPocket(id: 5, center: Vector2(x: width, y: height), name: "Inferior direita")]
    }
}

public struct TableState: Codable, Equatable, Sendable {
    public var table: PoolTable
    public var balls: [PoolBall]
    public init(table: PoolTable = PoolTable(), balls: [PoolBall]) { self.table = table; self.balls = balls }
    public var cueBall: PoolBall? { balls.first { $0.id == 0 && !$0.pocketed } }
    public static var practice: TableState {
        TableState(balls: [PoolBall(id: 0, position: Vector2(x: 45, y: 65)),
                           PoolBall(id: 1, position: Vector2(x: 110, y: 45)),
                           PoolBall(id: 2, position: Vector2(x: 150, y: 70)),
                           PoolBall(id: 3, position: Vector2(x: 65, y: 25)),
                           PoolBall(id: 8, position: Vector2(x: 150, y: 30))])
    }
    public static var straightShot: TableState {
        TableState(balls: [PoolBall(id: 0, position: Vector2(x: 100, y: 70)),
                           PoolBall(id: 1, position: Vector2(x: 100, y: 35))])
    }
    public static var fullRack: TableState {
        let table = PoolTable()
        let gap = table.ballRadius * 2 + 0.05
        let ids = [1, 9, 2, 10, 8, 3, 4, 11, 5, 12, 6, 13, 7, 14, 15]
        var balls = [PoolBall(id: 0, position: Vector2(x: 45, y: 50))]
        var index = 0
        for row in 0..<5 {
            for column in 0...row {
                balls.append(PoolBall(id: ids[index], position: Vector2(
                    x: 135 + Double(row) * gap * sqrt(3) / 2,
                    y: 50 + (Double(column) - Double(row) / 2) * gap)))
                index += 1
            }
        }
        return TableState(table: table, balls: balls)
    }
}

public struct ShotParameters: Codable, Equatable, Sendable {
    public var angleRadians: Double
    public var power: Double
    public var initialSpin: BallSpin?
    public init(angleRadians: Double, power: Double, initialSpin: BallSpin? = nil) {
        self.angleRadians = angleRadians; self.power = power; self.initialSpin = initialSpin
    }
}

public struct SimulationFrame: Sendable {
    public let time: Double
    public let balls: [PoolBall]
}

public struct BallTrace: Identifiable, Sendable {
    public let id: Int
    public let points: [Vector2]
}

public enum ShotEvent: Equatable, Sendable {
    case ballCollision(first: Int, second: Int)
    case cushion(ball: Int)
    case pocket(ball: Int, pocket: Int)
}

public struct ShotResult: Sendable {
    public let finalState: TableState
    public let frames: [SimulationFrame]
    public let traces: [BallTrace]
    public let events: [ShotEvent]
    public let duration: Double
    public let settled: Bool
    public var scratched: Bool { finalState.balls.contains { $0.id == 0 && $0.pocketed } }
    public var pocketedIDs: [Int] {
        events.compactMap { if case let .pocket(ball, _) = $0 { return ball }; return nil }
    }
}

public enum BilliardsError: Error, LocalizedError, Equatable {
    case invalidTable, invalidBalls, overlappingBalls, missingCueBall, movingBalls, invalidShot
    public var errorDescription: String? {
        switch self {
        case .invalidTable: return "Confira as dimensões e os parâmetros da mesa."
        case .invalidBalls: return "A mesa aceita até 16 bolas com números únicos de 0 a 15 e posições válidas."
        case .overlappingBalls: return "Separe as bolas que estão sobrepostas."
        case .missingCueBall: return "Reposicione a bola branca para continuar."
        case .movingBalls: return "Espere as bolas pararem antes da próxima tacada."
        case .invalidShot: return "Confira o ângulo e a força da tacada."
        }
    }
}

public enum ShotMethod: String, Codable, Sendable { case direct, bank, breakShot }

public struct ShotSuggestion: Identifiable, Sendable {
    public var id: String { "\(targetID)-\(pocketID)-\(method.rawValue)-\(shot.angleRadians)-\(shot.power)" }
    public let targetID: Int
    public let pocketID: Int
    public let method: ShotMethod
    public let shot: ShotParameters
    public let ghostBall: Vector2
    public let aimPoint: Vector2
    public let score: Double
    public let result: ShotResult
}
