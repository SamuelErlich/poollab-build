import Foundation

public actor KeyAuthClient: Licensing {
    private static let endpoint = URL(string: "https://keyauth.win/api/1.3/")!
    private static let maximumResponseBytes = 256 * 1024

    private let configuration: KeyAuthConfiguration
    private let transport: any KeyAuthTransport
    private let now: @Sendable () -> Date
    private let verifier: KeyAuthResponseVerifier
    private var remoteSessionID: String?
    private var authenticatedSession: LicenseSession?
    private var generation: UInt64 = 0
    private var inFlight: Task<KeyAuthHTTPResponse, Error>?

    // Actor isolation alone does not serialize an operation across await points.
    private var slotTaken = false
    private var waiters: [(UUID, CheckedContinuation<Void, Error>)] = []

    public init(configuration: KeyAuthConfiguration) {
        self.configuration = configuration
        self.transport = KeyAuthURLSessionTransport()
        self.now = { Date() }
        self.verifier = KeyAuthResponseVerifier(
            publicKeyBytes: KeyAuthResponseVerifier.decodeHex(KeyAuthResponseVerifier.officialPublicKeyHex)!,
            now: { Date() }
        )
    }

    /// Internal seam for unit tests; production consumers cannot replace trust
    /// anchors, network transport, or the clock through the public API.
    init(configuration: KeyAuthConfiguration, transport: any KeyAuthTransport,
         now: @escaping @Sendable () -> Date, signaturePublicKey: Data) {
        self.configuration = configuration
        self.transport = transport
        self.now = now
        self.verifier = KeyAuthResponseVerifier(publicKeyBytes: signaturePublicKey, now: now)
    }

    public func authenticate(key: String, deviceID: String,
                             twoFactorCode: String? = nil) async throws -> LicenseSession {
        let epoch = generation
        try await acquireSlot()
        defer { releaseSlot() }
        try ensureCurrent(epoch)
        try validateConfiguration()
        let key = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, key.utf8.count <= 4096,
              !deviceID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              deviceID.utf8.count <= 256,
              (twoFactorCode?.utf8.count ?? 0) <= 64 else { throw KeyAuthError.invalidInput }

        // A previous login is never retained if a replacement login fails.
        remoteSessionID = nil
        authenticatedSession = nil
        do {
            let initialized = try await request(fields: [
                "type": "init", "ver": configuration.version
            ], epoch: epoch)
            guard let sessionID = initialized.sessionid,
                  !sessionID.isEmpty, sessionID.utf8.count <= 4096 else {
                throw KeyAuthError.invalidResponse
            }
            remoteSessionID = sessionID
            var fields = ["type": "license", "key": key,
                          "hwid": deviceID, "sessionid": sessionID]
            if let code = twoFactorCode, !code.isEmpty { fields["code"] = code }
            let licensed = try await request(fields: fields, epoch: epoch)
            guard let info = licensed.info else { throw KeyAuthError.invalidResponse }
            let session = try validatedSession(info: info, fallback: nil)
            try ensureCurrent(epoch)
            authenticatedSession = session
            return session
        } catch {
            if epoch == generation {
                remoteSessionID = nil
                authenticatedSession = nil
            }
            throw error
        }
    }

    @discardableResult
    public func checkSession() async throws -> LicenseSession {
        let epoch = generation
        try await acquireSlot()
        defer { releaseSlot() }
        try ensureCurrent(epoch)
        guard let existing = authenticatedSession, let sessionID = remoteSessionID else {
            throw KeyAuthError.authenticationRequired
        }
        do {
            guard existing.expiresAt > now() else { throw KeyAuthError.noActiveSubscription }
            let checked = try await request(fields: ["type": "check", "sessionid": sessionID], epoch: epoch)
            // Some check responses only contain success/message. They cannot
            // create a license or extend its expiry; retain the prior entitlement.
            let updated = try checked.info.map { try validatedSession(info: $0, fallback: existing) } ?? existing
            try ensureCurrent(epoch)
            guard updated.expiresAt > now() else { throw KeyAuthError.noActiveSubscription }
            authenticatedSession = updated
            return updated
        } catch {
            // Fail closed on expired, unsigned, rejected, interrupted or offline
            // checks. The UI must also revoke its access on a thrown check.
            if epoch == generation {
                authenticatedSession = nil
                remoteSessionID = nil
            }
            throw error
        }
    }

    public func logout() async {
        // Revoke locally before the first await. In-flight and queued operations
        // from the previous generation cannot publish a late successful login.
        generation &+= 1
        let epoch = generation
        let sessionID = remoteSessionID
        remoteSessionID = nil
        authenticatedSession = nil
        inFlight?.cancel()
        do { try await acquireSlot() } catch { return }
        defer { releaseSlot() }
        guard generation == epoch, let sessionID else { return }
        _ = try? await request(fields: ["type": "logout", "sessionid": sessionID], epoch: epoch)
    }

    private func request(fields: [String: String], epoch: UInt64) async throws -> ServiceReply {
        try ensureCurrent(epoch)
        var fields = fields
        fields["name"] = configuration.appName
        fields["ownerid"] = configuration.ownerID
        var request = URLRequest(url: Self.endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = Self.formBody(fields)
        let transport = self.transport
        let outboundRequest = request
        let task = Task { try await transport.send(outboundRequest, maximumResponseBytes: Self.maximumResponseBytes) }
        inFlight = task
        defer { inFlight = nil }
        let response = try await withTaskCancellationHandler(operation: {
            try await task.value
        }, onCancel: { task.cancel() })
        try ensureCurrent(epoch)
        guard response.body.count <= Self.maximumResponseBytes else { throw KeyAuthError.responseTooLarge }
        // Keep raw bytes unchanged until the signature has been verified.
        try verifier.verify(response)
        guard (200..<300).contains(response.statusCode) else {
            throw KeyAuthError.unexpectedHTTPStatus(response.statusCode)
        }
        let reply: ServiceReply
        do { reply = try JSONDecoder().decode(ServiceReply.self, from: response.body) }
        catch { throw KeyAuthError.invalidResponse }
        guard reply.success else {
            throw KeyAuthError.serviceRejected(message: String((reply.message ?? "Licença ou sessão recusada.").prefix(512)))
        }
        return reply
    }

    private func validatedSession(info: ServiceInfo, fallback: LicenseSession?) throws -> LicenseSession {
        guard let username = info.username ?? fallback?.username, !username.isEmpty,
              let subscriptions = info.subscriptions?.map({
                  LicenseSubscription(name: $0.subscription, expiresAt: $0.expiry.date)
              }) ?? fallback?.subscriptions else { throw KeyAuthError.invalidResponse }
        let required = configuration.requiredSubscription
        let valid = subscriptions.filter {
            !$0.name.isEmpty && $0.expiresAt > now() && (required == nil || $0.name == required)
        }
        guard let expiresAt = valid.map(\.expiresAt).max() else { throw KeyAuthError.noActiveSubscription }
        return LicenseSession(username: username, subscriptions: subscriptions, expiresAt: expiresAt)
    }

    private func validateConfiguration() throws {
        let values = [configuration.appName, configuration.ownerID, configuration.version]
        guard values.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.utf8.count <= 256 }),
              configuration.requiredSubscription.map({ !$0.isEmpty && $0.utf8.count <= 256 }) ?? true else {
            throw KeyAuthError.invalidConfiguration
        }
    }

    private func ensureCurrent(_ epoch: UInt64) throws {
        try Task.checkCancellation()
        guard epoch == generation else { throw KeyAuthError.sessionEnded }
    }

    private func acquireSlot() async throws {
        try Task.checkCancellation()
        if !slotTaken { slotTaken = true; return }
        let id = UUID()
        try await withTaskCancellationHandler(operation: {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                waiters.append((id, continuation))
            }
        }, onCancel: {
            Task { await self.cancelWaiter(id) }
        })
        // The waiter may have been granted the slot just before cancellation.
        if Task.isCancelled { releaseSlot(); throw CancellationError() }
    }

    private func cancelWaiter(_ id: UUID) {
        guard let index = waiters.firstIndex(where: { $0.0 == id }) else { return }
        waiters.remove(at: index).1.resume(throwing: CancellationError())
    }

    private func releaseSlot() {
        if waiters.isEmpty { slotTaken = false }
        else {
            let (_, continuation) = waiters.removeFirst()
            continuation.resume()
        }
    }

    static func formBody(_ fields: [String: String]) -> Data {
        let allowed = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")
        let text = fields.keys.sorted().map { key in
            let encodedKey = key.addingPercentEncoding(withAllowedCharacters: allowed)!
            let encodedValue = fields[key]!.addingPercentEncoding(withAllowedCharacters: allowed)!
            return "\(encodedKey)=\(encodedValue)"
        }.joined(separator: "&")
        return Data(text.utf8)
    }
}

private struct ServiceReply: Decodable {
    let success: Bool
    let message: String?
    let sessionid: String?
    let info: ServiceInfo?
}

private struct ServiceInfo: Decodable {
    let username: String?
    let subscriptions: [ServiceSubscription]?
}

private struct ServiceSubscription: Decodable {
    let subscription: String
    let expiry: EpochSeconds
}

private struct EpochSeconds: Decodable {
    let date: Date

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let seconds: Double?
        if let string = try? container.decode(String.self) { seconds = Double(string) }
        else { seconds = try? container.decode(Double.self) }
        guard let seconds, seconds.isFinite, seconds >= 0, seconds < 1_000_000_000_000 else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid Unix timestamp")
        }
        date = Date(timeIntervalSince1970: seconds)
    }
}
