import Foundation

public struct KeyAuthConfiguration: Sendable {
    public let appName: String
    public let ownerID: String
    public let version: String
    public let requiredSubscription: String?

    public init(appName: String, ownerID: String, version: String,
                requiredSubscription: String? = nil) {
        self.appName = appName
        self.ownerID = ownerID
        self.version = version
        self.requiredSubscription = requiredSubscription
    }
}

public struct LicenseSubscription: Sendable, Equatable {
    public let name: String
    public let expiresAt: Date

    public init(name: String, expiresAt: Date) {
        self.name = name
        self.expiresAt = expiresAt
    }
}

public struct LicenseSession: Sendable, Equatable {
    public let username: String
    public let subscriptions: [LicenseSubscription]
    /// End of the configured entitlement, not the lifetime of an init session.
    public let expiresAt: Date

    public init(username: String, subscriptions: [LicenseSubscription], expiresAt: Date) {
        self.username = username
        self.subscriptions = subscriptions
        self.expiresAt = expiresAt
    }
}

public protocol Licensing: Sendable {
    func authenticate(key: String, deviceID: String, twoFactorCode: String?) async throws -> LicenseSession
    @discardableResult func checkSession() async throws -> LicenseSession
    func logout() async
}

public enum KeyAuthError: Error, Sendable, Equatable, LocalizedError {
    case invalidConfiguration
    case invalidInput
    case invalidResponse
    case responseTooLarge
    case unexpectedHTTPStatus(Int)
    case invalidSignature
    case staleResponse
    case serviceRejected(message: String)
    case noActiveSubscription
    case authenticationRequired
    case sessionEnded

    public var errorDescription: String? {
        switch self {
        case .invalidConfiguration: return "Preencha os dados do seu aplicativo KeyAuth."
        case .invalidInput: return "Confira a licença, o identificador do aparelho e o código informado."
        case .invalidResponse: return "O serviço enviou uma resposta inválida."
        case .responseTooLarge: return "A resposta excedeu o tamanho permitido."
        case .unexpectedHTTPStatus(let status): return "O serviço respondeu com HTTP \(status)."
        case .invalidSignature: return "Não foi possível verificar a autenticidade da resposta."
        case .staleResponse: return "A resposta expirou ou o relógio do aparelho está incorreto."
        case .serviceRejected(let message): return message.isEmpty ? "O serviço recusou a solicitação." : message
        case .noActiveSubscription: return "A licença não possui a assinatura exigida vigente."
        case .authenticationRequired: return "Entre com uma licença válida para continuar."
        case .sessionEnded: return "A sessão foi encerrada. Entre novamente."
        }
    }
}
