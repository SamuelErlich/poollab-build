import Foundation

/// A point or vector in the table's coordinate system, measured in arbitrary units.
public struct Vector2: Codable, Equatable, Sendable {
    public var x: Double
    public var y: Double

    public init(x: Double, y: Double) {
        self.x = x
        self.y = y
    }
}

/// Outer cushion bounds. A standard practice table uses width 200 and height 100.
public struct TableBounds: Equatable, Sendable {
    public var width: Double
    public var height: Double

    public init(width: Double, height: Double) {
        self.width = width
        self.height = height
    }
}

public enum PracticeGeometryError: Error, Equatable, Sendable {
    case nonFiniteInput
    case invalidTable
    case invalidBallRadius
    case originOutsideTable
    case invalidBounceLimit
    case invalidDistanceLimit
}

/// Independent ray geometry for an isolated practice table.
///
/// This is a geometric centerline, not a full billiards simulation. It has no
/// ball-to-ball collisions, pockets, spin, friction, speed, or game integration.
public enum PracticeGeometry {
    /// Bounds work performed even if a caller supplies an unreasonable budget.
    public static let maximumBounceLimit = 1_000

    /// Traces a ball's center inside the rectangle inset by `ballRadius`.
    ///
    /// - Coordinates: x grows rightward and y grows downward; angle zero points
    ///   right and positive angles turn clockwise when drawn on a screen.
    /// - Distance: the sum of the segment lengths, in table units.
    /// - Bounces: the number of allowed reflections. With zero reflections the
    ///   path ends at its first cushion, or earlier if `maxDistance` is reached.
    ///   After the last allowed reflection, one final segment reaches the next
    ///   cushion or the distance limit. A corner reflects both components and
    ///   counts as one reflection. An outward ray starting on a cushion uses a
    ///   reflection immediately, without adding a duplicate starting point.
    /// - Numeric policy: direction components below 1e-12 are treated as zero.
    ///   Nearly simultaneous corner contacts use a small floating-point tolerance.
    /// - Returns: the origin, contact points, and a final endpoint as applicable.
    ///   Consecutive equal points are omitted. An outward boundary origin with
    ///   zero available reflections therefore returns only the origin.
    public static func trajectory(
        origin: Vector2,
        angleRadians: Double,
        table: TableBounds,
        ballRadius: Double,
        maxBounces: Int = 3,
        maxDistance: Double = 600
    ) throws -> [Vector2] {
        guard [origin.x, origin.y, angleRadians, table.width, table.height,
               ballRadius, maxDistance].allSatisfy({ $0.isFinite }) else {
            throw PracticeGeometryError.nonFiniteInput
        }
        guard table.width > 0, table.height > 0 else {
            throw PracticeGeometryError.invalidTable
        }
        guard ballRadius > 0,
              ballRadius < min(table.width, table.height) / 2 else {
            throw PracticeGeometryError.invalidBallRadius
        }
        guard (0...maximumBounceLimit).contains(maxBounces) else {
            throw PracticeGeometryError.invalidBounceLimit
        }
        guard maxDistance > 0 else {
            throw PracticeGeometryError.invalidDistanceLimit
        }

        let left = ballRadius
        let right = table.width - ballRadius
        let top = ballRadius
        let bottom = table.height - ballRadius
        guard origin.x >= left, origin.x <= right,
              origin.y >= top, origin.y <= bottom else {
            throw PracticeGeometryError.originOutsideTable
        }

        var dx = cos(angleRadians)
        var dy = sin(angleRadians)
        if abs(dx) < 1e-12 { dx = 0 }
        if abs(dy) < 1e-12 { dy = 0 }
        let magnitude = (dx * dx + dy * dy).squareRoot()
        dx /= magnitude
        dy /= magnitude

        var position = origin
        var remaining = maxDistance
        var reflections = 0
        var path = [origin]
        path.reserveCapacity(maxBounces + 3)

        // Every iteration either terminates or spends one reflection. This also
        // prevents zero-distance boundary contacts from producing infinite loops.
        while true {
            let tx: Double
            if dx > 0 {
                tx = (right - position.x) / dx
            } else if dx < 0 {
                tx = (left - position.x) / dx
            } else {
                tx = .infinity
            }

            let ty: Double
            if dy > 0 {
                ty = (bottom - position.y) / dy
            } else if dy < 0 {
                ty = (top - position.y) / dy
            } else {
                ty = .infinity
            }

            let contactDistance = min(tx, ty)
            if contactDistance > remaining {
                let endpoint = Vector2(
                    x: clamp(position.x + dx * remaining, lower: left, upper: right),
                    y: clamp(position.y + dy * remaining, lower: top, upper: bottom)
                )
                if endpoint != path.last! { path.append(endpoint) }
                return path
            }

            // Infinity is never a contact. At least one direction component is
            // nonzero, but extremely large distances may overflow to infinity;
            // the finite remaining-distance branch above then handles the ray.
            let contactTolerance = 32 * contactDistance.ulp
            let hitsX = tx.isFinite && abs(tx - contactDistance) <= contactTolerance
            let hitsY = ty.isFinite && abs(ty - contactDistance) <= contactTolerance

            var contact = Vector2(
                x: clamp(position.x + dx * contactDistance, lower: left, upper: right),
                y: clamp(position.y + dy * contactDistance, lower: top, upper: bottom)
            )
            if hitsX { contact.x = dx > 0 ? right : left }
            if hitsY { contact.y = dy > 0 ? bottom : top }
            if contact != path.last! { path.append(contact) }
            remaining = max(0, remaining - contactDistance)

            guard remaining > 0, reflections < maxBounces else { return path }
            if hitsX { dx = -dx }
            if hitsY { dy = -dy }
            position = contact
            reflections += 1
        }
    }

    private static func clamp(_ value: Double, lower: Double, upper: Double) -> Double {
        min(upper, max(lower, value))
    }
}
