import Foundation

/// Presentation/cadence only. Every mode uses the same legal-shot simulation.
public enum AutoPlayMode: String, CaseIterable, Codable, Sendable {
    case small, normal, hard

    public var displayName: String {
        switch self {
        case .small: return "Small"
        case .normal: return "Normal"
        case .hard: return "Hard"
        }
    }

    /// A successful fast search is still followed by a brief confirmation.
    /// This does not shorten the planner's simulation budget in Hard mode.
    public var minimumAnalysisDuration: TimeInterval {
        switch self {
        case .small: return 0.9
        case .normal: return 0.55
        case .hard: return 0.28
        }
    }

    public func controlProfile(angleDelta: Double, power: Double) -> AutoPlayControlProfile {
        let distance = min(1, abs(angleDelta.isFinite ? angleDelta : 0) / .pi)
        let force = min(1, max(0, power.isFinite ? power : 0))
        // The feint takes place with the power released and ends before pulling.
        let direction = angleDelta < 0 ? -1.0 : 1.0
        switch self {
        case .small:
            return .init(alignmentDuration: 0.70 + 0.70 * distance,
                         correctionDuration: 0.32, pullDuration: 0.85 + 0.50 * force,
                         settleDuration: 0.22, feintRadians: direction * 0.045)
        case .normal:
            return .init(alignmentDuration: 0.38 + 0.40 * distance,
                         correctionDuration: 0.18, pullDuration: 0.48 + 0.30 * force,
                         settleDuration: 0.16, feintRadians: direction * 0.022)
        case .hard:
            return .init(alignmentDuration: 0.20 + 0.24 * distance,
                         correctionDuration: 0, pullDuration: 0.26 + 0.20 * force,
                         settleDuration: 0.12, feintRadians: 0)
        }
    }
}

public struct AutoPlayControlSample: Equatable, Sendable {
    public let angle: Double
    public let power: Double
    public let phase: String
}

public struct AutoPlayControlProfile: Equatable, Sendable {
    public let alignmentDuration: TimeInterval
    public let correctionDuration: TimeInterval
    public let pullDuration: TimeInterval
    public let settleDuration: TimeInterval
    public let feintRadians: Double

    public var duration: TimeInterval {
        alignmentDuration + correctionDuration + pullDuration + settleDuration
    }

    public func phase(at elapsed: TimeInterval) -> String {
        if elapsed < alignmentDuration { return "aligning" }
        if elapsed < alignmentDuration + correctionDuration { return "correcting" }
        if elapsed < alignmentDuration + correctionDuration + pullDuration { return "pulling" }
        if elapsed < duration { return "settling" }
        return "ready"
    }

    public func sample(startAngle: Double, startPower: Double, targetAngle: Double,
                       targetPower: Double, elapsed: TimeInterval) -> AutoPlayControlSample {
        let time = max(0, elapsed.isFinite ? elapsed : 0)
        let delta = (targetAngle - startAngle).remainder(dividingBy: 2 * .pi)
        let phase = phase(at: time)
        if phase == "aligning" {
            let t = Self.smooth(time / alignmentDuration)
            return .init(angle: startAngle + (delta + feintRadians) * t,
                         power: 0, phase: phase)
        }
        if phase == "correcting" {
            let t = Self.smooth((time - alignmentDuration) / correctionDuration)
            return .init(angle: targetAngle + feintRadians * (1 - t), power: 0, phase: phase)
        }
        let t = Self.smooth((time - alignmentDuration - correctionDuration) / pullDuration)
        return .init(angle: targetAngle, power: Self.clamp(targetPower) * t, phase: phase)
    }

    private static func smooth(_ value: Double) -> Double {
        let t = clamp(value)
        return t * t * (3 - 2 * t)
    }
    private static func clamp(_ value: Double) -> Double {
        min(1, max(0, value.isFinite ? value : 0))
    }
}

/// Counts enabled session time, including planning/opponent/menu waits.
/// User pause and disable stop the clock; a new activation starts a new session.
/// All inputs must come from one monotonic clock, never the wall clock.
public struct AutomationSessionClock: Sendable {
    private var enabled = false
    private var runningSince: TimeInterval?
    private var accumulated: TimeInterval = 0
    private var lastTime: TimeInterval = 0

    public init() {}

    public mutating func synchronize(enabled nextEnabled: Bool, paused: Bool, at timestamp: TimeInterval) {
        guard timestamp.isFinite else { return }
        let now = max(lastTime, timestamp)
        lastTime = now
        if !enabled && nextEnabled {
            accumulated = 0
            runningSince = nil
        }
        let shouldRun = nextEnabled && !paused
        if !shouldRun, let start = runningSince {
            accumulated += max(0, now - start)
            runningSince = nil
        } else if shouldRun && runningSince == nil {
            runningSince = now
        }
        enabled = nextEnabled
    }

    public func elapsed(at timestamp: TimeInterval) -> TimeInterval {
        let now = timestamp.isFinite ? max(lastTime, timestamp) : lastTime
        return accumulated + (runningSince.map { max(0, now - $0) } ?? 0)
    }
}
