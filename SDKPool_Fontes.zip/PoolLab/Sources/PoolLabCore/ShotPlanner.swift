import Foundation

/// Shot selection for this project's local physics model only.
///
/// A suggestion is returned only after a simulation pockets the selected object
/// ball in the requested pocket, first contacts that ball with the cue ball,
/// settles, and leaves the cue ball on the table. The search is deliberately
/// bounded and incomplete: an empty result does not prove a position impossible.
public enum ShotPlanner {
    public static let maximumCandidates = 24
    public static let maximumPowerSamples = 8
    public static let maximumFallbackCandidates = 32
    public static let maximumRefinementSimulations = 96
    public static let maximumPowerRefinementSimulations = 48
    public static let maximumSimulations = (maximumCandidates + maximumFallbackCandidates) * maximumPowerSamples
        + maximumRefinementSimulations + maximumPowerRefinementSimulations
    public static let maximumBreakSimulations = 49

    /// `score` is a relative cost, with lower values preferred, not a probability.
    /// `ghostBall` is the cue ball's desired center at impact; `aimPoint` is the
    /// object ball's pocket center or its first cushion contact for a bank.
    /// For kicks the ghost marker is a geometric contact estimate; the returned
    /// simulation, not that marker, determines the complete displayed trajectory.
    /// Pass the current game's legal first-contact targets in `allowedTargetIDs`.
    /// `nil` preserves unrestricted practice search; an empty set permits no shot.
    /// Restricted searches also reject any outcome that pockets an illegal 8.
    /// `minimumPower` is the simulator's speed fraction, not a native slider
    /// value. Every candidate is simulated at or above this limit; callers must
    /// never raise a returned shot's power after its outcome was verified.
    /// `isBreakShot` requires a freshly verified native standard-8-ball break
    /// stage with no pocket nomination. Break suggestions use `.breakShot`;
    /// their `pocketID` is an unused placeholder, not a claimed target pocket.
    public static func suggestions(
        for state: TableState,
        targetID: Int? = nil,
        pocketID: Int? = nil,
        includeBanks: Bool = true,
        limit: Int = 5,
        allowedTargetIDs: Set<Int>? = nil,
        minimumPower: Double = 0,
        isBreakShot: Bool = false
    ) throws -> [ShotSuggestion] {
        try Task.checkCancellation()
        try BilliardsEngine.validate(state)
        guard minimumPower.isFinite, (0...1).contains(minimumPower) else {
            throw BilliardsError.invalidShot
        }
        guard limit > 0, allowedTargetIDs?.isEmpty != true,
              let cue = state.cueBall else { return [] }
        if isBreakShot {
            return try breakSuggestions(for: state, cue: cue, allowedTargetIDs: allowedTargetIDs,
                                        minimumPower: minimumPower, limit: limit)
        }

        let targets = state.balls.filter {
            !$0.pocketed && $0.id != 0 && (targetID == nil || $0.id == targetID) &&
                (allowedTargetIDs?.contains($0.id) ?? true)
        }.sorted { $0.id < $1.id }
        let pockets = state.table.pockets.filter { pocketID == nil || $0.id == pocketID }
        var candidates: [Candidate] = []
        candidates.reserveCapacity(min(targets.count * pockets.count * 5, 450))

        for target in targets {
            try Task.checkCancellation()
            for pocket in pockets {
                if let direct = candidate(
                    state: state, cue: cue, target: target, pocket: pocket,
                    cushion: nil
                ) {
                    candidates.append(direct)
                }
                if includeBanks {
                    for rail in Rail.allCases {
                        if let contact = bankContact(
                            from: target.position, to: pocket.center,
                            rail: rail, table: state.table
                        ), let bank = candidate(
                            state: state, cue: cue, target: target, pocket: pocket,
                            cushion: contact
                        ) {
                            candidates.append(bank)
                        }
                    }
                }
            }
        }

        candidates.sort(by: candidatePrecedes)
        // Give every legal object a route before spending the initial budget on
        // alternative pockets of one object. Deterministic and still bounded.
        let initial = diverseCandidates(candidates, limit: maximumCandidates)
        let initialKeys = Set(initial.map(\.key))
        var powerRefinementCount = 0
        var suggestions = try evaluate(initial, state: state, cue: cue,
            allowedTargetIDs: allowedTargetIDs, minimumPower: minimumPower,
            refinementBudget: maximumRefinementSimulations / 2,
            powerRefinementCount: &powerRefinementCount)

        // Expensive geometric alternatives are generated only after the ordinary
        // routes failed. Never broaden legal target rules or invent a result.
        if suggestions.isEmpty, includeBanks {
            var fallback = candidates.filter { !initialKeys.contains($0.key) }
            for target in targets {
                try Task.checkCancellation()
                for pocket in pockets {
                    for rail in Rail.allCases {
                        if let kick = routedCandidate(state: state, cue: cue, target: target,
                            pocket: pocket, objectRails: [], cueRails: [rail]) {
                            fallback.append(kick)
                        }
                        for second in Rail.allCases where second != rail {
                            if let bank = routedCandidate(state: state, cue: cue, target: target,
                                pocket: pocket, objectRails: [rail, second], cueRails: []) {
                                fallback.append(bank)
                            }
                        }
                    }
                }
            }
            fallback.sort(by: candidatePrecedes)
            suggestions = try evaluate(diverseCandidates(fallback, limit: maximumFallbackCandidates),
                state: state, cue: cue, allowedTargetIDs: allowedTargetIDs,
                minimumPower: minimumPower, refinementBudget: maximumRefinementSimulations / 2,
                powerRefinementCount: &powerRefinementCount)
        }

        suggestions.sort {
            if $0.score != $1.score { return $0.score < $1.score }
            if $0.shot.power != $1.shot.power { return $0.shot.power < $1.shot.power }
            if $0.targetID != $1.targetID { return $0.targetID < $1.targetID }
            if $0.pocketID != $1.pocketID { return $0.pocketID < $1.pocketID }
            if $0.method != $1.method { return methodOrder($0.method) < methodOrder($1.method) }
            if $0.shot.angleRadians != $1.shot.angleRadians { return $0.shot.angleRadians < $1.shot.angleRadians }
            return $0.shot.power < $1.shot.power
        }
        return Array(suggestions.prefix(min(limit, maximumCandidates)))
    }

    // Kept internal so the acceptance contract can be tested independently of
    // the candidate search and the numerical integration implementation.
    static func isValidOutcome(
        _ result: ShotResult, targetID: Int, pocketID: Int,
        method: ShotMethod? = nil, allowedTargetIDs: Set<Int>? = nil
    ) -> Bool {
        // A break follows a distinct rule and must not be accepted by the
        // selected-pocket contract used for ordinary shots.
        if method == .breakShot { return false }
        if let allowedTargetIDs {
            guard allowedTargetIDs.contains(targetID) else { return false }
            if !allowedTargetIDs.contains(8),
               result.finalState.balls.contains(where: { $0.id == 8 && $0.pocketed }) ||
                result.pocketedIDs.contains(8) {
                return false
            }
        }
        guard result.settled, !result.scratched,
              result.finalState.balls.contains(where: { $0.id == targetID && $0.pocketed }),
              result.events.contains(.pocket(ball: targetID, pocket: pocketID)) else { return false }

        var objectCushions = 0
        var cueCushionsBeforeContact = 0
        var firstContact: Int?
        var objectDeflection = false
        for event in result.events {
            if event == .pocket(ball: targetID, pocket: pocketID) { break }
            if event == .cushion(ball: targetID) { objectCushions += 1 }
            if firstContact == nil, event == .cushion(ball: 0) { cueCushionsBeforeContact += 1 }
            if case let .ballCollision(first, second) = event,
               first != 0, second != 0, first == targetID || second == targetID { objectDeflection = true }
            if firstContact == nil, case let .ballCollision(first, second) = event {
                if first == 0 { firstContact = second }
                if second == 0 { firstContact = first }
            }
        }
        guard firstContact == targetID else { return false }
        if let method {
            switch method {
            case .direct: return objectCushions == 0 && cueCushionsBeforeContact == 0
            case .bank: return objectCushions == 1 && cueCushionsBeforeContact == 0
            case .doubleBank: return objectCushions == 2 && cueCushionsBeforeContact == 0
            case .kick: return objectCushions == 0 && cueCushionsBeforeContact == 1
            case .carom: return objectDeflection
            case .multiCushion: return objectCushions > 2 || cueCushionsBeforeContact > 1 ||
                (objectCushions > 0 && cueCushionsBeforeContact > 0)
            case .breakShot: return false
            }
        }
        return true
    }

    /// Exact-build native state confirms that a break is due; the additional
    /// geometry guard prevents an incorrect or stale flag from firing into an
    /// arbitrary board. No cue placement is performed by this planner.
    private static func breakSuggestions(
        for state: TableState, cue: PoolBall, allowedTargetIDs: Set<Int>?,
        minimumPower: Double, limit: Int, searchClock: SearchClock? = nil
    ) throws -> [ShotSuggestion] {
        let table = state.table
        let objects = state.balls.filter { $0.id != 0 && !$0.pocketed }
        guard state.balls.count == 16, objects.count == 15,
              Set(state.balls.map(\.id)) == Set(0...15),
              let target = objects.min(by: {
                  let left = $0.position.distance(to: cue.position)
                  let right = $1.position.distance(to: cue.position)
                  return left == right ? $0.id < $1.id : left < right
              }), target.id != 8, allowedTargetIDs?.contains(target.id) ?? true else { return [] }
        let radius = table.ballRadius
        let minX = objects.map(\.position.x).min()!, maxX = objects.map(\.position.x).max()!
        let minY = objects.map(\.position.y).min()!, maxY = objects.map(\.position.y).max()!
        let center = Vector2(x: (minX + maxX) / 2, y: (minY + maxY) / 2)
        guard maxX - minX <= 8.2 * radius, maxY - minY <= 10.2 * radius,
              maxX - minX >= 5 * radius, maxY - minY >= 6 * radius,
              abs(center.y - table.height / 2) <= table.height * 0.12,
              center.x < table.width * 0.4 || center.x > table.width * 0.6,
              cue.position.distance(to: target.position) >= 8 * radius,
              objects.allSatisfy({ ball in
                  objects.filter { $0.id != ball.id && $0.position.distance(to: ball.position) <= 2.08 * radius }.count >= 2
              }) else { return [] }
        let direction = (target.position - cue.position).normalized()
        let side = Vector2(x: -direction.y, y: direction.x)
        let offsets = [-0.75, -0.4, -0.2, 0, 0.2, 0.4, 0.75]
        var powers: [Double] = []
        for power in [0.22, 0.32, 0.45, 0.58, 0.72, 0.88, 1.0].map({ max(minimumPower, $0) }) {
            if powers.last != power { powers.append(power) }
        }
        let allowed = allowedTargetIDs ?? Set(objects.filter { $0.id != 8 }.map(\.id))
        var shots: [ShotSuggestion] = []
        for offset in offsets {
            if let searchClock { guard try searchClock.active() else { break }; searchClock.candidates += 1 }
            let aim = target.position + side * (offset * radius)
            let delta = aim - cue.position
            let angle = atan2(delta.y, delta.x)
            for power in powers {
                try Task.checkCancellation()
                let shot = try executableShot(angle: angle, power: power, minimumPower: minimumPower, table: table)
                let result: ShotResult
                if let searchClock {
                    guard try searchClock.active() else { break }
                    guard let simulated = try searchClock.simulate(state, shot) else { continue }
                    result = simulated
                } else { result = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false) }
                guard isValidBreakOutcome(result, allowedTargetIDs: allowed),
                      firstObjectContact(result) == target.id else { continue }
                let railBalls = Set(result.events.compactMap { event -> Int? in
                    if case let .cushion(ball) = event, ball != 0 { return ball }; return nil
                })
                let remaining = result.finalState.balls.filter { $0.id != 0 && !$0.pocketed }
                let spread = remaining.reduce(0.0) { $0 + $1.position.distance(to: center) } / table.width
                let score = -8 * Double(result.pocketedIDs.count) - 0.5 * Double(railBalls.count) - spread + power * 0.1
                shots.append(ShotSuggestion(targetID: target.id, pocketID: 0, method: .breakShot,
                    shot: shot, ghostBall: target.position - delta.normalized() * (2 * radius),
                    aimPoint: aim, score: score, result: result))
            }
        }
        shots.sort {
            if $0.score != $1.score { return $0.score < $1.score }
            if $0.shot.power != $1.shot.power { return $0.shot.power < $1.shot.power }
            return $0.shot.angleRadians < $1.shot.angleRadians
        }
        return Array(shots.prefix(min(limit, maximumCandidates)))
    }

    static func isValidBreakOutcome(_ result: ShotResult, allowedTargetIDs: Set<Int>) -> Bool {
        guard result.settled, !result.scratched,
              !result.pocketedIDs.contains(0), !result.pocketedIDs.contains(8),
              !result.finalState.balls.contains(where: { $0.id == 8 && $0.pocketed }),
              let first = firstObjectContact(result), first != 8, allowedTargetIDs.contains(first) else { return false }
        let objectPotted = result.pocketedIDs.contains { (1...15).contains($0) && $0 != 8 }
        let cushions = Set(result.events.compactMap { event -> Int? in
            if case let .cushion(ball) = event, (1...15).contains(ball) { return ball }; return nil
        })
        return objectPotted || cushions.count >= 4
    }

    private static func firstObjectContact(_ result: ShotResult) -> Int? {
        for event in result.events {
            if case let .ballCollision(first, second) = event {
                if first == 0 { return second }
                if second == 0 { return first }
            }
        }
        return nil
    }

    private struct Candidate {
        let targetID: Int
        let pocketID: Int
        let method: ShotMethod
        let targetPosition: Vector2
        let pocketCenter: Vector2
        let ghost: Vector2
        let aim: Vector2
        let angle: Double
        let cutCosine: Double
        let cueDistance: Double
        let objectFirstDistance: Double
        let objectLastDistance: Double
        let cushionSpeedSquared: Double
        let geometryCost: Double
        var cueRails: [Rail] = []
        var requiredPowerEstimate: Double? = nil
        var key: String { "\(targetID)-\(pocketID)-\(method.rawValue)-\(angle)" }
    }

    private enum Rail: CaseIterable, Equatable { case left, right, top, bottom }

    private static func candidate(
        state: TableState, cue: PoolBall, target: PoolBall,
        pocket: PoolPocket, cushion: Vector2?
    ) -> Candidate? {
        let table = state.table
        let aim = cushion ?? pocket.aimPoint
        // Reaching a pocket center on paper is insufficient at a shallow angle:
        // the ball center may strike the adjoining cushion before entering its
        // capture circle. Exclude that extra-bounce route before simulation.
        guard table.nativeGeometry != nil
                ? BilliardsEngine.directPocketPathClear(from: cushion ?? target.position, pocket: pocket, table: table)
                : canEnterPocket(from: cushion ?? target.position, pocket: pocket.center, table: table) else {
            return nil
        }
        let objectVector = aim - target.position
        guard objectVector.length > table.ballRadius else { return nil }
        let direction = objectVector.normalized()
        let ghost = target.position - direction * (2 * table.ballRadius)
        guard isInside(ghost, table: table),
              !table.pockets.contains(where: { ghost.distance(to: $0.center) <= $0.radius }) else {
            return nil
        }
        let cueVector = ghost - cue.position
        guard cueVector.length > 1e-8 else { return nil }
        let cutCosine = cueVector.normalized().dot(direction)
        // Extremely thin cuts are deliberately outside this coarse search.
        guard cutCosine >= 0.22 else { return nil }
        let stationaryObstacles = state.balls.filter { !$0.pocketed && $0.id != 0 && $0.id != target.id }
        guard clearRoute(from: cue.position, to: ghost, obstacles: stationaryObstacles, radius: table.ballRadius),
              clearRoute(from: target.position, to: aim, obstacles: stationaryObstacles, radius: table.ballRadius) else {
            return nil
        }

        var finalDistance = 0.0
        var cushionSpeedSquared = 1.0
        if let cushion {
            guard clearRoute(from: cushion, to: pocket.aimPoint, obstacles: stationaryObstacles, radius: table.ballRadius) else {
                return nil
            }
            // The cue ball moves away from its initial center after impact;
            // its actual interaction with the bank route is checked by the engine.
            finalDistance = cushion.distance(to: pocket.aimPoint)
            let hitsVertical = abs(cushion.x - table.ballRadius) < 1e-7 ||
                abs(cushion.x - (table.width - table.ballRadius)) < 1e-7
            let normal = hitsVertical ? direction.x : direction.y
            cushionSpeedSquared = 1 - normal * normal * (1 - table.cushionRestitution * table.cushionRestitution)
            guard cushionSpeedSquared > 1e-8 else { return nil }
        }

        let cut = acos(min(1, max(-1, cutCosine)))
        let totalDistance = cueVector.length + objectVector.length + finalDistance
        return Candidate(
            targetID: target.id, pocketID: pocket.id,
            method: cushion == nil ? .direct : .bank,
            targetPosition: target.position, pocketCenter: pocket.center,
            ghost: ghost, aim: aim,
            angle: atan2(cueVector.y, cueVector.x), cutCosine: cutCosine,
            cueDistance: cueVector.length,
            objectFirstDistance: objectVector.length,
            objectLastDistance: finalDistance,
            cushionSpeedSquared: cushionSpeedSquared,
            geometryCost: 1.2 * cut + totalDistance / table.width + (cushion == nil ? 0 : 0.55)
        )
    }

    /// Unfold the target pocket across the cushion's center-contact line.
    /// Scale its normal distance by 1/restitution because this engine reduces
    /// normal velocity at a cushion while retaining tangential velocity.
    private static func bankContact(from source: Vector2, to pocket: Vector2, rail: Rail, table: PoolTable) -> Vector2? {
        guard table.cushionRestitution > 1e-6 else { return nil }
        let radius = table.ballRadius
        let vertical = rail == .left || rail == .right
        let boundary: Double
        switch rail {
        case .left, .top: boundary = radius
        case .right: boundary = table.width - radius
        case .bottom: boundary = table.height - radius
        }
        let sourceNormal = vertical ? source.x : source.y
        let pocketNormal = vertical ? pocket.x : pocket.y
        // Both endpoints must be on the playable side of the bank cushion.
        // Otherwise this would hit that pocket directly or cross another rail.
        guard (sourceNormal - boundary) * (pocketNormal - boundary) > 1e-8 else { return nil }
        let virtualNormal = boundary - (pocketNormal - boundary) / table.cushionRestitution
        let denominator = virtualNormal - sourceNormal
        guard abs(denominator) > 1e-8 else { return nil }
        let fraction = (boundary - sourceNormal) / denominator
        guard fraction > 0, fraction < 1 else { return nil }
        let virtualPocket = vertical ? Vector2(x: virtualNormal, y: pocket.y) : Vector2(x: pocket.x, y: virtualNormal)
        var contact = source + (virtualPocket - source) * fraction
        if vertical { contact.x = boundary } else { contact.y = boundary }
        guard isInside(contact, table: table),
              !table.pockets.contains(where: { contact.distance(to: $0.center) <= $0.attractionRadius + radius * 0.25 }) else {
            return nil
        }
        return contact
    }

    private static func isInside(_ point: Vector2, table: PoolTable) -> Bool {
        point.isFinite && point.x >= table.ballRadius && point.x <= table.width - table.ballRadius &&
            point.y >= table.ballRadius && point.y <= table.height - table.ballRadius
    }

    /// Entry point of the actual refined cue ray into the object's collision
    /// circle, so the suggestion's marker agrees with its returned angle.
    private static func impactPoint(from cue: Vector2, target: Vector2, angle: Double, radius: Double) -> Vector2? {
        let direction = Vector2(x: cos(angle), y: sin(angle))
        let delta = target - cue
        let projection = delta.dot(direction)
        let perpendicularSquared = max(0, delta.lengthSquared - projection * projection)
        let discriminant = 4 * radius * radius - perpendicularSquared
        guard discriminant >= 0 else { return nil }
        let distance = projection - sqrt(discriminant)
        guard distance > 0 else { return nil }
        return cue + direction * distance
    }

    private static func canEnterPocket(from start: Vector2, pocket: Vector2, table: PoolTable) -> Bool {
        let delta = pocket - start
        let radius = table.ballRadius
        var fraction = 1.0
        if delta.x < 0, pocket.x < radius {
            fraction = min(fraction, (radius - start.x) / delta.x)
        }
        if delta.x > 0, pocket.x > table.width - radius {
            fraction = min(fraction, (table.width - radius - start.x) / delta.x)
        }
        if delta.y < 0, pocket.y < radius {
            fraction = min(fraction, (radius - start.y) / delta.y)
        }
        if delta.y > 0, pocket.y > table.height - radius {
            fraction = min(fraction, (table.height - radius - start.y) / delta.y)
        }
        return (start + delta * fraction).distance(to: pocket) <= table.pocketRadius
    }

    private static func clearRoute(from start: Vector2, to end: Vector2, obstacles: [PoolBall], radius: Double) -> Bool {
        let segment = end - start
        let lengthSquared = segment.lengthSquared
        guard lengthSquared > 1e-12 else { return false }
        let clearance = 2 * radius + 0.02
        for ball in obstacles {
            let fraction = min(1, max(0, (ball.position - start).dot(segment) / lengthSquared))
            let nearest = start + segment * fraction
            if ball.position.distance(to: nearest) < clearance { return false }
        }
        return true
    }

    private static func powerSamples(for candidate: Candidate, table: PoolTable, minimumPower: Double) -> [Double] {
        let transfer = ((1 + table.ballRestitution) / 2) * candidate.cutCosine
        let objectDistance = candidate.objectFirstDistance + candidate.objectLastDistance / candidate.cushionSpeedSquared
        let requiredSpeedSquared = 2 * table.rollingDeceleration *
            (candidate.cueDistance + objectDistance / (transfer * transfer))
        let estimate = candidate.requiredPowerEstimate ?? (sqrt(requiredSpeedSquared) / table.maximumShotSpeed)
        let proposed = [estimate * 0.92, estimate * 1.04, estimate * 1.20,
                        estimate * 1.45, estimate * 1.80, 0.45, 0.68, 0.90]
        var result: [Double] = []
        for power in proposed.map({ min(1, max(minimumPower, max(0.015, $0))) }).sorted() {
            if let last = result.last, abs(last - power) < 1e-6 { continue }
            result.append(power)
        }
        return Array(result.prefix(maximumPowerSamples))
    }

    private static func methodOrder(_ method: ShotMethod) -> Int {
        switch method {
        case .direct: return 0
        case .bank: return 1
        case .kick: return 2
        case .doubleBank: return 3
        case .carom: return 4
        case .multiCushion: return 5
        case .breakShot: return 6
        }
    }

    private static func diverseCandidates(_ sorted: [Candidate], limit: Int) -> [Candidate] {
        var picked: [Candidate] = []
        var groups = Set<String>()
        var targets = Set<Int>()
        var keys = Set<String>()
        // Cover every legal target first, then its different route types, then
        // alternatives. Many routes for one object cannot starve another object.
        for candidate in sorted where targets.insert(candidate.targetID).inserted {
            picked.append(candidate)
            keys.insert(candidate.key)
            groups.insert("\(candidate.targetID)-\(candidate.method.rawValue)")
            if picked.count == limit { return picked }
        }
        for candidate in sorted {
            let group = "\(candidate.targetID)-\(candidate.method.rawValue)"
            if groups.insert(group).inserted, keys.insert(candidate.key).inserted {
                picked.append(candidate)
                if picked.count == limit { return picked }
            }
        }
        for candidate in sorted where keys.insert(candidate.key).inserted {
            picked.append(candidate)
            if picked.count == limit { break }
        }
        return picked
    }

    static func executableShot(angle: Double, power: Double, minimumPower: Double,
                                       table: PoolTable) throws -> ShotParameters {
        guard table.nativeDynamics != nil || table.nativeGeometry != nil else {
            return ShotParameters(angleRadians: angle, power: power)
        }
        // The verified game commit rounds angle and native control power to
        // 1e-4. Validate the exact representable command, including minimum
        // power, instead of sending a weaker/different untested command.
        let minimumControl = try GameShotCalibration.controlPower(fromSimulationPower: minimumPower)
        let desiredControl = try GameShotCalibration.controlPower(fromSimulationPower: power)
        let control = min(1, max(ceil(minimumControl * 10_000 - 1e-9) / 10_000,
                                (desiredControl * 10_000).rounded() / 10_000))
        // Bridge input is the negated model angle, normalized into [0, 2π).
        // Quantize in that domain: 2π is not itself on the 1e-4 grid.
        let revolution = 2 * Double.pi
        var nativeAngle = (-angle).truncatingRemainder(dividingBy: revolution)
        if nativeAngle < 0 { nativeAngle += revolution }
        nativeAngle = (nativeAngle * 10_000).rounded() / 10_000
        if nativeAngle >= revolution { nativeAngle = 0 }
        return ShotParameters(angleRadians: -nativeAngle,
                              power: try GameShotCalibration.simulationPower(fromControlPower: control))
    }

    private static func evaluate(_ candidates: [Candidate], state: TableState, cue: PoolBall,
                                 allowedTargetIDs: Set<Int>?, minimumPower: Double,
                                 refinementBudget: Int, powerRefinementCount: inout Int) throws -> [ShotSuggestion] {
        var accepted: [ShotSuggestion] = []
        var unresolved: [(candidate: Candidate, powers: [Double])] = []
        for candidate in candidates {
            try Task.checkCancellation()
            var misses: [(power: Double, distance: Double)] = []
            var found = false
            var lower = minimumPower
            for power in powerSamples(for: candidate, table: state.table, minimumPower: minimumPower) {
                try Task.checkCancellation()
                let shot = try executableShot(angle: candidate.angle, power: power,
                                              minimumPower: minimumPower, table: state.table)
                let result = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false)
                guard isValidOutcome(result, targetID: candidate.targetID, pocketID: candidate.pocketID,
                                     method: candidate.method, allowedTargetIDs: allowedTargetIDs) else {
                    let reached = result.events.contains(.pocket(ball: candidate.targetID, pocket: candidate.pocketID))
                    let distance = reached ? 0 : (result.finalState.balls.first {
                        $0.id == candidate.targetID
                    }?.position.distance(to: candidate.pocketCenter) ?? .infinity)
                    misses.append((shot.power, distance))
                    lower = shot.power
                    continue
                }
                let gentle = try gentlerOutcome(candidate: candidate, state: state, shot: shot,
                    result: result, lower: lower, minimumPower: minimumPower,
                    allowedTargetIDs: allowedTargetIDs, simulations: &powerRefinementCount)
                if let ghost = actualGhost(candidate, cue: cue.position, angle: gentle.shot.angleRadians, table: state.table) {
                    accepted.append(suggestion(candidate, shot: gentle.shot, result: gentle.result, ghost: ghost))
                    found = true
                }
                break
            }
            if !found {
                misses.sort {
                    if $0.distance != $1.distance { return $0.distance < $1.distance }
                    return $0.power < $1.power
                }
                unresolved.append((candidate, misses.map(\.power)))
            }
        }
        // Rotate between routes. The fallback phase has its own half-budget,
        // so failed direct routes cannot consume all bank/kick refinements.
        let offsets = [0.0025, -0.0025, 0.005, -0.005]
        var refinedRoutes = Set<Int>()
        var simulations = 0
        refinement: for powerIndex in 0..<maximumPowerSamples {
            for offset in offsets {
                for (index, route) in unresolved.enumerated() {
                    try Task.checkCancellation()
                    guard !refinedRoutes.contains(index), powerIndex < route.powers.count else { continue }
                    guard simulations < refinementBudget else { break refinement }
                    let candidate = route.candidate
                    let shot = try executableShot(angle: candidate.angle + offset, power: route.powers[powerIndex],
                                                  minimumPower: minimumPower, table: state.table)
                    guard actualGhost(candidate, cue: cue.position, angle: shot.angleRadians, table: state.table) != nil else { continue }
                    simulations += 1
                    let result = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false)
                    guard isValidOutcome(result, targetID: candidate.targetID, pocketID: candidate.pocketID,
                                         method: candidate.method, allowedTargetIDs: allowedTargetIDs) else { continue }
                    let gentle = try gentlerOutcome(candidate: candidate, state: state, shot: shot,
                        result: result, lower: minimumPower, minimumPower: minimumPower,
                        allowedTargetIDs: allowedTargetIDs, simulations: &powerRefinementCount)
                    guard let ghost = actualGhost(candidate, cue: cue.position, angle: gentle.shot.angleRadians, table: state.table) else { continue }
                    accepted.append(suggestion(candidate, shot: gentle.shot, result: gentle.result, ghost: ghost,
                                               anglePenalty: abs(offset)))
                    refinedRoutes.insert(index)
                }
            }
        }
        return accepted
    }

    private static func suggestion(_ candidate: Candidate, shot: ShotParameters, result: ShotResult,
                                   ghost: Vector2, anglePenalty: Double = 0) -> ShotSuggestion {
        ShotSuggestion(targetID: candidate.targetID, pocketID: candidate.pocketID, method: candidate.method,
                       shot: shot, ghostBall: ghost, aimPoint: candidate.aim,
                       score: candidate.geometryCost + 6 * shot.power + anglePenalty, result: result)
    }

    private static func gentlerOutcome(candidate: Candidate, state: TableState, shot: ShotParameters,
                                       result: ShotResult, lower: Double, minimumPower: Double,
                                       allowedTargetIDs: Set<Int>?, simulations: inout Int) throws
        -> (shot: ShotParameters, result: ShotResult) {
        var low = max(minimumPower, min(lower, shot.power))
        var best = (shot: shot, result: result)
        // Success is not assumed monotonic in power (jaws, secondary collisions
        // and scratches can produce narrow windows). Keep an already verified
        // result at every step and never replace it with an inferred outcome.
        for _ in 0..<5 {
            guard simulations < maximumPowerRefinementSimulations - 1,
                  best.shot.power - low > 0.0005 else { break }
            try Task.checkCancellation()
            let probe = try executableShot(angle: shot.angleRadians, power: (low + best.shot.power) / 2,
                                           minimumPower: minimumPower, table: state.table)
            guard probe.power > low + 1e-9, probe.power < best.shot.power - 1e-9 else { break }
            simulations += 1
            let outcome = try BilliardsEngine.simulate(state: state, shot: probe, recordFrames: false)
            if isValidOutcome(outcome, targetID: candidate.targetID, pocketID: candidate.pocketID,
                              method: candidate.method, allowedTargetIDs: allowedTargetIDs) {
                best = (probe, outcome)
            } else { low = probe.power }
        }
        // Stay modestly above the lowest verified speed, without ever exceeding
        // the original accepted speed. This margin is also simulated; it is not
        // a confidence percentage or a guarantee against measurement error.
        if simulations < maximumPowerRefinementSimulations, best.shot.power < shot.power - 1e-9 {
            let reservePower = min(shot.power, best.shot.power * 1.035)
            let reserve = try executableShot(angle: shot.angleRadians, power: reservePower,
                                             minimumPower: minimumPower, table: state.table)
            if reserve.power >= best.shot.power, reserve.power <= shot.power + 1e-9 {
                try Task.checkCancellation()
                simulations += 1
                let outcome = try BilliardsEngine.simulate(state: state, shot: reserve, recordFrames: false)
                if isValidOutcome(outcome, targetID: candidate.targetID, pocketID: candidate.pocketID,
                                  method: candidate.method, allowedTargetIDs: allowedTargetIDs) {
                    best = (reserve, outcome)
                }
            }
        }
        return best
    }

    private static func actualGhost(_ candidate: Candidate, cue: Vector2, angle: Double, table: PoolTable) -> Vector2? {
        var start = cue
        var direction = Vector2(x: cos(angle), y: sin(angle))
        for rail in candidate.cueRails {
            guard let contact = rayContact(from: start, direction: direction, rail: rail, table: table) else { return nil }
            start = contact
            if rail == .left || rail == .right { direction.x *= -table.cushionRestitution }
            else { direction.y *= -table.cushionRestitution }
            direction = direction.normalized()
        }
        return impactPoint(from: start, target: candidate.targetPosition,
                           angle: atan2(direction.y, direction.x), radius: table.ballRadius)
    }

    private static func boundary(_ rail: Rail, table: PoolTable) -> Double {
        switch rail {
        case .left, .top: return table.ballRadius
        case .right: return table.width - table.ballRadius
        case .bottom: return table.height - table.ballRadius
        }
    }

    private static func rayContact(from start: Vector2, direction: Vector2, rail: Rail, table: PoolTable) -> Vector2? {
        let vertical = rail == .left || rail == .right
        let component = vertical ? direction.x : direction.y
        guard abs(component) > 1e-9 else { return nil }
        let distance = (boundary(rail, table: table) - (vertical ? start.x : start.y)) / component
        guard distance > 1e-7 else { return nil }
        var contact = start + direction * distance
        if vertical { contact.x = boundary(rail, table: table) }
        else { contact.y = boundary(rail, table: table) }
        guard isInside(contact, table: table), !table.pockets.contains(where: {
            contact.distance(to: $0.center) <= $0.attractionRadius + table.ballRadius * 0.25
        }) else { return nil }
        return contact
    }

    private static func railPath(from start: Vector2, to end: Vector2, rails: [Rail], table: PoolTable) -> [Vector2]? {
        guard table.cushionRestitution > 1e-6 else { return nil }
        var images = [Vector2](repeating: end, count: rails.count)
        var virtual = end
        for index in rails.indices.reversed() {
            let rail = rails[index]
            let edge = boundary(rail, table: table)
            if rail == .left || rail == .right { virtual.x = edge - (virtual.x - edge) / table.cushionRestitution }
            else { virtual.y = edge - (virtual.y - edge) / table.cushionRestitution }
            images[index] = virtual
        }
        var cursor = start
        var contacts: [Vector2] = []
        for (index, rail) in rails.enumerated() {
            guard let contact = rayContact(from: cursor, direction: (images[index] - cursor).normalized(),
                                           rail: rail, table: table) else { return nil }
            contacts.append(contact)
            cursor = contact
        }
        return contacts
    }

    private static func routedCandidate(state: TableState, cue: PoolBall, target: PoolBall,
                                        pocket: PoolPocket, objectRails: [Rail], cueRails: [Rail]) -> Candidate? {
        let table = state.table
        guard let objectContacts = railPath(from: target.position, to: pocket.aimPoint, rails: objectRails, table: table) else { return nil }
        let aim = objectContacts.first ?? pocket.aimPoint
        let objectDirection = (aim - target.position).normalized()
        let ghost = target.position - objectDirection * (2 * table.ballRadius)
        guard isInside(ghost, table: table), !table.pockets.contains(where: { ghost.distance(to: $0.center) <= $0.radius }),
              let cueContacts = railPath(from: cue.position, to: ghost, rails: cueRails, table: table) else { return nil }
        let finalCueStart = cueContacts.last ?? cue.position
        let incoming = (ghost - finalCueStart).normalized()
        let cutCosine = incoming.dot(objectDirection)
        guard cutCosine >= 0.22 else { return nil }
        let lastObjectStart = objectContacts.last ?? target.position
        guard table.nativeGeometry != nil
            ? BilliardsEngine.directPocketPathClear(from: lastObjectStart, pocket: pocket, table: table)
            : canEnterPocket(from: lastObjectStart, pocket: pocket.center, table: table) else { return nil }
        let obstacles = state.balls.filter { !$0.pocketed && $0.id != 0 && $0.id != target.id }
        let cuePoints = [cue.position] + cueContacts + [ghost]
        let objectPoints = [target.position] + objectContacts + [pocket.aimPoint]
        for index in 1..<cuePoints.count {
            // The target is an obstacle before the final cue segment as well;
            // a route may not hit it before the intended cushion sequence.
            let blockers = index < cuePoints.count - 1 ? obstacles + [target] : obstacles
            guard clearRoute(from: cuePoints[index - 1], to: cuePoints[index], obstacles: blockers, radius: table.ballRadius) else { return nil }
        }
        for index in 1..<objectPoints.count {
            guard clearRoute(from: objectPoints[index - 1], to: objectPoints[index], obstacles: obstacles, radius: table.ballRadius) else { return nil }
        }
        // Work required speed backwards through the ideal route, accounting for
        // tangential retention and normal loss at each planned cushion. Native
        // jaws/spin/attraction are still decided exclusively by full simulation.
        func initialSpeedSquared(points: [Vector2], rails: [Rail], finalSpeedSquared: Double) -> Double {
            var speedSquared = finalSpeedSquared
            for index in (1..<points.count).reversed() {
                speedSquared += 2 * table.rollingDeceleration * points[index].distance(to: points[index - 1])
                if index > 1 {
                    let direction = (points[index - 1] - points[index - 2]).normalized()
                    let rail = rails[index - 2]
                    let normal = rail == .left || rail == .right ? direction.x : direction.y
                    let retained = 1 - normal * normal * (1 - table.cushionRestitution * table.cushionRestitution)
                    speedSquared /= max(retained, 1e-8)
                }
            }
            return speedSquared
        }
        let objectSpeedSquared = initialSpeedSquared(points: objectPoints, rails: objectRails, finalSpeedSquared: 0)
        let transfer = ((1 + table.ballRestitution) / 2) * cutCosine
        let cueSpeedSquared = initialSpeedSquared(points: cuePoints, rails: cueRails,
                                                 finalSpeedSquared: objectSpeedSquared / (transfer * transfer))
        let totalDistance = zip(cuePoints, cuePoints.dropFirst()).reduce(0.0) { $0 + $1.0.distance(to: $1.1) }
            + zip(objectPoints, objectPoints.dropFirst()).reduce(0.0) { $0 + $1.0.distance(to: $1.1) }
        let firstCue = cuePoints[1] - cue.position
        return Candidate(targetID: target.id, pocketID: pocket.id,
            method: cueRails.isEmpty ? .doubleBank : .kick,
            targetPosition: target.position, pocketCenter: pocket.center,
            ghost: ghost, aim: aim, angle: atan2(firstCue.y, firstCue.x), cutCosine: cutCosine,
            cueDistance: 0, objectFirstDistance: 0, objectLastDistance: 0, cushionSpeedSquared: 1,
            geometryCost: 1.2 * acos(min(1, max(-1, cutCosine))) + totalDistance / table.width
                + 0.55 * Double(objectRails.count + cueRails.count), cueRails: cueRails,
            requiredPowerEstimate: sqrt(cueSpeedSquared) / table.maximumShotSpeed)
    }

    private static func candidatePrecedes(_ lhs: Candidate, _ rhs: Candidate) -> Bool {
        if lhs.geometryCost != rhs.geometryCost { return lhs.geometryCost < rhs.geometryCost }
        if lhs.targetID != rhs.targetID { return lhs.targetID < rhs.targetID }
        if lhs.pocketID != rhs.pocketID { return lhs.pocketID < rhs.pocketID }
        if lhs.method != rhs.method { return methodOrder(lhs.method) < methodOrder(rhs.method) }
        return lhs.angle < rhs.angle
    }
}

// V14 automatic search deliberately has a separate entry point. The existing
// deterministic practice suggestions and the prediction engine stay available.
extension ShotPlanner {
    private final class SearchClock {
        let started = ProcessInfo.processInfo.systemUptime
        let budget: ShotSearchBudget
        var simulations = 0
        var candidates = 0
        var phases: [String] = []
        var seen = Set<String>()
        init(_ budget: ShotSearchBudget) { self.budget = budget }
        var elapsed: TimeInterval { ProcessInfo.processInfo.systemUptime - started }
        var termination: ShotSearchTermination? {
            if elapsed >= budget.maximumDuration { return .timeLimit }
            if simulations >= budget.maximumSimulations { return .simulationLimit }
            return nil
        }
        func active() throws -> Bool { try Task.checkCancellation(); return termination == nil }
        func simulate(_ state: TableState, _ shot: ShotParameters, targetID: Int? = nil) throws -> ShotResult? {
            guard try active() else { return nil }
            let key = "\(targetID ?? -1)-\(shot.angleRadians)-\(shot.power)"
            guard seen.insert(key).inserted else { return nil }
            simulations += 1
            return try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false)
        }
    }

    /// Deadline-aware search for automatic play. It first tries ordinary paths,
    /// then target-preserving deflections and longer cushion routes, then a
    /// contact-angle sweep that lets the engine discover unplanned interactions.
    /// All accepted commands have been simulated at their exact native rounding.
    public static func search(
        for state: TableState, targetID: Int? = nil, pocketID: Int? = nil,
        includeBanks: Bool = true, limit: Int = 5, allowedTargetIDs: Set<Int>? = nil,
        minimumPower: Double = 0, isBreakShot: Bool = false,
        budget: ShotSearchBudget = .automatic
    ) throws -> ShotSearchReport {
        let clock = SearchClock(budget)
        try Task.checkCancellation()
        try BilliardsEngine.validate(state)
        guard minimumPower.isFinite, (0...1).contains(minimumPower) else { throw BilliardsError.invalidShot }
        var accepted: [ShotSuggestion] = []
        func report(_ finished: ShotSearchTermination = .completed) -> ShotSearchReport {
            accepted.sort {
                if $0.score != $1.score { return $0.score < $1.score }
                return $0.id < $1.id
            }
            return ShotSearchReport(suggestions: Array(accepted.prefix(max(0, min(limit, 24)))),
                simulations: clock.simulations, candidates: clock.candidates, elapsed: clock.elapsed,
                termination: clock.termination ?? finished, phases: clock.phases, explorationPass: budget.explorationPass)
        }
        guard limit > 0, allowedTargetIDs?.isEmpty != true, let cue = state.cueBall,
              try clock.active() else { return report() }
        if isBreakShot {
            clock.phases.append("break")
            accepted = try breakSuggestions(for: state, cue: cue, allowedTargetIDs: allowedTargetIDs,
                minimumPower: minimumPower, limit: limit, searchClock: clock)
            return report(accepted.isEmpty ? .completed : .solutionFound)
        }
        let targets = rotated(state.balls.filter { !$0.pocketed && $0.id != 0 &&
            (targetID == nil || $0.id == targetID) && (allowedTargetIDs?.contains($0.id) ?? true) }
            .sorted { $0.id < $1.id }, by: budget.explorationPass)
        let pockets = rotated(state.table.pockets.filter { pocketID == nil || $0.id == pocketID },
                              by: budget.explorationPass / max(1, targets.count))
        guard !targets.isEmpty, !pockets.isEmpty else { return report() }
        var ordinary: [Candidate] = []
        if budget.explorationPass % 4 == 0 {
            clock.phases.append("ordinary")
            for target in targets {
                for pocket in pockets {
                    guard try clock.active() else { return report() }
                    if let route = candidate(state: state, cue: cue, target: target, pocket: pocket, cushion: nil) {
                        ordinary.append(route)
                    }
                    if includeBanks {
                        for rail in Rail.allCases {
                            guard try clock.active() else { return report() }
                            if let contact = bankContact(from: target.position, to: pocket.aimPoint, rail: rail, table: state.table),
                               let route = candidate(state: state, cue: cue, target: target, pocket: pocket, cushion: contact) {
                                ordinary.append(route)
                            }
                        }
                    }
                }
            }
            // Every ordinary candidate receives the first power before any receives
            // the next one. There is no fixed top-24 truncation in this entry point.
            try evaluateAnytime(ordinary, state: state, cue: cue, pockets: pockets,
                                allowed: allowedTargetIDs, minimumPower: minimumPower,
                                clock: clock, accepted: &accepted, permitCushions: includeBanks, phaseDuration: budget.maximumDuration * 0.22)
            if try !accepted.isEmpty || !clock.active() {
                try polishAnytime(&accepted, state: state, allowed: allowedTargetIDs,
                                  minimumPower: minimumPower, clock: clock, permitCushions: includeBanks)
                return report(accepted.isEmpty ? .completed : .solutionFound)
            }
        }
        if includeBanks {
            clock.phases.append("deflections_and_cushions")
            var advanced: [Candidate] = []
            let generationDeadline = clock.elapsed + budget.maximumDuration * 0.16
            // A slow device still evaluates a partial batch and reaches the
            // sweep. Later passes rotate geometry order instead of rebuilding
            // the same prefix forever.
            generation: for target in targets {
                for pocket in pockets {
                    guard try clock.active() else { return report() }
                    if clock.elapsed >= generationDeadline { break generation }
                    for obstacle in rotated(state.balls.filter { !$0.pocketed && $0.id != 0 && $0.id != target.id },
                                            by: budget.explorationPass) {
                        guard try clock.active() else { return report() }
                        if clock.elapsed >= generationDeadline { break generation }
                        advanced += try caromCandidates(state: state, cue: cue, target: target,
                                                         obstacle: obstacle, pocket: pocket, clock: clock, generationDeadline: generationDeadline)
                    }
                    for first in Rail.allCases {
                        guard try clock.active() else { return report() }
                        if clock.elapsed >= generationDeadline { break generation }
                        if let route = routedCandidate(state: state, cue: cue, target: target,
                            pocket: pocket, objectRails: [], cueRails: [first]) { advanced.append(route) }
                        for second in Rail.allCases where second != first {
                            guard try clock.active() else { return report() }
                            if clock.elapsed >= generationDeadline { break generation }
                            for (objectRails, cueRails) in [([first, second], [Rail]()),
                                ([Rail](), [first, second]), ([second], [first])] {
                                if let route = routedCandidate(state: state, cue: cue, target: target,
                                    pocket: pocket, objectRails: objectRails, cueRails: cueRails) { advanced.append(route) }
                            }
                            for third in Rail.allCases where third != second {
                                guard try clock.active() else { return report() }
                                if clock.elapsed >= generationDeadline { break generation }
                                if let route = routedCandidate(state: state, cue: cue, target: target,
                                    pocket: pocket, objectRails: [first, second, third], cueRails: []) { advanced.append(route) }
                            }
                        }
                    }
                }
            }
            try evaluateAnytime(advanced, state: state, cue: cue, pockets: pockets,
                                allowed: allowedTargetIDs, minimumPower: minimumPower,
                                clock: clock, accepted: &accepted, phaseDuration: budget.maximumDuration * 0.42)
            if try !accepted.isEmpty || !clock.active() {
                try polishAnytime(&accepted, state: state, allowed: allowedTargetIDs,
                                  minimumPower: minimumPower, clock: clock, permitCushions: includeBanks)
                return report(accepted.isEmpty ? .completed : .solutionFound)
            }
        }
        clock.phases.append("contact_sweep")
        // This geometric fan intentionally does not reject obstructed target
        // paths. The complete simulation can discover rail/ball combinations
        // that no ideal straight-segment candidate represented.
        let fractions: [Double] = [0] + (1...32).flatMap { index -> [Double] in
            let value = (Double(index) + explorationUnit(budget.explorationPass)) / 33
            return [value, -value]
        }
        var sweep: [Candidate] = []
        for fraction in fractions {
            for target in targets {
                guard try clock.active() else { return report() }
                let delta = target.position - cue.position
                let halfAngle = asin(min(0.999, 2 * state.table.ballRadius / delta.length))
                let angle = atan2(delta.y, delta.x) + fraction * halfAngle
                guard let ghost = impactPoint(from: cue.position, target: target.position,
                                               angle: angle, radius: state.table.ballRadius) else { continue }
                let initialDirection = (target.position - ghost).normalized()
                let cosine = max(0.035, Vector2(x: cos(angle), y: sin(angle)).dot(initialDirection))
                let nearest = pockets.min { target.position.distance(to: $0.center) < target.position.distance(to: $1.center) }!
                sweep.append(Candidate(targetID: target.id, pocketID: nearest.id, method: .carom,
                    targetPosition: target.position, pocketCenter: nearest.center, ghost: ghost,
                    aim: target.position + initialDirection * 10, angle: angle, cutCosine: cosine,
                    cueDistance: delta.length, objectFirstDistance: target.position.distance(to: nearest.center),
                    objectLastDistance: 0, cushionSpeedSquared: 1, geometryCost: 2 + abs(fraction)))
            }
        }
        try evaluateAnytime(sweep, state: state, cue: cue, pockets: pockets, allowed: allowedTargetIDs,
                            minimumPower: minimumPower, clock: clock, accepted: &accepted,
                            anyPocket: true, permitCushions: includeBanks)
        try polishAnytime(&accepted, state: state, allowed: allowedTargetIDs,
                          minimumPower: minimumPower, clock: clock, permitCushions: includeBanks)
        return report(accepted.isEmpty ? .completed : .solutionFound)
    }

    private struct NearMiss {
        let candidate: Candidate
        let shot: ShotParameters
        let distance: Double
    }

    private static func evaluateAnytime(_ input: [Candidate], state: TableState, cue: PoolBall,
                                        pockets: [PoolPocket], allowed: Set<Int>?, minimumPower: Double,
                                        clock: SearchClock, accepted: inout [ShotSuggestion],
                                        anyPocket: Bool = false, permitCushions: Bool = true,
                                        phaseDuration: TimeInterval? = nil) throws {
        let phaseDeadline = clock.elapsed + (phaseDuration ?? clock.budget.maximumDuration)
        func phaseActive() throws -> Bool { try clock.active() && clock.elapsed < phaseDeadline }
        var unique = Set<String>()
        let sorted = input.filter { unique.insert($0.key).inserted }.sorted(by: candidatePrecedes)
        let candidates = diverseCandidates(sorted, limit: max(1, sorted.count))
        clock.candidates += candidates.count
        let powerShift = clock.budget.explorationPass == 0 ? 1 : 0.88 + 0.24 * explorationUnit(clock.budget.explorationPass)
        let samples = candidates.map { powerSamples(for: $0, table: state.table, minimumPower: minimumPower)
            .map { min(1, max(minimumPower, $0 * powerShift)) } }
        var misses: [NearMiss] = []
        var found = Set<String>()
        func consider(_ candidate: Candidate, angle: Double, power: Double) throws {
            let shot = try executableShot(angle: angle, power: power, minimumPower: minimumPower, table: state.table)
            guard let result = try clock.simulate(state, shot, targetID: candidate.targetID) else { return }
            // The same exact command may appear in several geometric candidates.
            // Accept its actual pocket if allowed by the caller, so de-duplication
            // cannot discard a valid result merely seeded for another pocket.
            let requested = pockets
            if let pocket = requested.first(where: {
                isValidOutcome(result, targetID: candidate.targetID, pocketID: $0.id, allowedTargetIDs: allowed)
            }) {
                let method = actualMethod(result, targetID: candidate.targetID, pocketID: pocket.id)
                guard permitCushions || !hasRouteCushions(result, targetID: candidate.targetID, pocketID: pocket.id),
                      let ghost = actualGhost(candidate, cue: cue.position, angle: shot.angleRadians, table: state.table) else { return }
                accepted.append(ShotSuggestion(targetID: candidate.targetID, pocketID: pocket.id, method: method,
                    shot: shot, ghostBall: ghost, aimPoint: candidate.aim,
                    score: candidate.geometryCost + 6 * shot.power, result: result))
                found.insert(candidate.key)
            } else if firstObjectContact(result) == candidate.targetID,
                      let target = result.finalState.balls.first(where: { $0.id == candidate.targetID }), !target.pocketed {
                let distance = requested.map { target.position.distance(to: $0.center) }.min() ?? .infinity
                misses.append(NearMiss(candidate: candidate, shot: shot, distance: distance))
            }
        }
        for powerIndex in 0..<maximumPowerSamples {
            for (index, candidate) in candidates.enumerated() {
                guard try phaseActive() else { return }
                guard !found.contains(candidate.key), powerIndex < samples[index].count else { continue }
                try consider(candidate, angle: candidate.angle, power: samples[index][powerIndex])
            }
            // Keep the first validated commands available before exploring
            // expensive alternatives. Refinement below still verifies gentler
            // power before declaring solutionFound.
            if !accepted.isEmpty { return }
        }
        misses.sort { $0.distance < $1.distance }
        // Endpoint-guided local search explores wider and finer angles than V13,
        // with several nearby powers. Round-robin targets prevent one near miss
        // from monopolizing the entire local-refinement allowance.
        var selected: [NearMiss] = []
        var routeKeys = Set<String>()
        for miss in misses where routeKeys.insert(miss.candidate.key).inserted {
            selected.append(miss)
            if selected.count == 48 { break }
        }
        let angleScale = clock.budget.explorationPass == 0 ? 1 : 0.7 + explorationUnit(clock.budget.explorationPass)
        let angles = [0.001, -0.001, 0.003, -0.003, 0.007, -0.007, 0.015, -0.015, 0.03, -0.03].map { $0 * angleScale }
        for scale in [1.0, 0.96, 1.04, 0.88, 1.12] {
            for offset in angles {
                for miss in selected {
                    guard try phaseActive() else { return }
                    guard !found.contains(miss.candidate.key) else { continue }
                    try consider(miss.candidate, angle: miss.shot.angleRadians + offset,
                                 power: min(1, max(minimumPower, miss.shot.power * scale)))
                }
                if !accepted.isEmpty { return }
            }
        }
    }

    private static func rotated<T>(_ values: [T], by offset: Int) -> [T] {
        guard !values.isEmpty else { return values }
        let index = offset % values.count
        return Array(values[index...]) + Array(values[..<index])
    }

    private static func explorationUnit(_ pass: Int) -> Double {
        var bits = max(0, pass), place = 0.5, value = 0.0
        while bits > 0 { value += Double(bits & 1) * place; bits >>= 1; place *= 0.5 }
        return value
    }

    private static func hasRouteCushions(_ result: ShotResult, targetID: Int, pocketID: Int) -> Bool {
        var contacted = false
        for event in result.events {
            if event == .pocket(ball: targetID, pocket: pocketID) { break }
            if event == .cushion(ball: targetID) || (!contacted && event == .cushion(ball: 0)) { return true }
            if case let .ballCollision(first, second) = event, first == 0 || second == 0 { contacted = true }
        }
        return false
    }

    private static func actualMethod(_ result: ShotResult, targetID: Int, pocketID: Int) -> ShotMethod {
        var cueRails = 0, objectRails = 0
        var contacted = false, deflected = false
        for event in result.events {
            if event == .pocket(ball: targetID, pocket: pocketID) { break }
            if event == .cushion(ball: 0), !contacted { cueRails += 1 }
            if event == .cushion(ball: targetID) { objectRails += 1 }
            if case let .ballCollision(first, second) = event {
                if first == 0 || second == 0 { contacted = true }
                else if first == targetID || second == targetID { deflected = true }
            }
        }
        if deflected { return .carom }
        if cueRails == 0 && objectRails == 0 { return .direct }
        if cueRails == 0 && objectRails == 1 { return .bank }
        if cueRails == 0 && objectRails == 2 { return .doubleBank }
        if cueRails == 1 && objectRails == 0 { return .kick }
        return .multiCushion
    }

    private static func polishAnytime(_ accepted: inout [ShotSuggestion], state: TableState,
                                       allowed: Set<Int>?, minimumPower: Double, clock: SearchClock, permitCushions: Bool) throws {
        guard !accepted.isEmpty else { return }
        accepted.sort { $0.score < $1.score }
        // Retain every original valid command if the deadline arrives midway.
        for index in 0..<min(3, accepted.count) {
            guard try clock.active() else { return }
            let original = accepted[index]
            var best = original
            var low = minimumPower
            for _ in 0..<6 {
                guard try clock.active() else { accepted[index] = best; return }
                let probe = try executableShot(angle: best.shot.angleRadians,
                    power: (low + best.shot.power) / 2, minimumPower: minimumPower, table: state.table)
                guard probe.power > low + 1e-9, probe.power < best.shot.power - 1e-9 else { break }
                guard let result = try clock.simulate(state, probe, targetID: best.targetID) else { continue }
                if isValidOutcome(result, targetID: best.targetID, pocketID: best.pocketID, allowedTargetIDs: allowed),
                   permitCushions || !hasRouteCushions(result, targetID: best.targetID, pocketID: best.pocketID) {
                    best = ShotSuggestion(targetID: best.targetID, pocketID: best.pocketID,
                        method: actualMethod(result, targetID: best.targetID, pocketID: best.pocketID), shot: probe,
                        ghostBall: best.ghostBall, aimPoint: best.aimPoint,
                        score: original.score - 6 * (original.shot.power - probe.power), result: result)
                } else { low = probe.power }
            }
            // A speed reserve is never inferred. Only replace the softer shot
            // when the exact reserve command also survives the complete engine.
            let reserve = try executableShot(angle: best.shot.angleRadians,
                power: min(original.shot.power, best.shot.power * 1.035), minimumPower: minimumPower, table: state.table)
            if let result = try clock.simulate(state, reserve, targetID: best.targetID),
               isValidOutcome(result, targetID: best.targetID, pocketID: best.pocketID, allowedTargetIDs: allowed),
                   permitCushions || !hasRouteCushions(result, targetID: best.targetID, pocketID: best.pocketID) {
                best = ShotSuggestion(targetID: best.targetID, pocketID: best.pocketID,
                    method: actualMethod(result, targetID: best.targetID, pocketID: best.pocketID), shot: reserve,
                    ghostBall: best.ghostBall, aimPoint: best.aimPoint,
                    score: original.score - 6 * (original.shot.power - reserve.power), result: result)
            }
            accepted[index] = best
        }
    }

    /// Locate the two tangential deflection families of a stationary object.
    /// Root finding includes the configured restitution; it is a seed only.
    /// The full engine decides the cue follow-through, every collision, pockets,
    /// and whether the same legal target reaches the nominated pocket.
    private static func caromCandidates(state: TableState, cue: PoolBall, target: PoolBall,
                                          obstacle: PoolBall, pocket: PoolPocket, clock: SearchClock, generationDeadline: TimeInterval) throws -> [Candidate] {
        let table = state.table, diameter = 2 * state.table.ballRadius
        let transfer = (1 + table.ballRestitution) / 2
        var result: [Candidate] = []
        // Include an object cushion before its glancing collision. This covers
        // the video pattern: legal red -> top rail -> black -> same red potted.
        for rail: Rail? in [nil] + Rail.allCases.map(Optional.some) {
            func deflection(_ angle: Double) -> (point: Vector2, bank: Vector2?, outgoing: Vector2, error: Double)? {
                let normal = Vector2(x: cos(angle), y: sin(angle))
                let point = obstacle.position + normal * diameter
                let bank: Vector2?
                if let rail {
                    guard let contact = bankContact(from: target.position, to: point, rail: rail, table: table) else { return nil }
                    bank = contact
                } else { bank = nil }
                let incoming = (point - (bank ?? target.position)).normalized()
                guard incoming.dot(normal) < -0.015 else { return nil }
                let outgoing = incoming - normal * (transfer * incoming.dot(normal))
                let desired = (pocket.aimPoint - point).normalized()
                guard outgoing.dot(desired) > 0.03 else { return nil }
                return (point, bank, outgoing, outgoing.x * desired.y - outgoing.y * desired.x)
            }
            let step = 2 * Double.pi / 96
            for index in 0..<96 {
                guard try clock.active(), clock.elapsed < generationDeadline else { return result }
                var left = Double(index) * step, right = Double(index + 1) * step
                guard let start = deflection(left), let end = deflection(right), start.error * end.error <= 0 else { continue }
                var leftError = start.error
                for _ in 0..<22 {
                    let mid = (left + right) / 2
                    guard let sample = deflection(mid) else { break }
                    if leftError * sample.error <= 0 { right = mid }
                    else { left = mid; leftError = sample.error }
                }
                guard let solution = deflection((left + right) / 2), abs(solution.error) < 0.00001,
                      isInside(solution.point, table: table) else { continue }
                let firstAim = solution.bank ?? solution.point
                let direction = (firstAim - target.position).normalized()
                let ghost = target.position - direction * diameter
                guard isInside(ghost, table: table) else { continue }
                let incoming = ghost - cue.position
                let cosine = incoming.normalized().dot(direction)
                guard cosine > 0.04 else { continue }
                let all = state.balls.filter { !$0.pocketed && $0.id != 0 && $0.id != target.id }
                let others = all.filter { $0.id != obstacle.id }
                guard clearRoute(from: cue.position, to: ghost, obstacles: all, radius: table.ballRadius),
                      clearRoute(from: target.position, to: firstAim, obstacles: others, radius: table.ballRadius),
                      clearRoute(from: solution.bank ?? target.position, to: solution.point, obstacles: others, radius: table.ballRadius),
                      clearRoute(from: solution.point, to: pocket.aimPoint, obstacles: others, radius: table.ballRadius),
                      table.nativeGeometry != nil
                        ? BilliardsEngine.directPocketPathClear(from: solution.point, pocket: pocket, table: table)
                        : canEnterPocket(from: solution.point, pocket: pocket.center, table: table) else { continue }
                var firstDistance = target.position.distance(to: firstAim)
                if let bank = solution.bank { firstDistance += bank.distance(to: solution.point) }
                let lastDistance = solution.point.distance(to: pocket.aimPoint)
                let retained = max(0.002, solution.outgoing.lengthSquared)
                var objectWork = firstDistance + lastDistance / retained
                if let rail {
                    let normal = rail == .left || rail == .right ? direction.x : direction.y
                    objectWork /= max(0.05, 1 - normal * normal * (1 - table.cushionRestitution * table.cushionRestitution))
                }
                let speedSquared = 2 * table.rollingDeceleration *
                    (incoming.length + objectWork / pow(transfer * cosine, 2))
                result.append(Candidate(targetID: target.id, pocketID: pocket.id, method: .carom,
                    targetPosition: target.position, pocketCenter: pocket.center, ghost: ghost, aim: firstAim,
                    angle: atan2(incoming.y, incoming.x), cutCosine: cosine, cueDistance: incoming.length,
                    objectFirstDistance: firstDistance, objectLastDistance: lastDistance,
                    cushionSpeedSquared: retained,
                    geometryCost: 1.1 + (incoming.length + firstDistance + lastDistance) / table.width,
                    requiredPowerEstimate: sqrt(speedSquared) / table.maximumShotSpeed))
            }
        }
        return result
    }
}
