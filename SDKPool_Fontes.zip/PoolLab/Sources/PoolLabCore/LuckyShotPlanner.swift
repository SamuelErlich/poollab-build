import Foundation

public struct LuckyShotSuggestion: Sendable {
    /// Linear simulation power. Convert before writing the game's cue control.
    public let shot: ShotParameters
    public let result: ShotResult
    public let finalDistance: Double
}

/// Bounded search for stopping the golden ball near the observed target.
/// Suggestions that touch an obstacle are rejected: its special collision
/// response has not been established for this game build. No prize guarantee.
public enum LuckyShotPlanner {
    public static let maximumSimulations = 240

    public static func suggestion(
        for state: TableState,
        targetBallID: Int,
        targetCenter: Vector2,
        obstacleIDs: Set<Int> = []
    ) throws -> LuckyShotSuggestion? {
        try Task.checkCancellation()
        try BilliardsEngine.validate(state)
        let activeIDs = Set(state.balls.filter { !$0.pocketed }.map(\.id))
        guard targetBallID != 0, targetCenter.isFinite,
              (0...state.table.width).contains(targetCenter.x),
              (0...state.table.height).contains(targetCenter.y),
              obstacleIDs.isSubset(of: activeIDs),
              !obstacleIDs.contains(0), !obstacleIDs.contains(targetBallID),
              let cue = state.cueBall,
              let target = state.balls.first(where: { $0.id == targetBallID && !$0.pocketed }) else {
            throw BilliardsError.invalidBalls
        }
        let initialDistance = target.position.distance(to: targetCenter)
        guard initialDistance > state.table.ballRadius * 0.05 else { return nil }
        let desired = (targetCenter - target.position).normalized()
        let ghost = target.position - desired * (2 * state.table.ballRadius)
        let ghostVector = ghost - cue.position
        let targetVector = target.position - cue.position
        guard ghostVector.length > 1e-8, targetVector.length > 2 * state.table.ballRadius else { return nil }
        let ghostAngle = atan2(ghostVector.y, ghostVector.x)
        let centerAngle = atan2(targetVector.y, targetVector.x)
        let halfAngle = asin(min(1, (2 * state.table.ballRadius - 1e-6) / targetVector.length))
        var angles = [-0.6, 0, 0.6].map { ghostAngle + $0 * .pi / 180 }
        angles += [-0.9, -0.45, 0, 0.45, 0.9].map { centerAngle + halfAngle * $0 }
        var best: LuckyShotSuggestion?
        var simulations = 0

        func evaluate(angle: Double, power: Double) throws {
            try Task.checkCancellation()
            guard simulations < maximumSimulations, power > 0, power <= 1 else { return }
            simulations += 1
            let shot = ShotParameters(angleRadians: angle, power: power)
            let result = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false)
            guard isUsable(result, targetID: targetBallID, obstacleIDs: obstacleIDs),
                  let final = result.finalState.balls.first(where: { $0.id == targetBallID }) else { return }
            let distance = final.position.distance(to: targetCenter)
            guard distance < initialDistance else { return }
            if let prior = best {
                guard distance < prior.finalDistance - 1e-8 ||
                    (abs(distance - prior.finalDistance) <= 1e-8 && power < prior.shot.power) else { return }
            }
            best = LuckyShotSuggestion(shot: shot, result: result, finalDistance: distance)
        }

        // A coarse pass covers the full power range, including low-power cuts.
        let powers = (1...20).map { Double($0) / 20 }
        for angle in angles {
            for power in powers { try evaluate(angle: angle, power: power) }
        }
        if let coarse = best {
            for angleIndex in -3...3 {
                for powerIndex in -5...5 {
                    try evaluate(angle: coarse.shot.angleRadians + Double(angleIndex) * .pi / 900,
                                 power: coarse.shot.power + Double(powerIndex) * 0.01)
                }
            }
        }
        guard let selected = best else { return nil }
        try Task.checkCancellation()
        let recorded = try BilliardsEngine.simulate(state: state, shot: selected.shot, recordFrames: true)
        guard isUsable(recorded, targetID: targetBallID, obstacleIDs: obstacleIDs) else { return nil }
        return LuckyShotSuggestion(shot: selected.shot, result: recorded, finalDistance: selected.finalDistance)
    }

    static func isUsable(_ result: ShotResult, targetID: Int, obstacleIDs: Set<Int>) -> Bool {
        guard result.settled, !result.scratched,
              result.finalState.balls.contains(where: { $0.id == targetID && !$0.pocketed }) else { return false }
        var firstCueContact: Int?
        for event in result.events {
            if case let .ballCollision(a, b) = event {
                if obstacleIDs.contains(a) || obstacleIDs.contains(b) { return false }
                if firstCueContact == nil {
                    if a == 0 { firstCueContact = b }
                    else if b == 0 { firstCueContact = a }
                }
            }
        }
        return firstCueContact == targetID
    }
}
