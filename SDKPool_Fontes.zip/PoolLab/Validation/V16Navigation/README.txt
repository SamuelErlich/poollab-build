SDKPool V16: diagnóstico de navegação

API: +[PLQueueBridge diagnosticSnapshot], Swift PLQueueBridge.diagnosticSnapshot().
Retorna NSDictionary serializável em JSON. Deve ser chamado na thread principal.
Não chama capture/captureNavigation, não renova tokens, não consome ações e não envia toques.

Campos principais:
schemaVersion: 1.
guards: app ativa, bundle/build/executável exatos, thread principal/rendering.
native: inicialização/ABI de MainManager, MenuManager e GameManager, examinados independentemente.
mainState: isInGame/isInMenu com valores e ABI.
menuState: classe atual e resultado independente de getCurrentMenuState.
result: mState, _isMatchEnding, animações, pedidos/revanche, desafio/aposta e campos MatchInfo; sem ID/tier/token.
controls: visível/executando/habilitado, ABI de voltar, seletor, célula atual e estado touch/spring/center.
modal/uiKit: somente classes/estados de janelas e controladores; detalhes do botão fechar apenas para news conhecida.
latches: presença e consumo booleanos, sem valores de tokens.
issues: até 48 falhas com scope, code, reason fixo, incluindo incompatibilidade de assinatura/campo.

Limites: 12 janelas, 8 controladores por janela, classe com até 160 caracteres, encoding até 192.
Não registra texto, accessibility label/value, credenciais, clipboard, URL nem ID de partida.
Uma falha de MainManager/GameManager não impede a tentativa de getCurrentMenuState se MenuManager estiver válido.
Falha geral de ambiente/thread impede acesso nativo; o retorno conserva o motivo, sem tentar burlar o gate.

Correção restrita: notícias conhecidas são observadas antes da captura legacy do resultado.
Uma incompatibilidade de resultado/tier não bloqueia mais o fechamento de uma notícia reconhecida.
Captura legacy permanece obrigatória no ramo real de MenuPlayerMatch antes de preparar backToMaps.
O bloco inteiro de PLQCaptureResult e a API de envio da navegação são idênticos aos da V15.
Não foram acrescentados novos seletores de ação, telas conhecidas nem cliques por coordenada.
A janela PLInteractionRingWindow é excluída explicitamente do scanner de modais; demais overlays mantêm o bloqueio.

Validação: 31 contratos de fonte e análise sintática ARM64 ARC com fixtures de declarações.
Não é compilação Apple SDK e não confirma funcionamento no iPhone.
O bloqueio por dependência legacy existe no código; o motivo exato no aparelho precisa do relatório gravado.
