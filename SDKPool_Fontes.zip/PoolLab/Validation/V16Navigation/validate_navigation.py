#!/usr/bin/env python3
"""Targeted source-contract regression checks. Not native runtime tests."""
from pathlib import Path
import hashlib, json, re

here = Path(__file__).resolve().parent
project = here.parents[1]
source_path = project/'Integrated/PLQueueBridge.m'
header_path = project/'Integrated/PLQueueBridge.h'
s = source_path.read_text()
h = header_path.read_text()
baseline = (project/'Validation/V15Navigation/NavigationSyntax.m').read_text()
sha = lambda value: hashlib.sha256(value).hexdigest()
checks = []
def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
def block(text, start, end):
    return text[text.index(start):text.index(end,text.index(start))]
result = block(s, 'static PLQueueSnapshot *PLQCaptureResult(', '// V15 metadata')
base_result = block(baseline, 'static PLQueueSnapshot *PLQCaptureResult(', '// V15 metadata')
nav = block(s, 'static PLQueueSnapshot *PLQCaptureNavigation(', '// V16 diagnostics')
diag = block(s, '// V16 diagnostics', '@implementation PLQueueBridge')
public = s[s.index('@implementation PLQueueBridge'):]
legacy_syntax=json.loads((project/'Validation/V15NavigationSyntax.json').read_text())
check('Completed-result guard and legacy queue capture byte-preserved', sha(result.encode()) == legacy_syntax['exactBlockSHA256']['captureResult'])
check('Original public navigation mutation implementation byte-preserved',
      sha(s[s.index('+ (PLQueueSnapshot *)captureNavigationWithError:'):s.rindex('@end')].encode()) == legacy_syntax['exactBlockSHA256']['mutationAPI'])
check('Diagnostic API exported with stable Swift name',
      'NS_SWIFT_NAME(diagnosticSnapshot())' in h)
check('Diagnostics cannot call stateful captures', not re.search(r'PLQCapture(?:Result|Navigation)?\s*\(', diag))
check('Diagnostics cannot call navigation token helpers',
      not re.search(r'PLQ(?:ObserveNavigationScene|NavigationReady|NavigationFailure)\s*\(',diag))
check('Diagnostics never assign bridge global bookkeeping',
      not re.search(r'\bPLQ(?:Observed\w+|ResultToken|Consumed|ResultInfo|Navigation\w+)\s*=(?!=)',diag))
check('Diagnostics do not invoke action selectors', all(
      not re.search(r'(?:PLQObject|PLQBool|PLQInt)\([^\n]+@"'+name+'"',diag)
      for name in ['startSingleMatch:', 'backButtonCallback', 'dismissNewsfeed:', 'exitButtonCallback', 'tierButtonCallback', 'itemPressed:']))
check('Diagnostics have no touch dispatch or runtime writes', all(x not in diag for x in
      ['sendAction:', 'sendEvent:', 'setValue:', 'setObject:forKey:', 'object_setIvar', 'method_setImplementation', 'memcpy(', 'vm_write(', 'performSelector:']))
check('No raw match identity or result token exported', not re.search(
      r'[@]["].+?["].*:\s*(?:PLQObservedMatchID|PLQObservedTier|PLQResultToken|PLQNavigationToken)\b',diag))
check('Match/tier accessors ABI only in diagnostics',
      'PLQDObject(game, @"matchId"' not in diag and
      'NSSelectorFromString(@"tierCode")' not in diag)
check('No UIKit text/credentials/URLs captured', all(x not in diag for x in
      ['.text', '.attributedText', '.accessibilityLabel', '.accessibilityValue', '.URL', '.absoluteString', '.description', 'UIPasteboard']))
check('Native data reads require main thread first',
      diag.index('if (![NSThread isMainThread])') < diag.index('report[@"latches"]'))
check('Native data reads require verified build and render thread',
      diag.index('if (!active || !build || !executable)') < diag.index('id director =') and
      diag.index('if (!renderThread)') < diag.index('id main = PLQDSingleton'))
check('Current menu independent of result/main/game failure',
      'id screen = menu ? PLQDObject(menu, @"getCurrentMenuState"' in diag)
check('Per-method ABI mismatch retained with expected and actual types',
      all(x in diag for x in ['@"abiMatches"', '@"expectedEncoding"', '@"actualEncoding"', 'PLQDIssue(issues, [NSString stringWithFormat:@"%@.%@", scope, name], error)']))
check('Result fields independently queried after each failed ivar read',
      'for (NSString *name in @[@"_isMatchEnding"' in diag and 'PLQDReadBool(screen, @"MenuPlayerMatch", name.UTF8String' in diag)
check('Back control enabled visibility and action ABI observed',
      'controls[@"back"] = PLQDNode(back, YES' in diag and 'PLQDMethod(screen, @"backButtonCallback"' in diag)
check('Map selector touch/spring/center state observed', all(x in diag for x in
      ['@"mNumCurrentTouches"', '@"mIsOnSpring"', '@"centerRatio"', '@"getCellForCurrentOffset"']) or
      all(x in diag for x in ['"mNumCurrentTouches"', '"mIsOnSpring"', '@"centerRatio"', '@"getCellForCurrentOffset"']))
check('Known news close state observed without action',
      'modal[@"close"]' in diag and 'PLQDMethod(news, @"dismissNewsfeed:"' in diag)
check('Snapshot payload bounded', all(x in diag for x in
      ['issues.count >= 48', 'name.length > 160', 'type.length > 192', 'seen++ >= 12', 'depth < 8']))
check('Nonfinite center ratio never exported as JSON number',
      'if (isfinite(ratio)) cellFields[@"centerRatio"] = @(ratio);' in diag)
check('Exception description never exported',
      'exception.reason' not in diag + public and 'exception.description' not in diag + public)
check('Known modal checked before legacy result observation',
      nav.index('UIViewController *news = PLQPresentedController') < nav.index('PLQCaptureResult('))
check('Ongoing match observation retained before queue rearm',
      nav.index('snapshot = PLQCaptureResult(YES') < nav.index('PLQNavigationQueueConsumed = NO'))
check('Result back still requires legacy resultReady plus interactability',
      nav.index('if (!resultReady)') < nav.index('if (!PLQMenuInteractable(screen, error))') < nav.index('@"backToMaps"'))
check('Only result and ongoing-match branches use legacy result capture', nav.count('PLQCaptureResult(YES') == 2)
check('Matchmaking latch rejection retained', 'if (PLQNavigationQueueConsumed || PLQConsumed)' in nav)
check('Own pending result flags preserved in legacy result capture',
      'if (challenge || betSelection || requested || (!leavingResult && (opponentRequested || pendingProposal)))' in result)
check('Exact recorder window excluded, other overlay behavior retained',
      s.count('[NSStringFromClass(window.class) isEqual:@"PLInteractionRingWindow"]') == 1 and
      'if (window.windowLevel != UIWindowLevelNormal) { *blocked = YES; modalCount++; continue; }' in s)
check('Diagnostic ring exclusion exact class in report scan',
      '[cls isEqual:@"PLInteractionRingWindow"]' in diag)
syntax=json.loads((project/'Validation/V16NavigationSyntax.json').read_text())
check('Final source bound to passed ARC syntax report', syntax['result']=='passed' and
      syntax['sourceSHA256']['Integrated/PLQueueBridge.m']==sha(s.encode()) and
      syntax['sourceSHA256']['Integrated/PLQueueBridge.h']==sha(h.encode()))
report={'format':'SDKPool.V16.NavigationSourceValidation','result':'passed' if all(x['passed'] for x in checks) else 'failed',
 'checkCount':len(checks),'checks':checks,'sourceSHA256':{'Integrated/PLQueueBridge.m':sha(s.encode()),'Integrated/PLQueueBridge.h':sha(h.encode())},
 'protectedResultSHA256':sha(result.encode()),
 'limitations':['Source-contract checks and declaration-only ARC syntax, not iPhone runtime execution.',
 'The misplaced legacy-result dependency is established by source; it is not confirmed as the device failure without a captured report.',
 'No new screen types, coordinates or actions inferred. Completed-result and uncertain queue protections remain.']}
(project/'Validation/V16NavigationSourceValidation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':report['result'],'checkCount':len(checks),'failed':[x['name'] for x in checks if not x['passed']]}))
raise SystemExit(0 if report['result']=='passed' else 1)
