"""Extract unedited production automation members; supply native/UI mocks only."""
from pathlib import Path
import hashlib, json, os, re

here = Path(__file__).resolve().parent
root = here.parent.parent
out = Path(os.environ.get('SDKPOOL_V15_VALIDATION_OUT', '/workspace/scratch/93d3b09386b0/sdkpool-validation/automation'))
out.mkdir(parents=True, exist_ok=True)
s = (root / 'Integrated/IntegratedGameModel.swift').read_text()

def member(name, kind='func'):
    m = re.search(r'^    (?:private |static )*' + kind + ' ' + re.escape(name) + r'\b[^\n]*', s, re.M)
    if not m:
        raise RuntimeError('Missing production declaration: ' + name)
    return s[m.start():s.index('\n    }', m.start()) + 6]

names = ['setAutoAimEnabled', 'setAutoPlay', 'toggleAutomationPause',
         'resetAutomaticPlan', 'advanceAutomation', 'advanceAutomaticControlSequence',
         'hasNativeControlTouch', 'controlAngleDelta', 'smoothControlFraction',
         'cancelAutomaticControlSequence', 'execute', 'acknowledgeShotProgress',
         'waitAutomation', 'deferAutomaticActions', 'stopAutomation',
         'handleCaptureFailure', 'panelOpened', 'panelClosed', 'cancelPlanner',
         'pauseAutomationForUnsupportedMotion', 'isFreshSample', 'clearBoard',
         'setAutoQueue', 'pollQueue', 'setAutoPlayMode', 'updateAutomationClock',
         'becameInactive', 'becameActive', 'authorizationChanged']
structs = ['AutomaticContext', 'AutomaticPlan', 'AutomaticControlSequence', 'QueueTransition']
variables = ['currentAutomaticContext', 'canPreserveAutomationIntent']
header = (here / 'MockHeader.swift.txt').read_text()
parts = [member(n) for n in names] + [member(n, 'struct') for n in structs] + [member(n, 'var') for n in variables]
tests = (here / 'Tests.swift.txt').read_text()
(out / 'V15SmoothAutomationHarness.swift').write_text(header + '\n\n'.join(parts) + '\n' + tests)
digest = lambda text: hashlib.sha256(text.encode()).hexdigest()
(out / 'ExtractedMethods.json').write_text(json.dumps({
    'sourceSHA256': digest(s),
    'methods': {n: digest(member(n)) for n in names},
    'structs': {n: digest(member(n, 'struct')) for n in structs},
    'variables': {n: digest(member(n, 'var')) for n in variables},
    'note': 'Exact production members; native and UI I/O mocked. No Apple SDK or iPhone runtime.'
}, indent=2) + '\n')
