from pathlib import Path
import runpy,json,hashlib
v=runpy.run_path(str(Path(__file__).resolve().with_name('build_harness.py')))
out=v['out']
s=(out/'V15SmoothAutomationHarness.swift').read_text()
s=s.replace('final class IntegratedGameModel {','@MainActor\nfinal class IntegratedGameModel {')
s=s.replace('var plannerTask: MockTask?','var plannerTask: Task<Void,Never>?')
s=s.replace('    var isBreakShot = false','    var isBreakShot = false\n    var minimumShotPower = 0.01',1)
s=s.replace('''    var canEnableAutoAim = true, canEnableAutoPlay = true''','''    var canEnableAutoAim = true, canEnableAutoPlay = true
    var canRecommend = true
    var planningMilliseconds = 0.0
    var suggestionIsBreakShot = false
    func setPreview(_ shot: ShotParameters) -> Bool { true }
    func applyAim() {}''')
stub='    func startPlanning(_ purpose: PlanningPurpose) { planRequests.append(purpose); isPlanning = true; planningPurpose = purpose }'
s=s.replace(stub,'\n'.join(v['member'](n) for n in ['startPlanning','accepts','acceptsPlan','minimumPlannerPower']))
s=s.replace('\ntry IntegratedGameModel.run()','')
ix=s.rindex('\n}')
s=s[:ix]+r'''
    static func awaitPlanner(_ model: IntegratedGameModel) async throws {
        let deadline = ProcessInfo.processInfo.systemUptime + 15
        while ProcessInfo.processInfo.systemUptime < deadline {
            if !model.isPlanning {
                guard let plan = model.automaticPlan, !plan.aimApplied, plan.controlSequence == nil else { return }
                model.advanceAutomation()
                if model.automaticPlan?.controlSequence != nil { return }
            }
            try await Task.sleep(nanoseconds:10_000_000)
        }
        expect(false, "planner and confirmation finished before harness deadline")
    }
    static func runAsync() async throws {
        let model = fixture(); model.setAutoPlay(true)
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); expect(model.isPlanning,"actual detached planner starts")
        let generation = model.plannerGeneration
        model.toggleAutomationPause(); expect(model.plannerGeneration > generation,"pause invalidates pending planner generation")
        expect(model.lastPlanningSearch["state"] as? String == "cancelled","cancelled stage reports cancellation")
        try await Task.sleep(nanoseconds:100_000_000)
        expect(PLRuntimeBridge.aims.isEmpty && PLRuntimeBridge.shoots.isEmpty,"cancelled planner cannot start controls")
        model.toggleAutomationPause(); model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); try await awaitPlanner(model)
        expect(!model.isPlanning && model.automaticPlan?.controlSequence != nil && PLRuntimeBridge.shoots.isEmpty,"accepted real planner begins gradual controls without immediate shot")
        expect(model.automaticPlan?.suggestion.id == model.suggestions.first?.id,"gradual sequence owns real top-ranked exact solution")
        expect((model.lastPlanningSearch["simulations"] as? Int ?? 0) > 0 && (model.lastPlanningSearch["candidates"] as? Int ?? 0) > 0,"accepted planner exports real simulation and candidate counts")
        expect(!(model.lastPlanningSearch["phases"] as? [String] ?? []).isEmpty && model.lastPlanningSearch["termination"] is String,"search phases and exact stop reason are retained")
        expect(model.lastPlanningSearch["maximumDurationMs"] as? Double == ShotSearchBudget.automatic.maximumDuration * 1_000 && model.lastPlanningSearch["maximumSimulations"] as? Int == ShotSearchBudget.automatic.maximumSimulations,"automatic operation forwards explicit shared search budget")
        expect(model.lastPlanningSearch["turnRemainingTimeAvailable"] as? Bool == false,"no native turn countdown is invented")
        model.finish(); expect(PLRuntimeBridge.shoots.count == 1,"real planning to staged controls ends in one release")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.tableState!.balls[1].position.x += 5; model.snapshot!.state = model.tableState!; PLRuntimeBridge.snapshot = model.snapshot
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); try await awaitPlanner(model)
        expect(PLRuntimeBridge.shoots.count == 1 && model.automaticPlan?.controlSequence != nil,"second board gets a new full gradual sequence")
        model.finish(); expect(PLRuntimeBridge.shoots.count == 2,"two actual-planner turns complete continuously")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1; model.advanceAutomation()
        model.tableState!.balls[1].position.x += 5
        let applied = PLRuntimeBridge.aims.count
        try await awaitPlanner(model)
        expect(PLRuntimeBridge.aims.count == applied && PLRuntimeBridge.shoots.count == 2 && model.captureEvents.contains("planningDiscarded"),"changed-board completion cannot start a stale sequence")
        expect(model.lastPlanningSearch["state"] as? String == "discarded","stale result remains diagnostic only")

        let background = fixture(); background.setAutoPlay(true)
        background.stableSince = ProcessInfo.processInfo.systemUptime - 1
        background.advanceAutomation(); background.becameInactive()
        try await Task.sleep(nanoseconds:100_000_000)
        expect(background.autoPlayEnabled && background.autoQueueEnabled && !background.isAuthorized && !background.isPlanning && PLRuntimeBridge.shoots.isEmpty, "suspension cancels pending worker while preserving user intent")
        background.becameActive()
        try await Task.sleep(nanoseconds:50_000_000)
        expect(background.isAuthorized && background.autoPlayEnabled && !background.automationPaused, "foreground session refresh restores authorization without another toggle")
        let freshBoard = fixture()
        background.tableState = freshBoard.tableState; background.snapshot = freshBoard.snapshot
        background.hasTable = true; background.isPlayerTurn = true; background.isCalibrated = true
        background.hasNativePhysics = true; background.shotInputSupported = true; background.runtimeCanShoot = true
        background.captureHealthy = true; background.aimAvailable = true; background.autoShotAvailable = true; background.legalTargets = [1]
        background.automaticRetryAfter = 0
        background.stableSince = ProcessInfo.processInfo.systemUptime - 1
        background.advanceAutomation(); try await awaitPlanner(background); background.finish()
        expect(PLRuntimeBridge.shoots.count == 1, "foreground recovery plans from fresh board and releases once without re-enabling")

        let noRoute = fixture(); noRoute.setAutoPlay(true)
        noRoute.legalTargets = [3]; noRoute.snapshot!.legalTargetNumbers = [3]; PLRuntimeBridge.snapshot = noRoute.snapshot
        noRoute.stableSince = ProcessInfo.processInfo.systemUptime - 1
        noRoute.advanceAutomation(); try await awaitPlanner(noRoute)
        expect(noRoute.suggestions.isEmpty && noRoute.automaticSearchContext == noRoute.currentAutomaticContext,"completed empty search retains exact retry context")
        let requests = noRoute.captureEvents.filter { $0 == "planningStarted" }.count
        for _ in 0..<180 { noRoute.advanceAutomation() }
        expect(!noRoute.isPlanning && noRoute.captureEvents.filter { $0 == "planningStarted" }.count == requests && PLRuntimeBridge.shoots.isEmpty,"empty unchanged board waits through cooldown without repeated search or forced shot")
        expect(noRoute.lastPlanningSearch["state"] as? String == "completed" && noRoute.lastPlanningSearch["solutions"] as? Int == 0,"empty completed result retained for exported diagnostics")
        expect(noRoute.automaticSearchPass == 1 && noRoute.autoPlayEnabled && !noRoute.automationPaused,"empty initial pass advances exploration without pausing")
        noRoute.automaticSearchRetryAt = 0
        noRoute.advanceAutomation()
        for _ in 0..<180 { noRoute.advanceAutomation() }
        expect(noRoute.captureEvents.filter { $0 == "planningStarted" }.count == requests + 1,"expired cooldown starts only one worker despite repeated frames")
        try await awaitPlanner(noRoute)
        expect(noRoute.lastPlanningSearch["explorationPass"] as? Int == 1 && noRoute.automaticSearchPass == 2,"next bounded worker explores a different pass")
        noRoute.toggleAutomationPause(); noRoute.automaticSearchRetryAt = 0; noRoute.advanceAutomation()
        expect(!noRoute.isPlanning && noRoute.automationPaused,"explicit pause blocks all further search")
        noRoute.toggleAutomationPause()
        noRoute.stableSince = ProcessInfo.processInfo.systemUptime - 1
        noRoute.legalTargets = [1]; noRoute.snapshot!.legalTargetNumbers = [1]; PLRuntimeBridge.snapshot = noRoute.snapshot
        noRoute.stableSince = ProcessInfo.processInfo.systemUptime - 1
        noRoute.advanceAutomation(); try await awaitPlanner(noRoute)
        expect(noRoute.automaticPlan?.controlSequence != nil && !noRoute.suggestions.isEmpty && noRoute.lastPlanningSearch["explorationPass"] as? Int == 0,"changed legal context restarts search from first pass and prepares controls")
        noRoute.finish(); expect(PLRuntimeBridge.shoots.count == 1,"recovered context still releases exactly once after gradual controls")

        let expired = fixture(); expired.setAutoPlay(true); expired.stableSince = ProcessInfo.processInfo.systemUptime - 1
        expired.advanceAutomation(); expired.isPlayerTurn = false; expired.runtimeCanShoot = false; expired.canRecommend = false
        try await awaitPlanner(expired)
        expect(expired.automaticPlan == nil && PLRuntimeBridge.aims.isEmpty && PLRuntimeBridge.shoots.isEmpty,"native readiness lost while calculating prevents all control updates")
        let changedRules = fixture(); changedRules.setAutoPlay(true); changedRules.stableSince = ProcessInfo.processInfo.systemUptime - 1
        changedRules.advanceAutomation(); changedRules.legalTargets = [8]; changedRules.snapshot!.legalTargetNumbers = [8]
        try await awaitPlanner(changedRules)
        expect(changedRules.automaticPlan == nil && PLRuntimeBridge.aims.isEmpty && PLRuntimeBridge.shoots.isEmpty,"new legal target set invalidates pending result before aim")
        let changedView = fixture(); changedView.setAutoPlay(true); changedView.stableSince = ProcessInfo.processInfo.systemUptime - 1
        changedView.advanceAutomation(); changedView.snapshot!.coordinateView = MockView()
        try await awaitPlanner(changedView)
        expect(changedView.automaticPlan == nil && PLRuntimeBridge.aims.isEmpty && PLRuntimeBridge.shoots.isEmpty,"new native table view invalidates pending result")
        print("{\"result\":\"passed\",\"checks\":\(checks),\"scope\":\"Actual production startPlanning and Task.detached plus V15 Core, progression and dispatch; native I/O mocked\"}")
    }
'''+s[ix:]
s+='\n@main struct Main { static func main() async throws { try await IntegratedGameModel.runAsync() } }\n'
(out/'V15AsyncSmoothAutomationHarness.swift').write_text(s)
metaPath=out/'ExtractedMethods.json';meta=json.loads(metaPath.read_text());meta['asyncMethods']={n:hashlib.sha256(v['member'](n).encode()).hexdigest() for n in ['startPlanning','accepts','acceptsPlan','minimumPlannerPower']};metaPath.write_text(json.dumps(meta,indent=2))
