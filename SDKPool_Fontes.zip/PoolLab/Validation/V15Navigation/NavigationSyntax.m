// Declaration-only stand-ins for an ARC syntax/type pass. Not an Apple SDK.
typedef signed char BOOL;
typedef long NSInteger;
typedef unsigned long NSUInteger;
typedef double NSTimeInterval;
typedef double CGFloat;
typedef unsigned long size_t;
typedef unsigned long uintptr_t;
typedef unsigned char uint8_t;
typedef long ptrdiff_t;
typedef struct objc_ivar *Ivar;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define NULL ((void *)0)
#define nil ((id)0)
#define NS_ASSUME_NONNULL_BEGIN
#define NS_ASSUME_NONNULL_END
#define NS_SWIFT_NAME(x) __attribute__((swift_name(#x)))
__attribute__((objc_root_class)) @interface NSObject
+ (instancetype)new;
+ (Class)class;
- (Class)class;
- (BOOL)isKindOfClass:(Class)cls;
@end
@class NSString,NSDictionary,NSMutableDictionary;
@interface NSString : NSObject
@property(nonatomic,readonly) NSUInteger length;
+ (instancetype)stringWithFormat:(NSString *)format, ...;
- (BOOL)isEqual:(id)object;
- (BOOL)isEqualToString:(NSString *)string;
- (BOOL)hasSuffix:(NSString *)suffix;
- (id)copy;
@end
@interface NSNumber : NSObject
+ (instancetype)numberWithBool:(BOOL)value;
@end
@interface NSError : NSObject
@property(nonatomic,readonly) NSInteger code;
@property(nonatomic,readonly) NSString *domain;
@property(nonatomic,readonly) NSString *localizedDescription;
@property(nonatomic,readonly) NSDictionary *userInfo;
+ (instancetype)errorWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(NSDictionary *)info;
@end
@interface NSException : NSObject @end
typedef struct { unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5]; } NSFastEnumerationState;
@interface NSArray<__covariant ObjectType> : NSObject
+ (id)arrayWithObjects:(const id[])objects count:(NSUInteger)count;
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(NSUInteger)count;
@end
@interface NSDictionary<__covariant KeyType,__covariant ObjectType> : NSObject
+ (instancetype)dictionary;
+ (id)dictionaryWithObjects:(const id[])objects forKeys:(const id[])keys count:(NSUInteger)count;
- (id)mutableCopy;
@end
@interface NSMutableDictionary<KeyType,ObjectType> : NSDictionary<KeyType,ObjectType>
- (void)setObject:(ObjectType)object forKeyedSubscript:(KeyType)key;
@end
@interface NSProcessInfo : NSObject
@property(class,nonatomic,readonly) NSProcessInfo *processInfo;
@property(nonatomic,readonly) NSTimeInterval systemUptime;
@end
@interface NSUUID : NSObject
@property(class,nonatomic,readonly) NSUUID *UUID;
@property(nonatomic,readonly) NSString *UUIDString;
@end
@class UIWindow,UIViewController;
@interface UIView : NSObject
@property(nonatomic,readonly) UIWindow *window;
@property(nonatomic,readonly,getter=isHidden) BOOL hidden;
@property(nonatomic,readonly) CGFloat alpha;
@property(nonatomic,readonly,getter=isUserInteractionEnabled) BOOL userInteractionEnabled;
@end
@interface UIControl : UIView
@property(nonatomic,readonly,getter=isEnabled) BOOL enabled;
@end
@interface UIViewController : NSObject
@property(nonatomic,readonly) UIViewController *presentedViewController;
@property(nonatomic,readonly) BOOL isViewLoaded;
@property(nonatomic,readonly) UIView *view;
@property(nonatomic,readonly) BOOL isBeingDismissed;
@property(nonatomic,readonly) BOOL isBeingPresented;
@end
@interface UIWindow : UIView
@property(nonatomic,readonly) UIViewController *rootViewController;
@property(nonatomic,readonly) CGFloat windowLevel;
@end
@interface UIApplication : NSObject
@property(class,nonatomic,readonly) UIApplication *sharedApplication;
@property(nonatomic,readonly) NSArray<UIWindow *> *windows;
@end
extern const CGFloat UIWindowLevelNormal;
extern NSString *const NSLocalizedDescriptionKey;
extern NSString *NSStringFromClass(Class);
extern Class NSClassFromString(NSString *);
extern SEL NSSelectorFromString(NSString *);
extern Class object_getClass(id);
extern id object_getIvar(id,Ivar);
extern ptrdiff_t ivar_getOffset(Ivar);
extern id objc_msgSend(id,SEL,...);
#define isfinite __builtin_isfinite
extern float fabsf(float);


NS_ASSUME_NONNULL_BEGIN

@interface PLQueueSnapshot : NSObject
@property(nonatomic, readonly) BOOL ready;
@property(nonatomic, readonly) BOOL isResultScreen;
@property(nonatomic, copy, readonly) NSString *resultToken;
@property(nonatomic, copy, readonly) NSString *unavailableReason;
/// V15 navigation uses one revalidated action per observed scene visit.
@property(nonatomic, copy, readonly) NSString *actionToken;
@property(nonatomic, copy, readonly) NSString *navigationAction;
@property(nonatomic, copy, readonly) NSString *sceneName;
@property(nonatomic, copy, readonly) NSString *selectedTier;
@property(nonatomic, copy, readonly) NSString *observedMatchID;
@property(nonatomic, readonly) BOOL isInMatch;
@property(nonatomic, readonly) BOOL isMatchmaking;
@end

/// Reuses the game's normal matchmaking entry point for the observed match's
/// unchanged tier. It never selects a new tier, accepts a purchase, or rematches.
@interface PLQueueBridge : NSObject
+ (nullable PLQueueSnapshot *)captureWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(capture());
+ (BOOL)startNextMatchForToken:(NSString *)token error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(startNextMatch(token:));
/// Return to the native map carousel, select its foreground/centered ordinary
/// coin map, and dismiss specifically verified news/promotion windows. Unknown
/// windows wait for the user. This does not select the most expensive map.
+ (nullable PLQueueSnapshot *)captureNavigationWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(captureNavigation());
+ (BOOL)performNavigationForToken:(NSString *)token error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(performNavigation(token:));
@end

NS_ASSUME_NONNULL_END
@interface PLQueueSnapshot ()
@property(nonatomic, readwrite) BOOL ready;
@property(nonatomic, readwrite) BOOL isResultScreen;
@property(nonatomic, copy, readwrite) NSString *resultToken;
@property(nonatomic, copy, readwrite) NSString *unavailableReason;
@property(nonatomic, copy, readwrite) NSString *actionToken;
@property(nonatomic, copy, readwrite) NSString *navigationAction;
@property(nonatomic, copy, readwrite) NSString *sceneName;
@property(nonatomic, copy, readwrite) NSString *selectedTier;
@property(nonatomic, copy, readwrite) NSString *observedMatchID;
@property(nonatomic, readwrite) BOOL isInMatch;
@property(nonatomic, readwrite) BOOL isMatchmaking;
@end
@implementation PLQueueSnapshot
@end


static NSString *PLQObservedMatchID;
static NSString *PLQObservedTier;
static NSString *PLQResultToken;
static int PLQObservedMode;
static BOOL PLQConsumed;
static id PLQResultInfo;

// Navigation and matchmaking have separate latches. A popup/timeout/toggle is
// never evidence that a submitted matchmaking request was rejected.
static id PLQNavigationScene;
static NSString *PLQNavigationKey;
static NSString *PLQNavigationToken;
static NSString *PLQNavigationMatchID;
static NSTimeInterval PLQNavigationFirstSeen;
static BOOL PLQNavigationConsumed;
static BOOL PLQNavigationQueueConsumed;



extern BOOL PLQFail(NSError**,NSInteger,NSString*);
extern BOOL PLQMethod(id,NSString*,const char*,NSError**);
extern id PLQObject(id,NSString*);
extern BOOL PLQBool(id,NSString*);
extern int PLQInt(id,NSString*);
extern Ivar PLQIvar(id,NSString*,const char*,const char*,size_t,NSError**);
extern BOOL PLQRead(id,NSString*,const char*,const char*,void*,size_t,NSError**);
extern BOOL PLQEnvironment(id __strong*,id __strong*,id __strong*,NSError**);
extern NSString *PLQTierAtAddress(uintptr_t);
extern PLQueueSnapshot *PLQSnapshot(BOOL,NSString*);
extern id PLQSingleton(NSString*,NSString*,NSString*,NSError**);
extern const char *const PLQStringType;

static PLQueueSnapshot *PLQCaptureResult(BOOL leavingResult, id __strong *menuOut, id __strong *infoOut,
                                       const void **tierOut, NSError **error) {
    id main = nil, menu = nil, game = nil;
    if (!PLQEnvironment(&main, &menu, &game, error)) {
        if (error && *error) return nil;
        return PLQSnapshot(NO, @"Entre em uma partida para preparar a próxima mesa.");
    }
    if (!PLQMethod(main, @"isInGame", "B16@0:8", error) || !PLQMethod(main, @"isInMenu", "B16@0:8", error)) return nil;
    if (PLQBool(main, @"isInGame")) {
        if (!PLQMethod(game, @"matchId", "@16@0:8", error) ||
            !PLQMethod(game, @"tierCode", "r^v16@0:8", error) ||
            !PLQMethod(game, @"gameMode", "i16@0:8", error) ||
            !PLQMethod(game, @"isOnPlayerMatch", "B16@0:8", error) ||
            !PLQMethod(game, @"isOnAllInOrAdvantageGameMode", "B16@0:8", error) ||
            !PLQMethod(game, @"isInSpectatorMode", "B16@0:8", error)) return nil;
        id matchID = PLQObject(game, @"matchId");
        if (![matchID isKindOfClass:NSString.class] || ![matchID length] || [matchID length] > 256)
            return PLQSnapshot(NO, @"Aguardando a identificação da partida.");
        if (![PLQObservedMatchID isEqualToString:matchID]) {
            PLQObservedTier = nil; PLQResultInfo = nil; PLQResultToken = nil; PLQConsumed = NO;
            if (PLQBool(game, @"isOnPlayerMatch") && !PLQBool(game, @"isOnAllInOrAdvantageGameMode") &&
                !PLQBool(game, @"isInSpectatorMode")) {
                const void *tier = ((const void *(*)(id, SEL))objc_msgSend)(game, NSSelectorFromString(@"tierCode"));
                PLQObservedTier = PLQTierAtAddress((uintptr_t)tier);
                PLQObservedMode = PLQInt(game, @"gameMode");
                if (PLQObservedTier) {
                    PLQObservedMatchID = [matchID copy];
                    PLQResultToken = NSUUID.UUID.UUIDString;
                }
            }
        }
        return PLQSnapshot(NO, PLQObservedTier ? @"A próxima partida aguarda o resultado desta mesa." :
                            @"Próxima partida indisponível neste modo.");
    }
    if (!PLQBool(main, @"isInMenu")) return PLQSnapshot(NO, @"Aguardando o fim da transição.");
    if (!PLQMethod(menu, @"getCurrentMenuState", "@16@0:8", error)) return nil;
    id screen = PLQObject(menu, @"getCurrentMenuState");
    Class resultClass = NSClassFromString(@"MenuPlayerMatch");
    if (!resultClass || ![screen isKindOfClass:resultClass]) return PLQSnapshot(NO, @"Aguardando a tela de resultado.");
    int state = -1;
    BOOL ending = NO, animations = YES, requested = YES, opponentRequested = YES, pendingProposal = YES;
    BOOL challenge = YES, betSelection = YES;
    if (!PLQRead(screen, @"MenuPlayerMatch", "mState", "i", &state, sizeof(state), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_isMatchEnding", "B", &ending, sizeof(ending), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_hasPendingProgressionAnimations", "B", &animations, sizeof(animations), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "mPlayerWantsRematch", "B", &requested, sizeof(requested), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "mOpponentWantsRematch", "B", &opponentRequested, sizeof(opponentRequested), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_pendingRematchProposalFromOpponent", "B", &pendingProposal, sizeof(pendingProposal), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_isChallenge", "B", &challenge, sizeof(challenge), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_isBetSelectionGame", "B", &betSelection, sizeof(betSelection), error)) return nil;
    if (!ending || state != 2) return PLQSnapshot(NO, @"Aguardando o resultado completo da partida.");
    PLQueueSnapshot *snapshot = PLQSnapshot(YES, @"Aguardando o fim das animações do resultado.");
    if (!PLQObservedTier || !PLQResultToken) {
        snapshot.unavailableReason = @"Ative durante uma partida normal; a próxima mesa será a mesma."; return snapshot;
    }
    if (PLQConsumed) { snapshot.unavailableReason = @"Próxima partida já solicitada. Aguardando uma nova partida."; return snapshot; }
    // Opponent offers do not block the real back button at completed mState=2.
    // Native handleGoBack uses the ordinary result exit path in that state.
    // They still block legacy direct matchmaking, and our own pending rematch
    // always blocks either action so an uncertain request is not cancelled.
    if (challenge || betSelection || requested || (!leavingResult && (opponentRequested || pendingProposal))) {
        snapshot.unavailableReason = @"Próxima partida pausada para desafio, revanche ou aposta variável."; return snapshot;
    }
    if (animations) return snapshot;
    if (!PLQMethod(screen, @"matchInfo", "@16@0:8", error)) return nil;
    id info = PLQObject(screen, @"matchInfo");
    if (![info isKindOfClass:NSClassFromString(@"MatchInfo")]) return snapshot;
    if (!PLQMethod(info, @"wasChallenge", "B16@0:8", error) ||
        !PLQMethod(info, @"isAllInOrAdvantageMode", "B16@0:8", error) ||
        !PLQMethod(info, @"userPlayedOnMatch", "B16@0:8", error) ||
        !PLQMethod(info, @"gameMode", "i16@0:8", error) || !PLQMethod(info, @"betId", "i16@0:8", error)) return nil;
    if (PLQBool(info, @"wasChallenge") || PLQBool(info, @"isAllInOrAdvantageMode") ||
        !PLQBool(info, @"userPlayedOnMatch") || PLQInt(info, @"gameMode") != PLQObservedMode || PLQInt(info, @"betId") != -1) {
        snapshot.unavailableReason = @"Resultado incompatível com a próxima partida na mesma mesa."; return snapshot;
    }
    Ivar tierIvar = PLQIvar(info, @"MatchInfo", "_tierCode", PLQStringType, 24, error);
    if (!tierIvar) return nil;
    const void *tier = (const uint8_t *)(__bridge const void *)info + ivar_getOffset(tierIvar);
    if (![PLQObservedTier isEqualToString:PLQTierAtAddress((uintptr_t)tier)] || (PLQResultInfo && PLQResultInfo != info)) {
        snapshot.unavailableReason = @"A mesa do resultado mudou. Escolha a próxima partida no jogo."; return snapshot;
    }
    Ivar backIvar = PLQIvar(screen, @"MenuPlayerMatch", "mBackButton", "@\"MCMenuItemNodeRGBA\"", sizeof(id), error);
    if (!backIvar) return nil;
    id back = object_getIvar(screen, backIvar);
    if (!back) return snapshot;
    if (!PLQMethod(back, @"visible", "B16@0:8", error) || !PLQMethod(back, @"isEnabled", "B16@0:8", error)) return nil;
    if (!PLQBool(back, @"visible") || !PLQBool(back, @"isEnabled")) return snapshot;
    if (!PLQMethod(menu, @"startSingleMatch:", "v24@0:8r^v16", error) ||
        !PLQMethod(menu, @"enterLondonOnAuthentication", "B16@0:8", error)) return nil;
    // checkStartNanoMatch: can redirect an underfunded authentication flow to a
    // different tier. Do not enter that flow from this same-tier feature.
    if (PLQBool(menu, @"enterLondonOnAuthentication")) {
        snapshot.unavailableReason = @"Aguarde o jogo terminar de conectar antes da próxima partida."; return snapshot;
    }
    PLQResultInfo = info;
    snapshot.ready = YES;
    snapshot.unavailableReason = @"Pronta para procurar outro adversário na mesma mesa.";
    if (menuOut) *menuOut = menu;
    if (infoOut) *infoOut = info;
    if (tierOut) *tierOut = tier;
    return snapshot;
}
static PLQueueSnapshot *PLQCapture(id __strong *menuOut, id __strong *infoOut,
                                   const void **tierOut, NSError **error) {
    return PLQCaptureResult(NO, menuOut, infoOut, tierOut, error);
}


// V15 metadata and disassembly are retained in V15NavigationEvidence.json.
static id PLQCheckedObjectIvar(id object, NSString *cls, const char *name,
                              const char *encoding, NSError **error) {
    Ivar ivar = PLQIvar(object, cls, name, encoding, sizeof(id), error);
    return ivar ? object_getIvar(object, ivar) : nil;
}
static BOOL PLQVisibleNode(id object, BOOL button, NSError **error) {
    if (!object || !PLQMethod(object, @"visible", "B16@0:8", error) ||
        !PLQMethod(object, @"isRunning", "B16@0:8", error)) return NO;
    if (!PLQBool(object, @"visible") || !PLQBool(object, @"isRunning")) return NO;
    return !button || (PLQMethod(object, @"isEnabled", "B16@0:8", error) && PLQBool(object, @"isEnabled"));
}
static BOOL PLQMenuInteractable(id screen, NSError **error) {
    return PLQVisibleNode(screen, NO, error) &&
        PLQMethod(screen, @"isInteractable", "B16@0:8", error) && PLQBool(screen, @"isInteractable");
}
static void PLQObserveNavigationScene(id scene, NSString *key) {
    // Keep the actual object alive while its identity is used; allocator address
    // reuse alone must never rearm a consumed action.
    if (PLQNavigationScene != scene || ![PLQNavigationKey isEqual:key]) {
        PLQNavigationScene = scene;
        PLQNavigationKey = [key copy];
        PLQNavigationToken = NSUUID.UUID.UUIDString;
        PLQNavigationFirstSeen = NSProcessInfo.processInfo.systemUptime;
        PLQNavigationConsumed = NO;
    }
}
static void PLQNavigationReady(PLQueueSnapshot *snapshot, id scene, NSString *action, NSString *detail) {
    NSString *key = [NSString stringWithFormat:@"%@|%@|%@", PLQNavigationMatchID ?: @"", action, detail ?: @""];
    PLQObserveNavigationScene(scene, key);
    snapshot.navigationAction = action;
    snapshot.actionToken = PLQNavigationToken ?: @"";
    snapshot.ready = !PLQNavigationConsumed &&
        NSProcessInfo.processInfo.systemUptime - PLQNavigationFirstSeen >= 0.35;
    if (PLQNavigationConsumed) snapshot.unavailableReason = @"Aguardando a resposta da tela à ação enviada.";
}
static BOOL PLQNavigationFailure(NSError **error, NSInteger code, NSString *message, BOOL dispatched) {
    if (error) {
        NSError *original = *error;
        NSMutableDictionary *details = original.userInfo ? [original.userInfo mutableCopy] : [NSMutableDictionary dictionary];
        details[NSLocalizedDescriptionKey] = original.localizedDescription ?: message;
        details[@"navigationDispatched"] = @(dispatched);
        *error = [NSError errorWithDomain:original.domain ?: @"PoolLab.QueueBridge"
                                    code:original ? original.code : code userInfo:details];
    }
    return NO;
}
static UIViewController *PLQPresentedController(BOOL *blocked) {
    // Only an actually presented UIKit controller. Other visible windows block
    // navigation; the SDKPool window is specifically excluded, not every overlay.
    UIViewController *news = nil;
    NSUInteger modalCount = 0;
    for (UIWindow *window in UIApplication.sharedApplication.windows) {
        if (window.hidden || window.alpha < 0.01 ||
            [NSStringFromClass(window.class) hasSuffix:@"PLPassthroughWindow"]) continue;
        if (window.windowLevel != UIWindowLevelNormal) { *blocked = YES; modalCount++; continue; }
        UIViewController *root = window.rootViewController, *top = root;
        for (NSUInteger depth = 0; depth < 16 && top.presentedViewController; depth++) top = top.presentedViewController;
        if (!top || top == root || !top.isViewLoaded || top.view.window != window || top.view.hidden) continue;
        *blocked = YES;
        modalCount++;
        if ([NSStringFromClass(top.class) isEqual:@"MCNewsfeedViewController"] &&
            !top.isBeingDismissed && !top.isBeingPresented) news = top;
    }
    return modalCount == 1 ? news : nil;
}
static PLQueueSnapshot *PLQCaptureNavigation(id __strong *targetOut, id __strong *argumentOut,
                                           NSString *__strong *selectorOut, NSError **error) {
    PLQueueSnapshot *snapshot = PLQCaptureResult(YES, NULL, NULL, NULL, error);
    if (!snapshot) return nil;
    // Legacy ready means same-tier queue. The V15 action is independently gated.
    BOOL resultReady = snapshot.ready;
    snapshot.ready = NO;
    id main = nil, menu = nil, game = nil;
    if (!PLQEnvironment(&main, &menu, &game, error)) return (error && *error) ? nil : snapshot;
    if (!PLQMethod(main, @"isInGame", "B16@0:8", error) ||
        !PLQMethod(main, @"isInMenu", "B16@0:8", error) ||
        !PLQMethod(menu, @"getCurrentMenuState", "@16@0:8", error)) return nil;
    snapshot.isInMatch = PLQBool(main, @"isInGame");
    if (snapshot.isInMatch && snapshot.observedMatchID.length &&
        ![PLQNavigationMatchID isEqual:snapshot.observedMatchID]) {
        PLQNavigationMatchID = [snapshot.observedMatchID copy];
        PLQNavigationQueueConsumed = NO;
        PLQObserveNavigationScene(game, @"playing");
    }
    BOOL modal = NO;
    UIViewController *news = PLQPresentedController(&modal);
    if (modal) {
        snapshot.sceneName = news ? @"MCNewsfeedViewController" : @"UIKitModal";
        snapshot.unavailableReason = news ? @"Fechando notícias para continuar." : @"Aguardando uma janela do jogo ser fechada.";
        if (!news) { PLQObserveNavigationScene(menu, @"unknownUIKitModal"); return snapshot; }
        id view = PLQCheckedObjectIvar(news, @"MCNewsfeedViewController", "newsfeedView", "@\"MCNewsfeedView\"", error);
        id close = PLQCheckedObjectIvar(view, @"MCNewsfeedView", "closeButton", "@\"MCNewsfeedCloseButton\"", error);
        if (error && *error) return nil;
        if (![close isKindOfClass:UIView.class]) return snapshot;
        UIView *closeView = close;
        if (!closeView.window || closeView.hidden || closeView.alpha < 0.01 || !closeView.userInteractionEnabled ||
            ([closeView isKindOfClass:UIControl.class] && ![(UIControl *)closeView isEnabled])) return snapshot;
        if (!PLQMethod(news, @"dismissNewsfeed:", "v24@0:8@16", error)) return nil;
        PLQNavigationReady(snapshot, news, @"closeNews", @"");
        if (targetOut) *targetOut = news;
        if (argumentOut) *argumentOut = close;
        if (selectorOut) *selectorOut = @"dismissNewsfeed:";
        return snapshot;
    }
    if (snapshot.isInMatch) {
        snapshot.sceneName = @"GameManager";
        snapshot.unavailableReason = @"Partida em andamento.";
        PLQObserveNavigationScene(game, @"playing");
        return snapshot;
    }
    if (!PLQBool(main, @"isInMenu")) {
        snapshot.sceneName = @"Transition";
        snapshot.unavailableReason = @"Aguardando a transição do jogo.";
        // Do not rearm a consumed menu action on a transient main-state flag.
        return snapshot;
    }
    id screen = PLQObject(menu, @"getCurrentMenuState");
    snapshot.sceneName = screen ? NSStringFromClass(object_getClass(screen)) : @"Transition";
    if ([snapshot.sceneName isEqual:@"MenuPlayerMatch"]) {
        if (!PLQMethod(screen, @"isMatchRequested", "B16@0:8", error) ||
            !PLQMethod(screen, @"isRematchRequested", "B16@0:8", error)) return nil;
        snapshot.isMatchmaking = PLQBool(screen, @"isMatchRequested") || PLQBool(screen, @"isRematchRequested");
        if (!resultReady) {
            if (snapshot.isMatchmaking) PLQObserveNavigationScene(screen, @"matchmaking");
            return snapshot;
        }
        if (!PLQMenuInteractable(screen, error)) return (error && *error) ? nil : snapshot;
        if (!PLQMethod(screen, @"backButtonCallback", "v16@0:8", error)) return nil;
        snapshot.unavailableReason = @"Voltando à seleção de mapas.";
        PLQNavigationReady(snapshot, screen, @"backToMaps", snapshot.resultToken);
        if (targetOut) *targetOut = screen;
        if (selectorOut) *selectorOut = @"backButtonCallback";
        return snapshot;
    }
    if ([snapshot.sceneName isEqual:@"MenuPromotionSystemPopUp"]) {
        BOOL purchase = YES, leaving = YES;
        if (!PLQRead(screen, @"MenuPromotionSystemPopUp", "_isWaitingForPurchase", "B", &purchase, sizeof(purchase), error) ||
            !PLQRead(screen, @"MenuPromotionSystemPopUp", "isLeaving", "B", &leaving, sizeof(leaving), error)) return nil;
        snapshot.unavailableReason = @"Aguardando a promoção poder ser fechada.";
        if (purchase || leaving || !PLQMenuInteractable(screen, error)) return (error && *error) ? nil : snapshot;
        if (!PLQMethod(screen, @"exitButtonCallback", "v16@0:8", error)) return nil;
        PLQNavigationReady(snapshot, screen, @"closePromotion", @"");
        if (targetOut) *targetOut = screen;
        if (selectorOut) *selectorOut = @"exitButtonCallback";
        return snapshot;
    }
    if ([snapshot.sceneName isEqual:@"MenuGameType"]) {
        snapshot.unavailableReason = @"Abrindo a seleção de mapas.";
        if (!PLQMenuInteractable(screen, error)) return (error && *error) ? nil : snapshot;
        if (!PLQMethod(screen, @"defaultTierSelectorButton", "@16@0:8", error)) return nil;
        id button = PLQObject(screen, @"defaultTierSelectorButton");
        if (![button isKindOfClass:NSClassFromString(@"MenuGameTypeButton")] || !PLQVisibleNode(button, YES, error))
            return (error && *error) ? nil : snapshot;
        if (!PLQMethod(button, @"isEventUnlocked", "B16@0:8", error) ||
            !PLQMethod(button, @"tierButtonCallback", "v16@0:8", error)) return nil;
        if (!PLQBool(button, @"isEventUnlocked")) { snapshot.unavailableReason = @"A seleção de mapas ainda está bloqueada."; return snapshot; }
        PLQNavigationReady(snapshot, screen, @"openMaps", @"");
        if (targetOut) *targetOut = button;
        if (selectorOut) *selectorOut = @"tierButtonCallback";
        return snapshot;
    }
    if ([snapshot.sceneName isEqual:@"MenuTierSelector"]) {
        snapshot.unavailableReason = @"Aguardando o mapa destacado ficar pronto.";
        if (!PLQMenuInteractable(screen, error)) return (error && *error) ? nil : snapshot;
        if (!PLQMethod(screen, @"isTournament", "B16@0:8", error) ||
            !PLQMethod(screen, @"itemPressed:", "v24@0:8@16", error)) return nil;
        if (PLQBool(screen, @"isTournament")) { snapshot.unavailableReason = @"Selecione uma mesa normal para continuar."; return snapshot; }
        id table = PLQCheckedObjectIvar(screen, @"MenuTierSelector", "mTable", "@\"CCTable\"", error);
        if (error && *error) return nil;
        if (!table) return snapshot;
        if (!PLQMethod(table, @"enabled", "B16@0:8", error) ||
            !PLQMethod(table, @"getCellForCurrentOffset", "@16@0:8", error)) return nil;
        unsigned int touches = 1; BOOL spring = YES;
        if (!PLQRead(table, @"CCTable", "mNumCurrentTouches", "I", &touches, sizeof(touches), error) ||
            !PLQRead(table, @"CCTable", "mIsOnSpring", "B", &spring, sizeof(spring), error)) return nil;
        if (!PLQBool(table, @"enabled") || touches || spring) return snapshot;
        id cell = PLQObject(table, @"getCellForCurrentOffset");
        if (![cell isKindOfClass:NSClassFromString(@"MenuTierSelectorNode")] || !PLQVisibleNode(cell, YES, error))
            return (error && *error) ? nil : snapshot;
        for (NSString *name in @[@"isAllInMode", @"isTournament", @"active", @"isToEnterGame", @"showRules"])
            if (!PLQMethod(cell, name, "B16@0:8", error)) return nil;
        if (!PLQMethod(cell, @"betGroupId", "i16@0:8", error) ||
            !PLQMethod(cell, @"entryFee", "i16@0:8", error) ||
            !PLQMethod(cell, @"currentRatio", "f16@0:8", error) ||
            !PLQMethod(cell, @"tierCode", "r^v16@0:8", error)) return nil;
        if (PLQBool(cell, @"isAllInMode") || PLQBool(cell, @"isTournament") || PLQInt(cell, @"betGroupId") != -1) {
            snapshot.unavailableReason = @"O mapa destacado precisa ser uma mesa normal, com aposta fixa."; return snapshot;
        }
        float ratio = ((float (*)(id, SEL))objc_msgSend)(cell, NSSelectorFromString(@"currentRatio"));
        if (!PLQBool(cell, @"active") || !PLQBool(cell, @"isToEnterGame") || PLQBool(cell, @"showRules") ||
            !isfinite(ratio) || fabsf(ratio) > 0.02f) return snapshot;
        const void *tier = ((const void *(*)(id, SEL))objc_msgSend)(cell, NSSelectorFromString(@"tierCode"));
        snapshot.selectedTier = PLQTierAtAddress((uintptr_t)tier) ?: @"";
        if (!snapshot.selectedTier.length) return snapshot;
        int fee = PLQInt(cell, @"entryFee");
        id user = PLQSingleton(@"UserInfo", @"isUserInfoInitialized", @"sharedUserInfo", error);
        if (error && *error) return nil;
        if (!user || fee < 0) return snapshot;
        if (!PLQMethod(user, @"hasEnoughCoins:", "B24@0:8Q16", error)) return nil;
        if (!((BOOL (*)(id, SEL, unsigned long long))objc_msgSend)(user, NSSelectorFromString(@"hasEnoughCoins:"), (unsigned long long)fee)) {
            snapshot.unavailableReason = @"Saldo insuficiente para o mapa destacado. Escolha outra mesa."; return snapshot;
        }
        if (PLQNavigationQueueConsumed || PLQConsumed) {
            snapshot.unavailableReason = @"Uma entrada já foi enviada. Aguardando confirmação de uma nova partida."; return snapshot;
        }
        snapshot.unavailableReason = @"Entrando no mapa destacado.";
        PLQNavigationReady(snapshot, screen, @"selectMap", snapshot.selectedTier);
        if (targetOut) *targetOut = screen;
        if (argumentOut) *argumentOut = cell;
        if (selectorOut) *selectorOut = @"itemPressed:";
        return snapshot;
    }
    snapshot.unavailableReason = @"Aguardando uma tela reconhecida para continuar automaticamente.";
    PLQObserveNavigationScene(screen, @"unknownMenu");
    return snapshot;
}


@implementation PLQueueBridge
+ (PLQueueSnapshot *)captureNavigationWithError:(NSError **)error {
    @try { return PLQCaptureNavigation(NULL, NULL, NULL, error); }
    @catch (NSException *exception) {
        PLQFail(error, 40, @"A navegação do jogo mudou. Aguardando uma tela reconhecida."); return nil;
    }
}
+ (BOOL)performNavigationForToken:(NSString *)token error:(NSError **)error {
    BOOL dispatched = NO;
    @try {
        id target = nil, argument = nil; NSString *selector = nil;
        PLQueueSnapshot *snapshot = PLQCaptureNavigation(&target, &argument, &selector, error);
        if (!snapshot) return PLQNavigationFailure(error, 41, @"A tela mudou antes da navegação.", NO);
        if (!snapshot.ready || !token.length || ![snapshot.actionToken isEqual:token] || !target || !selector)
            return PLQNavigationFailure(error, 41, snapshot.unavailableReason, NO);
        PLQNavigationConsumed = YES;
        if ([snapshot.navigationAction isEqual:@"selectMap"]) PLQNavigationQueueConsumed = YES;
        dispatched = YES;
        // Only the exact allowlisted method selected and revalidated above.
        if (argument) ((void (*)(id, SEL, id))objc_msgSend)(target, NSSelectorFromString(selector), argument);
        else ((void (*)(id, SEL))objc_msgSend)(target, NSSelectorFromString(selector));
        return YES;
    } @catch (NSException *exception) {
        return PLQNavigationFailure(error, 42, @"A navegação aguarda a resposta do jogo.", dispatched);
    }
}

@end
