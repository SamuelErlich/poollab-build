import struct,json,hashlib,sys
from pathlib import Path
B=Path(__file__).with_name('8ballpool').read_bytes()
SEG=[];SEC={};o=32
for i in range(struct.unpack_from('<I',B,16)[0]):
 cmd,size=struct.unpack_from('<II',B,o)
 if cmd==0x19:
  seg,va,vs,off,fs=struct.unpack_from('<16sQQQQ',B,o+8);SEG.append((va,fs,off))
  ns=struct.unpack_from('<I',B,o+64)[0]
  for j in range(ns):
   s=o+72+j*80;name,seg,addr,length,offset=struct.unpack_from('<16s16sQQI',B,s);SEC[name.rstrip(b'\0').decode()]=(addr,length,offset)
 o+=size
def off(a):
 for va,size,offset in SEG:
  if va<=a<va+size:return offset+a-va
 raise ValueError(hex(a))
def unpack(fmt,a):return struct.unpack_from('<'+fmt,B,off(a))
def q(a):return unpack('Q',a)[0]
def string(a):
 if not a:return ''
 p=off(a);return B[p:B.index(0,p)].decode('utf8','replace')
def methods(a):
 if not a:return []
 flags,count=unpack('II',a);size=flags&0xffff;small=flags&0x80000000
 ret=[]
 for i in range(count):
  p=a+8+i*size
  if small:
   rn,rt,ri=unpack('iii',p);name=p+rn
   if not flags&0x40000000:name=q(name)
   types=p+4+rt;imp=p+8+ri
  else:name,types,imp=unpack('QQQ',p)
  ret.append({'selector':string(name),'encoding':string(types),'imp':hex(imp)})
 return ret
def ivars(a):
 if not a:return []
 size,count=unpack('II',a);ret=[]
 for i in range(count):
  r,n,t,align,length=unpack('QQQII',a+8+i*size)
  ret.append({'name':string(n),'encoding':string(t),'offset':unpack('I',r)[0] if any(va<=r<va+size for va,size,_ in SEG) else None,'size':length,'ref':hex(r)})
 return ret
def cls(a):
 ro=q(a+32)&~7
 return {'name':string(q(ro+24)), 'address':hex(a),'super':hex(q(a+8)), 'methods':methods(q(ro+32)), 'ivars':ivars(q(ro+48))}
def allclasses():
 a,size,_=SEC['__objc_classlist'];ret={}
 for p in range(a,a+size,8):
  c=q(p);d=cls(c);d['classMethods']=cls(q(c))['methods'];ret[d['name']]=d
 return ret
if __name__=='__main__':
 d=allclasses();Path(__file__).with_name('classes.json').write_text(json.dumps(d,indent=2));print(len(d))
