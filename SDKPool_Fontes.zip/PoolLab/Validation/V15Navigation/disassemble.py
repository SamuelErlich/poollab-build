import json,re,sys,bisect
import capstone
import inspect_native as n
from pathlib import Path
C=json.loads(Path(__file__).with_name('classes.json').read_text());md=capstone.Cs(capstone.CS_ARCH_ARM64,capstone.CS_MODE_LITTLE_ENDIAN)
METHODS={int(m['imp'],16):c+'.'+m['selector'] for c,x in C.items() for m in x['methods']+x['classMethods']};addrs=set(METHODS)
o=32
for _ in range(n.unpack('I',0x100000010)[0]):
 cmd,size=__import__('struct').unpack_from('<II',n.B,o)
 if cmd==0x26:
  offset,length=__import__('struct').unpack_from('<II',n.B,o+8);a=0x100000000;value=shift=0
  for b in n.B[offset:offset+length]:
   value|=(b&127)<<shift
   if b&128:shift+=7
   else:
    if not value:break
    a+=value;addrs.add(a);value=shift=0
 o+=size
addrs=sorted(addrs)
def label(a):
 if a in METHODS:return METHODS[a]
 start,size,_=n.SEC['__objc_stubs']
 if start<=a<start+size:
  ii=list(md.disasm(n.B[n.off(a):n.off(a)+8],a))
  if len(ii)==2:
   base=int(ii[0].op_str.split('#')[1],16);s=re.search(r'#(0x[0-9a-f]+)',ii[1].op_str);offset=int(s[1],16) if s else 0
   return 'objc_msgSend$'+n.string(n.q(base+offset))
 return ''
def disasm(a,end):
 lines=[]
 for i in md.disasm(n.B[n.off(a):n.off(a)+end-a],a):
  suffix=''
  if i.mnemonic in ['b','bl'] and i.op_str.startswith('#0x'):suffix=label(int(i.op_str[1:],16))
  lines.append(f'{i.address:#x} {i.mnemonic:8} {i.op_str:42} {suffix}')
 return '\n'.join(lines)
if __name__=='__main__':
 for name in sys.argv[1:]:
  c,sel=name.split('.',1);m=next(x for x in C[c]['methods'] if x['selector']==sel);a=int(m['imp'],16);end=addrs[bisect.bisect_right(addrs,a)]
  print('\n'+name,json.dumps(m), '\n'+disasm(a,end))
