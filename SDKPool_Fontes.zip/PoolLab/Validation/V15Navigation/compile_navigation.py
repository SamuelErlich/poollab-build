#!/usr/bin/env python3
"""Compile exact navigation/result blocks with declaration-only SDK stand-ins."""
from pathlib import Path
import argparse, hashlib, json, subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--clang', required=True)
args = parser.parse_args()
here = Path(__file__).resolve().parent
project = here.parents[1]
source = (project/'Integrated/PLQueueBridge.m').read_text()
header = (project/'Integrated/PLQueueBridge.h').read_text()
sha = lambda value: hashlib.sha256(value).hexdigest()
snapshot = source[source.index('@interface PLQueueSnapshot ()'):source.index('static NSString *PLQObservedMatchID;')]
globals_ = source[source.index('static NSString *PLQObservedMatchID;'):source.index('static BOOL PLQFail(')]
capture = source[source.index('static PLQueueSnapshot *PLQCaptureResult('):source.index('// V15 metadata')]
navigation = source[source.index('// V15 metadata'):source.index('@implementation PLQueueBridge')]
methods = source[source.index('+ (PLQueueSnapshot *)captureNavigationWithError:'):source.rindex('@end')]
prototypes = '''
extern BOOL PLQFail(NSError**,NSInteger,NSString*);
extern BOOL PLQMethod(id,NSString*,const char*,NSError**);
extern id PLQObject(id,NSString*);
extern BOOL PLQBool(id,NSString*);
extern int PLQInt(id,NSString*);
extern Ivar PLQIvar(id,NSString*,const char*,const char*,size_t,NSError**);
extern BOOL PLQRead(id,NSString*,const char*,const char*,void*,size_t,NSError**);
extern BOOL PLQEnvironment(id __strong*,id __strong*,id __strong*,NSError**);
extern NSString *PLQTierAtAddress(uintptr_t);
extern PLQueueSnapshot *PLQSnapshot(BOOL,NSString*);
extern id PLQSingleton(NSString*,NSString*,NSString*,NSError**);
extern const char *const PLQStringType;
'''
fixture = (here/'FoundationUIKitTypeFixture.inc').read_text()
fixture += '\n' + '\n'.join(line for line in header.splitlines() if not line.startswith('#import'))
fixture += '\n'+snapshot+'\n'+globals_+'\n'+prototypes+'\n'+capture+'\n'+navigation
fixture += '\n@implementation PLQueueBridge\n'+methods+'\n@end\n'
path=here/'NavigationSyntax.m';path.write_text(fixture)
command=[args.clang,'-target','arm64-apple-ios15.0','-fobjc-arc','-fsyntax-only','-Werror',
         '-Wno-incomplete-implementation','-Wno-nullability-completeness',str(path)]
result=subprocess.run(command,capture_output=True,text=True)
(here/'NavigationSyntax.txt').write_text(result.stdout+result.stderr)
report={'format':'SDKPool.V15.NavigationSyntax','result':'passed' if result.returncode==0 else 'failed',
 'command':command,'exitCode':result.returncode,'sourceSHA256':{'Integrated/PLQueueBridge.m':sha(source.encode()),'Integrated/PLQueueBridge.h':sha(header.encode())},
 'exactBlockSHA256':{name:sha(value.encode()) for name,value in [('captureResult',capture),('navigation',navigation),('mutationAPI',methods)]},
 'fixtureSHA256':sha(fixture.encode()),'limitations':['Declaration-only stand-ins check ARM64 ARC syntax/types. Not an Apple SDK build or iPhone runtime.']}
(project/'Validation/V15NavigationSyntax.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':report['result'],'exitCode':result.returncode,'diagnostics':result.stderr}))
raise SystemExit(result.returncode)
