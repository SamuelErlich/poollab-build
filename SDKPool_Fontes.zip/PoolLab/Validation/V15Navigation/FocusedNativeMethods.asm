MenuLayer.isInteractable
0x10031d804 adrp     x8, #0x104826000                           
0x10031d808 ldrsw    x8, [x8, #0xe4]                            
0x10031d80c ldrb     w0, [x0, x8]                               
0x10031d810 ret                                                 

MenuLayer.enableInput
0x10031cec4 stp      x20, x19, [sp, #-0x20]!                    
0x10031cec8 stp      x29, x30, [sp, #0x10]                      
0x10031cecc add      x29, sp, #0x10                             
0x10031ced0 mov      x19, x0                                    
0x10031ced4 adrp     x8, #0x104826000                           
0x10031ced8 ldrsw    x8, [x8, #0x118]                           
0x10031cedc ldr      x0, [x0, x8]                               
0x10031cee0 cbz      x0, #0x10031cee8                           
0x10031cee4 bl       #0x1031bffc0                               objc_msgSend$enableCallback
0x10031cee8 adrp     x8, #0x104826000                           
0x10031ceec ldrsw    x8, [x8, #0xe4]                            
0x10031cef0 mov      w9, #1                                     
0x10031cef4 strb     w9, [x19, x8]                              
0x10031cef8 mov      x0, x19                                    
0x10031cefc mov      w2, #1                                     
0x10031cf00 ldp      x29, x30, [sp, #0x10]                      
0x10031cf04 ldp      x20, x19, [sp], #0x20                      
0x10031cf08 b        #0x103243080                               objc_msgSend$notifyParentStateThatChildStateHasSetEnabledInput:

MenuLayer.disableInput
0x10031cf0c stp      x20, x19, [sp, #-0x20]!                    
0x10031cf10 stp      x29, x30, [sp, #0x10]                      
0x10031cf14 add      x29, sp, #0x10                             
0x10031cf18 mov      x19, x0                                    
0x10031cf1c adrp     x8, #0x104826000                           
0x10031cf20 ldrsw    x8, [x8, #0x118]                           
0x10031cf24 ldr      x0, [x0, x8]                               
0x10031cf28 cbz      x0, #0x10031cf30                           
0x10031cf2c bl       #0x1031ba9c0                               objc_msgSend$disableCallback
0x10031cf30 adrp     x8, #0x104826000                           
0x10031cf34 ldrsw    x8, [x8, #0xe4]                            
0x10031cf38 strb     wzr, [x19, x8]                             
0x10031cf3c mov      x0, x19                                    
0x10031cf40 mov      w2, #0                                     
0x10031cf44 ldp      x29, x30, [sp, #0x10]                      
0x10031cf48 ldp      x20, x19, [sp], #0x20                      
0x10031cf4c b        #0x103243080                               objc_msgSend$notifyParentStateThatChildStateHasSetEnabledInput:

CCNode.visible
0x101552ae0 ldrb     w0, [x0, #0x357]                           
0x101552ae4 ret                                                 

CCNode.isRunning
0x101552b10 ldrb     w0, [x0, #0x356]                           
0x101552b14 ret                                                 

CCMenuItem.isEnabled
0x1015715f0 adrp     x8, #0x104832000                           
0x1015715f4 ldrsw    x8, [x8, #0xa00]                           
0x1015715f8 ldrb     w0, [x0, x8]                               
0x1015715fc ret                                                 

MenuGameType.defaultTierSelectorButton
0x10030dbf4 adrp     x8, #0x104826000                           
0x10030dbf8 ldrsw    x8, [x8, #0x80]                            
0x10030dbfc ldr      x0, [x0, x8]                               
0x10030dc00 ret                                                 

MenuGameTypeButton.tierButtonCallback
0x10084550c stp      x22, x21, [sp, #-0x30]!                    
0x100845510 stp      x20, x19, [sp, #0x10]                      
0x100845514 stp      x29, x30, [sp, #0x20]                      
0x100845518 add      x29, sp, #0x20                             
0x10084551c mov      x19, x0                                    
0x100845520 adrp     x8, #0x10482a000                           
0x100845524 ldrsw    x21, [x8, #0x824]                          
0x100845528 ldr      x0, [x0, x21]                              
0x10084552c adrp     x8, #0x103ef1000                           
0x100845530 add      x8, x8, #0x340                             
0x100845534 ldr      x2, [x8]                                   
0x100845538 bl       #0x10321b000                               objc_msgSend$isEqualToString:
0x10084553c mov      x20, x0                                    
0x100845540 cbz      w0, #0x100845550                           
0x100845544 adrp     x0, #0x103486000                           
0x100845548 add      x0, x0, #0x9e0                             
0x10084554c bl       #0x10013a738                               
0x100845550 mov      x0, x19                                    
0x100845554 bl       #0x10321b240                               objc_msgSend$isEventUnlocked
0x100845558 cbz      w0, #0x1008455a8                           
0x10084555c adrp     x20, #0x10480c000                          
0x100845560 ldr      x0, [x20, #0x5c8]                          
0x100845564 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x100845568 mov      w2, #0                                     
0x10084556c bl       #0x1032a1aa0                               objc_msgSend$setGoToSelectedTier:
0x100845570 ldr      x0, [x20, #0x5c8]                          
0x100845574 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x100845578 ldr      x2, [x19, x21]                             
0x10084557c adrp     x3, #0x104020000                           
0x100845580 add      x3, x3, #0x798                             
0x100845584 mov      w4, #9                                     
0x100845588 bl       #0x1032ba680                               objc_msgSend$setParameter:withKey:forState:
0x10084558c ldr      x0, [x20, #0x5c8]                          
0x100845590 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x100845594 mov      w2, #9                                     
0x100845598 ldp      x29, x30, [sp, #0x20]                      
0x10084559c ldp      x20, x19, [sp, #0x10]                      
0x1008455a0 ldp      x22, x21, [sp], #0x30                      
0x1008455a4 b        #0x103263be0                               objc_msgSend$pushNextMenuState:
0x1008455a8 bl       #0x1000ebfd0                               
0x1008455ac mov      x21, x0                                    
0x1008455b0 adrp     x8, #0x10482a000                           
0x1008455b4 ldrsw    x8, [x8, #0x854]                           
0x1008455b8 ldr      x0, [x19, x8]                              
0x1008455bc bl       #0x10001f26c                               
0x1008455c0 adrp     x8, #0x10482a000                           
0x1008455c4 ldrsw    x8, [x8, #0x848]                           
0x1008455c8 ldr      w1, [x19, x8]                              
0x1008455cc mov      x2, x20                                    
0x1008455d0 cbz      w21, #0x1008455e4                          
0x1008455d4 ldp      x29, x30, [sp, #0x20]                      
0x1008455d8 ldp      x20, x19, [sp, #0x10]                      
0x1008455dc ldp      x22, x21, [sp], #0x30                      
0x1008455e0 b        #0x10076d54c                               
0x1008455e4 ldp      x29, x30, [sp, #0x20]                      
0x1008455e8 ldp      x20, x19, [sp, #0x10]                      
0x1008455ec ldp      x22, x21, [sp], #0x30                      
0x1008455f0 b        #0x10076d5e0                               

MenuGameTypeButton.isEventUnlocked
0x10084597c adrp     x8, #0x10482a000                           
0x100845980 ldrsw    x8, [x8, #0x844]                           
0x100845984 add      x0, x0, x8                                 
0x100845988 b        #0x100ba78e8                               

MenuTierSelector.itemPressed:
0x1003e6fc0 sub      sp, sp, #0x90                              
0x1003e6fc4 stp      x26, x25, [sp, #0x40]                      
0x1003e6fc8 stp      x24, x23, [sp, #0x50]                      
0x1003e6fcc stp      x22, x21, [sp, #0x60]                      
0x1003e6fd0 stp      x20, x19, [sp, #0x70]                      
0x1003e6fd4 stp      x29, x30, [sp, #0x80]                      
0x1003e6fd8 add      x29, sp, #0x80                             
0x1003e6fdc mov      x20, x2                                    
0x1003e6fe0 mov      x19, x0                                    
0x1003e6fe4 adrp     x8, #0x103ea5000                           
0x1003e6fe8 ldr      x8, [x8, #0x588]                           
0x1003e6fec ldr      x8, [x8]                                   
0x1003e6ff0 str      x8, [sp, #0x38]                            
0x1003e6ff4 adrp     x24, #0x10480c000                          
0x1003e6ff8 ldr      x0, [x24, #0x5c8]                          
0x1003e6ffc bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003e7000 mov      w2, #0x2b                                  
0x1003e7004 bl       #0x1031e0cc0                               objc_msgSend$getMenuStateInstance:
0x1003e7008 cbz      x0, #0x1003e7018                           
0x1003e700c bl       #0x1031d81a0                               objc_msgSend$getConnectingMode
0x1003e7010 cmp      w0, #4                                     
0x1003e7014 b.eq     #0x1003e718c                               
0x1003e7018 adrp     x8, #0x104826000                           
0x1003e701c ldrsw    x8, [x8, #0xd40]                           
0x1003e7020 add      x8, x19, x8                                
0x1003e7024 ldr      x9, [x8, #0x18]                            
0x1003e7028 cbz      x9, #0x1003e70f0                           
0x1003e702c ldr      x23, [x8, #0x10]                           
0x1003e7030 cbz      x23, #0x1003e70f0                          
0x1003e7034 mov      w8, #0                                     
0x1003e7038 adrp     x25, #0x104959000                          
0x1003e703c add      x25, x25, #0xa18                           
0x1003e7040 mov      w26, #4                                    
0x1003e7044 adrp     x21, #0x103ea5000                          
0x1003e7048 ldr      x21, [x21, #0x4f0]                         
0x1003e704c ldrb     w9, [x23, #0x28]                           
0x1003e7050 cmp      w9, #1                                     
0x1003e7054 b.eq     #0x1003e7064                               
0x1003e7058 ldr      x23, [x23]                                 
0x1003e705c cbnz     x23, #0x1003e704c                          
0x1003e7060 b        #0x1003e70ec                               
0x1003e7064 ldr      x1, [x25]                                  
0x1003e7068 add      x0, sp, #0x18                              
0x1003e706c bl       #0x100004538                               
0x1003e7070 str      xzr, [sp]                                  
0x1003e7074 strh     w26, [sp, #8]                              
0x1003e7078 mov      w0, #0x18                                  
0x1003e707c mov      x1, x21                                    
0x1003e7080 bl       #0x10314b5f0                               
0x1003e7084 mov      x22, x0                                    
0x1003e7088 cbz      x0, #0x1003e70b4                           
0x1003e708c ldrsb    w8, [x23, #0x27]                           
0x1003e7090 tbnz     w8, #0x1f, #0x1003e70a8                    
0x1003e7094 ldur     q0, [x23, #0x10]                           
0x1003e7098 ldur     x8, [x23, #0x20]                           
0x1003e709c str      x8, [x22, #0x10]                           
0x1003e70a0 str      q0, [x22]                                  
0x1003e70a4 b        #0x1003e70b4                               
0x1003e70a8 ldp      x1, x2, [x23, #0x10]                       
0x1003e70ac mov      x0, x22                                    
0x1003e70b0 bl       #0x100007d0c                               
0x1003e70b4 str      x22, [sp]                                  
0x1003e70b8 add      x0, sp, #0x18                              
0x1003e70bc mov      x1, sp                                     
0x1003e70c0 bl       #0x100fe0ebc                               
0x1003e70c4 mov      x0, sp                                     
0x1003e70c8 bl       #0x100fd57a4                               
0x1003e70cc ldrsb    w8, [sp, #0x2f]                            
0x1003e70d0 tbz      w8, #0x1f, #0x1003e70dc                    
0x1003e70d4 ldr      x0, [sp, #0x18]                            
0x1003e70d8 bl       #0x10314b5b4                               
0x1003e70dc ldr      x23, [x23]                                 
0x1003e70e0 mov      w8, #1                                     
0x1003e70e4 cbnz     x23, #0x1003e704c                          
0x1003e70e8 b        #0x1003e718c                               
0x1003e70ec tbnz     w8, #0, #0x1003e718c                       
0x1003e70f0 adrp     x8, #0x104826000                           
0x1003e70f4 ldrsw    x8, [x8, #0xd3c]                           
0x1003e70f8 mov      w9, #-1                                    
0x1003e70fc str      w9, [x19, x8]                              
0x1003e7100 adrp     x8, #0x104826000                           
0x1003e7104 ldrsw    x22, [x8, #0xd34]                          
0x1003e7108 strb     wzr, [x19, x22]                            
0x1003e710c adrp     x8, #0x104826000                           
0x1003e7110 ldrsw    x21, [x8, #0xd38]                          
0x1003e7114 str      wzr, [x19, x21]                            
0x1003e7118 mov      x0, x20                                    
0x1003e711c bl       #0x1032e8dc0                               objc_msgSend$showRules
0x1003e7120 cbz      w0, #0x1003e7134                           
0x1003e7124 mov      x0, x20                                    
0x1003e7128 mov      w2, #0                                     
0x1003e712c bl       #0x1032c84a0                               objc_msgSend$setShowRules:
0x1003e7130 b        #0x1003e718c                               
0x1003e7134 mov      x0, x20                                    
0x1003e7138 bl       #0x103223740                               objc_msgSend$isToEnterGame
0x1003e713c cbz      w0, #0x1003e718c                           
0x1003e7140 mov      x0, x20                                    
0x1003e7144 bl       #0x10316a9c0                               objc_msgSend$active
0x1003e7148 cbz      w0, #0x1003e7180                           
0x1003e714c mov      x0, x20                                    
0x1003e7150 bl       #0x1031af820                               objc_msgSend$currentRatio
0x1003e7154 fcmp     s0, #0.0                                   
0x1003e7158 cset     w23, mi                                    
0x1003e715c mov      x0, x20                                    
0x1003e7160 bl       #0x1031af820                               objc_msgSend$currentRatio
0x1003e7164 fneg     s1, s0                                     
0x1003e7168 cmp      w23, #0                                    
0x1003e716c fcsel    s0, s1, s0, ne                             
0x1003e7170 adrp     x8, #0x103456000                           
0x1003e7174 ldr      s1, [x8, #0x990]                           
0x1003e7178 fcmp     s0, s1                                     
0x1003e717c b.le     #0x1003e71c0                               
0x1003e7180 mov      x0, x20                                    
0x1003e7184 mov      w2, #0                                     
0x1003e7188 bl       #0x1032c84a0                               objc_msgSend$setShowRules:
0x1003e718c ldr      x8, [sp, #0x38]                            
0x1003e7190 adrp     x9, #0x103ea5000                           
0x1003e7194 ldr      x9, [x9, #0x588]                           
0x1003e7198 ldr      x9, [x9]                                   
0x1003e719c cmp      x9, x8                                     
0x1003e71a0 b.ne     #0x1003e751c                               
0x1003e71a4 ldp      x29, x30, [sp, #0x80]                      
0x1003e71a8 ldp      x20, x19, [sp, #0x70]                      
0x1003e71ac ldp      x22, x21, [sp, #0x60]                      
0x1003e71b0 ldp      x24, x23, [sp, #0x50]                      
0x1003e71b4 ldp      x26, x25, [sp, #0x40]                      
0x1003e71b8 add      sp, sp, #0x90                              
0x1003e71bc ret                                                 
0x1003e71c0 adrp     x8, #0x104826000                           
0x1003e71c4 ldrsw    x25, [x8, #0xd30]                          
0x1003e71c8 add      x0, x19, x25                               
0x1003e71cc bl       #0x100b61428                               
0x1003e71d0 mov      w0, #1                                     
0x1003e71d4 mov      w1, #0                                     
0x1003e71d8 bl       #0x1008e861c                               
0x1003e71dc adrp     x8, #0x104826000                           
0x1003e71e0 ldrsw    x8, [x8, #0xcf0]                           
0x1003e71e4 ldrb     w8, [x19, x8]                              
0x1003e71e8 cmp      w8, #1                                     
0x1003e71ec b.ne     #0x1003e7204                               
0x1003e71f0 adrp     x0, #0x10401d000                           
0x1003e71f4 add      x0, x0, #0x398                             
0x1003e71f8 mov      w1, #0                                     
0x1003e71fc mov      w2, #1                                     
0x1003e7200 bl       #0x10004de64                               
0x1003e7204 mov      x0, x20                                    
0x1003e7208 bl       #0x1032178c0                               objc_msgSend$isAllInMode
0x1003e720c strb     w0, [x19, x22]                             
0x1003e7210 mov      x0, x20                                    
0x1003e7214 bl       #0x103301620                               objc_msgSend$tierCode
0x1003e7218 mov      x1, x0                                     
0x1003e721c adrp     x8, #0x104826000                           
0x1003e7220 ldrsw    x22, [x8, #0xd20]                          
0x1003e7224 add      x0, x19, x22                               
0x1003e7228 bl       #0x10314b1a0                               
0x1003e722c add      x0, x19, x22                               
0x1003e7230 bl       #0x100d85f48                               
0x1003e7234 bl       #0x100cfaddc                               
0x1003e7238 bl       #0x1004778e0                               
0x1003e723c bl       #0x100d860ec                               
0x1003e7240 ldr      x0, [x24, #0x5c8]                          
0x1003e7244 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003e7248 adrp     x8, #0x104826000                           
0x1003e724c ldrsw    x8, [x8, #0xce0]                           
0x1003e7250 ldr      x2, [x19, x8]                              
0x1003e7254 bl       #0x103296be0                               objc_msgSend$setCurrentTierSelector:
0x1003e7258 mov      x0, x20                                    
0x1003e725c bl       #0x103185b40                               objc_msgSend$betGroupId
0x1003e7260 cmn      w0, #1                                     
0x1003e7264 b.eq     #0x1003e729c                               
0x1003e7268 adrp     x8, #0x10480d000                           
0x1003e726c ldr      x0, [x8, #0x8b8]                           
0x1003e7270 add      x2, x19, x22                               
0x1003e7274 bl       #0x10330a740                               objc_msgSend$tryShowTierTutorialPopup:
0x1003e7278 mov      x21, x0                                    
0x1003e727c mov      x0, x20                                    
0x1003e7280 bl       #0x103185b40                               objc_msgSend$betGroupId
0x1003e7284 mov      x2, x0                                     
0x1003e7288 cbz      w21, #0x1003e737c                          
0x1003e728c add      x3, x19, x22                               
0x1003e7290 mov      x0, x19                                    
0x1003e7294 bl       #0x1032de2e0                               objc_msgSend$setupTutorialEndHandlerWithBet:tierCode:
0x1003e7298 b        #0x1003e718c                               
0x1003e729c mov      x0, x20                                    
0x1003e72a0 bl       #0x1031c3360                               objc_msgSend$entryFee
0x1003e72a4 str      w0, [x19, x21]                             
0x1003e72a8 ldr      x0, [x24, #0x5c8]                          
0x1003e72ac bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003e72b0 mov      x21, x0                                    
0x1003e72b4 adrp     x8, #0x104826000                           
0x1003e72b8 ldrsw    x8, [x8, #0xd1c]                           
0x1003e72bc ldrb     w8, [x19, x8]                              
0x1003e72c0 adrp     x9, #0x104790000                           
0x1003e72c4 add      x9, x9, #0xb70                             
0x1003e72c8 adrp     x10, #0x104790000                          
0x1003e72cc add      x10, x10, #0xe98                           
0x1003e72d0 cmp      w8, #0                                     
0x1003e72d4 csel     x8, x9, x10, ne                            
0x1003e72d8 ldr      x22, [x8]                                  
0x1003e72dc mov      x0, x20                                    
0x1003e72e0 bl       #0x103301620                               objc_msgSend$tierCode
0x1003e72e4 adrp     x8, #0x10480c000                           
0x1003e72e8 ldr      x8, [x8, #0x5f8]                           
0x1003e72ec ldrsb    w9, [x0, #0x17]                            
0x1003e72f0 ldr      x10, [x0]                                  
0x1003e72f4 cmp      w9, #0                                     
0x1003e72f8 csel     x2, x10, x0, lt                            
0x1003e72fc mov      x0, x8                                     
0x1003e7300 bl       #0x1032fbc40                               objc_msgSend$stringWithUTF8String:
0x1003e7304 mov      x23, x0                                    
0x1003e7308 mov      x0, x20                                    
0x1003e730c bl       #0x1031c3360                               objc_msgSend$entryFee
0x1003e7310 sxtw     x5, w0                                     
0x1003e7314 mov      x0, x21                                    
0x1003e7318 mov      x2, x19                                    
0x1003e731c mov      x3, x22                                    
0x1003e7320 mov      x4, x23                                    
0x1003e7324 bl       #0x103322100                               objc_msgSend$willShowCoinsPopUpForCallback:selector:parameter:withPrice:
0x1003e7328 sub      w8, w0, #1                                 
0x1003e732c cmn      w8, #2                                     
0x1003e7330 b.lo     #0x1003e718c                               
0x1003e7334 adrp     x8, #0x10480d000                           
0x1003e7338 ldr      x21, [x8, #0x8b0]                          
0x1003e733c mov      x0, x20                                    
0x1003e7340 bl       #0x103241e20                               objc_msgSend$nominatePocketMode
0x1003e7344 mov      x2, x0                                     
0x1003e7348 mov      x0, x21                                    
0x1003e734c bl       #0x10318efe0                               objc_msgSend$canShowPopup:
0x1003e7350 mov      x21, x0                                    
0x1003e7354 mov      x0, x20                                    
0x1003e7358 bl       #0x103241e20                               objc_msgSend$nominatePocketMode
0x1003e735c cmp      w0, #4                                     
0x1003e7360 b.eq     #0x1003e7374                               
0x1003e7364 mov      x0, x20                                    
0x1003e7368 bl       #0x103241e20                               objc_msgSend$nominatePocketMode
0x1003e736c cmp      w0, #3                                     
0x1003e7370 b.ne     #0x1003e738c                               
0x1003e7374 mov      w8, #0                                     
0x1003e7378 b        #0x1003e739c                               
0x1003e737c add      x3, x19, x22                               
0x1003e7380 mov      x0, x19                                    
0x1003e7384 bl       #0x103301600                               objc_msgSend$tierBetSelection:tierCode:
0x1003e7388 b        #0x1003e718c                               
0x1003e738c mov      x0, x20                                    
0x1003e7390 bl       #0x103241e20                               objc_msgSend$nominatePocketMode
0x1003e7394 cmp      w0, #5                                     
0x1003e7398 cset     w8, ne                                     
0x1003e739c cbz      w21, #0x1003e7420                          
0x1003e73a0 tbnz     w8, #0, #0x1003e7420                       
0x1003e73a4 adrp     x8, #0x10480c000                           
0x1003e73a8 ldr      x0, [x8, #0x6c0]                           
0x1003e73ac bl       #0x1031b3d00                               objc_msgSend$defaultCenter
0x1003e73b0 adrp     x8, #0x104802000                           
0x1003e73b4 ldr      x3, [x8, #0x608]                           
0x1003e73b8 adrp     x4, #0x10402e000                           
0x1003e73bc add      x4, x4, #0x4f8                             
0x1003e73c0 mov      x2, x19                                    
0x1003e73c4 mov      x5, #0                                     
0x1003e73c8 bl       #0x103173b60                               objc_msgSend$addObserver:selector:name:object:
0x1003e73cc ldr      x0, [x24, #0x5c8]                          
0x1003e73d0 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003e73d4 mov      x19, x0                                    
0x1003e73d8 adrp     x8, #0x10480c000                           
0x1003e73dc ldr      x21, [x8, #0x550]                          
0x1003e73e0 mov      x0, x20                                    
0x1003e73e4 bl       #0x103241e20                               objc_msgSend$nominatePocketMode
0x1003e73e8 mov      x2, x0                                     
0x1003e73ec mov      x0, x21                                    
0x1003e73f0 bl       #0x103243ee0                               objc_msgSend$numberWithFloat:
0x1003e73f4 mov      x2, x0                                     
0x1003e73f8 adrp     x3, #0x10402e000                           
0x1003e73fc add      x3, x3, #0x518                             
0x1003e7400 mov      x0, x19                                    
0x1003e7404 mov      w4, #0x87                                  
0x1003e7408 bl       #0x1032ba680                               objc_msgSend$setParameter:withKey:forState:
0x1003e740c ldr      x0, [x24, #0x5c8]                          
0x1003e7410 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003e7414 mov      w2, #0x87                                  
0x1003e7418 bl       #0x103263be0                               objc_msgSend$pushNextMenuState:
0x1003e741c b        #0x1003e718c                               
0x1003e7420 adrp     x8, #0x10480d000                           
0x1003e7424 ldr      x21, [x8, #0x8b8]                          
0x1003e7428 mov      x0, x20                                    
0x1003e742c bl       #0x103301620                               objc_msgSend$tierCode
0x1003e7430 mov      x2, x0                                     
0x1003e7434 mov      x0, x21                                    
0x1003e7438 bl       #0x10330a740                               objc_msgSend$tryShowTierTutorialPopup:
0x1003e743c cbz      w0, #0x1003e744c                           
0x1003e7440 add      x0, x19, x25                               
0x1003e7444 bl       #0x100b6153c                               
0x1003e7448 tbz      w0, #0, #0x1003e7458                       
0x1003e744c mov      x0, x19                                    
0x1003e7450 bl       #0x103301680                               objc_msgSend$tierRulesAccepted
0x1003e7454 b        #0x1003e718c                               
0x1003e7458 adrp     x8, #0x104826000                           
0x1003e745c add      x8, x8, #0xe0                              
0x1003e7460 ldrsw    x8, [x8]                                   
0x1003e7464 add      x8, x19, x8                                
0x1003e7468 ldp      x21, x20, [x8]                             
0x1003e746c cbz      x20, #0x1003e7484                          
0x1003e7470 add      x8, x20, #0x10                             
0x1003e7474 ldxr     x9, [x8]                                   
0x1003e7478 add      x9, x9, #1                                 
0x1003e747c stxr     w10, x9, [x8]                              
0x1003e7480 cbnz     w10, #0x1003e7474                          
0x1003e7484 adrp     x8, #0x104959000                           
0x1003e7488 add      x8, x8, #0x9b0                             
0x1003e748c ldr      x1, [x8]                                   
0x1003e7490 mov      x0, sp                                     
0x1003e7494 bl       #0x100004538                               
0x1003e7498 cbz      x20, #0x1003e74b0                          
0x1003e749c add      x8, x20, #0x10                             
0x1003e74a0 ldxr     x9, [x8]                                   
0x1003e74a4 add      x9, x9, #1                                 
0x1003e74a8 stxr     w10, x9, [x8]                              
0x1003e74ac cbnz     w10, #0x1003e74a0                          
0x1003e74b0 adrp     x8, #0x103ec1000                           
0x1003e74b4 add      x8, x8, #0xd58                             
0x1003e74b8 stp      x8, x21, [sp, #0x18]                       
0x1003e74bc add      x21, sp, #0x18                             
0x1003e74c0 stp      x20, x21, [sp, #0x28]                      
0x1003e74c4 add      x0, x19, x25                               
0x1003e74c8 mov      x1, sp                                     
0x1003e74cc add      x2, sp, #0x18                              
0x1003e74d0 bl       #0x100b6154c                               
0x1003e74d4 ldr      x0, [sp, #0x30]                            
0x1003e74d8 cmp      x0, x21                                    
0x1003e74dc b.eq     #0x1003e74ec                               
0x1003e74e0 cbz      x0, #0x1003e74fc                           
0x1003e74e4 mov      w8, #0x28                                  
0x1003e74e8 b        #0x1003e74f0                               
0x1003e74ec mov      w8, #0x20                                  
0x1003e74f0 ldr      x9, [x0]                                   
0x1003e74f4 ldr      x8, [x9, x8]                               
0x1003e74f8 blr      x8                                         
0x1003e74fc ldrsb    w8, [sp, #0x17]                            
0x1003e7500 tbz      w8, #0x1f, #0x1003e750c                    
0x1003e7504 ldr      x0, [sp]                                   
0x1003e7508 bl       #0x10314b5b4                               
0x1003e750c cbz      x20, #0x1003e718c                          
0x1003e7510 mov      x0, x20                                    
0x1003e7514 bl       #0x10314b374                               
0x1003e7518 b        #0x1003e718c                               
0x1003e751c bl       #0x10314b740                               
0x1003e7520 mov      x19, x0                                    
0x1003e7524 ldr      x0, [sp, #0x30]                            
0x1003e7528 cmp      x0, x21                                    
0x1003e752c b.ne     #0x1003e7538                               
0x1003e7530 mov      w8, #0x20                                  
0x1003e7534 b        #0x1003e7540                               
0x1003e7538 cbz      x0, #0x1003e754c                           
0x1003e753c mov      w8, #0x28                                  
0x1003e7540 ldr      x9, [x0]                                   
0x1003e7544 ldr      x8, [x9, x8]                               
0x1003e7548 blr      x8                                         
0x1003e754c ldrsb    w8, [sp, #0x17]                            
0x1003e7550 tbz      w8, #0x1f, #0x1003e7564                    
0x1003e7554 ldr      x0, [sp]                                   
0x1003e7558 bl       #0x10314b5b4                               
0x1003e755c b        #0x1003e7564                               
0x1003e7560 mov      x19, x0                                    
0x1003e7564 cbz      x20, #0x1003e75a8                          
0x1003e7568 mov      x0, x20                                    
0x1003e756c bl       #0x10314b374                               
0x1003e7570 b        #0x1003e75a8                               
0x1003e7574 mov      x19, x0                                    
0x1003e7578 cbz      w1, #0x1003e75a8                           
0x1003e757c mov      x0, x19                                    
0x1003e7580 bl       #0x100004414                               
0x1003e7584 mov      x19, x0                                    
0x1003e7588 mov      x0, sp                                     
0x1003e758c bl       #0x100fd57a4                               
0x1003e7590 ldrsb    w8, [sp, #0x2f]                            
0x1003e7594 tbz      w8, #0x1f, #0x1003e75a8                    
0x1003e7598 ldr      x0, [sp, #0x18]                            
0x1003e759c bl       #0x10314b5b4                               
0x1003e75a0 b        #0x1003e75a8                               
0x1003e75a4 mov      x19, x0                                    
0x1003e75a8 mov      x0, x19                                    
0x1003e75ac bl       #0x10314af6c                               

MenuTierSelector.isTournament
0x1003e8c24 stp      x20, x19, [sp, #-0x20]!                    
0x1003e8c28 stp      x29, x30, [sp, #0x10]                      
0x1003e8c2c add      x29, sp, #0x10                             
0x1003e8c30 mov      x19, x0                                    
0x1003e8c34 adrp     x8, #0x10480c000                           
0x1003e8c38 ldr      x0, [x8, #0x690]                           
0x1003e8c3c bl       #0x1032e12a0                               objc_msgSend$sharedMCConfigurationDataCpp
0x1003e8c40 adrp     x8, #0x104826000                           
0x1003e8c44 ldrsw    x8, [x8, #0xce0]                           
0x1003e8c48 ldr      x5, [x19, x8]                              
0x1003e8c4c adrp     x2, #0x10402e000                           
0x1003e8c50 add      x2, x2, #0x598                             
0x1003e8c54 adrp     x3, #0x104028000                           
0x1003e8c58 add      x3, x3, #0x978                             
0x1003e8c5c adrp     x4, #0x104020000                           
0x1003e8c60 add      x4, x4, #0x798                             
0x1003e8c64 bl       #0x10331a660                               objc_msgSend$valueForField:atTable:searchByField:withValue:
0x1003e8c68 mov      w1, #0                                     
0x1003e8c6c ldp      x29, x30, [sp, #0x10]                      
0x1003e8c70 ldp      x20, x19, [sp], #0x20                      
0x1003e8c74 b        #0x101652cc0                               

MenuTierSelector.getCurrentTier
0x1003e86f8 adrp     x8, #0x104826000                           
0x1003e86fc ldrsw    x8, [x8, #0xd20]                           
0x1003e8700 add      x0, x0, x8                                 
0x1003e8704 ret                                                 

MenuTierSelectorNode.isAllInMode
0x1004e0aec adrp     x8, #0x104827000                           
0x1004e0af0 ldrsw    x8, [x8, #0xa18]                           
0x1004e0af4 ldr      w8, [x0, x8]                               
0x1004e0af8 cmp      w8, #2                                     
0x1004e0afc cset     w0, eq                                     
0x1004e0b00 ret                                                 

MenuTierSelectorNode.isTournament
0x1004e1304 mov      w0, #0                                     
0x1004e1308 ret                                                 

MenuTierSelectorNode.active
0x1004e13fc adrp     x8, #0x104827000                           
0x1004e1400 ldrsw    x8, [x8, #0xabc]                           
0x1004e1404 ldrb     w0, [x0, x8]                               
0x1004e1408 ret                                                 

MenuTierSelectorNode.isToEnterGame
0x1004e1284 adrp     x8, #0x104827000                           
0x1004e1288 ldrsw    x8, [x8, #0xb18]                           
0x1004e128c ldrb     w8, [x0, x8]                               
0x1004e1290 mov      w9, #1                                     
0x1004e1294 bic      w0, w9, w8                                 
0x1004e1298 ret                                                 

MenuTierSelectorNode.showRules
0x1004e140c adrp     x8, #0x104827000                           
0x1004e1410 ldrsw    x8, [x8, #0xac4]                           
0x1004e1414 ldrb     w0, [x0, x8]                               
0x1004e1418 ret                                                 

MenuTierSelectorNode.betGroupId
0x1004e144c adrp     x8, #0x104827000                           
0x1004e1450 ldrsw    x8, [x8, #0xa30]                           
0x1004e1454 ldr      w0, [x0, x8]                               
0x1004e1458 ret                                                 

MenuTierSelectorNode.entryFee
0x1004e13ec adrp     x8, #0x104827000                           
0x1004e13f0 ldrsw    x8, [x8, #0xab8]                           
0x1004e13f4 ldr      w0, [x0, x8]                               
0x1004e13f8 ret                                                 

MenuTierSelectorNode.currentRatio
0x1004e141c adrp     x8, #0x104827000                           
0x1004e1420 ldrsw    x8, [x8, #0xba4]                           
0x1004e1424 ldr      s0, [x0, x8]                               
0x1004e1428 ret                                                 

MenuTierSelectorNode.tierCode
0x1004e13dc adrp     x8, #0x104827000                           
0x1004e13e0 ldrsw    x8, [x8, #0x9ec]                           
0x1004e13e4 add      x0, x0, x8                                 
0x1004e13e8 ret                                                 

CCTable.enabled
0x101443f4c adrp     x8, #0x104831000                           
0x101443f50 ldrsw    x8, [x8, #0x42c]                           
0x101443f54 ldrb     w0, [x0, x8]                               
0x101443f58 ret                                                 

CCTable.getCellForCurrentOffset
0x101440348 sub      sp, sp, #0x150                             
0x10144034c stp      d11, d10, [sp, #0xd0]                      
0x101440350 stp      d9, d8, [sp, #0xe0]                        
0x101440354 stp      x28, x27, [sp, #0xf0]                      
0x101440358 stp      x26, x25, [sp, #0x100]                     
0x10144035c stp      x24, x23, [sp, #0x110]                     
0x101440360 stp      x22, x21, [sp, #0x120]                     
0x101440364 stp      x20, x19, [sp, #0x130]                     
0x101440368 stp      x29, x30, [sp, #0x140]                     
0x10144036c add      x29, sp, #0x140                            
0x101440370 mov      x19, x0                                    
0x101440374 adrp     x8, #0x103ea5000                           
0x101440378 ldr      x8, [x8, #0x588]                           
0x10144037c ldr      x8, [x8]                                   
0x101440380 stur     x8, [x29, #-0x80]                          
0x101440384 bl       #0x1031d9640                               objc_msgSend$getCurrentGridOffset
0x101440388 fmov     s9, wzr                                    
0x10144038c fcmp     s0, #0.0                                   
0x101440390 fmov     s8, wzr                                    
0x101440394 b.le     #0x1014403a4                               
0x101440398 mov      x0, x19                                    
0x10144039c bl       #0x1031d9640                               objc_msgSend$getCurrentGridOffset
0x1014403a0 fmov     s8, s0                                     
0x1014403a4 movi     v0.16b, #0                                 
0x1014403a8 stp      q0, q0, [sp, #0x20]                        
0x1014403ac stp      q0, q0, [sp]                               
0x1014403b0 adrp     x8, #0x104831000                           
0x1014403b4 ldrsw    x8, [x8, #0x3a4]                           
0x1014403b8 ldr      x20, [x19, x8]                             
0x1014403bc mov      x2, sp                                     
0x1014403c0 add      x3, sp, #0x40                              
0x1014403c4 mov      x0, x20                                    
0x1014403c8 mov      w4, #0x10                                  
0x1014403cc bl       #0x1031a00e0                               objc_msgSend$countByEnumeratingWithState:objects:count:
0x1014403d0 cbz      x0, #0x1014404a0                           
0x1014403d4 mov      x21, x0                                    
0x1014403d8 mov      x23, #0                                    
0x1014403dc mov      x24, #0                                    
0x1014403e0 mov      w25, #0                                    
0x1014403e4 ldr      x8, [sp, #0x10]                            
0x1014403e8 ldr      x26, [x8]                                  
0x1014403ec adrp     x27, #0x104831000                          
0x1014403f0 fmov     s10, wzr                                   
0x1014403f4 mov      x28, #0                                    
0x1014403f8 ldr      x8, [sp, #0x10]                            
0x1014403fc ldr      x8, [x8]                                   
0x101440400 cmp      x8, x26                                    
0x101440404 b.eq     #0x101440410                               
0x101440408 mov      x0, x20                                    
0x10144040c bl       #0x10314c580                               
0x101440410 ldr      x8, [sp, #8]                               
0x101440414 ldr      x8, [x8, x28, lsl #3]                      
0x101440418 ldr      x22, [x8, #0x10]                           
0x10144041c ldrsw    x8, [x27, #0x448]                          
0x101440420 ldrb     w8, [x19, x8]                              
0x101440424 tbnz     w8, #0, #0x101440434                       
0x101440428 mov      x0, x22                                    
0x10144042c bl       #0x10321aa00                               objc_msgSend$isEnabled
0x101440430 cbz      w0, #0x101440474                           
0x101440434 ucvtf    s0, w25                                    
0x101440438 fcmp     s8, s0                                     
0x10144043c b.lt     #0x101440454                               
0x101440440 fabd     s1, s8, s0                                 
0x101440444 fcmp     s1, s9                                     
0x101440448 ccmp     x23, #0, #4, pl                            
0x10144044c fcsel    s9, s1, s9, eq                             
0x101440450 csel     x23, x22, x23, eq                          
0x101440454 fcmp     s8, s0                                     
0x101440458 b.hi     #0x101440470                               
0x10144045c fabd     s0, s0, s8                                 
0x101440460 fcmp     s0, s10                                    
0x101440464 ccmp     x24, #0, #4, pl                            
0x101440468 fcsel    s10, s0, s10, eq                           
0x10144046c csel     x24, x22, x24, eq                          
0x101440470 add      w25, w25, #1                               
0x101440474 add      x28, x28, #1                               
0x101440478 cmp      x21, x28                                   
0x10144047c b.ne     #0x1014403f8                               
0x101440480 mov      x2, sp                                     
0x101440484 add      x3, sp, #0x40                              
0x101440488 mov      x0, x20                                    
0x10144048c mov      w4, #0x10                                  
0x101440490 bl       #0x1031a00e0                               objc_msgSend$countByEnumeratingWithState:objects:count:
0x101440494 mov      x21, x0                                    
0x101440498 cbnz     x0, #0x1014403f4                           
0x10144049c b        #0x1014404ac                               
0x1014404a0 mov      x23, #0                                    
0x1014404a4 mov      x24, #0                                    
0x1014404a8 fmov     s10, wzr                                   
0x1014404ac fcmp     s9, s10                                    
0x1014404b0 ccmp     x24, #0, #4, hi                            
0x1014404b4 ccmp     x23, #0, #4, eq                            
0x1014404b8 csel     x0, x24, x23, eq                           
0x1014404bc ldur     x8, [x29, #-0x80]                          
0x1014404c0 adrp     x9, #0x103ea5000                           
0x1014404c4 ldr      x9, [x9, #0x588]                           
0x1014404c8 ldr      x9, [x9]                                   
0x1014404cc cmp      x9, x8                                     
0x1014404d0 b.ne     #0x1014404fc                               
0x1014404d4 ldp      x29, x30, [sp, #0x140]                     
0x1014404d8 ldp      x20, x19, [sp, #0x130]                     
0x1014404dc ldp      x22, x21, [sp, #0x120]                     
0x1014404e0 ldp      x24, x23, [sp, #0x110]                     
0x1014404e4 ldp      x26, x25, [sp, #0x100]                     
0x1014404e8 ldp      x28, x27, [sp, #0xf0]                      
0x1014404ec ldp      d9, d8, [sp, #0xe0]                        
0x1014404f0 ldp      d11, d10, [sp, #0xd0]                      
0x1014404f4 add      sp, sp, #0x150                             
0x1014404f8 ret                                                 
0x1014404fc bl       #0x10314b740                               

UserInfo.hasEnoughCoins:
0x1002c7eb8 stp      x20, x19, [sp, #-0x20]!                    
0x1002c7ebc stp      x29, x30, [sp, #0x10]                      
0x1002c7ec0 add      x29, sp, #0x10                             
0x1002c7ec4 mov      x19, x2                                    
0x1002c7ec8 bl       #0x103198e20                               objc_msgSend$coins
0x1002c7ecc cmp      x0, x19                                    
0x1002c7ed0 cset     w0, hs                                     
0x1002c7ed4 ldp      x29, x30, [sp, #0x10]                      
0x1002c7ed8 ldp      x20, x19, [sp], #0x20                      
0x1002c7edc ret                                                 

UserInfo.isUserInfoInitialized
0x1002c61f0 adrp     x8, #0x104adf000                           
0x1002c61f4 ldr      x8, [x8, #0xb38]                           
0x1002c61f8 cmp      x8, #0                                     
0x1002c61fc cset     w0, ne                                     
0x1002c6200 ret                                                 

UserInfo.sharedUserInfo
0x1002c61bc stp      x20, x19, [sp, #-0x20]!                    
0x1002c61c0 stp      x29, x30, [sp, #0x10]                      
0x1002c61c4 add      x29, sp, #0x10                             
0x1002c61c8 adrp     x19, #0x104adf000                          
0x1002c61cc ldr      x0, [x19, #0xb38]                          
0x1002c61d0 cbnz     x0, #0x1002c61e4                           
0x1002c61d4 adrp     x8, #0x10480c000                           
0x1002c61d8 ldr      x0, [x8, #0x688]                           
0x1002c61dc bl       #0x10314c4d8                               
0x1002c61e0 str      x0, [x19, #0xb38]                          
0x1002c61e4 ldp      x29, x30, [sp, #0x10]                      
0x1002c61e8 ldp      x20, x19, [sp], #0x20                      
0x1002c61ec ret                                                 

MenuPlayerMatch.backButtonCallback
0x1003c78a0 adrp     x8, #0x104826000                           
0x1003c78a4 ldrsw    x8, [x8, #0xa10]                           
0x1003c78a8 strb     wzr, [x0, x8]                              
0x1003c78ac adrp     x8, #0x104826000                           
0x1003c78b0 ldrsw    x8, [x8, #0xa14]                           
0x1003c78b4 strb     wzr, [x0, x8]                              
0x1003c78b8 b        #0x1031ed6a0                               objc_msgSend$goBack

MenuPlayerMatch.goBack
0x1003c7948 sub      sp, sp, #0x60                              
0x1003c794c stp      x20, x19, [sp, #0x40]                      
0x1003c7950 stp      x29, x30, [sp, #0x50]                      
0x1003c7954 add      x29, sp, #0x50                             
0x1003c7958 mov      x19, x0                                    
0x1003c795c add      x0, sp, #8                                 
0x1003c7960 bl       #0x1009402d0                               
0x1003c7964 adrp     x8, #0x104826000                           
0x1003c7968 ldrsw    x8, [x8, #0x9e8]                           
0x1003c796c ldr      x0, [x19, x8]                              
0x1003c7970 cbz      x0, #0x1003c79a8                           
0x1003c7974 bl       #0x1031f9b20                               objc_msgSend$hostWon
0x1003c7978 cmp      w0, #0                                     
0x1003c797c mov      w8, #1                                     
0x1003c7980 cinc     w8, w8, eq                                 
0x1003c7984 ldr      w9, [sp, #0x28]                            
0x1003c7988 orr      w9, w9, #2                                 
0x1003c798c str      w9, [sp, #0x28]                            
0x1003c7990 str      w8, [sp, #0x38]                            
0x1003c7994 bl       #0x100045d64                               
0x1003c7998 add      x3, sp, #8                                 
0x1003c799c mov      w1, #2                                     
0x1003c79a0 mov      w2, #1                                     
0x1003c79a4 bl       #0x1001085b4                               
0x1003c79a8 bl       #0x1006c0edc                               
0x1003c79ac bl       #0x1006c162c                               
0x1003c79b0 mov      x0, x19                                    
0x1003c79b4 bl       #0x1031f0720                               objc_msgSend$handleGoBack
0x1003c79b8 add      x0, sp, #8                                 
0x1003c79bc bl       #0x1009b88bc                               
0x1003c79c0 ldp      x29, x30, [sp, #0x50]                      
0x1003c79c4 ldp      x20, x19, [sp, #0x40]                      
0x1003c79c8 add      sp, sp, #0x60                              
0x1003c79cc ret                                                 
0x1003c79d0 b        #0x1003c79d4                               
0x1003c79d4 mov      x19, x0                                    
0x1003c79d8 add      x0, sp, #8                                 
0x1003c79dc bl       #0x1009b88bc                               
0x1003c79e0 mov      x0, x19                                    
0x1003c79e4 bl       #0x10314af6c                               

MenuPlayerMatch.handleGoBack
0x1003c79e8 sub      sp, sp, #0xa0                              
0x1003c79ec stp      x24, x23, [sp, #0x60]                      
0x1003c79f0 stp      x22, x21, [sp, #0x70]                      
0x1003c79f4 stp      x20, x19, [sp, #0x80]                      
0x1003c79f8 stp      x29, x30, [sp, #0x90]                      
0x1003c79fc add      x29, sp, #0x90                             
0x1003c7a00 mov      x19, x0                                    
0x1003c7a04 adrp     x8, #0x103ea5000                           
0x1003c7a08 ldr      x8, [x8, #0x588]                           
0x1003c7a0c ldr      x8, [x8]                                   
0x1003c7a10 stur     x8, [x29, #-0x38]                          
0x1003c7a14 adrp     x8, #0x104826000                           
0x1003c7a18 ldrsw    x8, [x8, #0xa14]                           
0x1003c7a1c ldrb     w8, [x0, x8]                               
0x1003c7a20 cmp      w8, #1                                     
0x1003c7a24 b.ne     #0x1003c7a68                               
0x1003c7a28 adrp     x8, #0x104826000                           
0x1003c7a2c ldrsw    x8, [x8, #0xa10]                           
0x1003c7a30 mov      w9, #1                                     
0x1003c7a34 strb     w9, [x19, x8]                              
0x1003c7a38 ldur     x8, [x29, #-0x38]                          
0x1003c7a3c adrp     x9, #0x103ea5000                           
0x1003c7a40 ldr      x9, [x9, #0x588]                           
0x1003c7a44 ldr      x9, [x9]                                   
0x1003c7a48 cmp      x9, x8                                     
0x1003c7a4c b.ne     #0x1003c7d84                               
0x1003c7a50 ldp      x29, x30, [sp, #0x90]                      
0x1003c7a54 ldp      x20, x19, [sp, #0x80]                      
0x1003c7a58 ldp      x22, x21, [sp, #0x70]                      
0x1003c7a5c ldp      x24, x23, [sp, #0x60]                      
0x1003c7a60 add      sp, sp, #0xa0                              
0x1003c7a64 ret                                                 
0x1003c7a68 adrp     x8, #0x104826000                           
0x1003c7a6c ldrsw    x20, [x8, #0xa1c]                          
0x1003c7a70 ldr      x8, [x19, x20]                             
0x1003c7a74 cbz      x8, #0x1003c7ae4                           
0x1003c7a78 adrp     x8, #0x10480c000                           
0x1003c7a7c ldr      x0, [x8, #0xa48]                           
0x1003c7a80 bl       #0x1031b2340                               objc_msgSend$date
0x1003c7a84 ldr      x2, [x19, x20]                             
0x1003c7a88 bl       #0x103301a00                               objc_msgSend$timeIntervalSinceDate:
0x1003c7a8c fcvt     s0, d0                                     
0x1003c7a90 fmov     s1, #4.00000000                            
0x1003c7a94 fcmp     s0, s1                                     
0x1003c7a98 b.pl     #0x1003c7ad4                               
0x1003c7a9c ldur     x8, [x29, #-0x38]                          
0x1003c7aa0 adrp     x9, #0x103ea5000                           
0x1003c7aa4 ldr      x9, [x9, #0x588]                           
0x1003c7aa8 ldr      x9, [x9]                                   
0x1003c7aac cmp      x9, x8                                     
0x1003c7ab0 b.ne     #0x1003c7d84                               
0x1003c7ab4 fsub     s0, s1, s0                                 
0x1003c7ab8 mov      x0, x19                                    
0x1003c7abc ldp      x29, x30, [sp, #0x90]                      
0x1003c7ac0 ldp      x20, x19, [sp, #0x80]                      
0x1003c7ac4 ldp      x22, x21, [sp, #0x70]                      
0x1003c7ac8 ldp      x24, x23, [sp, #0x60]                      
0x1003c7acc add      sp, sp, #0xa0                              
0x1003c7ad0 b        #0x103274f00                               objc_msgSend$rescheduleGoBack:
0x1003c7ad4 ldr      x0, [x19, x20]                             
0x1003c7ad8 cbz      x0, #0x1003c7ae4                           
0x1003c7adc bl       #0x10314c664                               
0x1003c7ae0 str      xzr, [x19, x20]                            
0x1003c7ae4 adrp     x8, #0x104826000                           
0x1003c7ae8 ldrsw    x8, [x8, #0xa10]                           
0x1003c7aec strb     wzr, [x19, x8]                             
0x1003c7af0 mov      x0, x19                                    
0x1003c7af4 bl       #0x10330d4e0                               objc_msgSend$unscheduleAllSelectors
0x1003c7af8 adrp     x8, #0x104826000                           
0x1003c7afc ldrsw    x8, [x8, #0xa9c]                           
0x1003c7b00 ldr      x0, [x19, x8]                              
0x1003c7b04 bl       #0x10331eb60                               objc_msgSend$visible
0x1003c7b08 adrp     x20, #0x104826000                          
0x1003c7b0c tbnz     w0, #0, #0x1003c7b1c                       
0x1003c7b10 ldrsw    x8, [x20, #0xb10]                          
0x1003c7b14 ldr      w8, [x19, x8]                              
0x1003c7b18 cbnz     w8, #0x1003c7a38                           
0x1003c7b1c mov      w0, #0x75                                  
0x1003c7b20 bl       #0x100bad4f4                               
0x1003c7b24 ldrsw    x21, [x20, #0xb10]                         
0x1003c7b28 ldr      w8, [x19, x21]                             
0x1003c7b2c mov      w20, #1                                    
0x1003c7b30 adrp     x23, #0x10480c000                          
0x1003c7b34 cmp      w8, #2                                     
0x1003c7b38 b.gt     #0x1003c7b4c                               
0x1003c7b3c cbz      w8, #0x1003c7b5c                           
0x1003c7b40 cmp      w8, #2                                     
0x1003c7b44 b.eq     #0x1003c7b9c                               
0x1003c7b48 b        #0x1003c7b80                               
0x1003c7b4c cmp      w8, #4                                     
0x1003c7b50 b.eq     #0x1003c7b9c                               
0x1003c7b54 cmp      w8, #3                                     
0x1003c7b58 b.ne     #0x1003c7b80                               
0x1003c7b5c bl       #0x100045d64                               
0x1003c7b60 bl       #0x100103628                               
0x1003c7b64 ldr      w8, [x19, x21]                             
0x1003c7b68 cbnz     w8, #0x1003c7b80                           
0x1003c7b6c adrp     x8, #0x104826000                           
0x1003c7b70 ldrsw    x8, [x8, #0x9e8]                           
0x1003c7b74 ldr      x0, [x19, x8]                              
0x1003c7b78 bl       #0x1031f9b20                               objc_msgSend$hostWon
0x1003c7b7c eor      w20, w0, #1                                
0x1003c7b80 ldr      x0, [x23, #0x5c8]                          
0x1003c7b84 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003c7b88 mov      x2, x20                                    
0x1003c7b8c bl       #0x1032a1aa0                               objc_msgSend$setGoToSelectedTier:
0x1003c7b90 mov      x0, x19                                    
0x1003c7b94 bl       #0x10326c2e0                               objc_msgSend$removeBackButtonPressedObserver
0x1003c7b98 b        #0x1003c7c78                               
0x1003c7b9c adrp     x8, #0x104826000                           
0x1003c7ba0 ldrsw    x22, [x8, #0x9e8]                          
0x1003c7ba4 ldr      x0, [x19, x22]                             
0x1003c7ba8 bl       #0x1031f9b20                               objc_msgSend$hostWon
0x1003c7bac mov      x20, x0                                    
0x1003c7bb0 ldr      w8, [x19, x21]                             
0x1003c7bb4 cmp      w8, #4                                     
0x1003c7bb8 b.ne     #0x1003c7c20                               
0x1003c7bbc bl       #0x100045d64                               
0x1003c7bc0 mov      x21, x0                                    
0x1003c7bc4 ldr      x0, [x19, x22]                             
0x1003c7bc8 bl       #0x10324cb00                               objc_msgSend$opponentId
0x1003c7bcc mov      x22, x0                                    
0x1003c7bd0 adrp     x1, #0x103653000                           
0x1003c7bd4 add      x1, x1, #0x650                             
0x1003c7bd8 add      x0, sp, #0x20                              
0x1003c7bdc bl       #0x100004538                               
0x1003c7be0 add      x8, sp, #0x38                              
0x1003c7be4 add      x1, sp, #0x20                              
0x1003c7be8 mov      x0, x22                                    
0x1003c7bec bl       #0x1008dfc90                               
0x1003c7bf0 add      x1, sp, #0x38                              
0x1003c7bf4 mov      x0, x21                                    
0x1003c7bf8 mov      w2, #1                                     
0x1003c7bfc bl       #0x100106ac0                               
0x1003c7c00 ldrsb    w8, [sp, #0x4f]                            
0x1003c7c04 tbz      w8, #0x1f, #0x1003c7c10                    
0x1003c7c08 ldr      x0, [sp, #0x38]                            
0x1003c7c0c bl       #0x10314b5b4                               
0x1003c7c10 ldrsb    w8, [sp, #0x37]                            
0x1003c7c14 tbz      w8, #0x1f, #0x1003c7c20                    
0x1003c7c18 ldr      x0, [sp, #0x20]                            
0x1003c7c1c bl       #0x10314b5b4                               
0x1003c7c20 adrp     x8, #0x10480c000                           
0x1003c7c24 ldr      x0, [x8, #0xc50]                           
0x1003c7c28 bl       #0x1032e0de0                               objc_msgSend$sharedAdsManager
0x1003c7c2c bl       #0x103220fe0                               objc_msgSend$isReadyToShowInterstitial
0x1003c7c30 mov      x21, x0                                    
0x1003c7c34 ldr      x0, [x23, #0x5c8]                          
0x1003c7c38 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003c7c3c eor      w2, w20, #1                                
0x1003c7c40 bl       #0x1032a1aa0                               objc_msgSend$setGoToSelectedTier:
0x1003c7c44 mov      x0, x19                                    
0x1003c7c48 bl       #0x10326c2e0                               objc_msgSend$removeBackButtonPressedObserver
0x1003c7c4c cbz      w21, #0x1003c7c78                          
0x1003c7c50 adrp     x8, #0x104826000                           
0x1003c7c54 ldrsw    x8, [x8, #0x9fc]                           
0x1003c7c58 add      x8, x19, x8                                
0x1003c7c5c ldrsb    w9, [x8, #0x17]                            
0x1003c7c60 tbnz     w9, #0x1f, #0x1003c7cb8                    
0x1003c7c64 ldr      q0, [x8]                                   
0x1003c7c68 str      q0, [sp, #0x20]                            
0x1003c7c6c ldr      x8, [x8, #0x10]                            
0x1003c7c70 str      x8, [sp, #0x30]                            
0x1003c7c74 b        #0x1003c7cc4                               
0x1003c7c78 adrp     x8, #0x10480c000                           
0x1003c7c7c ldr      x0, [x8, #0x688]                           
0x1003c7c80 bl       #0x1032e1900                               objc_msgSend$sharedUserInfo
0x1003c7c84 bl       #0x10330b100                               objc_msgSend$tutorialCompleted
0x1003c7c88 mov      x20, x0                                    
0x1003c7c8c ldr      x0, [x23, #0x5c8]                          
0x1003c7c90 bl       #0x1032e1440                               objc_msgSend$sharedMenuManager
0x1003c7c94 cbz      w20, #0x1003c7cac                          
0x1003c7c98 adrp     x8, #0x104826000                           
0x1003c7c9c ldrsw    x8, [x8, #0x9fc]                           
0x1003c7ca0 add      x2, x19, x8                                
0x1003c7ca4 bl       #0x1031ed9a0                               objc_msgSend$goToSelectionTier:
0x1003c7ca8 b        #0x1003c7a38                               
0x1003c7cac mov      w2, #4                                     
0x1003c7cb0 bl       #0x103263be0                               objc_msgSend$pushNextMenuState:
0x1003c7cb4 b        #0x1003c7a38                               
0x1003c7cb8 ldp      x1, x2, [x8]                               
0x1003c7cbc add      x0, sp, #0x20                              
0x1003c7cc0 bl       #0x100007d0c                               
0x1003c7cc4 adrp     x8, #0x10480d000                           
0x1003c7cc8 ldr      x19, [x8, #0x230]                          
0x1003c7ccc ldrsb    w8, [sp, #0x37]                            
0x1003c7cd0 tbnz     w8, #0x1f, #0x1003c7ce8                    
0x1003c7cd4 ldr      q0, [sp, #0x20]                            
0x1003c7cd8 str      q0, [sp]                                   
0x1003c7cdc ldr      x8, [sp, #0x30]                            
0x1003c7ce0 str      x8, [sp, #0x10]                            
0x1003c7ce4 b        #0x1003c7cf4                               
0x1003c7ce8 ldp      x1, x2, [sp, #0x20]                        
0x1003c7cec mov      x0, sp                                     
0x1003c7cf0 bl       #0x100007d0c                               
0x1003c7cf4 str      xzr, [sp, #0x50]                           
0x1003c7cf8 mov      w0, #0x20                                  
0x1003c7cfc bl       #0x10314b5e4                               
0x1003c7d00 adrp     x8, #0x103ec1000                           
0x1003c7d04 add      x8, x8, #0x190                             
0x1003c7d08 str      x8, [x0]                                   
0x1003c7d0c ldr      q0, [sp]                                   
0x1003c7d10 stur     q0, [x0, #8]                               
0x1003c7d14 ldr      x8, [sp, #0x10]                            
0x1003c7d18 str      x8, [x0, #0x18]                            
0x1003c7d1c stp      xzr, xzr, [sp]                             
0x1003c7d20 str      xzr, [sp, #0x10]                           
0x1003c7d24 str      x0, [sp, #0x50]                            
0x1003c7d28 add      x20, sp, #0x38                             
0x1003c7d2c add      x2, sp, #0x38                              
0x1003c7d30 mov      x0, x19                                    
0x1003c7d34 bl       #0x1032e4ba0                               objc_msgSend$showAdBreakScreenWithCallback:
0x1003c7d38 ldr      x0, [sp, #0x50]                            
0x1003c7d3c cmp      x0, x20                                    
0x1003c7d40 b.eq     #0x1003c7d50                               
0x1003c7d44 cbz      x0, #0x1003c7d60                           
0x1003c7d48 mov      w8, #0x28                                  
0x1003c7d4c b        #0x1003c7d54                               
0x1003c7d50 mov      w8, #0x20                                  
0x1003c7d54 ldr      x9, [x0]                                   
0x1003c7d58 ldr      x8, [x9, x8]                               
0x1003c7d5c blr      x8                                         
0x1003c7d60 ldrsb    w8, [sp, #0x17]                            
0x1003c7d64 tbz      w8, #0x1f, #0x1003c7d70                    
0x1003c7d68 ldr      x0, [sp]                                   
0x1003c7d6c bl       #0x10314b5b4                               
0x1003c7d70 ldrsb    w8, [sp, #0x37]                            
0x1003c7d74 tbz      w8, #0x1f, #0x1003c7a38                    
0x1003c7d78 ldr      x0, [sp, #0x20]                            
0x1003c7d7c bl       #0x10314b5b4                               
0x1003c7d80 b        #0x1003c7a38                               
0x1003c7d84 bl       #0x10314b740                               
0x1003c7d88 b        #0x1003c7de8                               
0x1003c7d8c mov      x19, x0                                    
0x1003c7d90 ldr      x0, [sp, #0x50]                            
0x1003c7d94 cmp      x0, x20                                    
0x1003c7d98 b.ne     #0x1003c7da4                               
0x1003c7d9c mov      w8, #0x20                                  
0x1003c7da0 b        #0x1003c7dac                               
0x1003c7da4 cbz      x0, #0x1003c7dc0                           
0x1003c7da8 mov      w8, #0x28                                  
0x1003c7dac ldr      x9, [x0]                                   
0x1003c7db0 ldr      x8, [x9, x8]                               
0x1003c7db4 blr      x8                                         
0x1003c7db8 b        #0x1003c7dc0                               
0x1003c7dbc mov      x19, x0                                    
0x1003c7dc0 ldrsb    w8, [sp, #0x17]                            
0x1003c7dc4 tbz      w8, #0x1f, #0x1003c7dec                    
0x1003c7dc8 ldr      x0, [sp]                                   
0x1003c7dcc b        #0x1003c7de0                               
0x1003c7dd0 mov      x19, x0                                    
0x1003c7dd4 ldrsb    w8, [sp, #0x4f]                            
0x1003c7dd8 tbz      w8, #0x1f, #0x1003c7dec                    
0x1003c7ddc ldr      x0, [sp, #0x38]                            
0x1003c7de0 bl       #0x10314b5b4                               
0x1003c7de4 b        #0x1003c7dec                               
0x1003c7de8 mov      x19, x0                                    
0x1003c7dec ldrsb    w8, [sp, #0x37]                            
0x1003c7df0 tbz      w8, #0x1f, #0x1003c7e04                    
0x1003c7df4 ldr      x0, [sp, #0x20]                            
0x1003c7df8 bl       #0x10314b5b4                               
0x1003c7dfc b        #0x1003c7e04                               
0x1003c7e00 mov      x19, x0                                    
0x1003c7e04 mov      x0, x19                                    
0x1003c7e08 bl       #0x10314af6c                               

MenuPlayerMatch.isMatchRequested
0x1003cce38 adrp     x8, #0x104826000                           
0x1003cce3c ldrsw    x8, [x8, #0xb10]                           
0x1003cce40 ldr      w8, [x0, x8]                               
0x1003cce44 cmp      w8, #0                                     
0x1003cce48 cset     w0, eq                                     
0x1003cce4c ret                                                 

MenuPlayerMatch.isRematchRequested
0x1003cce50 adrp     x8, #0x104826000                           
0x1003cce54 ldrsw    x8, [x8, #0xb10]                           
0x1003cce58 ldr      w8, [x0, x8]                               
0x1003cce5c cmp      w8, #3                                     
0x1003cce60 cset     w0, eq                                     
0x1003cce64 ret                                                 

MenuPromotionSystemPopUp.exitButtonCallback
0x100d27774 mov      w2, #0                                     
0x100d27778 b        #0x10325df40                               objc_msgSend$prepareToLeaveWithExplicitlyPopped:

MenuPromotionSystemPopUp.prepareToLeaveWithExplicitlyPopped:
0x100d2777c adrp     x8, #0x10482d000                           
0x100d27780 ldrsw    x8, [x8, #0x58c]                           
0x100d27784 ldr      x8, [x0, x8]                               
0x100d27788 cbz      x8, #0x100d27794                           
0x100d2778c mov      x0, x8                                     
0x100d27790 b        #0x1031c6a80                               objc_msgSend$exitButtonCallback
0x100d27794 adrp     x8, #0x10482d000                           
0x100d27798 ldrsw    x8, [x8, #0x590]                           
0x100d2779c ldr      x8, [x0, x8]                               
0x100d277a0 cbz      x8, #0x100d277ac                           
0x100d277a4 cbz      w2, #0x100d277b0                           
0x100d277a8 b        #0x1032ad940                               objc_msgSend$setLeavingState
0x100d277ac ret                                                 
0x100d277b0 mov      w2, #1                                     
0x100d277b4 b        #0x103181220                               objc_msgSend$attemptLeaveWithLockedTable:

MCNewsfeedViewController.dismissNewsfeed:
0x101533918 b        #0x1031bb900                               objc_msgSend$dismissBoard

MCNewsfeedViewController.dismissBoard
0x101533f30 stp      x22, x21, [sp, #-0x30]!                    
0x101533f34 stp      x20, x19, [sp, #0x10]                      
0x101533f38 stp      x29, x30, [sp, #0x20]                      
0x101533f3c add      x29, sp, #0x20                             
0x101533f40 mov      x19, x0                                    
0x101533f44 adrp     x8, #0x104832000                           
0x101533f48 ldrsw    x20, [x8, #0x630]                          
0x101533f4c ldr      x0, [x0, x20]                              
0x101533f50 bl       #0x103222660                               objc_msgSend$isShowingVideo
0x101533f54 cbz      w0, #0x101533f94                           
0x101533f58 ldr      x0, [x19, x20]                             
0x101533f5c bl       #0x1032f9c60                               objc_msgSend$stopVideo
0x101533f60 adrp     x8, #0x104832000                           
0x101533f64 ldrsw    x8, [x8, #0x628]                           
0x101533f68 ldr      x0, [x19, x8]                              
0x101533f6c adrp     x8, #0x104832000                           
0x101533f70 adrp     x9, #0x104832000                           
0x101533f74 ldrsw    x9, [x9, #0x62c]                           
0x101533f78 ldrsw    x9, [x19, x9]                              
0x101533f7c ldrsw    x8, [x8, #0x624]                           
0x101533f80 ldr      x8, [x19, x8]                              
0x101533f84 mov      w10, #0x70                                 
0x101533f88 smaddl   x8, w9, w10, x8                            
0x101533f8c ldr      w2, [x8, #0x68]                            
0x101533f90 bl       #0x1031cd5c0                               objc_msgSend$finishedShowingVideoForMessage:
0x101533f94 adrp     x21, #0x10480e000                          
0x101533f98 ldr      x0, [x21, #0x468]                          
0x101533f9c adrp     x2, #0x10408b000                           
0x101533fa0 add      x2, x2, #0x958                             
0x101533fa4 mov      x3, #0                                     
0x101533fa8 bl       #0x103185560                               objc_msgSend$beginAnimations:context:
0x101533fac ldr      x0, [x21, #0x468]                          
0x101533fb0 mov      x2, x19                                    
0x101533fb4 bl       #0x103289f20                               objc_msgSend$setAnimationDelegate:
0x101533fb8 ldr      x0, [x21, #0x468]                          
0x101533fbc adrp     x8, #0x104795000                           
0x101533fc0 ldr      x2, [x8, #0x58]                            
0x101533fc4 bl       #0x103289f60                               objc_msgSend$setAnimationDidStopSelector:
0x101533fc8 ldr      x0, [x21, #0x468]                          
0x101533fcc adrp     x8, #0x104795000                           
0x101533fd0 ldr      x2, [x8, #0x60]                            
0x101533fd4 bl       #0x10328a1c0                               objc_msgSend$setAnimationWillStartSelector:
0x101533fd8 ldr      x0, [x19, x20]                             
0x101533fdc fmov     d0, xzr                                    
0x101533fe0 bl       #0x103289920                               objc_msgSend$setAlpha:
0x101533fe4 ldr      x0, [x21, #0x468]                          
0x101533fe8 adrp     x8, #0x10344b000                           
0x101533fec ldr      d0, [x8, #0xb98]                           
0x101533ff0 bl       #0x103289f80                               objc_msgSend$setAnimationDuration:
0x101533ff4 ldr      x0, [x21, #0x468]                          
0x101533ff8 ldp      x29, x30, [sp, #0x20]                      
0x101533ffc ldp      x20, x19, [sp, #0x10]                      
0x101534000 ldp      x22, x21, [sp], #0x30                      
0x101534004 b        #0x103199ec0                               objc_msgSend$commitAnimations
