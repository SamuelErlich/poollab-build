"""Freeze exact model/Core source, compile both harnesses, execute and record proof.

SDKPOOL_SWIFT_USR points to an official Swift5.10.1 Linux usr directory.
SDKPOOL_V16_VALIDATION_OUT chooses a fresh intermediate output directory.
Run from any cwd. Historical validation files are never edited.
"""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

here = Path(__file__).resolve().parent
root = here.parent.parent
out = Path(os.environ.get('SDKPOOL_V16_VALIDATION_OUT', '/workspace/scratch/93d3b09386b0/sdkpool-validation/v16/automation'))
out.mkdir(parents=True, exist_ok=True)
frozen, binary = out / 'Inputs', out / 'compiled'
frozen.mkdir(exist_ok=True); binary.mkdir(exist_ok=True)
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
compiler = ['python3', str(here / 'scoped_swiftc.py')]
receipt_path = out / 'CompileInputs.json'
if '--finish' not in sys.argv:
    subprocess.run(['python3', str(here / 'build_async_harness.py')], check=True)
    sources = sorted((root / 'Sources/PoolLabCore').glob('*.swift'))
    sources = [p for p in sources if not p.stem.startswith('KeyAuth')]
    sources.append(root / 'Integrated/IntegratedGameModel.swift')
    bindings = {}
    for source in sources:
        rel = str(source.relative_to(root))
        dest = frozen / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        bindings[rel] = digest(source)
        assert bindings[rel] == digest(dest)
    receipt = {'sourceSHA256': bindings, 'inputsFrozenBeforeCompilation': True,
               'compilerWrapperSHA256': digest(here / 'scoped_swiftc.py'),
               'platform': 'Swift5.10.1 Linux x86_64, scoped frontend/linker', 'commands': {}}
    def write_receipt(): receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    def compile_target(name, args):
        command = compiler + args
        receipt['commands'][name] = command; write_receipt()
        subprocess.run(command, check=True)
    core_paths = [str(frozen / rel) for rel in bindings if rel.startswith('Sources/')]
    compile_target('core', ['-O', '-enable-testing', '-emit-library', '-emit-module',
                           '-module-name', 'PoolLabCore', *core_paths,
                           '-o', str(binary / 'libPoolLabCore.so')])
    for kind, harness, flags in [('synchronous', 'V16SmoothAutomationHarness.swift', ['-O']),
                                  ('asynchronous', 'V16AsyncSmoothAutomationHarness.swift', ['-O', '-parse-as-library'])]:
        compile_target(kind, [*flags, '-I', str(binary), '-L', str(binary), '-lPoolLabCore',
                              str(out / harness), '-o', str(binary / kind)])
    receipt['compiledCoreSHA256'] = digest(binary / 'libPoolLabCore.so')
    receipt['compiledHarnessSHA256'] = {n: digest(binary / n) for n in ['synchronous', 'asynchronous']}
    receipt['harnessSHA256'] = {name: digest(out / name) for name in ['V16SmoothAutomationHarness.swift', 'V16AsyncSmoothAutomationHarness.swift', 'ExtractedMethods.json']}
    write_receipt()
    print('Compiled exact frozen inputs. Launch each binary DIRECTLY from shell and redirect output to synchronous.log/asynchronous.log, then run --finish.')
    raise SystemExit(0)
receipt = json.loads(receipt_path.read_text())
bindings = receipt['sourceSHA256']
def write_receipt(): receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['compiledCoreSHA256'] == digest(binary / 'libPoolLabCore.so')
for n, sha in receipt['compiledHarnessSHA256'].items(): assert sha == digest(binary / n)
for n, sha in receipt['harnessSHA256'].items(): assert sha == digest(out / n)
results = {}
for kind in ['synchronous', 'asynchronous']:
    results[kind] = json.loads((out / f'{kind}.log').read_text().strip())
    assert results[kind]['result'] == 'passed'
    (out / f'{kind}.json').write_text(json.dumps(results[kind], indent=2) + '\n')
for rel, sha in bindings.items():
    assert digest(root / rel) == sha == digest(frozen / rel), 'Sources changed while compiling: ' + rel
meta = json.loads((out / 'ExtractedMethods.json').read_text())
assert meta['sourceSHA256'] == bindings['Integrated/IntegratedGameModel.swift']
receipt['compiledCoreSHA256'] = digest(binary / 'libPoolLabCore.so')
receipt['sourcesRecheckedAfterExecution'] = True
write_receipt()
receipt['harnessSHA256'] = {name: digest(out / name) for name in ['V16SmoothAutomationHarness.swift', 'V16AsyncSmoothAutomationHarness.swift', 'ExtractedMethods.json']}
write_receipt()
report = {'format': 'SDKPool.V16.AutomationValidation', 'result': 'passed',
          'sourceSHA256': bindings, 'testResults': results,
          'assertionCount': sum(v['checks'] for v in results.values()),
          'deviceRuntimeVerified': False, 'appleSDKBuildVerified': False,
          'scope': 'Exact extracted model members, real Core planner, mocked native/UI collaborators.'}
(out / 'Report.json').write_text(json.dumps(report, indent=2) + '\n')
# Keep source/log receipts with the release; compiled binaries stay in scratch.
evidence = here / 'Evidence'
evidence.mkdir(exist_ok=True)
for name in ['CompileInputs.json', 'ExtractedMethods.json', 'V16SmoothAutomationHarness.swift',
             'V16AsyncSmoothAutomationHarness.swift', 'synchronous.log', 'asynchronous.log',
             'synchronous.json', 'asynchronous.json']:
    shutil.copyfile(out / name, evidence / name)
for rel in bindings:
    dest = evidence / 'Inputs' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(frozen / rel, dest)
report['evidenceSHA256'] = {str(p.relative_to(root / 'Validation')): digest(p)
                           for p in sorted(evidence.rglob('*')) if p.is_file()}
(root / 'Validation/V16AutomationValidation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
