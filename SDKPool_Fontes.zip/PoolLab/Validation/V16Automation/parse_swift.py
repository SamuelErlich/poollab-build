#!/usr/bin/env python3
"""Parse final integrated model/UI files; no Apple SDK typechecking is claimed."""
from pathlib import Path
import hashlib,json,subprocess
here=Path(__file__).resolve().parent
root=here.parents[1]
sources=['Integrated/IntegratedGameModel.swift','Integrated/PoolLabIntegration.swift','iOS/PracticeView.swift']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bindings={rel:sha(root/rel) for rel in sources}
command=['python3',str(here/'scoped_swiftc.py'),'-parse',*[str(root/rel) for rel in sources]]
result=subprocess.run(command,capture_output=True,text=True)
for rel,value in bindings.items():assert sha(root/rel)==value
(here/'SwiftParse.log').write_text(result.stdout+result.stderr)
report={'format':'SDKPool.V16.IntegratedSwiftParse','result':'passed' if result.returncode==0 else 'failed','exitCode':result.returncode,
        'command':command,'sourceSHA256':bindings,'logSHA256':sha(here/'SwiftParse.log'),
        'limitations':['Swift syntax parse only for UIKit/SwiftUI integration; no Apple SDK typecheck or device execution.']}
(root/'Validation/V16IntegratedSwiftParse.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':report['result'],'files':len(sources)}))
raise SystemExit(result.returncode)
