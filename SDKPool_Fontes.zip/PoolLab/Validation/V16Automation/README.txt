SDKPool V16 automation integration validation

The harness extracts production model methods without changing their bodies.
Native capture, authorization callbacks, UIKit collaborators and navigation I/O
are mocked. The real Core planner is compiled from frozen source inputs.
The asynchronous suite executes the production Task.detached planning path.

Coverage includes multiple turns, empty-search retries, interruption recovery,
explicit pause/off, stale-result rejection, single-dispatch protection, all three
mode cadences, final simulated angle/power, background/session refresh recovery,
and autonomous navigation state/token/cooldown behavior.

V16 adds 33 executed recording checks: no-table start/export, preservation of
paused user intent, failed starts, session expiry, inactivity and authorization
loss, lightweight status throttling, explicit resume, no queued one-shot during
recording, and export with no frame capture. Recorder/native I/O remains mocked;
these checks verify model orchestration, not touch interception on an iPhone.

Navigation fixtures verify the Swift model's response to an already classified
native scene. They do not prove scene recognition or native taps on an iPhone.
Device behavior, performance, UIKit appearance and Apple SDK compilation remain
outside this Linux harness. No win/loss results are inferred from navigation.

Reproduction:
1. Set SDKPOOL_SWIFT_USR to an official Swift 5.10.1 Linux usr directory.
2. Set SDKPOOL_V16_VALIDATION_OUT to a scratch directory outside the source tree.
3. Run python3 Validation/V16Automation/run_harness.py.
4. Run each compiled/synchronous and compiled/asynchronous executable directly
   from a shell. Redirect stdout to synchronous.log and asynchronous.log in the
   selected scratch directory. Both must exit zero and emit result passed.
5. Run python3 Validation/V16Automation/run_harness.py --finish.

Direct shell launch is used because this environment's Swift concurrency runtime
can fail before a test assertion when started inside Python subprocess capture.
The compile-input manifest is written before compilation, and source snapshots,
compiled binary hashes and final production hashes are checked after execution.
Only text source/log evidence is copied into the release. No Linux binary ships.
