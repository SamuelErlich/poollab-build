import Foundation
@testable import PoolLabCore
@main struct Verify {
 static func main() throws {
 let state = try JSONDecoder().decode(TableState.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
 let expected = ShotParameters(angleRadians: -0.7684, power: 0.49611509250623514)
 let replay = try BilliardsEngine.simulate(state: state, shot: expected, recordFrames: true)
 func resultJSON(_ result: ShotResult) -> [String:Any] {
 var first:Int? = nil
 let events:[[String:Int]] = result.events.map { event in
 switch event {
 case let .ballCollision(a,b):
 if first == nil { if a == 0 { first=b }; if b == 0 { first=a } }
 return ["collisionFirst":a,"collisionSecond":b]
 case let .cushion(ball): return ["cushionBall":ball]
 case let .pocket(ball,pocket): return ["pocketBall":ball,"pocketID":pocket]
 }
 }
 return ["settled":result.settled,"scratched":result.scratched,"pocketedIDs":result.pocketedIDs,"firstContact":first as Any,"events":events,"duration":result.duration,"frameCount":result.frames.count,"target3Pocketed":result.finalState.balls.first(where:{$0.id==3})!.pocketed,"ball8Pocketed":result.finalState.balls.first(where:{$0.id==8})!.pocketed,"finalState":try! JSONSerialization.jsonObject(with:JSONEncoder().encode(result.finalState))]
 }
 let old = try ShotPlanner.suggestions(for:state,targetID:3,pocketID:5,limit:24,allowedTargetIDs:[3])
 var output:[String:Any] = ["fixture":"separate synthetic native-geometry bank-carom fixture, not video reconstruction","ordinarySuggestionsCount":old.count,"replayedCommand":["angleRadians":expected.angleRadians,"power":expected.power],"replay":resultJSON(replay)]
 precondition(old.isEmpty,"baseline expected no suggestion")
 precondition(replay.settled && !replay.scratched && replay.events.contains(.pocket(ball:3,pocket:5)))
 precondition(!replay.finalState.balls.first(where:{$0.id == 8})!.pocketed)

 print(String(data:try JSONSerialization.data(withJSONObject:output,options:[.prettyPrinted,.sortedKeys]),encoding:.utf8)!)
 }
}
