V14 independent synthetic bank/carom fixture

These 7-file Core snapshots were copied before compiling each version. V13 came from the frozen source ZIP identified in SnapshotManifest.json. Both versions used the same explicit synthetic table state. VerifyV13.swift and VerifyV14.swift were compiled with the portable Swift5.10.1 compiler and -O. The manifest records source, executable and library hashes and exact commands; binaries are deliberately omitted from this release.

The V13 public suggestions query returned zero suggestions. V14 search returned the same legal target3 in pocket5 after two target cushion contacts and a collision with8. Black8 remained on the table. The actual selected command was replayed on both frozen engines and produced identical events/final states. The public V14 ordinary compatibility suggestions also returned zero.

This is not a reconstruction of the user video. It independently verifies a similar interaction pattern on a separate controlled table. Found in the ordinary refinement phase, so it does not independently prove analytic carom seed coverage.
