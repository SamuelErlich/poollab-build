V14 planner validation

67 XCTest cases passed: 32 original planner + 9 V13 planner + 16 V14 planner + 10 native pocket geometry.

CompileInputs.json was written from retained source copies before compilation. TestRun.json records the actual compiler/linker commands and compiled Core digest. Inputs contains those exact files; production hashes were checked again after execution. The compiled library and test executable are intentionally not packaged.

run_tests.py is the scoped workspace reproduction recipe; its Swift toolchain dependency is not bundled. Normal macOS CI runs swift test using all package tests.

The three-ball regression is synthetic and independently selected, not fitted to the video. The video approximation was retained unchanged and V13 already finds an alternative route on that approximate layout; it cannot establish the exact cause of the observed installed-build stop.

No iPhone or Apple SDK performance/IPA validation is implied. The 1.4-second budget is a monotonic checkpoint budget; a currently executing engine simulation can finish beyond it. No remaining native turn timer is available.
