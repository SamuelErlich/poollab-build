V11 continuous automation regression fixtures

V11AutomationHarness.swift executes 51 assertions against extracted production methods.
V11AsyncAutomationHarness.swift executes 7 assertions including actual Task.detached ShotPlanner completion, cancellation and generation acceptance.
Native captures, native setters and release are explicit in-memory mocks. The PoolLabCore module and ShotPlanner are the unchanged real production implementation.
The emitted suggestions used by both harnesses come from the actual ShotPlanner, not fabricated ShotSuggestion initializers.

To reproduce with Swift 5.10 or later:
1. From the PoolLab project root, build a PoolLabCore module and shared library into a temporary directory from BilliardsTypes.swift, BilliardsEngine.swift, ShotPlanner.swift, LuckyShotPlanner.swift, GameShotCalibration.swift, PracticeGeometry.swift, TableStateCodec.swift in Sources/PoolLabCore.
2. Compile V11AutomationHarness.swift with -O -I <module-dir> -L <module-dir> -lPoolLabCore.
3. Compile V11AsyncAutomationHarness.swift with the same flags and -parse-as-library.
4. Run each executable with the module library in the platform's dynamic loader path.

build_harness.py and build_async_harness.py record the exact extraction procedure used in the workspace layout new_project/PoolLab and new_project/validation/v11_model. ExtractedMethods.json binds every extracted production method and the entire model source hash.
This validates host control flow and real planner interactions. It does not substitute iPhone/native UIKit runtime validation.
