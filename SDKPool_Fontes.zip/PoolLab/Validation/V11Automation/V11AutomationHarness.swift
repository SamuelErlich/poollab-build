import Foundation
import PoolLabCore
final class MockView {}
struct Snapshot {
    var state: TableState
    var coordinateView: MockView
    var legalTargetNumbers: [NSNumber]
    var playerTurn = true
    var canShoot = true
    var autoShotAvailable = true
    var shotInputSupported = true
    var captureTimestamp = ProcessInfo.processInfo.systemUptime
    var isBreakShot = false
}
struct Normalized {
    var state: TableState
    var calibrated = true
    var nativePhysics = true
    var predictionIssue: String? = nil
    var moving = false
}
final class MockTask { func cancel() {} }
enum PLRuntimeBridge {
    static var snapshot: Snapshot!
    static var shootError: NSError?
    static var aimError: NSError?
    static var captureError: NSError?
    static var shoots: [(angle: Double, power: Double, target: Int, pocket: Int)] = []
    static var aims: [(angle: Double, power: Double, target: Int, pocket: Int)] = []
    static func capture() throws -> Snapshot {
        if let e = captureError { throw e }
        var current = snapshot!
        current.captureTimestamp = ProcessInfo.processInfo.systemUptime
        return current
    }
    static func shoot(angle: Double, power: Double, target: Int, pocket: Int) throws {
        shoots.append((angle,power,target,pocket))
        if let e = shootError { throw e }
    }
    static func applyPlannedAim(angle: Double, power: Double, target: Int, pocket: Int) throws {
        aims.append((angle,power,target,pocket))
        if let e = aimError { throw e }
    }
}
final class IntegratedGameModel {
    var aimEnabled = false, autoPlayEnabled = false, automationPaused = false
    var automationArmed: Bool { aimEnabled || autoPlayEnabled }
    var automationIsRunning: Bool { automationArmed && !automationPaused }
    var canEnableAutoAim = true, canEnableAutoPlay = true
    var isAuthorized = true, canCalculate = true, canApplyAim = true
    var isPlayerTurn = true, isMoving = false, isLuckyShot = false
    var isWaitingForShot = false, singleShotRequested = false
    var panelIsOpen = false, isPlanning = false, hasTable = true
    var hasFreshCapture = true, hasNativePhysics = true, captureHealthy = true
    var runtimeCanShoot = true, autoShotAvailable = true
    var followGameAim = true, previewIsTemporary = false, suggestionContextIsCurrent = true
    var previewPowerLocked = false
    var lockedPreviewPower: Double?
    var aimActionReadiness = "waiting", autoShotUnavailableReason = "unsupported", liveReadiness = "not ready"
    var automationStatus = "off", status = "", suggestionStatus = ""
    var legalTargets: Set<Int> = [1]
    var tableState: TableState?
    var snapshot: Snapshot?
    var angleDegrees = 0.0, power = 0.5
    private var automaticPlan: AutomaticPlan?, automaticBlockedContext: AutomaticContext?
    private var automaticAttemptContext: AutomaticContext?
    var automaticCommandAttempts = 0
    var automaticRetryAfter: TimeInterval = 0
    var lastSubmittedState: TableState?
    var stableSince: TimeInterval? = ProcessInfo.processInfo.systemUptime - 1
    var shotSubmittedAt: TimeInterval?, captureFailureStartedAt: TimeInterval?
    var unsupportedMotionStartedAt: TimeInterval?
    let minimumStableTime = 0.65, unsupportedMotionTimeout = 30.0
    var queueTransition: Int?
    var plannerTask: MockTask?
    var plannerGeneration: UInt64 = 0
    enum PlanningPurpose { case suggestions, applyAim, continuousAim, singleShot, autoPlay, luckyShot }
    var planningPurpose: PlanningPurpose?
    var suggestionState: TableState?
    var suggestionAllowed: Set<Int> = []
    var suggestionCoordinateIdentity: ObjectIdentifier?
    var selectedSuggestionID: String?
    var suggestions: [ShotSuggestion] = []
    var luckySuggestion: Int?
    var onOverlayChange: (() -> Void)?
    var planRequests: [PlanningPurpose] = []
    var clearRequests = 0, pollRequests = 0
    var captureEvents: [String] = []
    enum CaptureError: Error { case changedTable }
    static func normalized(_ value: Snapshot) throws -> Normalized { Normalized(state: value.state) }
    static func degrees(_ radians: Double) -> Double { radians * 180 / .pi }
    func recordCaptureEvent(_ name: String, at: TimeInterval, details: [String:String] = [:]) { captureEvents.append(name) }
    func cancelPrediction(clearOverlay: Bool) {}
    func poll() { pollRequests += 1 }
    func startPlanning(_ purpose: PlanningPurpose) { planRequests.append(purpose); isPlanning = true; planningPurpose = purpose }
    func clearBoard(message: String, preserveQueueIntent: Bool) { clearRequests += 1; stopAutomation(message:message); hasTable = false }
    func setAutoAimEnabled(_ enabled: Bool) {
        guard enabled != aimEnabled else { return }
        if !enabled {
            stopAutomation(message: "AIM e jogo automático desligados.")
            onOverlayChange?()
            return
        }
        guard canEnableAutoAim else { return }
        aimEnabled = true
        automationPaused = false
        resetAutomaticPlan()
        automationStatus = "AIM ligado. Aguardando sua vez e a mesa parar."
        recordCaptureEvent("continuousAimEnabled", at: ProcessInfo.processInfo.systemUptime)
        poll()
    }

    func setAutoPlay(_ enabled: Bool) {
        guard enabled != autoPlayEnabled else { return }
        if !enabled {
            autoPlayEnabled = false
            singleShotRequested = false
            resetAutomaticPlan()
            automationStatus = automationPaused ? "AIM pausado." : "Auto Play desligado. AIM continua ligado."
            onOverlayChange?()
            return
        }
        guard canEnableAutoPlay else { return }
        aimEnabled = true
        autoPlayEnabled = true
        automationPaused = false
        unsupportedMotionStartedAt = nil
        resetAutomaticPlan()
        recordCaptureEvent("autoPlayEnabled", at: ProcessInfo.processInfo.systemUptime)
        singleShotRequested = false
        automationStatus = "AIM e automático ligados. Aguardando sua vez e a mesa parar."
        poll()
    }

    func toggleAutomationPause() {
        guard automationArmed else { return }
        automationPaused.toggle()
        resetAutomaticPlan()
        singleShotRequested = false
        recordCaptureEvent(automationPaused ? "automationPaused" : "automationResumed",
                           at: ProcessInfo.processInfo.systemUptime)
        automationStatus = automationPaused ? "AIM e automático pausados." : "Retomando com uma nova leitura da mesa."
        if !automationPaused { poll() }
        onOverlayChange?()
    }

    private func resetAutomaticPlan() {
        // Automatic control and the visible forecast use the same live power.
        // A manually locked preview must not conceal the selected shot force.
        previewPowerLocked = false
        lockedPreviewPower = nil
        followGameAim = true
        previewIsTemporary = false
        cancelPlanner(clearSuggestions: true)
        automaticPlan = nil
        automaticBlockedContext = nil
        automaticAttemptContext = nil
        automaticCommandAttempts = 0
        automaticRetryAfter = 0
        stableSince = nil
    }

    private func advanceAutomation() {
        guard automationIsRunning || singleShotRequested, isAuthorized, !isWaitingForShot, !isPlanning else { return }
        guard !panelIsOpen else { waitAutomation(message: "Feche o menu para continuar o AIM e o automático."); return }
        guard canCalculate, isPlayerTurn else { waitAutomation(message: aimActionReadiness); return }
        guard !isLuckyShot else { waitAutomation(message: "AIM contínuo disponível nas partidas de sinuca."); return }
        guard tableState?.balls.contains(where: { $0.id != 0 && !$0.pocketed }) == true else {
            stopAutomation(message: "Mesa concluída. AIM e automático desligados.")
            return
        }
        guard !legalTargets.isEmpty else { waitAutomation(message: "Aguardando o jogo informar as bolas permitidas."); return }
        guard runtimeCanShoot else { waitAutomation(message: liveReadiness); return }
        if autoPlayEnabled || singleShotRequested {
            guard autoShotAvailable else { waitAutomation(message: autoShotUnavailableReason); return }
            guard tableState != lastSubmittedState else {
                waitAutomation(message: "Aguardando confirmação da tacada anterior. Esta posição não será repetida.")
                return
            }
        }
        let now = ProcessInfo.processInfo.systemUptime
        guard now >= automaticRetryAfter else { return }
        guard let stableSince, now - stableSince >= minimumStableTime else {
            waitAutomation(message: "Confirmando que a mesa está parada…")
            return
        }
        guard let context = currentAutomaticContext, context != automaticBlockedContext else { return }
        if let ready = automaticPlan, ready.context == context {
            if autoPlayEnabled {
                execute(ready.suggestion, expectedState: context.state, allowed: context.allowed)
            } else if aimEnabled && !ready.aimApplied {
                applyAutomaticAim(ready)
            }
            return
        }
        startPlanning(autoPlayEnabled ? .autoPlay : (aimEnabled ? .continuousAim : .singleShot))
    }

    private func applyAutomaticAim(_ plan: AutomaticPlan) {
        guard automationIsRunning, aimEnabled, !autoPlayEnabled, !panelIsOpen,
              canApplyAim, currentAutomaticContext == plan.context else { return }
        if automaticAttemptContext != plan.context {
            automaticAttemptContext = plan.context
            automaticCommandAttempts = 0
        }
        automaticCommandAttempts += 1
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            guard current.playerTurn, current.canShoot, current.shotInputSupported,
                  Self.isFreshSample(current.captureTimestamp, at: ProcessInfo.processInfo.systemUptime),
                  normalized.calibrated, normalized.nativePhysics, normalized.predictionIssue == nil,
                  !normalized.moving, normalized.state == plan.context.state,
                  ObjectIdentifier(current.coordinateView) == plan.context.coordinate,
                  Set(current.legalTargetNumbers.map { $0.intValue }) == plan.context.allowed,
                  current.isBreakShot == plan.context.isBreakShot,
                  plan.context.allowed.contains(plan.suggestion.targetID), isAuthorized else {
                throw CaptureError.changedTable
            }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: plan.suggestion.shot.power)
            try PLRuntimeBridge.applyPlannedAim(angle: -plan.suggestion.shot.angleRadians, power: nativePower,
                target: plan.suggestion.targetID, pocket: plan.suggestion.pocketID)
            automaticPlan?.aimApplied = true
            angleDegrees = Self.degrees(plan.suggestion.shot.angleRadians)
            power = nativePower
            followGameAim = true
            previewIsTemporary = false
            automationStatus = "AIM na bola \(plan.suggestion.targetID), força \(Int((nativePower * 100).rounded()))%. Aguardando sua tacada."
            recordCaptureEvent("continuousAimApplied", at: ProcessInfo.processInfo.systemUptime,
                details: ["target": String(plan.suggestion.targetID), "pocket": String(plan.suggestion.pocketID)])
            poll()
        } catch {
            automaticPlan = nil
            recordCaptureEvent("continuousAimRejected", at: ProcessInfo.processInfo.systemUptime,
                details: ["code": String((error as NSError).code), "domain": (error as NSError).domain,
                          "attempt": String(automaticCommandAttempts)])
            if case CaptureError.changedTable = error {
                stableSince = nil
                waitAutomation(message: "A mesa mudou. Aguardando uma leitura estável para o AIM.")
            } else if automaticCommandAttempts < 2 {
                // This API only sets controls, never releases a shot. One new
                // capture and bounded retry can recover a transient cue guard.
                automaticRetryAfter = ProcessInfo.processInfo.systemUptime + 0.75
                stableSince = nil
                waitAutomation(message: "Aguardando o jogo liberar o ajuste da mira.")
            } else {
                pauseAutomaticActions(message: "AIM pausado: \(error.localizedDescription)")
            }
        }
    }

    private func execute(_ suggestion: ShotSuggestion, expectedState: TableState, allowed: Set<Int>) {
        guard (autoPlayEnabled && automationIsRunning) || singleShotRequested,
              isAuthorized, !isWaitingForShot, !panelIsOpen,
              expectedState != lastSubmittedState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            let currentAllowed = Set(current.legalTargetNumbers.map { $0.intValue })
            guard current.playerTurn, current.canShoot, current.autoShotAvailable, current.shotInputSupported,
                  Self.isFreshSample(current.captureTimestamp, at: ProcessInfo.processInfo.systemUptime),
                  current.isBreakShot == (suggestion.method == .breakShot),
                  normalized.calibrated, normalized.nativePhysics, normalized.predictionIssue == nil, !normalized.moving, normalized.state == expectedState,
                  current.coordinateView === snapshot?.coordinateView,
                  currentAllowed == allowed, allowed.contains(suggestion.targetID),
                  isAuthorized else { throw CaptureError.changedTable }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power)
            // Mark before entering the game: even a partial runtime failure
            // cannot cause a second invocation for this unchanged board.
            let context = currentAutomaticContext
            if automaticAttemptContext != context {
                automaticAttemptContext = context
                automaticCommandAttempts = 0
            }
            automaticCommandAttempts += 1
            lastSubmittedState = expectedState
            shotSubmittedAt = ProcessInfo.processInfo.systemUptime
            isWaitingForShot = true
            singleShotRequested = false
            recordCaptureEvent("shotSubmitted", at: ProcessInfo.processInfo.systemUptime,
                               details: ["target": String(suggestion.targetID), "pocket": String(suggestion.pocketID),
                                         "method": suggestion.method.rawValue])
            try PLRuntimeBridge.shoot(angle: -suggestion.shot.angleRadians, power: nativePower,
                                      target: suggestion.targetID, pocket: suggestion.pocketID)
            angleDegrees = Self.degrees(suggestion.shot.angleRadians)
            power = nativePower
            followGameAim = true
            automationStatus = "Tacada enviada. Aguardando movimento no jogo…"
            status = suggestion.method == .breakShot ? "Tacada de saída enviada." : "Bola \(suggestion.targetID), caçapa \(suggestion.pocketID + 1)."
            cancelPrediction(clearOverlay: true)
        } catch {
            recordCaptureEvent("automaticShotRejected", at: ProcessInfo.processInfo.systemUptime,
                details: ["code": String((error as NSError).code), "domain": (error as NSError).domain,
                          "attempt": String(automaticCommandAttempts),
                          "shotDispatched": ((error as NSError).userInfo["shotDispatched"] as? Bool).map(String.init) ?? "unknown"])
            shotSubmittedAt = nil
            isWaitingForShot = false
            if (error as NSError).userInfo["shotDispatched"] as? Bool == false {
                // A rejected guard is different from an uncertain release.
                // The bridge explicitly proves that no shot callback ran.
                lastSubmittedState = nil
            }
            automaticPlan = nil
            if case CaptureError.changedTable = error {
                stableSince = nil
                waitAutomation(message: "A mesa mudou. Aguardando nova leitura para calcular a tacada.")
            } else if (error as NSError).userInfo["shotDispatched"] as? Bool == false,
                      autoPlayEnabled, automaticCommandAttempts < 2 {
                automaticRetryAfter = ProcessInfo.processInfo.systemUptime + 0.75
                stableSince = nil
                waitAutomation(message: "O jogo ainda não liberou a tacada. Conferindo novamente.")
            } else {
                pauseAutomaticActions(message: "Tacada automática pausada: \(error.localizedDescription)")
            }
            status = automationStatus
        }
    }

    private func acknowledgeShotProgress() {
        guard isMoving || !isPlayerTurn else { return }
        lastSubmittedState = nil
        automaticPlan = nil
        automaticBlockedContext = nil
        automaticAttemptContext = nil
        automaticCommandAttempts = 0
        if isWaitingForShot {
            isWaitingForShot = false
            shotSubmittedAt = nil
            automationStatus = autoPlayEnabled ? "Tacada iniciada. Aguardando as bolas pararem." : "Tacada iniciada no jogo."
            recordCaptureEvent("shotMotionObserved", at: ProcessInfo.processInfo.systemUptime)
        }
    }

    private func waitAutomation(message: String) {
        if (automationIsRunning || singleShotRequested) && automationStatus != message { automationStatus = message }
    }

    private func pauseAutomaticActions(message: String) {
        if automationArmed { automationPaused = true }
        singleShotRequested = false
        cancelPlanner(clearSuggestions: true)
        automaticPlan = nil
        if automationStatus != message { automationStatus = message }
    }

    private func stopAutomation(message: String) {
        if automationArmed || singleShotRequested {
            recordCaptureEvent("automationStopped", at: ProcessInfo.processInfo.systemUptime,
                               details: ["reason": String(message.prefix(256))])
        }
        unsupportedMotionStartedAt = nil
        queueTransition = nil
        if autoPlayEnabled { autoPlayEnabled = false }
        if aimEnabled { aimEnabled = false }
        if automationPaused { automationPaused = false }
        automaticPlan = nil
        automaticBlockedContext = nil
        if singleShotRequested { singleShotRequested = false }
        if planningPurpose == .singleShot || planningPurpose == .autoPlay || planningPurpose == .continuousAim {
            cancelPlanner(clearSuggestions: false)
        }
        if automationStatus != message { automationStatus = message }
    }

    private func handleCaptureFailure(_ error: Error, at now: TimeInterval, transient: Bool) {
        let runtime = error as NSError
        let firstFailure = captureFailureStartedAt == nil
        if firstFailure {
            captureFailureStartedAt = now
            recordCaptureEvent("captureUnavailable", at: now,
                               details: ["domain": runtime.domain, "code": String(runtime.code),
                                         "reason": String(error.localizedDescription.prefix(256))])
        }
        captureHealthy = false
        runtimeCanShoot = false
        stableSince = nil
        // No fresh-reading gate can authorize a shot during even one failure.
        if firstFailure {
            automaticPlan = nil
            cancelPrediction(clearOverlay: true)
            cancelPlanner(clearSuggestions: true)
            if queueTransition == nil && (automationArmed || singleShotRequested) {
                waitAutomation(message: "Aguardando uma nova leitura da mesa.")
            }
        }
        // Expected native transitions do not repeatedly reset the panel's
        // entire table state. Hide estimates immediately, then clear a lasting
        // loss after a bounded grace period. Authorization failures never use it.
        let failureAge = max(0, now - (captureFailureStartedAt ?? now))
        if transient && hasTable && failureAge < 3 {
            onOverlayChange?()
            return
        }
        clearBoard(message: "Leitura indisponível: \(error.localizedDescription)",
                   preserveQueueIntent: queueTransition != nil && transient)
    }

    func panelOpened() {
        panelIsOpen = true
        if planningPurpose == .singleShot || planningPurpose == .autoPlay || planningPurpose == .continuousAim {
            cancelPlanner(clearSuggestions: true)
        }
        automaticPlan = nil
        if (automationArmed && !automationPaused) || singleShotRequested {
            automationStatus = "Feche o menu para continuar o AIM e o automático."
        }
        onOverlayChange?()
    }

    func panelClosed() {
        let keepSelectedPreview = selectedSuggestionID != nil && suggestionContextIsCurrent
            && !autoPlayEnabled && !singleShotRequested && !followGameAim && previewIsTemporary
        panelIsOpen = false
        if !keepSelectedPreview { selectedSuggestionID = nil }
        if automationArmed || singleShotRequested { stableSince = ProcessInfo.processInfo.systemUptime }
        if previewIsTemporary && !keepSelectedPreview {
            previewIsTemporary = false
            followGameAim = true
            poll()
        }
        onOverlayChange?()
    }

    private func cancelPlanner(clearSuggestions: Bool) {
        plannerGeneration &+= 1
        plannerTask?.cancel()
        plannerTask = nil
        planningPurpose = nil
        if isPlanning { isPlanning = false }
        if clearSuggestions {
            suggestionState = nil
            suggestionAllowed = []
            suggestionCoordinateIdentity = nil
            if selectedSuggestionID != nil {
                selectedSuggestionID = nil
                followGameAim = true
                previewIsTemporary = false
            }
            if !suggestions.isEmpty { suggestions = [] }
            if suggestionStatus != "Calcule uma sugestão quando a mesa estiver pronta." {
                suggestionStatus = "Calcule uma sugestão quando a mesa estiver pronta."
            }
            if luckySuggestion != nil { luckySuggestion = nil }
        }
    }

    private func pauseAutomationForUnsupportedMotion(issue: String, at now: TimeInterval) {
        guard automationArmed || singleShotRequested else { return }
        // A native pocket animation can leave the independent solver's rectangle.
        // Keep only already-armed intent, never a plan or release permission.
        guard automationIsRunning, isAuthorized, hasFreshCapture else {
            waitAutomation(message: issue)
            return
        }
        automaticPlan = nil
        if unsupportedMotionStartedAt == nil {
            unsupportedMotionStartedAt = now
            recordCaptureEvent("autoPlayPausedForNativeMotion", at: now)
        }
        guard let since = unsupportedMotionStartedAt, now - since < unsupportedMotionTimeout else {
            pauseAutomaticActions(message: "A mesa não voltou a uma geometria suportada em 30 segundos. Confira a partida.")
            return
        }
        let message = "Automático aguardando as bolas e a caçapa terminarem o movimento."
        waitAutomation(message: message)
    }

    private static func isFreshSample(_ timestamp: TimeInterval, at now: TimeInterval) -> Bool {
        timestamp.isFinite && now.isFinite && timestamp <= now + 0.01 && now - timestamp <= 0.25
    }

    private struct AutomaticContext: Equatable {
        let state: TableState
        let allowed: Set<Int>
        let coordinate: ObjectIdentifier
        let isBreakShot: Bool
    }

    private struct AutomaticPlan {
        let context: AutomaticContext
        let suggestion: ShotSuggestion
        var aimApplied = false
    }

    private var currentAutomaticContext: AutomaticContext? {
        guard let tableState, let snapshot else { return nil }
        return AutomaticContext(state: tableState, allowed: legalTargets,
            coordinate: ObjectIdentifier(snapshot.coordinateView), isBreakShot: snapshot.isBreakShot)
    }
    static var checks = 0
    static func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
        checks += 1
        if !condition() { fatalError("CHECK \(checks): \(message)") }
    }
    static func fixture(_ index: Int = 1) -> IntegratedGameModel {
        let model = IntegratedGameModel()
        let state = TableState(table: PoolTable(), balls: [PoolBall(id:0,position:Vector2(x:40,y:50)),PoolBall(id:1,position:Vector2(x:100+Double(index),y:50))])
        model.tableState = state
        model.snapshot = Snapshot(state:state, coordinateView:MockView(), legalTargetNumbers:[1])
        PLRuntimeBridge.snapshot = model.snapshot
        PLRuntimeBridge.shootError = nil; PLRuntimeBridge.aimError = nil; PLRuntimeBridge.captureError = nil
        PLRuntimeBridge.shoots = []; PLRuntimeBridge.aims = []
        return model
    }
    func prepare(_ suggestion: ShotSuggestion) {
        isPlanning = false; plannerTask = nil; planningPurpose = nil
        automaticPlan = AutomaticPlan(context:currentAutomaticContext!, suggestion:suggestion)
        stableSince = ProcessInfo.processInfo.systemUptime - 1
    }
    static func run() throws {
        let seed = fixture()
        let state = seed.tableState!
        let suggestion = try ShotPlanner.suggestions(for:state,includeBanks:true,limit:1,allowedTargetIDs:[1]).first!
        let shot = suggestion.shot

        let aim = fixture()
        aim.previewPowerLocked = true; aim.lockedPreviewPower = 0.1
        aim.setAutoAimEnabled(true)
        expect(!aim.previewPowerLocked && aim.lockedPreviewPower == nil && aim.followGameAim,"AIM arming restores live selected power for prediction")
        expect(aim.aimEnabled && !aim.autoPlayEnabled && !aim.automationPaused,"AIM arms without firing")
        expect(aim.pollRequests == 1,"enabling recaptures")
        aim.stableSince = ProcessInfo.processInfo.systemUptime - 1
        aim.advanceAutomation()
        expect(aim.planRequests == [.continuousAim],"AIM requests automatic best plan")
        aim.prepare(suggestion); aim.advanceAutomation()
        expect(PLRuntimeBridge.aims.count == 1 && PLRuntimeBridge.shoots.isEmpty,"AIM only changes controls")
        expect(PLRuntimeBridge.aims[0].target == 1 && PLRuntimeBridge.aims[0].pocket == suggestion.pocketID,"AIM forwards legal target and nomination")
        for _ in 0..<100 { aim.advanceAutomation() }
        expect(PLRuntimeBridge.aims.count == 1,"stable board never reapplies per frame")
        aim.runtimeCanShoot = false; aim.advanceAutomation(); aim.runtimeCanShoot = true; aim.advanceAutomation()
        expect(PLRuntimeBridge.aims.count == 1,"manual cue touch does not reapply aligned state")
        aim.isMoving = true; aim.acknowledgeShotProgress(); aim.isMoving = false
        aim.tableState!.balls[1].position.x += 5; aim.snapshot!.state = aim.tableState!; PLRuntimeBridge.snapshot = aim.snapshot
        aim.stableSince = ProcessInfo.processInfo.systemUptime - 1
        aim.advanceAutomation(); expect(aim.planRequests.count == 2,"AIM replans after manual shot")
        aim.prepare(suggestion); aim.advanceAutomation(); expect(PLRuntimeBridge.aims.count == 2,"AIM applies second turn")
        aim.isPlayerTurn = false; aim.acknowledgeShotProgress(); aim.canCalculate = false; aim.advanceAutomation()
        expect(aim.aimEnabled && PLRuntimeBridge.aims.count == 2,"opponent waits with AIM intent")
        aim.isPlayerTurn = true; aim.canCalculate = true; aim.stableSince = ProcessInfo.processInfo.systemUptime - 1
        aim.advanceAutomation(); expect(aim.planRequests.count == 3,"returning own turn re-evaluates")

        let auto = fixture(); auto.setAutoPlay(true); auto.prepare(suggestion); auto.advanceAutomation()
        expect(auto.aimEnabled && auto.autoPlayEnabled,"Auto Play arms common AIM")
        expect(PLRuntimeBridge.shoots.count == 1 && PLRuntimeBridge.aims.isEmpty,"Auto Play uses native nominate-apply-release atomically")
        expect(PLRuntimeBridge.shoots[0].target == suggestion.targetID && PLRuntimeBridge.shoots[0].pocket == suggestion.pocketID,"same selected solution forwards all identifiers")
        expect(abs(PLRuntimeBridge.shoots[0].power - (try! GameShotCalibration.controlPower(fromSimulationPower:shot.power))) < 1e-12,"simulation power calibrated once")
        for _ in 0..<100 { auto.advanceAutomation() }
        expect(PLRuntimeBridge.shoots.count == 1,"pending shot never repeats")
        auto.isMoving = true; auto.acknowledgeShotProgress()
        expect(!auto.isWaitingForShot && auto.lastSubmittedState == nil,"actual measured motion acknowledges shot")
        auto.isMoving = false; auto.tableState!.balls[1].position.x += 7; auto.snapshot!.state = auto.tableState!; PLRuntimeBridge.snapshot = auto.snapshot
        auto.prepare(suggestion); auto.advanceAutomation()
        expect(PLRuntimeBridge.shoots.count == 2,"second settled own turn fires next plan")
        auto.isPlayerTurn = false; auto.acknowledgeShotProgress(); auto.canCalculate = false
        auto.advanceAutomation(); expect(auto.autoPlayEnabled && PLRuntimeBridge.shoots.count == 2,"opponent turn preserves intent without firing")
        auto.isPlayerTurn = true; auto.canCalculate = true; auto.prepare(suggestion); auto.advanceAutomation()
        expect(PLRuntimeBridge.shoots.count == 3,"third own turn continues")

        let pause = fixture(); pause.setAutoPlay(true); pause.prepare(suggestion)
        let generation = pause.plannerGeneration
        pause.toggleAutomationPause()
        expect(pause.automationPaused && pause.aimEnabled && pause.autoPlayEnabled,"pause retains enabled modes")
        expect(pause.plannerGeneration > generation && pause.automaticPlan == nil,"pause invalidates in-flight generation and solution")
        pause.advanceAutomation(); expect(PLRuntimeBridge.shoots.isEmpty,"pause prevents release")
        pause.toggleAutomationPause(); expect(!pause.automationPaused && pause.pollRequests == 2 && pause.stableSince == nil,"resume recaptures and requires stabilization")
        pause.prepare(suggestion); pause.panelOpened(); pause.advanceAutomation()
        expect(pause.autoPlayEnabled && !pause.automationPaused && PLRuntimeBridge.shoots.isEmpty,"menu temporarily inhibits without toggling modes")
        pause.panelClosed(); expect(pause.autoPlayEnabled && pause.stableSince != nil,"closing menu starts stability gate")
        pause.setAutoPlay(false); expect(pause.aimEnabled && !pause.autoPlayEnabled,"auto off keeps AIM")
        pause.setAutoAimEnabled(false); expect(!pause.automationArmed,"AIM off clears armed modes")

        let wait = fixture(); wait.setAutoPlay(true); wait.stableSince = ProcessInfo.processInfo.systemUptime - 1
        wait.legalTargets = []; wait.advanceAutomation(); expect(wait.autoPlayEnabled && wait.planRequests.isEmpty,"empty legal set waits")
        wait.legalTargets = [1]; wait.runtimeCanShoot = false; wait.advanceAutomation(); expect(wait.autoPlayEnabled,"native touch readiness waits")
        wait.runtimeCanShoot = true; wait.autoShotAvailable = false; wait.advanceAutomation(); expect(wait.autoPlayEnabled,"temporary shot support waits")
        wait.autoShotAvailable = true; wait.automaticBlockedContext = wait.currentAutomaticContext
        for _ in 0..<100 { wait.advanceAutomation() }
        expect(wait.planRequests.isEmpty,"empty planner result blocked per board without frame loop")
        wait.toggleAutomationPause(); wait.toggleAutomationPause(); expect(wait.automaticBlockedContext == nil,"explicit resume permits a fresh bounded search")

        let uncertain = fixture(); uncertain.setAutoPlay(true); uncertain.prepare(suggestion)
        PLRuntimeBridge.shootError = NSError(domain:"PoolLab.RuntimeBridge",code:73,userInfo:["shotDispatched":true])
        uncertain.advanceAutomation()
        expect(uncertain.automationPaused && uncertain.lastSubmittedState != nil,"uncertain release preserves duplicate latch and pauses")
        uncertain.toggleAutomationPause(); uncertain.prepare(suggestion); uncertain.advanceAutomation()
        expect(PLRuntimeBridge.shoots.count == 1,"resume cannot duplicate uncertain shot on same board")
        uncertain.isMoving = true; uncertain.acknowledgeShotProgress()
        expect(uncertain.lastSubmittedState == nil,"measured motion clears uncertain latch")

        let rejected = fixture(); rejected.setAutoPlay(true); rejected.prepare(suggestion)
        PLRuntimeBridge.shootError = NSError(domain:"PoolLab.RuntimeBridge",code:65,userInfo:["shotDispatched":false])
        rejected.advanceAutomation()
        expect(!rejected.automationPaused && rejected.lastSubmittedState == nil && rejected.automaticCommandAttempts == 1,"proven no dispatch permits one retry")
        rejected.advanceAutomation(); expect(PLRuntimeBridge.shoots.count == 1,"retry requires fresh delay and stabilization")
        rejected.automaticRetryAfter = 0; rejected.prepare(suggestion); rejected.advanceAutomation()
        expect(rejected.automationPaused && PLRuntimeBridge.shoots.count == 2,"second failure pauses, no retry loop")

        let aimRejected = fixture(); aimRejected.setAutoAimEnabled(true); aimRejected.prepare(suggestion)
        PLRuntimeBridge.aimError = NSError(domain:"PoolLab.RuntimeBridge",code:45)
        aimRejected.advanceAutomation()
        expect(!aimRejected.automationPaused && aimRejected.automaticCommandAttempts == 1,"transient AIM setter rejection permits one fresh retry")
        aimRejected.automaticRetryAfter = 0; aimRejected.prepare(suggestion); aimRejected.advanceAutomation()
        expect(aimRejected.automationPaused && PLRuntimeBridge.aims.count == 2 && PLRuntimeBridge.shoots.isEmpty,"repeated AIM rejection pauses without any release")

        let stale = fixture(); stale.setAutoPlay(true); stale.prepare(suggestion)
        PLRuntimeBridge.snapshot.state.balls[1].position.x += 10
        stale.advanceAutomation(); expect(PLRuntimeBridge.shoots.isEmpty && stale.autoPlayEnabled && stale.automaticPlan == nil,"fresh board mismatch discards without release")
        let auth = fixture(); auth.setAutoPlay(true); auth.prepare(suggestion); auth.isAuthorized = false
        auth.advanceAutomation(); expect(PLRuntimeBridge.shoots.isEmpty,"authorization always gates release")
        auth.stopAutomation(message:"lost authorization"); expect(!auth.automationArmed,"authorization shutdown clears intent")
        let done = fixture(); done.setAutoPlay(true); done.tableState!.balls.removeLast(); done.advanceAutomation()
        expect(!done.automationArmed,"completed table ends continuous automation")

        let capture = fixture(); capture.setAutoPlay(true); capture.prepare(suggestion)
        let now = ProcessInfo.processInfo.systemUptime
        let failure = NSError(domain:"PoolLab.RuntimeBridge",code:20)
        capture.handleCaptureFailure(failure,at:now,transient:true)
        expect(capture.autoPlayEnabled && !capture.captureHealthy && capture.automaticPlan == nil,"first transient capture blocks actions but keeps intent")
        capture.handleCaptureFailure(failure,at:now+2,transient:true)
        expect(capture.autoPlayEnabled && capture.clearRequests == 0,"bounded native transition grace")
        capture.handleCaptureFailure(failure,at:now+4,transient:true)
        expect(!capture.automationArmed && capture.clearRequests == 1,"lasting missing table ends safely")

        let unsupported = fixture(); unsupported.setAutoPlay(true)
        unsupported.pauseAutomationForUnsupportedMotion(issue:"pocket animation",at:now)
        expect(unsupported.autoPlayEnabled && !unsupported.automationPaused,"native motion geometry waits")
        unsupported.pauseAutomationForUnsupportedMotion(issue:"pocket animation",at:now+31)
        expect(unsupported.automationPaused,"unbounded unsupported state pauses safely")
        print("{\"result\":\"passed\",\"checks\":\(checks),\"scope\":\"Extracted production automation methods with synchronous native mocks and actual immutable PoolLabCore\"}")
    }
}
try IntegratedGameModel.run()
