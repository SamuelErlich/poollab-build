from pathlib import Path
import runpy
v=runpy.run_path('new_project/validation/v11_model/build_harness.py')
s=Path('new_project/validation/v11_model/V11AutomationHarness.swift').read_text()
s=s.replace('final class IntegratedGameModel {','@MainActor\nfinal class IntegratedGameModel {')
s=s.replace('var plannerTask: MockTask?','var plannerTask: Task<Void,Never>?')
s=s.replace('var isBreakShot = false','var isBreakShot = false\n    var minimumShotPower = 0.01',1)
s=s.replace('''    var canEnableAutoAim = true, canEnableAutoPlay = true''','''    var canEnableAutoAim = true, canEnableAutoPlay = true
    var canRecommend = true, isCalibrated = true, shotInputSupported = true
    var predictionInputIssue: String?
    var planningMilliseconds = 0.0
    var suggestionIsBreakShot = false
    func setPreview(_ shot: ShotParameters) -> Bool { true }
    func applyAim() {}''')
stub='    func startPlanning(_ purpose: PlanningPurpose) { planRequests.append(purpose); isPlanning = true; planningPurpose = purpose }'
s=s.replace(stub,v['member']('startPlanning')+'\n'+v['member']('accepts')+'\n'+v['member']('acceptsPlan')+'\n'+v['member']('minimumPlannerPower'))
s=s.replace('\ntry IntegratedGameModel.run()','')
ix=s.rindex('\n}')
s=s[:ix]+r'''
    static func runAsync() async throws {
        let model = fixture()
        model.setAutoAimEnabled(true)
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation()
        expect(model.isPlanning,"actual Task-based planner started")
        let generation = model.plannerGeneration
        model.toggleAutomationPause()
        expect(model.plannerGeneration > generation && model.automationPaused,"pause invalidates actual running planner")
        try await Task.sleep(nanoseconds:300_000_000)
        expect(PLRuntimeBridge.aims.isEmpty && PLRuntimeBridge.shoots.isEmpty && model.suggestions.isEmpty,"cancelled completion cannot apply or publish a stale suggestion")
        model.toggleAutomationPause()
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation()
        let deadline = ProcessInfo.processInfo.systemUptime + 10
        while model.isPlanning && ProcessInfo.processInfo.systemUptime < deadline { try await Task.sleep(nanoseconds:10_000_000) }
        expect(!model.isPlanning && PLRuntimeBridge.aims.count == 1,"fresh generation accepts actual planner and applies AIM once")
        expect(model.automaticPlan?.aimApplied == true && model.suggestions.first?.id == model.automaticPlan?.suggestion.id,"common prepared solution is actual top-ranked planner result")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.tableState!.balls[1].position.x += 5; model.snapshot!.state = model.tableState!; PLRuntimeBridge.snapshot = model.snapshot
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation()
        let secondDeadline = ProcessInfo.processInfo.systemUptime + 10
        while model.isPlanning && ProcessInfo.processInfo.systemUptime < secondDeadline { try await Task.sleep(nanoseconds:10_000_000) }
        expect(PLRuntimeBridge.aims.count == 2,"actual planner reapplies next best AIM after second settled board")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation()
        model.tableState!.balls[1].position.x += 5
        let staleDeadline = ProcessInfo.processInfo.systemUptime + 10
        while model.isPlanning && ProcessInfo.processInfo.systemUptime < staleDeadline { try await Task.sleep(nanoseconds:10_000_000) }
        expect(PLRuntimeBridge.aims.count == 2 && model.captureEvents.contains("planningDiscarded"),"actual completion on changed board is discarded without command")
        print("{\"result\":\"passed\",\"checks\":\(checks),\"scope\":\"Actual startPlanning, Task.detached, cancellation and generation acceptance; native I/O mocked; unchanged real ShotPlanner and Core\"}")
    }
'''+s[ix:]
s+='\n@main struct Main { static func main() async throws { try await IntegratedGameModel.runAsync() } }\n'
Path('new_project/validation/v11_model/V11AsyncAutomationHarness.swift').write_text(s)

import json,hashlib
metadataPath=Path('new_project/validation/v11_model/ExtractedMethods.json')
metadata=json.loads(metadataPath.read_text())
metadata['asyncMethods']={name:hashlib.sha256(v['member'](name).encode()).hexdigest() for name in ['startPlanning','accepts','acceptsPlan','minimumPlannerPower']}
metadataPath.write_text(json.dumps(metadata,indent=2))
