from pathlib import Path
import hashlib, json, shutil
workspace=Path('new_project/validation/v14_1_tests')
root=Path('new_project/PoolLab')
dest=root/'Validation/V14_1Planner'
dest.mkdir(parents=True,exist_ok=True)
labels=['baseline-debug','final-debug-v2','final-release-v2']
runs={label:json.loads((workspace/label/'TestRun.json').read_text()) for label in labels}
assert runs['baseline-debug']['result']==1
assert runs['final-debug-v2']['result']==runs['final-release-v2']['result']==0
final=runs['final-debug-v2']['compileInputs']
assert final==runs['final-release-v2']['compileInputs']
for rel,digest in final.items():
 assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest
for label in labels:
 run=runs[label]; source=workspace/label; target=dest/label
 target.mkdir(parents=True,exist_ok=True)
 for name in ['CompileInputs.json','main.swift','PlannerTests.txt','TestRun.json']:
  shutil.copyfile(source/name,target/name)
 shutil.copytree(source/'Inputs',target/'Inputs',dirs_exist_ok=True)
 for rel,digest in run['compileInputs'].items():
  assert hashlib.sha256((target/'Inputs'/rel).read_bytes()).hexdigest()==digest
for name in ['run_tests.py','package_evidence.py']:
 shutil.copyfile(workspace/name,dest/name)
readme='''SDKPool V14.1 planner build correction\n\nThe final exact source snapshots were compiled and tested with Swift5.10.1 Linux x86_64, in both -Onone and -O. This is a scoped portable XCTest harness, not a macOS Swift Package Manager run or Apple SDK build.\n\nThe original V14 debug snapshot reproduced the synthetic-carom failure at its original line12. The later-pass test passed on this Linux host; the user\'s macOS log showed both failures. The difference is consistent with host/optimization-dependent elapsed search cutoffs.\n\nFinal runs execute all18 V14PlannerTests (16existing,2new), with all outcomes, replay checks, legality checks and cancellation coverage retained. Controlled-clock outcome fixtures do not prove that a pot will be found within the real1.4-second production budget. The hard simulation cap still applies. Real public monotonic time, zero/tiny expiry, deterministic expiry after one simulation and deterministic phase reservation are separate assertions.\n\nThe production public search always supplies ProcessInfo.processInfo.systemUptime. The test clock overload is internal. No production search budget, phase fraction, simulation algorithm or candidate ordering changed.\n\nEvery compile started from Inputs copied before invoking the compiler. CompileInputs.json binds those files, and TestRun.json records the actual commands and compiled Core digest. The scoped compiler helper/toolchain lives under new_project/validation/v11_runtime in the working environment; it is not bundled into this release. No binaries are included in this evidence folder.\n'''
(dest/'README.txt').write_text(readme)
evidence={str(p.relative_to(root/'Validation')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.rglob('*')) if p.is_file()}
report={
 'format':'sdkpool.v14.1.planner-validation.v1','result':'passed',
 'sourceSHA256':final,
 'baseline':{'tests':2,'failures':1,'reproduced':'testSyntheticRailCaromMissedByLegacyPlannerPotsSameLegalTarget at original line12','notReproducedOnPortableHost':'testSubsequentPassChangesSamplingWhileRetainingVerifiedResults passed; macOS user log failed', 'compileInputs':runs['baseline-debug']['compileInputs']},
 'finalRuns':{label:{'configuration':run['mode'],'testCount':18,'failureCount':0,'wallSeconds':run['wallSeconds'],'compiledCoreSHA256':run['compiledCoreSHA256'],'snapshot':f'V14_1Planner/{label}/CompileInputs.json','log':f'V14_1Planner/{label}/PlannerTests.txt','commands':f'V14_1Planner/{label}/TestRun.json'} for label,run in runs.items() if label.startswith('final')},
 'evidenceSHA256':evidence,
 'deviceRuntimeVerified':False,'appleSDKBuildVerified':False,
 'limitations':['Functional result tests use controlled logical time and retain simulation caps. They do not establish a real-time1.4s success guarantee.','Swift5.10.1 Linux x86_64 scoped compiler harness; full SwiftPM/Xcode/iOS validation still required.','Checkpoints bound additional work after observed elapsed expiry; one in-flight simulation and scheduler delays can overrun a wall-clock threshold.'],
}
(root/'Validation/V14_1PlannerValidation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(root/'Validation/V14_1PlannerValidation.json'),'reportSHA256':hashlib.sha256((root/'Validation/V14_1PlannerValidation.json').read_bytes()).hexdigest(),'finalSourceSHA256':final,'finalTests':36},indent=2))
