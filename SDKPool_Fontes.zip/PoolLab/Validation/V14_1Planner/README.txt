SDKPool V14.1 planner build correction

The final exact source snapshots were compiled and tested with Swift5.10.1 Linux x86_64, in both -Onone and -O. This is a scoped portable XCTest harness, not a macOS Swift Package Manager run or Apple SDK build.

The original V14 debug snapshot reproduced the synthetic-carom failure at its original line12. The later-pass test passed on this Linux host; the user's macOS log showed both failures. The difference is consistent with host/optimization-dependent elapsed search cutoffs.

Final runs execute all18 V14PlannerTests (16existing,2new), with all outcomes, replay checks, legality checks and cancellation coverage retained. Controlled-clock outcome fixtures do not prove that a pot will be found within the real1.4-second production budget. The hard simulation cap still applies. Real public monotonic time, zero/tiny expiry, deterministic expiry after one simulation and deterministic phase reservation are separate assertions.

The production public search always supplies ProcessInfo.processInfo.systemUptime. The test clock overload is internal. No production search budget, phase fraction, simulation algorithm or candidate ordering changed.

Every compile started from Inputs copied before invoking the compiler. CompileInputs.json binds those files, and TestRun.json records the actual commands and compiled Core digest. The scoped compiler helper/toolchain lives under new_project/validation/v11_runtime in the working environment; it is not bundled into this release. No binaries are included in this evidence folder.
