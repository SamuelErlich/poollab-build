from pathlib import Path
import argparse, hashlib, json, re, shutil, subprocess, time
p=argparse.ArgumentParser()
p.add_argument('--label', required=True)
p.add_argument('--mode', choices=['debug','release'], required=True)
p.add_argument('--baseline', action='store_true')
a=p.parse_args()
root=Path('new_project/PoolLab')
out=Path('new_project/validation/v14_1_tests')/a.label
out.mkdir(parents=True, exist_ok=True)
compiler=['python3','new_project/validation/v11_runtime/scoped_swiftc.py']
core=['PracticeGeometry','BilliardsTypes','BilliardsEngine','GameShotCalibration','ShotPlanner','LuckyShotPlanner','TableStateCodec']
suites=['V14PlannerTests']
inputs={}
for relative in [*(f'Sources/PoolLabCore/{n}.swift' for n in core),*(f'Tests/PoolLabCoreTests/{n}.swift' for n in suites)]:
 dest=out/'Inputs'/relative; dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():
  assert dest.read_bytes()==(root/relative).read_bytes(), 'snapshot exists with different content; use a new label'
 else: shutil.copyfile(root/relative,dest)
 inputs[relative]=hashlib.sha256(dest.read_bytes()).hexdigest()
(out/'CompileInputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
flag='-Onone' if a.mode=='debug' else '-O'
commands=[]
command=compiler+[flag,'-enable-testing','-emit-library','-emit-module','-module-name','PoolLabCore']+[str(out/'Inputs/Sources/PoolLabCore'/f'{f}.swift') for f in core]+['-o',str(out/'libPoolLabCore.so')]
commands.append(command);subprocess.run(command,check=True)
entries=[];counts={}
for suite in suites:
 s=(out/'Inputs/Tests/PoolLabCoreTests'/f'{suite}.swift').read_text()
 tests=re.findall(r'func (test\w+)\(\)([^\n]*)\{',s)
 if a.baseline: tests=[(n,t) for n,t in tests if n in ['testSyntheticRailCaromMissedByLegacyPlannerPotsSameLegalTarget','testSubsequentPassChangesSamplingWhileRetainingVerifiedResults']]
 counts[suite]=len(tests)
 entries.append('testCase([\n'+',\n'.join(f'("{n}", '+(f'asyncTest({suite}.{n})' if 'async' in tail else f'{suite}.{n}')+')' for n,tail in tests)+'\n])')
(out/'main.swift').write_text('import XCTest\n@testable import PoolLabCore\nXCTMain([\n'+',\n'.join(entries)+'\n])\n')
command=compiler+[flag,'-I',str(out),'-L',str(out),'-l','PoolLabCore']+[str(out/'Inputs/Tests/PoolLabCoreTests'/f'{f}.swift') for f in suites]+[str(out/'main.swift'),'-o',str(out/'planner-tests')]
commands.append(command);subprocess.run(command,check=True)
started=time.monotonic()
with (out/'PlannerTests.txt').open('w') as log:
 result=subprocess.run([str(out/'planner-tests')],stdout=log,stderr=subprocess.STDOUT)
report={'result':result.returncode,'mode':a.mode,'tests':counts,'wallSeconds':time.monotonic()-started,'compileInputs':inputs,'commands':commands,'compiledCoreSHA256':hashlib.sha256((out/'libPoolLabCore.so').read_bytes()).hexdigest(),'platform':'Swift 5.10.1 Linux x86_64; scoped frontend/compiler harness, not Apple SDK'}
(out/'TestRun.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k in ('result','mode','tests','wallSeconds')},indent=2))
print('\n'.join((out/'PlannerTests.txt').read_text().splitlines()[-12:]))
raise SystemExit(result.returncode)
