import Foundation
private enum PLAutomationMarkGeometry {
    static let width: CGFloat = 176

    static func pauseFrame(in frame: CGRect) -> CGRect {
        CGRect(x: frame.maxX - 44, y: frame.minY, width: 44, height: 44)
    }

    static func frame(in safe: CGRect, table: CGRect?, exclusions: [CGRect]) -> CGRect? {
        guard !safe.isNull, !safe.isInfinite,
              [safe.minX, safe.minY, safe.width, safe.height].allSatisfy(\.isFinite),
              safe.width >= width, safe.height >= 44 else { return nil }
        // All candidates stay on the right. Reserve the same footprint while
        // planning and while idle, so status changes cannot move the control.
        let candidates = [CGFloat(0), 1, 0.25, 0.75, 0.5].map { fraction in
            CGRect(x: safe.maxX - width, y: safe.minY + (safe.height - 44) * fraction,
                   width: width, height: 44)
        }.filter { candidate in
            safe.contains(candidate) && exclusions.allSatisfy {
                $0.isNull || $0.isEmpty || !$0.insetBy(dx: -4, dy: -4).intersects(candidate)
            }
        }
        if let table, !table.isNull, !table.isEmpty,
           let outsideCloth = candidates.first(where: { !table.insetBy(dx: -4, dy: -4).intersects($0) }) {
            return outsideCloth
        }
        // On unusually small layouts keep pause reachable if a corner is free.
        // Pocket mouths, the prediction notice and the S button stay excluded.
        return candidates.first
    }
}

private enum PLAutomationTimeText {
    static func string(_ elapsed: TimeInterval) -> String {
        guard elapsed.isFinite, elapsed > 0 else { return "00:00" }
        // Keep the watermark width stable even if a session is left running.
        let seconds = Int(min(elapsed, 359_999))
        if seconds >= 3_600 {
            return String(format: "%02d:%02d:%02d", seconds / 3_600, (seconds / 60) % 60, seconds % 60)
        }
        return String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}


var checked = 0
func check(_ ok: Bool, _ title: String) {
    precondition(ok, title)
    checked += 1
}
let safe = CGRect(x: 12, y: 8, width: 800, height: 374)
let table = CGRect(x: 60, y: 70, width: 700, height: 250)
let first = PLAutomationMarkGeometry.frame(in: safe, table: table, exclusions: [])!
check(first.maxX == safe.maxX && first.minY == safe.minY, "Prefer upper right outside table")
let second = PLAutomationMarkGeometry.frame(in: safe, table: table, exclusions: [first])!
check(second.maxX == safe.maxX && second.maxY == safe.maxY, "Blocked upper corner moves lower right")
check(PLAutomationMarkGeometry.frame(in: safe, table: table, exclusions: [safe]) == nil, "Do not cover excluded controls")
check(PLAutomationMarkGeometry.frame(in: CGRect(x: 0, y: 0, width: 175, height: 400), table: nil, exclusions: []) == nil, "Do not overflow narrow surface")
check(PLAutomationMarkGeometry.frame(in: .null, table: nil, exclusions: []) == nil, "Reject unavailable surface")
let pause = PLAutomationMarkGeometry.pauseFrame(in: first)
check(pause.width == 44 && pause.height == 44 && first.contains(pause), "Reachable 44pt pause target")
let planning = CGRect(x: first.minX + 4, y: first.minY + 30, width: 118, height: 14)
check(first.contains(planning) && !planning.intersects(pause), "Planning notice leaves pause target and footprint intact")
for width in [CGFloat(320), 375, 667, 812, 932, 1_024] {
    for height in [CGFloat(180), 320, 430, 768] {
        let area = CGRect(x: 10, y: 4, width: width - 20, height: height - 8)
        let frame = PLAutomationMarkGeometry.frame(in: area, table: nil, exclusions: [])!
        check(area.contains(frame) && frame.maxX == area.maxX, "Right placement inside varied viewport")
    }
}
for (time, expected): (Double, String) in [(0,"00:00"),(-1,"00:00"),(.nan,"00:00"),(.infinity,"00:00"),(59.99,"00:59"),(60,"01:00"),(3_599.99,"59:59"),(3_600,"01:00:00"),(359_999,"99:59:59")] {
    check(PLAutomationTimeText.string(time) == expected, "Elapsed display formatting")
}
print("HUD geometry and time checks passed: \(checked)")
