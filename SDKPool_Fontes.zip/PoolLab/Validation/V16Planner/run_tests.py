#!/usr/bin/env python3
"""Freeze portable Core/test inputs, compile, then finalize a direct shell XCTest run.

KeyAuth uses Apple CryptoKit and is not substituted in this Linux run.
Run with no arguments to compile, launch the printed command directly in the
shell, and use --finish only after a successful shell exit code was observed.
"""
from pathlib import Path
import hashlib, json, re, shutil, subprocess, sys

here = Path(__file__).resolve().parent
root = here.parents[1]
binary = Path('/workspace/scratch/93d3b09386b0/sdkpool-validation/v16/core')
binary.mkdir(parents=True, exist_ok=True)
compiler = ['python3', str(root/'Validation/V15Automation/scoped_swiftc.py')]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt_path = here/'CompileInputs.json'

if '--finish' not in sys.argv:
    sources = sorted(p for p in (root/'Sources/PoolLabCore').glob('*.swift') if not p.stem.startswith('KeyAuth'))
    tests = sorted(p for p in (root/'Tests/PoolLabCoreTests').glob('*.swift') if not p.stem.startswith('KeyAuth'))
    bindings = {}
    for path in sources + tests:
        rel = path.relative_to(root)
        dest = here/'Inputs'/rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            assert dest.read_bytes() == path.read_bytes(), 'Inputs already frozen differently: ' + str(rel)
        else:
            shutil.copyfile(path,dest)
        bindings[str(rel)] = sha(dest)
    counts, entries = {}, []
    for path in tests:
        suite = path.stem
        text = (here/'Inputs'/path.relative_to(root)).read_text()
        methods = re.findall(r'func (test\w+)\(\)([^\n]*)\{',text)
        assert methods, 'No tests found in ' + suite
        counts[suite] = len(methods)
        entries.append('testCase([\n' + ',\n'.join('("'+name+'", '+('asyncTest('+suite+'.'+name+')' if 'async' in tail else suite+'.'+name)+')' for name,tail in methods) + '\n])')
    (here/'main.swift').write_text('import XCTest\n@testable import PoolLabCore\nXCTMain([\n'+',\n'.join(entries)+'\n])\n')
    receipt = {'platform':'Swift 5.10.1 Linux x86_64, scoped frontend/linker', 'configuration':'Release / -O', 'sourceSHA256':bindings,
               'inputsFrozenBeforeCompilation':True, 'testCounts':counts, 'excluded':'KeyAuthClientTests requires Apple CryptoKit; no replacement supplied.',
               'compilerWrapperSHA256':sha(compiler[1]), 'commands':{}}
    for name,args in [
        ('core',['-O','-enable-testing','-emit-library','-emit-module','-module-name','PoolLabCore',*[str(here/'Inputs'/p.relative_to(root)) for p in sources],'-o',str(binary/'libPoolLabCore.so')]),
        ('tests',['-O','-I',str(binary),'-L',str(binary),'-lPoolLabCore',*[str(here/'Inputs'/p.relative_to(root)) for p in tests],str(here/'main.swift'),'-o',str(binary/'core-tests')])
    ]:
        command = compiler + args
        receipt['commands'][name] = command
        receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
        with (here/('Compile'+name.title()+'.log')).open('w') as log:
            result = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:
            print((here/('Compile'+name.title()+'.log')).read_text())
            raise SystemExit(result.returncode)
    receipt['compiledCoreSHA256']=sha(binary/'libPoolLabCore.so')
    receipt['compiledTestsSHA256']=sha(binary/'core-tests')
    receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
    print('Compiled',sum(counts.values()),'tests. Launch directly from shell:')
    print(str(binary/'core-tests')+' > '+str(here/'AllCoreTests.log')+' 2>&1')
    raise SystemExit(0)

receipt = json.loads(receipt_path.read_text())
assert sha(binary/'libPoolLabCore.so') == receipt['compiledCoreSHA256']
assert sha(binary/'core-tests') == receipt['compiledTestsSHA256']
for rel,digest in receipt['sourceSHA256'].items():
    assert sha(root/rel) == sha(here/'Inputs'/rel) == digest, 'Source changed after freeze: '+rel
log = (here/'AllCoreTests.log').read_text()
matches = re.findall(r'Executed (\d+) tests?, with (\d+) failures?[^\n]*? in ([\d.]+)',log)
assert matches, 'Missing XCTest completion'
count,failures,seconds = matches[-1]
assert int(count) == sum(receipt['testCounts'].values()) and int(failures)==0
assert "Test Suite 'All tests' passed" in log
report = {'format':'SDKPool.V16.PlannerValidation','result':'passed','configuration':receipt['platform']+' / '+receipt['configuration'],
          'testCount':int(count),'failureCount':0,'xctestSeconds':float(seconds),'sourceSHA256':receipt['sourceSHA256'],
          'testCounts':receipt['testCounts'],'compiledCoreSHA256':receipt['compiledCoreSHA256'],'compiledTestsSHA256':receipt['compiledTestsSHA256'],
          'evidenceSHA256':{str(p.relative_to(root/'Validation')):sha(p) for p in sorted(here.rglob('*')) if p.is_file()},
          'appleSDKBuildVerified':False,'deviceRuntimeVerified':False,
          'limitations':['Portable Core only. Apple CryptoKit authentication tests require GitHub Apple build.',
                         'Controlled-clock search fixtures verify outcomes and simulation limits, not device elapsed performance.',
                         'Finite route seed coverage does not guarantee a shot in every position.']}
(root/'Validation/V16PlannerValidation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['result','testCount','failureCount','xctestSeconds']}))
