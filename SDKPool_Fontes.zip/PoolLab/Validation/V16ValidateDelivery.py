from pathlib import Path
import ast, hashlib, json, plistlib, re, subprocess, zipfile

repo=Path('/workspace/scratch/93d3b09386b0/sdkpool-repo')
root=repo/'source/PoolLab'
baseline=Path('/workspace/scratch/93d3b09386b0/sdkpool-validation/baseline/SDKPool_V15_Fontes.zip')
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(label,value):
    checks.append({'name':label,'passed':bool(value)})
    if not value: raise AssertionError(label)
reports=['V16PlannerValidation.json','V16AutomationValidation.json','V16IntegratedSwiftParse.json',
         'V16NavigationEvidence.json','V16NavigationSourceValidation.json','V16NavigationSyntax.json',
         'V16Interactions/RecorderValidation.json','V16IndependentReview.json']
for name in reports:
    p=root/'Validation'/name; data=json.loads(p.read_text())
    for relative,expected in data.get('sourceSHA256',{}).items():
        check(name+' source '+relative,sha(root/relative)==expected)
    for relative,expected in data.get('evidenceSHA256',{}).items():
        check(name+' evidence '+relative,sha(root/'Validation'/relative)==expected)
rec=json.loads((root/'Validation/V16Interactions/RecorderValidation.json').read_text())
for field,file in [('declarationsSHA256','RecorderDeclarations.h'),('translationUnitSHA256','RecorderSyntax.m'),('logSHA256','RecorderSyntax.log')]:
    check('recorder syntax '+file,sha(root/'Validation/V16Interactions'/file)==rec['syntax'][field])
changed=[]; historical=0
with zipfile.ZipFile(baseline) as z:
    for info in z.infolist():
        if info.is_dir(): continue
        rel=Path(info.filename).relative_to('PoolLab'); p=root/rel
        check('baseline file retained '+str(rel),p.is_file())
        same=p.read_bytes()==z.read(info.filename)
        if str(rel).startswith('Validation/'):
            check('historical evidence unchanged '+str(rel),same); historical+=1
        if not same: changed.append(str(rel))
    protected=['Sources/PoolLabCore/BilliardsEngine.swift','Sources/PoolLabCore/BilliardsTypes.swift',
        'Sources/PoolLabCore/GameShotCalibration.swift','Sources/PoolLabCore/AutoPlayMode.swift',
        'Integrated/PLRuntimeBridge.h','Integrated/PLRuntimeBridge.m','Integrated/PLAdControl.h',
        'Integrated/PLAdControl.m','Integrated/PLBootstrap.m','iOS/AppModel.swift','iOS/DeviceIdentity.swift',
        'Sources/PoolLabCore/KeyAuthClient.swift','Sources/PoolLabCore/KeyAuthTransport.swift',
        'Sources/PoolLabCore/KeyAuthTypes.swift','Sources/PoolLabCore/KeyAuthVerification.swift']
    for rel in protected:
        check('protected source '+rel,(root/rel).read_bytes()==z.read('PoolLab/'+rel))
    old_ui=z.read('PoolLab/Integrated/PoolLabIntegration.swift').decode()
    new_ui=(root/'Integrated/PoolLabIntegration.swift').read_text()
    marker='    private var diagnostics: some View {'
    check('trajectory and HUD renderer before diagnostics preserved',old_ui.split(marker)[0]==new_ui.split(marker)[0])
    check('previous delivery validation archived',(root/'Validation/PreviousV15DeliveryValidation.json').read_bytes()==z.read('PoolLab/VALIDACAO.json'))
for p in root.rglob('*.sh'):
    r=subprocess.run(['bash','-n',str(p)],capture_output=True,text=True)
    check('shell syntax '+str(p.relative_to(root)),r.returncode==0)
for p in root.rglob('*.py'):
    ast.parse(p.read_text(),filename=str(p)); check('python syntax '+str(p.relative_to(root)),True)
for p in root.rglob('*.plist'):
    plistlib.loads(p.read_bytes()); check('plist '+str(p.relative_to(root)),True)
pbx=(root/'PoolLab.xcodeproj/project.pbxproj').read_text()
check('framework build17 both configurations',pbx.count('CURRENT_PROJECT_VERSION = 17;')==2)
check('framework version1.14 both configurations',pbx.count('MARKETING_VERSION = 1.14;')==2)
objects={m[1]:m[2] for m in re.finditer(r'^\s*([0-9A-F]{24}) = (\{.*\});$',pbx,re.M)}
check('PBX no duplicate objectIDs',len(objects)==len(re.findall(r'^\s*[0-9A-F]{24} = \{',pbx,re.M)))
for ref in set(re.findall(r'\b[0-9A-F]{24}\b',pbx)):
    check('PBX reference resolves '+ref,ref in objects)
for filename,phase in [('PLInteractionRecorder.h','PBXHeadersBuildPhase'),('PLInteractionRecorder.m','PBXSourcesBuildPhase')]:
    refs=[oid for oid,body in objects.items() if 'isa = PBXFileReference;' in body and f'path = {filename};' in body]
    check('recorder file reference '+filename,len(refs)==1)
    ref=refs[0]
    builds=[oid for oid,body in objects.items() if f'fileRef = {ref};' in body]
    check('recorder one buildfile '+filename,len(builds)==1)
    check('recorder integrated group '+filename,any('path = Integrated;' in body and ref in body for body in objects.values()))
    phases=[oid for oid,body in objects.items() if f'isa = {phase};' in body and builds[0] in body]
    check('recorder correct buildphase '+filename,len(phases)==1)
    target=[body for body in objects.values() if 'isa = PBXNativeTarget;' in body and 'name = PoolLabIntegration;' in body][0]
    check('recorder framework target '+filename,phases[0] in target)
    if filename.endswith('.h'):check('recorder public header','ATTRIBUTES = (Public)' in objects[builds[0]])
script=(root/'scripts/build_integration_framework.sh').read_text()
for file in ['PLInteractionRecorder.h','PLInteractionRecorder.m']:
    check('build requires '+file,'Integrated/'+file in script)
check('umbrella exports recorder','PLInteractionRecorder.h' in (root/'Integrated/PoolLabIntegration.h').read_text())
check('framework guard1.14/17',"!= '17'" in script and "!= '1.14'" in script)
upgrade=(root/'scripts/upgrade_poollab_ipa.py').read_text()
check('packager guard1.14/17','NEW_VERSION = "1.14"' in upgrade and 'NEW_BUILD = "17"' in upgrade)
check('UI build label','SDKPool 1.14 · compilação 17' in new_ui)
model=(root/'Integrated/IntegratedGameModel.swift').read_text()
check('export build17 schema8','"version": 8, "frameworkBuild": 17' in model)
check('export filename V16','SDKPool-V16-' in model)
source_paths=['Integrated/IntegratedGameModel.swift','Integrated/PoolLabIntegration.swift','Integrated/PoolLabIntegration.h',
    'Integrated/PLInteractionRecorder.h','Integrated/PLInteractionRecorder.m','Integrated/PLQueueBridge.h','Integrated/PLQueueBridge.m',
    'Sources/PoolLabCore/ShotPlanner.swift','Tests/PoolLabCoreTests/V16PlannerTests.swift',
    'PoolLab.xcodeproj/project.pbxproj','scripts/build_integration_framework.sh','scripts/upgrade_poollab_ipa.py']
report={'format':'SDKPool.V16.DeliverySourceValidation','result':'passed','checkCount':len(checks),
    'historicalEvidenceFilesPreserved':historical,'changedBaselineFilesBeforeManifest':changed,
    'sourceSHA256':{name:sha(root/name) for name in source_paths},'checks':checks,
    'appleSDKBuildVerified':False,'deviceRuntimeVerified':False}
(root/'Validation/V16DeliverySourceValidation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':'passed','checks':len(checks),'historicalPreserved':historical,'changedBaseline':changed},ensure_ascii=False,indent=2))
