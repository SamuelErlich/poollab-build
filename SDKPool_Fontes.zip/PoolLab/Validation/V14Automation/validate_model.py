from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile

root=Path('new_project/PoolLab')
out=Path('new_project/validation/v14_model')
frozen=out/'CoreInputs'; frozen.mkdir(exist_ok=True)
binary=out/'compiled'; binary.mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
compiler=['python3','new_project/validation/v11_runtime/scoped_swiftc.py']
names=['PracticeGeometry','BilliardsTypes','BilliardsEngine','GameShotCalibration','ShotPlanner','LuckyShotPlanner','TableStateCodec']

if '--finish' not in sys.argv:
    subprocess.run(['python3',str(out/'build_async_harness.py')],check=True)
    sourceMap={}
    for name in names:
        rel=f'Sources/PoolLabCore/{name}.swift'
        shutil.copy2(root/rel,frozen/f'{name}.swift')
        sourceMap[rel]=digest(root/rel)
        assert sourceMap[rel]==digest(frozen/f'{name}.swift')
    receipt={'sourceSHA256':sourceMap,'modelSHA256':digest(root/'Integrated/IntegratedGameModel.swift'),
             'retainedInputSHA256':{p.name:digest(p) for p in frozen.glob('*.swift')},
             'inputsFrozenBeforeCompilation':True,'compilerWrapperSHA256':digest(compiler[1]),'commands':{}}
    receiptPath=out/'V14CoreInputReceipt.json'
    receiptPath.write_text(json.dumps(receipt,indent=2))
    command=compiler+['-O','-enable-testing','-emit-library','-emit-module','-module-name','PoolLabCore']+[str(frozen/f'{n}.swift') for n in names]+['-o',str(binary/'libPoolLabCore.so')]
    receipt['commands']['core']=command
    receiptPath.write_text(json.dumps(receipt,indent=2))
    subprocess.run(command,check=True)
    for kind,file,flags in [('synchronous','V14SmoothAutomationHarness.swift',['-O']),('asynchronous','V14AsyncSmoothAutomationHarness.swift',['-O','-parse-as-library'])]:
        command=compiler+flags+['-I',str(binary),'-L',str(binary),'-lPoolLabCore',str(out/file),'-o',str(binary/kind)]
        receipt['commands'][kind]=command
        receiptPath.write_text(json.dumps(receipt,indent=2))
        subprocess.run(command,check=True)
        assert (binary/kind).read_bytes().startswith(b'\x7fELF'),kind
    receipt['compiledLibrarySHA256']=digest(binary/'libPoolLabCore.so')
    receiptPath.write_text(json.dumps(receipt,indent=2))
    print('Compiled frozen Core and exact model fixtures. Launch binaries directly, capture JSON, then --finish.')
    raise SystemExit(0)

receipt=json.loads((out/'V14CoreInputReceipt.json').read_text())
assert receipt['modelSHA256']==digest(root/'Integrated/IntegratedGameModel.swift')
for rel,sha in receipt['sourceSHA256'].items():
    assert sha==digest(root/rel)==digest(frozen/Path(rel).name),rel
assert receipt['compiledLibrarySHA256']==digest(binary/'libPoolLabCore.so')
for name,sha in receipt['retainedInputSHA256'].items(): assert digest(frozen/name)==sha
meta=json.loads((out/'ExtractedMethods.json').read_text())
assert meta['sourceSHA256']==receipt['modelSHA256']
results={kind:json.loads((out/f'V14{kind.title()}Results.json').read_text()) for kind in ['synchronous','asynchronous']}
assert all(v['result']=='passed' for v in results.values())
baselinePath=Path('new_project/validation/v13_before_v14/SDKPool_Fontes.zip')
with zipfile.ZipFile(baselinePath) as z:
    old=z.read('PoolLab/Integrated/IntegratedGameModel.swift').decode()
current=(root/'Integrated/IntegratedGameModel.swift').read_text()
historical=json.loads((root/'Validation/V13SmoothAutomationAudit.json').read_text())
markers=list(historical['preservedPredictionMethods'])
markers+=['private struct AutomaticContext:','private struct AutomaticPlan {','private struct AutomaticControlSequence {',
          'private static func controlAngleDelta(', 'private static func smoothControlFraction(']
def block(text,marker):
    start=text.index('    '+marker)
    return text[start:text.index('\n    }',start)+6]
preserved={}
for marker in markers:
    before=block(old,marker); after=block(current,marker)
    assert before==after,marker
    preserved[marker]=hashlib.sha256(after.encode()).hexdigest()
normalizedPreserved={}
for marker in ['private func advanceAutomaticControlSequence(', 'private func execute(', 'private func acknowledgeShotProgress(']:
    before=block(old,marker); after=block(current,marker)
    normalized=before.replace('pauseAutomaticActions','deferAutomaticActions').replace('pause: true','waitForInput: true').replace('pause: false','waitForInput: false').replace('automaticBlockedContext','automaticSearchContext')
    normalized=normalized.replace('AIM pausado:', 'AIM aguardando os controles:').replace('Tacada automática pausada:', 'Automático aguardando confirmação dos controles:')
    assert normalized==after,marker
    normalizedPreserved[marker]={'baselineSHA256':hashlib.sha256(before.encode()).hexdigest(),
                                  'sourceSHA256':hashlib.sha256(after.encode()).hexdigest(),
                                  'changes':'Only internal pause helper renamed to defer, cancel argument label, context name, and wait messages; exact control/dispatch math and guards preserved.'}
subprocess.run(compiler+['-parse',str(root/'Integrated/IntegratedGameModel.swift')],check=True)
native=(root/'Integrated/PLRuntimeBridge.m').read_text()
assert 'mPlayerTurnTimeFinished' in native
readme='''V14 bounded expanded search integration

Production model methods are extracted verbatim. Native I/O and UI collaborators
are mocked; native field values are copied fixtures. The actual PoolLabCore is
compiled from seven frozen inputs recorded before compilation in the receipt.
The full source digest is checked again after execution. No Apple SDK or game
runtime is executed. Display steps are deterministic.

The synchronous suite keeps the V13 gradual control, pause, touch, fresh-state,
single-dispatch and uncertain-dispatch assertions. The async suite exercises the
real Task.detached planner and exact model acceptance path, recording search
stages/counts/budget/stop reason. It verifies bounded empty-result cooldown,
continuous exploration-pass retries with no worker overlap, legal-context reset,
pending-search cancellation, and rejection after table, legality, readiness or
native view changes. Routine capture loss, user touch, match result and queue
failure preserve user-enabled modes. Explicit user pause remains paused. Native
uncertain-dispatch protection remains active while automatic mode stays armed.

Reproduction from the repository workspace:
python3 new_project/validation/v14_model/validate_model.py
new_project/validation/v14_model/compiled/synchronous > new_project/validation/v14_model/V14SynchronousResults.json
new_project/validation/v14_model/compiled/asynchronous > new_project/validation/v14_model/V14AsynchronousResults.json
python3 new_project/validation/v14_model/validate_model.py --finish

The 1.4 second planner budget is checked between operations/simulations and can
overrun by the duration of one simulation. Only the native turn-expired flag is
known, not the remaining turn time; pre-release native readiness still applies.
No synthesized finger event or additional prediction/render timer is introduced.
'''
(out/'README.txt').write_text(readme)
dest=root/'Validation/V14Automation'; dest.mkdir(exist_ok=True)
(dest/'CoreInputs').mkdir(exist_ok=True)
files=['build_harness.py','build_async_harness.py','validate_model.py','Tests.swift.txt',
       'V14SmoothAutomationHarness.swift','V14AsyncSmoothAutomationHarness.swift','ExtractedMethods.json',
       'V14SynchronousResults.json','V14AsynchronousResults.json','V14CoreInputReceipt.json','README.txt']
for name in files: shutil.copy2(out/name,dest/name)
for name in names: shutil.copy2(frozen/f'{name}.swift',dest/'CoreInputs'/f'{name}.swift')
report={'format':'SDKPool.V14.AutomationAudit','result':'passed',
        'sourceSHA256':{'Integrated/IntegratedGameModel.swift':receipt['modelSHA256']},
        'baselineArchiveSHA256':digest(baselinePath),'baselineModelSHA256':hashlib.sha256(old.encode()).hexdigest(),
        'testResults':results,'assertionCount':sum(v['checks'] for v in results.values()),
        'preservedDeclarations':preserved,'preservedDeclarationCount':len(preserved),
        'normalizedProtectedAutomationDeclarations':normalizedPreserved,
        'compiledCoreSourceSHA256':receipt['sourceSHA256'],
        'compiledCoreInputReceipt':{'manifestBeforeCompilation':True,'inputsFrozenBeforeCompilation':True,
                                   'inputsRecheckedAfterCompilation':True,'productionSourcesRecheckedAfterCompilation':True,
                                   'retainedInputRoot':'Validation/V14Automation/CoreInputs',
                                   'manifest':'Validation/V14Automation/V14CoreInputReceipt.json',
                                   'compilerCommands':receipt['commands']},
        'compiledFixtureCoreSHA256':receipt['compiledLibrarySHA256'],
        'fixtureSHA256':{str(p.relative_to(root)):digest(p) for p in sorted(dest.rglob('*')) if p.is_file()},
        'swiftSyntax':'passed','deviceRuntimeVerified':False,'appleSDKBuildVerified':False,
        'scope':'Exact production automation and real expanded bounded planner with native I/O mocked; prediction and gradual control preserved.',
        'turnClockAudit':{'nativeExpiredField':'GameManager.mPlayerTurnTimeFinished',
                         'remainingTimeAvailable':False,'newNativeReads':False},
        'notes':['An empty bounded search schedules a different exploration pass after650ms with no concurrent planner workers.',
                 'User pause/off cancels planning. Changed board/rules/view restarts exploration at pass0.',
                 'Routine waiting preserves the enabled flags and explicit user pause; only user off or license loss disarms.',
                 'Only completed valid simulations reach gradual controls. The final state is checked before controls and release.',
                 'Elapsed budget is a soft bound between simulations; native turn readiness can reject expired shots.',
                 'No iPhone performance, UI power-slider animation or synthesized finger gesture verified.']}
(root/'Validation/V14AutomationAudit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'result':'passed','checks':report['assertionCount'],'preservedDeclarations':len(preserved),
                  'reportSHA256':digest(root/'Validation/V14AutomationAudit.json'), 'sourceSHA256':report['sourceSHA256']},indent=2))
