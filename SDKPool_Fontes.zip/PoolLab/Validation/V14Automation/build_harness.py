from pathlib import Path
import ast,re,json,hashlib
root=Path('new_project/PoolLab')
s=(root/'Integrated/IntegratedGameModel.swift').read_text()
out=Path('new_project/validation/v14_model');out.mkdir(exist_ok=True,parents=True)
old=ast.parse((root/'Validation/V11Automation/build_harness.py').read_text())
header=next(ast.literal_eval(n.value) for n in old.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='header' for t in n.targets))
header=header.replace('final class MockView {}','final class MockView {}\ntypealias PLGameSnapshot = Snapshot')
header=header.replace('    var isBreakShot = false','    var isBreakShot = false\n    var aimAvailable = true\n    var aimAngle = 2.9\n    var cuePower = 0.0\n    var diagnostics: [String:String] = [:]',1)
header=header.replace('    static var captureError: NSError?','    static var captureError: NSError?\n    static var forceStale = false')
header=header.replace('current.captureTimestamp = ProcessInfo.processInfo.systemUptime','current.captureTimestamp = ProcessInfo.processInfo.systemUptime - (forceStale ? 2 : 0)')
header=header.replace('    static func applyPlannedAim(', '    static func applyAimProgress(')
header=header.replace('''        if let e = aimError { throw e }
''','''        if let e = aimError { throw e }
        snapshot.aimAngle = angle
        snapshot.cuePower = power
''')
header=header.replace('automaticBlockedContext', 'automaticSearchContext')
header=header.replace('    var automaticRetryAfter: TimeInterval = 0', '    var automaticRetryAfter: TimeInterval = 0\n    var automaticSearchPass = 0\n    var automaticSearchRetryAt: TimeInterval = 0')
header=header.replace('    var planningPurpose: PlanningPurpose?', '    var planningPurpose: PlanningPurpose?\n    var lastPlanningSearch: [String:Any] = [:]')
header=header.replace('    var automaticCommandAttempts = 0','    var automaticCommandAttempts = 0\n    var automaticControlAttempts = 0\n    var lastAutomaticControlMilliseconds = 0.0\n    var maximumAutomaticControlMilliseconds = 0.0')
header=header.replace('final class MockView {}', '''final class MockView {}
final class MockAuthorization { var canUseModules = true }
struct MockQueueState {
    var isResultScreen = false, ready = false
    var resultToken = "", unavailableReason = "waiting"
}
enum PLQueueBridge {
    static var state = MockQueueState()
    static var error: NSError?
    static var submissions: [String] = []
    static func capture() throws -> MockQueueState { if let error { throw error }; return state }
    static func startNextMatch(token: String) throws { if let error { throw error }; submissions.append(token) }
}''')
header=header.replace('    var queueTransition: Int?', '''    private var queueTransition: QueueTransition?
    var authorization = MockAuthorization()
    var autoQueueEnabled = false, blockInterstitialAds = false
    var queueStatus = "", shotInputUnavailableReason = "", opponentPreviewUnavailableReason = "", luckyStatus = ""
    var isCalibrated = true, shotInputSupported = true
    var previewUsesReferencePower = false, opponentPreviewAvailable = false, aimAvailable = true
    var ballCount = 2
    var lastNativeAim: (angle:Double,power:Double)?
    var predictionInputIssue: String?
    var attemptedQueueTokens: Set<String> = []
    let queueTransitionTimeout = 30.0
    func setBlockInterstitialAds(_ value: Bool) { blockInterstitialAds = value }''')
header=header.replace('    func clearBoard(message: String, preserveQueueIntent: Bool) { clearRequests += 1; stopAutomation(message:message); hasTable = false }','')
def member(name,kind='func'):
 m=re.search(r'^    (?:private |static )*'+kind+' '+re.escape(name)+r'\b[^\n]*',s,re.M);assert m,name
 return s[m.start():s.index('\n    }',m.start())+6]
names=['setAutoAimEnabled','setAutoPlay','toggleAutomationPause','resetAutomaticPlan','advanceAutomation','advanceAutomaticControlSequence','hasNativeControlTouch','controlAngleDelta','smoothControlFraction','cancelAutomaticControlSequence','execute','acknowledgeShotProgress','waitAutomation','deferAutomaticActions','stopAutomation','handleCaptureFailure','panelOpened','panelClosed','cancelPlanner','pauseAutomationForUnsupportedMotion','isFreshSample','clearBoard','setAutoQueue','pollQueue']
parts=[member(n) for n in names]+[member('AutomaticContext','struct'),member('AutomaticPlan','struct'),member('AutomaticControlSequence','struct'),member('QueueTransition','struct'),member('currentAutomaticContext','var')]
tests=(out/'Tests.swift.txt').read_text()
(out/'V14SmoothAutomationHarness.swift').write_text(header+'\n\n'.join(parts)+'\n'+tests)
(out/'ExtractedMethods.json').write_text(json.dumps({'sourceSHA256':hashlib.sha256(s.encode()).hexdigest(),'methods':{n:hashlib.sha256(member(n).encode()).hexdigest() for n in names},'structs':{n:hashlib.sha256(member(n,'struct').encode()).hexdigest() for n in ['AutomaticContext','AutomaticPlan','AutomaticControlSequence']},'note':'Exact production methods; mocked native capture/control I/O and deterministic display steps. The real Core/ShotPlanner supplies fixture shots; does not validate UIKit rendering or device callbacks.'},indent=2))
