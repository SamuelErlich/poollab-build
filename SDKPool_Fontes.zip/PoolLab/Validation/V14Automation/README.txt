V14 bounded expanded search integration

Production model methods are extracted verbatim. Native I/O and UI collaborators
are mocked; native field values are copied fixtures. The actual PoolLabCore is
compiled from seven frozen inputs recorded before compilation in the receipt.
The full source digest is checked again after execution. No Apple SDK or game
runtime is executed. Display steps are deterministic.

The synchronous suite keeps the V13 gradual control, pause, touch, fresh-state,
single-dispatch and uncertain-dispatch assertions. The async suite exercises the
real Task.detached planner and exact model acceptance path, recording search
stages/counts/budget/stop reason. It verifies bounded empty-result cooldown,
continuous exploration-pass retries with no worker overlap, legal-context reset,
pending-search cancellation, and rejection after table, legality, readiness or
native view changes. Routine capture loss, user touch, match result and queue
failure preserve user-enabled modes. Explicit user pause remains paused. Native
uncertain-dispatch protection remains active while automatic mode stays armed.

Reproduction from the repository workspace:
python3 new_project/validation/v14_model/validate_model.py
new_project/validation/v14_model/compiled/synchronous > new_project/validation/v14_model/V14SynchronousResults.json
new_project/validation/v14_model/compiled/asynchronous > new_project/validation/v14_model/V14AsynchronousResults.json
python3 new_project/validation/v14_model/validate_model.py --finish

The 1.4 second planner budget is checked between operations/simulations and can
overrun by the duration of one simulation. Only the native turn-expired flag is
known, not the remaining turn time; pre-release native readiness still applies.
No synthesized finger event or additional prediction/render timer is introduced.
