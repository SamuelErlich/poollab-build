#include <cmath>
#include <limits>
#include <cstdio>
using std::isfinite;
bool acceptsPartial(double angle, double power, int target, int pocket) { return !(!isfinite(angle) || !isfinite(power) || power < 0 || power > 1 ||
        target < 1 || target > 15 || pocket < 0 || pocket > 5); }
bool acceptsShotArguments(double angle, double power, int target, int pocket) { return !(!isfinite(angle) || !isfinite(power) || power <= 0 || power > 1 ||
        target < 1 || target > 15 || pocket < 0 || pocket > 5); }
int main() {
 const double nan = std::numeric_limits<double>::quiet_NaN();
 const double inf = std::numeric_limits<double>::infinity();
 struct Sample { double angle, power; int target, pocket; bool partial, shot; } samples[] = {
  {0,0,1,0,true,false}, {0,0.001,1,0,true,true}, {0,0.2,8,3,true,true},
  {0,1,15,5,true,true}, {-3.141592653589793,0,1,0,true,false},
  {6.283185307179586,1,1,0,true,true}, {0,-0.01,1,0,false,false},
  {0,1.01,1,0,false,false}, {0,nan,1,0,false,false}, {0,inf,1,0,false,false},
  {nan,0.3,1,0,false,false}, {inf,0.3,1,0,false,false},
  {0,0.3,0,0,false,false}, {0,0.3,16,0,false,false},
  {0,0.3,1,-1,false,false}, {0,0.3,1,6,false,false}
 };
 int i = 0;
 for (const auto &s : samples) {
  ++i;
  if (acceptsPartial(s.angle,s.power,s.target,s.pocket) != s.partial ||
      acceptsShotArguments(s.angle,s.power,s.target,s.pocket) != s.shot) {
   std::printf("case %d failed\n",i); return 1;
  }
 }
 std::printf("%d extracted argument cases passed\n",i); return 0;
}
