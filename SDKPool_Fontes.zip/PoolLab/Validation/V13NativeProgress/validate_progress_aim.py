#!/usr/bin/env python3
"""Validate the isolated V13 partial-control API against the V12 source archive.

Foundation/runtime declarations are type stubs only. They do not execute game
code. The argument matrix executes extracted production validation expressions.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[2] / "PoolLab")
parser.add_argument("--baseline", type=Path, default=Path(__file__).resolve().parents[1] / "v12_before_v13/SDKPool_Fontes.zip")
parser.add_argument("--clang", type=Path, default=Path(__file__).resolve().parents[1] / "v11_runtime/swift-5.10.1-RELEASE-ubuntu24.04/usr/bin/clang")
args = parser.parse_args()
out = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
source_path = args.project / "Integrated/PLRuntimeBridge.m"
header_path = args.project / "Integrated/PLRuntimeBridge.h"
source = source_path.read_text()
header = header_path.read_text()
start = source.index('+ (BOOL)applyProgressAngle:')
end = source.index('+ (BOOL)pl_shootAngle:', start)
method = source[start:end].rstrip()
with zipfile.ZipFile(args.baseline) as archive:
    baseline_source = archive.read(next(n for n in archive.namelist() if n.endswith('/Integrated/PLRuntimeBridge.m'))).decode()
    baseline_header = archive.read(next(n for n in archive.namelist() if n.endswith('/Integrated/PLRuntimeBridge.h'))).decode()
declaration = '''/// Applies an intermediate gradual-aim or cue-pull sample. Accepts power in
/// [0,1], including below the shot minimum, because this method never releases
/// a shot. Nomination, target, native input ownership and readback are checked
/// exactly as for planned aim. Final dispatch must use the validated shoot API.
+ (BOOL)applyProgressAngle:(double)angle power:(double)power target:(NSInteger)target
                  pocket:(NSInteger)pocket error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(applyAimProgress(angle:power:target:pocket:));
'''
shoot = source[end:source.index('+ (BOOL)shootAngle:', end)]
planned = source[source.index('+ (BOOL)applyPlannedAngle:'):start]
checks = {
    'existingNativeSourceExactlyPreservedIncludingV12Readiness': source[:start] + source[end:] == baseline_source,
    'existingHeaderExactlyPreserved': header.replace(declaration, '', 1) == baseline_header,
    'allSixPocketMappingPreserved': '{5, 4, 3, 0, 1, 2}' in method,
    'finiteAndInclusivePartialPowerRange': '!isfinite(angle) || !isfinite(power) || power < 0 || power > 1' in method,
    'validTargetAndPocketArguments': 'target < 1 || target > 15 || pocket < 0 || pocket > 5' in method,
    'noMinimumPowerRequirementInPartialControlOnly': 'minimumShotPower' not in method and 'hasMinimumPowerRatio' not in method,
    'finalShotRetainsBothMinimumChecks': 'snapshot.minimumShotPower > 0 && power < snapshot.minimumShotPower' in shoot and 'hasMinimumPowerRatio' in shoot,
    'finalPlannedAimRetainsBothMinimumChecks': 'snapshot.minimumShotPower > 0 && power < snapshot.minimumShotPower' in planned and 'hasMinimumPowerRatio' in planned,
    'initialAndPostNominationCapture': method.count('snapshot = PLCapture(error)') == 2,
    'legalTargetBeforeAndAfterNomination': method.count('snapshot.legalTargetNumbers containsObject:@(target)') == 2,
    'nominationBeforeExistingApply': method.index('pocketNominationCallback:') < method.index('[self applyAngle:'),
    'nominationConfirmedBeforeApply': method.index('afterNomination.nominatedPocket != (int32_t)gamePocket') < method.index('[self applyAngle:'),
    'managerAndTableIdentityBeforeAndAfterApply': method.count('freshManager != manager') == 2 and 'freshTable != table' in method and 'error) != table' in method,
    'ruleIdentityBeforeAndAfterApply': all(method.count(s) == 2 for s in ['freshRules.rules != rules.rules', 'freshRules.classification != rules.classification', 'freshRules.isBreakShot != rules.isBreakShot']),
    'finalCueReadbackAndReadiness': all(s in method for s in ['PLReadCue(manager, &cue', 'PLReadyToPlan(manager, cue, [balls copy], NO, error)', 'fabs(remainder(verifiedAngle-angle, 2.0*M_PI)) > 1e-7', 'fabs(verifiedPower-power) > 1e-8']),
    'centeredEnglishRevalidated': 'PLCenteredEnglish(finalEnglish)' in method,
    'noReleaseOrShotDispatchCalls': not re.search(r'PLShotReleaseFunction|pl_shootAngle:|shootAngle:|simulateShot|resetInput|setEnabled|setInputActive|didDispatch', method),
    'onlyNominationDirectMessage': method.count('objc_msgSend') == 1,
    'noNewOffsetsOrDirectMemoryWrite': not re.search(r'memcpy|memset|object_setIvar|method_setImplementation|PLVerifiedFunction|0x[0-9a-fA-F]+', method),
    'noTouchInjectionOrEventSynthesis': not re.search(r'UITouch|IOHID|sendEvent|touchesBegan|touchesMoved|touchesEnded|UIApplication', method),
    'SwiftAPIExplicit': 'NS_SWIFT_NAME(applyAimProgress(angle:power:target:pocket:))' in header,
}
fixture = (out / 'FoundationDeclarationFixture.inc').read_text() + method + '\n@end\n'
fixture_path = out / 'ProgressAimCompile.m'
fixture_path.write_text(fixture)
command = [str(args.clang), '-target', 'arm64-apple-ios15.0', '-fobjc-arc', '-fsyntax-only', '-Werror', '-Werror=incompatible-pointer-types', str(fixture_path)]
compiled = subprocess.run(command, text=True, capture_output=True)
(out / 'ProgressAimCompile.txt').write_text(compiled.stdout + compiled.stderr)
checks['actualMethodARCClangSyntax'] = compiled.returncode == 0

def extract_argument_condition(body):
    match = re.search(r'if \((!isfinite\(angle\).*?)\)\s*\n\s*return PLFail\(error, 64,', body, re.S)
    assert match
    return match.group(1)

partial_guard = extract_argument_condition(method)
final_guard = extract_argument_condition(shoot)
matrix = '''#include <cmath>
#include <limits>
#include <cstdio>
using std::isfinite;
bool acceptsPartial(double angle, double power, int target, int pocket) { return !(PARTIAL); }
bool acceptsShotArguments(double angle, double power, int target, int pocket) { return !(FINAL); }
int main() {
 const double nan = std::numeric_limits<double>::quiet_NaN();
 const double inf = std::numeric_limits<double>::infinity();
 struct Sample { double angle, power; int target, pocket; bool partial, shot; } samples[] = {
  {0,0,1,0,true,false}, {0,0.001,1,0,true,true}, {0,0.2,8,3,true,true},
  {0,1,15,5,true,true}, {-3.141592653589793,0,1,0,true,false},
  {6.283185307179586,1,1,0,true,true}, {0,-0.01,1,0,false,false},
  {0,1.01,1,0,false,false}, {0,nan,1,0,false,false}, {0,inf,1,0,false,false},
  {nan,0.3,1,0,false,false}, {inf,0.3,1,0,false,false},
  {0,0.3,0,0,false,false}, {0,0.3,16,0,false,false},
  {0,0.3,1,-1,false,false}, {0,0.3,1,6,false,false}
 };
 int i = 0;
 for (const auto &s : samples) {
  ++i;
  if (acceptsPartial(s.angle,s.power,s.target,s.pocket) != s.partial ||
      acceptsShotArguments(s.angle,s.power,s.target,s.pocket) != s.shot) {
   std::printf("case %d failed\\n",i); return 1;
  }
 }
 std::printf("%d extracted argument cases passed\\n",i); return 0;
}
'''.replace('PARTIAL', partial_guard).replace('FINAL', final_guard)
matrix_path = out / 'ProgressArgumentRegression.cpp'
matrix_path.write_text(matrix)
matrix_binary = out / 'ProgressArgumentRegression'
matrix_build = subprocess.run(['c++', '-std=c++17', '-Wall', '-Wextra', '-Werror', str(matrix_path), '-o', str(matrix_binary)], text=True, capture_output=True)
matrix_run = subprocess.run([str(matrix_binary)], text=True, capture_output=True) if matrix_build.returncode == 0 else matrix_build
(out / 'ProgressArgumentRegression.txt').write_text(matrix_build.stdout + matrix_build.stderr + matrix_run.stdout + matrix_run.stderr)
checks['extractedArgumentMatrix16Cases'] = matrix_build.returncode == 0 and matrix_run.returncode == 0

evidence_path = args.project / 'Validation/V5AutoplayNativePaths.json'
evidence = json.loads(evidence_path.read_text())
# Retained evidence is historical binary analysis, not a new iPhone observation.
regions = evidence['regions'] if 'regions' in evidence else evidence.get('code_regions', [])
cue_region = next((r for r in regions if r.get('name') == 'cue_angle_power_setters'), None)
if cue_region is None:
    for value in evidence.values():
        if isinstance(value, list):
            cue_region = next((r for r in value if isinstance(r, dict) and r.get('name') == 'cue_angle_power_setters'), None)
            if cue_region is not None:
                break
assert cue_region is not None
checks['retainedSettersBothCallUpdateCue'] = sum('objc_msgSend$updateCue' in line for line in cue_region['disassembly']) == 2
report = {
    'schemaVersion': 1,
    'result': 'passed' if all(checks.values()) else 'failed',
    'checkCount': len(checks),
    'checks': checks,
    'sourceHashes': {'Integrated/PLRuntimeBridge.m': sha(source_path.read_bytes()), 'Integrated/PLRuntimeBridge.h': sha(header_path.read_bytes())},
    'baselineArchiveSHA256': sha(args.baseline.read_bytes()),
    'newMethodSHA256': sha(method.encode()),
    'compile': {'command': command, 'exitCode': compiled.returncode, 'fixtureSHA256': sha(fixture.encode()), 'usesExactProductionMethod': True, 'sdk': 'explicit Foundation/runtime declarations only; no Apple SDK', 'runtimeExecuted': False},
    'argumentMatrix': {'cases': 16, 'buildExitCode': matrix_build.returncode, 'executionExitCode': matrix_run.returncode, 'sourceSHA256': sha(matrix.encode()), 'productionExpressionsExtracted': True},
    'visualEvidence': {'file': 'Validation/V5AutoplayNativePaths.json', 'SHA256': sha(evidence_path.read_bytes()), 'region': cue_region['name'], 'regionSHA256': cue_region['sha256'], 'finding': 'Both native setters call updateCue; native setPower computes cue pull distance from requested power. This supports gradual cue rotation/retraction through repeated validated setters.', 'powerSliderAnimationVerified': False, 'fingerEventsSynthesized': False, 'newDeviceObservation': False},
    'limits': ['Objective-C syntax/type compilation and extracted argument checks only. No Apple SDK link or iPhone/native callback execution.', 'Original V12 native methods and declarations are byte-identical after removing isolated new API.', 'Partial power includes zero and values below the shot minimum because this method cannot release. Final shoot minimum-power checks remain unchanged.', 'The visible native cue is updated by retained setter evidence; the separate power-bar slider has not been traced or device-verified.']
}
(out / 'V13NativeProgressValidation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'result': report['result'], 'checkCount': len(checks), 'failed': [k for k,v in checks.items() if not v], 'argumentCases': 16}, ensure_ascii=False))
if not all(checks.values()):
    raise SystemExit(1)
