typedef signed char BOOL;
typedef long NSInteger;
typedef int int32_t;
typedef unsigned int uint32_t;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define nil ((id)0)
#define isfinite(x) __builtin_isfinite(x)
#define fabs(x) __builtin_fabs(x)
#define M_PI 3.14159265358979323846264338327950288
extern double remainder(double,double);
__attribute__((objc_root_class)) @interface NSObject
+ (Class)class;
- (BOOL)isKindOfClass:(Class)klass;
- (id)copy;
@end
@interface NSString:NSObject @end
@interface NSNumber:NSObject
+ (NSNumber*)numberWithLong:(long)x;
+ (NSNumber*)numberWithInteger:(NSInteger)x;
+ (NSNumber*)numberWithUnsignedInt:(unsigned int)x;
@end
@interface NSArray:NSObject
- (BOOL)containsObject:(id)x;
@end
@interface NSError:NSObject @end
@interface NSException:NSObject @end
@interface PLGameSnapshot:NSObject
@property(nonatomic) BOOL canShoot;
@property(nonatomic) BOOL autoShotAvailable;
@property(nonatomic) double minimumShotPower;
@property(nonatomic,copy) NSString* shootReadinessReason;
@property(nonatomic,copy) NSString* autoShotUnavailableReason;
@property(nonatomic,copy) NSArray* legalTargetNumbers;
@end
@interface PLRuntimeBridge:NSObject
+ (BOOL)applyAngle:(double)angle power:(double)power error:(NSError**)error;
@end
@interface PLRuntimeBridge (ProgressAim)
+ (BOOL)applyProgressAngle:(double)angle power:(double)power target:(NSInteger)target
                 pocket:(NSInteger)pocket error:(NSError**)error
 __attribute__((swift_name("applyProgressAim(angle:power:target:pocket:)")));
@end
typedef struct {
 void *rules;
 BOOL nominationRequired;
 BOOL isBreakShot;
 int32_t nominatedPocket;
 int32_t classification;
} PLRulesInfo;
extern BOOL PLFail(NSError**,NSInteger,NSString*);
extern PLGameSnapshot* PLCapture(NSError**);
extern BOOL PLEnvironment(id*,id*,NSError**);
extern id PLReadObject(id,NSString*,const char*,const char*,NSError**);
extern BOOL PLRules(id,id,PLRulesInfo*,NSError**);
extern BOOL PLCheckMethod(id,NSString*,const char*,NSError**);
extern SEL NSSelectorFromString(NSString*);
extern id objc_msgSend(id,SEL,...);
extern BOOL PLReadCue(id,id*,double*,double*,NSError**);
extern BOOL PLReadyToPlan(id,id,NSArray*,BOOL,NSError**);
extern BOOL PLBool(id,NSString*);
extern BOOL PLReadSelectedEnglish(id,double*,NSError**);
extern BOOL PLCenteredEnglish(const double*);
@implementation PLRuntimeBridge (ProgressAim)
+ (BOOL)applyProgressAngle:(double)angle power:(double)power target:(NSInteger)target
                 pocket:(NSInteger)pocket error:(NSError **)error {
    if (error) *error = nil;
    if (!isfinite(angle) || !isfinite(power) || power < 0 || power > 1 ||
        target < 1 || target > 15 || pocket < 0 || pocket > 5)
        return PLFail(error, 64, @"A mira precisa de uma bola, caçapa e força válidas.");
#if !defined(__arm64__)
    return PLFail(error, 1, @"O ajuste exige o executável arm64 do iPhone.");
#else
    @try {
        PLGameSnapshot *snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.canShoot || !snapshot.autoShotAvailable)
            return PLFail(error, 65, snapshot.autoShotAvailable ? snapshot.shootReadinessReason : snapshot.autoShotUnavailableReason);
        if (![snapshot.legalTargetNumbers containsObject:@(target)])
            return PLFail(error, 66, @"Essa bola não pertence ao seu alvo permitido nesta vez.");
        id manager = nil, director = nil;
        if (!PLEnvironment(&manager, &director, error)) return NO;
        id table = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
        PLRulesInfo rules = {0};
        if (!table || !PLRules(manager, table, &rules, error)) return NO;
        static const uint32_t gamePocketForPlanner[6] = {5, 4, 3, 0, 1, 2};
        uint32_t gamePocket = gamePocketForPlanner[pocket];
        if (rules.nominationRequired && rules.nominatedPocket != (int32_t)gamePocket) {
            if (!PLCheckMethod(manager, @"pocketNominationCallback:", "v24@0:8@16", error)) return NO;
            // The normal callback may reset the cue, so nominate before setting
            // either value. No input flag or rule field is written directly.
            ((void (*)(id, SEL, id))objc_msgSend)(manager,
                NSSelectorFromString(@"pocketNominationCallback:"), @(gamePocket));
            PLRulesInfo afterNomination = {0};
            if (!PLRules(manager, table, &afterNomination, error) ||
                afterNomination.rules != rules.rules || afterNomination.nominatedPocket != (int32_t)gamePocket)
                return PLFail(error, 67, @"O jogo não confirmou a caçapa escolhida.");
        }
        snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.canShoot || !snapshot.autoShotAvailable || ![snapshot.legalTargetNumbers containsObject:@(target)])
            return PLFail(error, 68, @"A mesa mudou antes do ajuste da mira.");
        id freshManager = nil, freshDirector = nil;
        if (!PLEnvironment(&freshManager, &freshDirector, error) || freshManager != manager)
            return PLFail(error, 69, @"A partida mudou antes do ajuste da mira.");
        id freshTable = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
        if (freshTable != table) return PLFail(error, 69, @"A mesa mudou antes do ajuste da mira.");
        PLRulesInfo freshRules = {0};
        if (!PLRules(manager, table, &freshRules, error) || freshRules.rules != rules.rules ||
            freshRules.classification != rules.classification || freshRules.isBreakShot != rules.isBreakShot ||
            (freshRules.nominationRequired && freshRules.nominatedPocket != (int32_t)gamePocket))
            return PLFail(error, 70, @"As regras ou a caçapa mudaram antes do ajuste da mira.");
        if (![self applyAngle:angle power:power error:error]) return NO;
        if (!PLEnvironment(&freshManager, &freshDirector, error) || freshManager != manager ||
            PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error) != table)
            return PLFail(error, 69, @"A partida mudou durante o ajuste da mira.");
        id cue = nil; double verifiedAngle = 0, verifiedPower = 0;
        if (!PLReadCue(manager, &cue, &verifiedAngle, &verifiedPower, error)) return NO;
        id balls = PLReadObject(table, @"Table", "mBalls", "@\"NSArray\"", error);
        if (![balls isKindOfClass:NSArray.class] || !PLReadyToPlan(manager, cue, [balls copy], NO, error)) return NO;
        if (!PLRules(manager, table, &freshRules, error) || freshRules.rules != rules.rules ||
            freshRules.classification != rules.classification || freshRules.isBreakShot != rules.isBreakShot ||
            (freshRules.nominationRequired && freshRules.nominatedPocket != (int32_t)gamePocket))
            return PLFail(error, 70, @"As regras ou a caçapa mudaram durante o ajuste da mira.");
        if (fabs(remainder(verifiedAngle-angle, 2.0*M_PI)) > 1e-7 || fabs(verifiedPower-power) > 1e-8)
            return PLFail(error, 71, @"O jogo não confirmou a direção e a força da mira.");
        double finalEnglish[2] = {0};
        if (!PLReadSelectedEnglish(manager, finalEnglish, error)) return NO;
        if (!PLCenteredEnglish(finalEnglish))
            return PLFail(error, 74, @"O efeito do taco mudou. Centralize o efeito para continuar.");
        // This is an intermediate control sample, so zero/below-minimum power
        // is deliberate while aiming or drawing the cue back. No release is
        // possible here. The unchanged shoot path enforces minimum shot power
        // after fresh state/readback validation before invoking its callback.
        return YES;
    } @catch (NSException *exception) {
        return PLFail(error, 91, @"O jogo recusou o ajuste da mira planejada.");
    }
#endif
}
@end
