"""Read-only V14.1 narrow CI repair review, run after production is frozen."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path('new_project/PoolLab')
BASE = Path('new_project/validation/v14_before_v14_1/SDKPool_Fontes.zip')
EXPECTED = 'dad5e783b1e11c6ed10aec51c804023d4dac348dce2895a3575e87448059eda5'
OUT = Path('new_project/validation/v14_1_review')
DEST = ROOT / 'Validation/V14_1IndependentReview'

def sha(data):
    return hashlib.sha256(data).hexdigest()

checks = []
def check(passed, identifier):
    checks.append({'id': identifier, 'passed': bool(passed)})

def declaration(text, signature):
    start = text.index(signature)
    line_start = text.rfind('\n', 0, start) + 1
    indent = text[line_start:start]
    assert not indent.strip(), signature
    opening = text.index('{', start)
    first_end = text.find('\n', opening)
    if '}' in text[opening:first_end]:
        return text[start:first_end].rstrip()
    closing = re.search(r'^' + re.escape(indent) + r'\}', text[opening:], re.M)
    assert closing, signature
    return text[start:opening + closing.end()]

check(sha(BASE.read_bytes()) == EXPECTED, 'immutable_delivered_v14_archive')
with zipfile.ZipFile(BASE) as z:
    old = {n.removeprefix('PoolLab/'): z.read(n) for n in z.namelist()
           if n.startswith('PoolLab/') and not n.endswith('/')}

def current(path):
    return (ROOT / path).read_bytes()

roots = {'.github', 'Integrated', 'Sources', 'Resources', 'iOS', 'Tests', 'scripts', 'PoolLab.xcodeproj'}
def is_source(path):
    return path.split('/')[0] in roots or path == 'Package.swift'

old_paths = sorted(p for p in old if is_source(p))
paths = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
               if p.is_file() and is_source(p.relative_to(ROOT).as_posix()))
changed = [p for p in old_paths if current(p) != old[p]]
added = sorted(set(paths) - set(old_paths))
allowed = {'Sources/PoolLabCore/ShotPlanner.swift', 'Tests/PoolLabCoreTests/V14PlannerTests.swift',
           'Integrated/IntegratedGameModel.swift', 'Integrated/PoolLabIntegration.swift',
           'PoolLab.xcodeproj/project.pbxproj', 'scripts/build_integration_framework.sh',
           'scripts/upgrade_poollab_ipa.py'}
check(set(old_paths) <= set(paths), 'no_baseline_source_deleted')
check(not added, 'no_unreviewed_source_added')
check(set(changed) <= allowed, 'only_reviewed_ci_clock_and_version_files_changed')
for p in old_paths:
    if p not in allowed:
        check(current(p) == old[p], 'unchanged_source:' + p)
for p in old:
    if p.startswith('Validation/'):
        check(current(p) == old[p], 'historical_evidence_preserved:' + p)

model_path = 'Integrated/IntegratedGameModel.swift'
model = current(model_path).decode()
model_normalized = model.replace('"frameworkBuild": 15', '"frameworkBuild": 14').replace('SDKPool-V14-1-', 'SDKPool-V14-')
check(model_normalized.encode() == old[model_path], 'entire_model_only_export_version_changed')
ui_path = 'Integrated/PoolLabIntegration.swift'
ui = current(ui_path).decode()
check(ui.replace('SDKPool 1.12.1 · compilação 15', 'SDKPool 1.12 · compilação 14').encode() == old[ui_path],
      'entire_ui_only_display_version_changed')

planner_path = 'Sources/PoolLabCore/ShotPlanner.swift'
planner, old_planner = current(planner_path).decode(), old[planner_path].decode()
clock_signature = '    private final class SearchClock'
check(planner[:planner.index(clock_signature)] == old_planner[:old_planner.index(clock_signature)],
      'all_legacy_planner_math_acceptance_and_quantization_byte_identical')
old_body_start = old_planner.index('        try Task.checkCancellation()', old_planner.index('public static func search('))
internal_start = planner.index('    static func search(', planner.index('public static func search('))
body_start = planner.index('        try Task.checkCancellation()', internal_start)
check(planner[body_start:] == old_planner[old_body_start:],
      'entire_automatic_search_algorithm_phases_checks_deadlines_unchanged')
public = declaration(planner, 'public static func search(')
check('now: { ProcessInfo.processInfo.systemUptime }' in public and 'if ' not in public,
      'public_search_unconditionally_uses_real_monotonic_clock')
check('static func search(' in planner[internal_start:] and
      'public static func search(' not in planner[internal_start:],
      'clock_override_not_exposed_in_public_api')
check('budget: ShotSearchBudget = .automatic' in public and
      old_planner[old_planner.index('public static func search('):old_body_start].split('    ) throws')[0] ==
      public.split('    ) throws')[0], 'public_search_signature_and_default_budget_unchanged')
clock, old_clock = declaration(planner, 'private final class SearchClock'), declaration(old_planner, 'private final class SearchClock')
check(clock[clock.index('        var termination:'):] == old_clock[old_clock.index('        var termination:'):],
      'shared_clock_termination_cancellation_dedup_and_simulation_limit_unchanged')

tests_path = 'Tests/PoolLabCoreTests/V14PlannerTests.swift'
tests, old_tests = current(tests_path).decode(), old[tests_path].decode()
old_test_names, test_names = set(re.findall(r'func (test\w+)', old_tests)), set(re.findall(r'func (test\w+)', tests))
check(old_test_names <= test_names, 'all_16_original_v14_test_cases_retained')
check(tests[tests.index('    private func syntheticRailCarom'):] == old_tests[old_tests.index('    private func syntheticRailCarom'):],
      'all_geometry_fixtures_and_native_coefficients_byte_identical')

pbx = current('PoolLab.xcodeproj/project.pbxproj').decode()
check(pbx.replace('CURRENT_PROJECT_VERSION = 15;', 'CURRENT_PROJECT_VERSION = 14;').replace('MARKETING_VERSION = 1.12.1;', 'MARKETING_VERSION = 1.12;').encode() == old['PoolLab.xcodeproj/project.pbxproj'],
      'xcode_project_only_framework_version_build_changed')
build_path = 'scripts/build_integration_framework.sh'
build = current(build_path).decode()
normalized_build = build.replace('swift test --configuration release --scratch-path', 'swift test --scratch-path')
normalized_build = normalized_build.replace("!= '15'", "!= '14'").replace("!= '1.12.1'", "!= '1.12'").replace('V14.1 (1.12.1, build 15)', 'V14 (1.12, build 14)')
check(normalized_build.encode() == old[build_path], 'build_script_only_release_test_configuration_and_version_guards_changed')
check('set -euo pipefail' in build and 'swift test --configuration release --scratch-path' in build and
      not any(s in build for s in ['--skip', '--filter', 'continue-on-error']), 'full_apple_suite_remains_mandatory_and_fail_closed')

previous = json.loads(old['Validation/V14IndependentReview.json'])
protected = []
for item in previous['protectedDeclarations']:
    p, signature = item['file'], item['declaration']
    before = declaration(old[p].decode(), signature)
    after = declaration(current(p).decode(), signature)
    identical = after.replace('SDKPool 1.12.1 · compilação 15', 'SDKPool 1.12 · compilação 14') == before
    check(identical, 'protected:' + p + ':' + signature)
    protected.append({'file': p, 'declaration': signature, 'preservedToV14': identical, 'sha256': sha(after.encode())})

findings = json.loads((OUT / 'FinalFindings.json').read_text())
check(findings['sourceReviewComplete'], 'independent_final_diff_review_complete')
for item in findings['checks']:
    check(item['passed'], item['id'])
hashes = {p: sha(current(p)) for p in paths}
for p, value in findings['reviewedSourceSHA256'].items():
    check(hashes[p] == value, 'reviewed_final_source_hash:' + p)

report = {
    'format': 'SDKPool.V14_1.IndependentIntegrationReview',
    'result': 'passed' if all(c['passed'] for c in checks) else 'failed',
    'scope': 'Independent uploaded CI log and narrow source/test repair review. No fresh Apple SDK build or iPhone execution.',
    'baselineArchiveSHA256': sha(BASE.read_bytes()),
    'sourceSHA256': hashes,
    'changedProductionFiles': changed,
    'addedProductionFiles': added,
    'protectedDeclarations': protected,
    'checks': checks,
    'checkCount': len(checks),
    'reviewFindings': findings['reviewFindings'],
    'limitations': findings['limitations'],
}
OUT.mkdir(exist_ok=True, parents=True)
DEST.mkdir(exist_ok=True, parents=True)
data = (json.dumps(report, indent=2, ensure_ascii=False) + '\n').encode()
(OUT / 'V14_1IndependentReview.json').write_bytes(data)
(ROOT / 'Validation/V14_1IndependentReview.json').write_bytes(data)
(DEST / 'independent_review.py').write_bytes(Path(__file__).read_bytes())
(DEST / 'FinalFindings.json').write_bytes((OUT / 'FinalFindings.json').read_bytes())
print(json.dumps({'result': report['result'], 'checks': len(checks),
                  'failed': [c['id'] for c in checks if not c['passed']],
                  'changed': changed, 'added': added}, indent=2))
raise SystemExit(0 if report['result'] == 'passed' else 1)
