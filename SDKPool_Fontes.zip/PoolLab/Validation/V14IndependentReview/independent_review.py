"""Independent V14 read-only preservation and integration review.

Run from workspace root, after production sources are frozen. Does not assert
Apple SDK compilation, exact replay of the uploaded video, or iPhone behavior.
"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path('new_project/PoolLab')
BASELINE = Path('new_project/validation/v13_before_v14/SDKPool_Fontes.zip')
OUTPUT = Path('new_project/validation/v14_review/V14IndependentReview.json')
BASELINE_SHA = '0e5edc45a4a88ef6e3a5c36b456269b2527472ba3053e78bbc52e9bdc5bcebc8'

def digest(data):
    return hashlib.sha256(data).hexdigest()

checks = []
def check(condition, name):
    checks.append({'id': name, 'passed': bool(condition)})

def declaration(text, signature):
    start = text.index(signature)
    line_start = text.rfind('\n', 0, start) + 1
    indent = text[line_start:start]
    assert not indent.strip(), signature
    opening = text.index('{', start)
    first_end = text.find('\n', opening)
    if '}' in text[opening:first_end]:
        return text[start:first_end].rstrip()
    closing = re.search(r'^' + re.escape(indent) + r'\}', text[opening:], re.M)
    assert closing, signature
    return text[start:opening + closing.end()]

check(digest(BASELINE.read_bytes()) == BASELINE_SHA, 'immutable_v13_delivered_archive')
with zipfile.ZipFile(BASELINE) as archive:
    baseline = {name.removeprefix('PoolLab/'): archive.read(name)
                for name in archive.namelist()
                if name.startswith('PoolLab/') and not name.endswith('/')}

previous = json.loads(baseline['Validation/V13IndependentReview.json'])
protected = []
for item in previous['protectedDeclarations']:
    relative, signature = item['file'], item['declaration']
    before = declaration(baseline[relative].decode(), signature)
    after = declaration((ROOT / relative).read_text(), signature)
    normalized = after.replace('SDKPool 1.12 · compilação 14', 'SDKPool 1.11 · compilação 13')
    identical = normalized == before
    check(identical, 'protected:' + relative + ':' + signature)
    protected.append({'file': relative, 'declaration': signature,
                      'preservedToV13': identical, 'sha256': digest(after.encode())})

for path in ['Integrated/PLRuntimeBridge.m', 'Integrated/PLRuntimeBridge.h']:
    check((ROOT / path).read_bytes() == baseline[path], 'entire_native_source_preserved:' + path)
native = (ROOT / 'Integrated/PLRuntimeBridge.m').read_text()
check(declaration(native, 'static BOOL PLReadyToPlan(') ==
      declaration(baseline['Integrated/PLRuntimeBridge.m'].decode(), 'static BOOL PLReadyToPlan('),
      'v12_off_table_residual_spin_and_native_readiness_fix_preserved')

protected_sources = sorted(path for path in baseline
                           if path.startswith('Sources/') and path.endswith('.swift')
                           and path not in {'Sources/PoolLabCore/ShotPlanner.swift',
                                            'Sources/PoolLabCore/BilliardsTypes.swift'})
for path in protected_sources:
    check((ROOT / path).read_bytes() == baseline[path], 'unchanged_core_auth:' + path)

types_path = 'Sources/PoolLabCore/BilliardsTypes.swift'
types = (ROOT / types_path).read_text()
old_types = baseline[types_path].decode()
check(types[:types.index('public enum ShotMethod:')] == old_types[:old_types.index('public enum ShotMethod:')],
      'all_physics_state_and_result_types_unchanged')
check(declaration(types, 'public struct ShotSuggestion:') == declaration(old_types, 'public struct ShotSuggestion:'),
      'shot_suggestion_contract_unchanged')
ui_path = 'Integrated/PoolLabIntegration.swift'
check((ROOT / ui_path).read_text().replace('SDKPool 1.12 · compilação 14',
      'SDKPool 1.11 · compilação 13').encode() == baseline[ui_path],
      'entire_integrated_ui_unchanged_except_visible_version')

model = (ROOT / 'Integrated/IntegratedGameModel.swift').read_text()
old_model = baseline['Integrated/IntegratedGameModel.swift'].decode()
for signature in ['private struct AutomaticControlSequence',
                  'private static func controlAngleDelta(',
                  'private static func smoothControlFraction(',
                  'private static func minimumPlannerPower(',
                  'private func acceptsPlan(',
                  'private static func hasNativeControlTouch(',
                  'func toggleAutomationPause(']:
    check(declaration(model, signature) == declaration(old_model, signature),
          'preserved_control_math_or_guard:' + signature)

for signature in ['private func advanceAutomaticControlSequence(', 'private func execute(']:
    current = declaration(model, signature)
    normalized = current.replace('waitForInput:', 'pause:')
    normalized = normalized.replace('deferAutomaticActions(', 'pauseAutomaticActions(')
    normalized = normalized.replace('AIM aguardando os controles:', 'AIM pausado:')
    normalized = normalized.replace('Automático aguardando confirmação dos controles:', 'Tacada automática pausada:')
    check(normalized == declaration(old_model, signature),
          'entire_progressive_or_release_body_preserved_except_wait_policy:' + signature)

ack = declaration(model, 'private func acknowledgeShotProgress(')
check(ack.replace('automaticSearchContext', 'automaticBlockedContext') ==
      declaration(old_model, 'private func acknowledgeShotProgress('),
      'motion_or_turn_acknowledgment_and_duplicate_latch_unchanged')

production_roots = {'.github', 'Integrated', 'Sources', 'Resources', 'iOS', 'Tests', 'scripts', 'PoolLab.xcodeproj'}
production_paths = sorted(path for path in baseline if path.split('/')[0] in production_roots or path == 'Package.swift')
actual_paths = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()
                      and (p.relative_to(ROOT).parts[0] in production_roots or p.relative_to(ROOT).as_posix() == 'Package.swift'))
added = sorted(set(actual_paths) - set(production_paths))
changed = [path for path in production_paths if (ROOT / path).read_bytes() != baseline[path]]
check(set(production_paths) <= set(actual_paths), 'all_baseline_production_files_retained')
allowed = {'Integrated/IntegratedGameModel.swift', 'Integrated/PoolLabIntegration.swift',
           'Sources/PoolLabCore/BilliardsTypes.swift', 'Sources/PoolLabCore/ShotPlanner.swift',
           'PoolLab.xcodeproj/project.pbxproj', 'scripts/build_integration_framework.sh',
           'scripts/upgrade_poollab_ipa.py'}
check(set(changed) <= allowed, 'production_changes_restricted_to_reviewed_files')
check(all(path.startswith('Tests/PoolLabCoreTests/V14') and path.endswith('.swift') for path in added),
      'added_production_files_only_v14_planner_tests')
for path in production_paths:
    if path.startswith('Tests/'):
        check((ROOT / path).read_bytes() == baseline[path], 'existing_test_preserved:' + path)
for path in baseline:
    if path.startswith('Validation/'):
        check((ROOT / path).read_bytes() == baseline[path], 'historical_evidence_preserved:' + path)

findings_path = Path('new_project/validation/v14_review/FinalFindings.json')
findings = json.loads(findings_path.read_text())
check(findings['sourceReviewComplete'] is True, 'independent_changed_source_review_complete')
for item in findings['checks']:
    check(item['passed'], item['id'])
source_hashes = {path: digest((ROOT / path).read_bytes()) for path in actual_paths}
for path, expected in findings['reviewedSourceSHA256'].items():
    check(source_hashes[path] == expected, 'reviewed_source_unchanged:' + path)
for path, expected in findings.get('reviewedDeliveryFilesSHA256', {}).items():
    check(digest(Path(path).read_bytes()) == expected, 'reviewed_delivery_file_unchanged:' + path)

report = {
    'format': 'SDKPool.V14.IndependentIntegrationReview',
    'result': 'passed' if all(item['passed'] for item in checks) else 'failed',
    'scope': 'Independent read-only video, source preservation and changed-code review; no iPhone execution claim.',
    'baselineArchiveSHA256': digest(BASELINE.read_bytes()),
    'sourceSHA256': source_hashes,
    'reviewedDeliveryFilesSHA256': findings.get('reviewedDeliveryFilesSHA256', {}),
    'changedProductionFiles': changed,
    'addedProductionFiles': added,
    'protectedDeclarations': protected,
    'checks': checks,
    'checkCount': len(checks),
    'reviewFindings': findings['reviewFindings'],
    'limitations': findings['limitations'],
}
OUTPUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'result': report['result'], 'checks': len(checks),
                  'failed': [item['id'] for item in checks if not item['passed']],
                  'changed': changed, 'added': added, 'output': str(OUTPUT)}, indent=2))
raise SystemExit(0 if report['result'] == 'passed' else 1)
