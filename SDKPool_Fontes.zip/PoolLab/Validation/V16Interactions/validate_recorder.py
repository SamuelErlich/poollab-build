#!/usr/bin/env python3
"""Bounded source review and ARC syntax check. Does not emulate UIKit."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
HEADER = PROJECT / "Integrated/PLInteractionRecorder.h"
SOURCE = PROJECT / "Integrated/PLInteractionRecorder.m"
text = SOURCE.read_text()
header = HEADER.read_text()
syntax = HERE / "RecorderSyntax.m"
syntax.write_text((HERE / "RecorderDeclarations.h").read_text() + "\n" + "\n".join(
    line for content in (header, text) for line in content.splitlines() if not line.startswith("#import ")
))
clang = Path(sys.argv[1]).resolve()
command = [str(clang), "-fsyntax-only", "-fobjc-arc", "-fblocks", "-fobjc-runtime=gnustep-2.0",
           "-Wno-nullability-completeness", "-Wno-incompatible-pointer-types", str(syntax)]
run = subprocess.run(command, capture_output=True, text=True)
(HERE / "RecorderSyntax.log").write_text(run.stdout + run.stderr)

def body(name):
    start = text.index(name)
    brace = text.index("{", start)
    depth = 1
    end = brace + 1
    while depth:
        if text[end] == "{": depth += 1
        elif text[end] == "}": depth -= 1
        end += 1
    return text[brace:end]

hook = body("static void PLIRSendEvent(")
status = body("+ (NSDictionary<NSString *, id> *)status")
checks = {
    "ARCDeclarationSyntaxPass": run.returncode == 0,
    "OriginalDispatchExactlyOnceInHook": hook.count("PLIRPreviousSendEvent)(application, selector, event)") == 1,
    "NoSynthesizedInputOrReplayAPIs": not any(term in text for term in ("sendAction:", "UIEvent new", "UITouch new", "IOHID", "GSEvent", "setLocationInWindow:")),
    "NoTextClipboardURLOrImageAccess": not any(term in text for term in ("UIPasteboard", "UIImage", "drawViewHierarchy", "renderInContext", "NSURLSession", "WKNavigation", ".text;", "textInRange:", "accessibilityLabel", "accessibilityValue")),
    "BoundedDurationAndEvents": "PLIRMaximumDuration = 180.0" in text and "PLIRMaximumEvents = 300" in text,
    "TouchRegistryWeakKeys": "[NSMapTable weakToStrongObjectsMapTable]" in text,
    "PendingWorkGenerationGuarded": text.count("generation != PLIRGeneration") >= 2 and "PLIRGeneration++;" in body("static void PLIRStop("),
    "CheapStatusHasNoNativeReadOrSerialization": "PLIRSnapshot" not in status and "JSONSerialization" not in status,
    "ModalLevelsNotRejected": "window.windowLevel !=" not in body("static NSString *PLIRExcludedTouch("),
    "OwnInputAndKeyboardExcluded": all(x in text for x in ("PLPassthroughWindow", "PLInteractionRingWindow", "PLIRKeyboardClassChain", "PLIREditableOrSecureView")),
    "WebViewProtocolAloneNotRejected": "if (![view conformsToProtocol:@protocol(UITextInput)]) return NO;" in text and "method_getReturnType" in text,
    "RingNeverTakesKeyOrIntercepts": "- (BOOL)canBecomeKeyWindow { return NO; }" in text and "hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }" in text,
    "RecorderDoesNotMutateNavigation": not any(x in text for x in ("performNavigation", "startNextMatch", "captureNavigation", "captureWithError")),
}
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = {
    "format": "SDKPool.V16InteractionRecorderSourceReview", "version": 1,
    "result": "passed" if all(checks.values()) else "failed",
    "sourceSHA256": {str(p.relative_to(PROJECT)): digest(p) for p in (HEADER, SOURCE)},
    "checks": checks, "checkCount": len(checks),
    "syntax": {"command": command, "exitCode": run.returncode, "declarationsSHA256": digest(HERE / "RecorderDeclarations.h"),
               "translationUnitSHA256": digest(syntax), "logSHA256": digest(HERE / "RecorderSyntax.log")},
    "runtimeExecuted": False, "appleSDKBuildVerified": False, "iPhoneBehaviorVerified": False,
    "review": [
        "Installed hook chains the actual application class implementation once; no event replacement, cancellation or replay.",
        "Diagnostic exceptions are isolated from original event forwarding. Original app exceptions still propagate.",
        "Stop, background and session generation invalidate delayed sampling; no UITouch/UIEvent retained in logs.",
        "Accepted samples capture pre/post native state and window-local geometry; coordinates are evidence, not navigation commands.",
        "Exact click target still requires matching screen state/video. Delayed after-state can include another manual tap.",
        "Keyboard, editable/secure controls and SDKPool windows are excluded; class names are recorded without user text or identifiers.",
        "The ring is non-key and hitTest returns nil. iPhone rotation/rendering must still be checked on device.",
        "status is constant-size. Full native snapshot/deep JSON copy happens only when an explicit report is requested."
    ],
    "limitations": ["Declaration stand-ins establish ARC syntax/types only; Apple framework linkage and real event delivery remain unverified.",
                    "Hook installation rejects an incompatible or subsequently replaced implementation instead of guessing a dispatch chain.",
                    "Native diagnostic snapshot may report a guard failure; that failure is retained without bypassing the guard."]
}
(HERE / "RecorderValidation.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"result": report["result"], "checks": len(checks), "failed": [k for k,v in checks.items() if not v], "sourceSHA256": report["sourceSHA256"]}, indent=2))
sys.exit(0 if all(checks.values()) else 1)
