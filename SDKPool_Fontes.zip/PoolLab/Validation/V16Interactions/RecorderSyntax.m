// Declaration-only syntax stand-ins. This is NOT an Apple SDK or runtime test.
typedef signed char BOOL;
typedef long NSInteger;
typedef unsigned long NSUInteger;
typedef double NSTimeInterval;
typedef double CGFloat;
typedef unsigned long size_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;
typedef struct { CGFloat x,y; } CGPoint;
typedef struct { CGFloat width,height; } CGSize;
typedef struct { CGPoint origin; CGSize size; } CGRect;
typedef struct { CGFloat top,left,bottom,right; } UIEdgeInsets;
typedef const void *CGColorRef;
typedef const void *CGPathRef;
typedef NSInteger UITouchPhase;
typedef NSInteger UIEventType;
typedef NSInteger UIInterfaceOrientation;
typedef NSUInteger UIInterfaceOrientationMask;
typedef NSInteger UISceneActivationState;
typedef void *dispatch_queue_t;
typedef uint64_t dispatch_time_t;
typedef id (*IMP)(id,SEL,...);
typedef struct objc_method *Method;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define nil ((id)0)
#define NULL ((void *)0)
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define NS_ASSUME_NONNULL_BEGIN
#define NS_ASSUME_NONNULL_END
#define NS_SWIFT_NAME(x) __attribute__((swift_name(#x)))
#define __unused __attribute__((unused))
#define isfinite __builtin_isfinite
#define DISPATCH_TIME_NOW 0
#define NSEC_PER_SEC 1000000000
enum { UITouchPhaseBegan,UITouchPhaseMoved,UITouchPhaseStationary,UITouchPhaseEnded,UITouchPhaseCancelled };
enum { UIEventTypeTouches=0, UISceneActivationStateForegroundActive=0, UIApplicationStateActive=0, UIInterfaceOrientationUnknown=0, UIInterfaceOrientationMaskAll=30 };
typedef struct { unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5]; } NSFastEnumerationState;
__attribute__((objc_root_class)) @interface NSObject
+ (instancetype)new;
+ (instancetype)alloc;
+ (Class)class;
- (Class)class;
- (BOOL)isKindOfClass:(Class)c;
- (BOOL)conformsToProtocol:(Protocol *)protocol;
- (BOOL)respondsToSelector:(SEL)selector;
- (id)copy;
- (id)mutableCopy;
@end
@class NSString,NSDictionary,NSMutableDictionary,NSArray,NSOperationQueue;
@interface NSString : NSObject
@property(nonatomic,readonly) NSUInteger length;
+ (instancetype)stringWithFormat:(NSString *)format,...;
- (NSString *)substringToIndex:(NSUInteger)length;
- (NSString *)lowercaseString;
- (BOOL)containsString:(NSString *)text;
- (BOOL)isEqual:(id)object;
- (BOOL)hasSuffix:(NSString *)suffix;
- (NSString *)stringByAppendingString:(NSString *)suffix;
@end
@interface NSNumber : NSObject
@property(nonatomic,readonly) double doubleValue;
@property(nonatomic,readonly) NSUInteger unsignedIntegerValue;
+ (instancetype)numberWithInt:(int)n;
+ (instancetype)numberWithLong:(long)n;
+ (instancetype)numberWithUnsignedLong:(unsigned long)n;
+ (instancetype)numberWithInteger:(NSInteger)n;
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)n;
+ (instancetype)numberWithDouble:(double)n;
+ (instancetype)numberWithBool:(BOOL)n;
@end
@interface NSArray<__covariant ObjectType> : NSObject
@property(nonatomic,readonly) NSUInteger count;
+ (id)arrayWithObjects:(const id[])objects count:(NSUInteger)count;
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(NSUInteger)count;
@end
@interface NSMutableArray<ObjectType> : NSArray<ObjectType>
+ (instancetype)array;
- (void)addObject:(ObjectType)object;
@end
@interface NSDictionary<__covariant KeyType,__covariant ObjectType> : NSObject
@property(nonatomic,readonly) NSUInteger count;
+ (instancetype)dictionary;
+ (id)dictionaryWithObjects:(const id[])objects forKeys:(const id[])keys count:(NSUInteger)count;
- (ObjectType)objectForKeyedSubscript:(KeyType)key;
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(NSUInteger)count;
@end
@interface NSMutableDictionary<KeyType,ObjectType> : NSDictionary<KeyType,ObjectType>
- (void)setObject:(ObjectType)object forKeyedSubscript:(KeyType)key;
- (void)removeObjectForKey:(KeyType)key;
- (void)removeAllObjects;
@end
@interface NSMapTable<KeyType,ObjectType> : NSObject
+ (instancetype)weakToStrongObjectsMapTable;
- (ObjectType)objectForKey:(KeyType)key;
- (void)setObject:(ObjectType)object forKey:(KeyType)key;
- (void)removeObjectForKey:(KeyType)key;
- (void)removeAllObjects;
@end
@interface NSNull : NSObject
@property(class,nonatomic,readonly) NSNull *null;
@end
@interface NSError : NSObject
+ (instancetype)errorWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(NSDictionary *)info;
@end
@interface NSException : NSObject @end
@interface NSData : NSObject @end
@interface NSJSONSerialization : NSObject
+ (NSData *)dataWithJSONObject:(id)object options:(NSUInteger)options error:(NSError **)error;
+ (id)JSONObjectWithData:(NSData *)data options:(NSUInteger)options error:(NSError **)error;
@end
@interface NSThread : NSObject
+ (BOOL)isMainThread;
@end
@interface NSProcessInfo : NSObject
@property(class,nonatomic,readonly) NSProcessInfo *processInfo;
@property(nonatomic,readonly) NSTimeInterval systemUptime;
@end
@interface NSNotification : NSObject @end
@interface NSOperationQueue : NSObject
@property(class,nonatomic,readonly) NSOperationQueue *mainQueue;
@end
@interface NSNotificationCenter : NSObject
@property(class,nonatomic,readonly) NSNotificationCenter *defaultCenter;
- (id)addObserverForName:(NSString *)name object:(id)object queue:(NSOperationQueue *)queue usingBlock:(void (^)(NSNotification *))block;
@end
@interface UIColor : NSObject
@property(class,nonatomic,readonly) UIColor *clearColor;
@property(nonatomic,readonly) CGColorRef CGColor;
+ (UIColor *)colorWithRed:(CGFloat)r green:(CGFloat)g blue:(CGFloat)b alpha:(CGFloat)a;
@end
@interface CALayer : NSObject
- (void)addSublayer:(CALayer *)layer;
- (void)removeAllAnimations;
@end
@interface CAShapeLayer : CALayer
+ (instancetype)layer;
@property(nonatomic) CGPathRef path;
@property(nonatomic) CGColorRef fillColor;
@property(nonatomic) CGColorRef strokeColor;
@property(nonatomic) CGFloat lineWidth;
@end
@interface CATransaction : NSObject
+ (void)begin;
+ (void)commit;
+ (void)setDisableActions:(BOOL)value;
@end
@interface UIBezierPath : NSObject
@property(nonatomic,readonly) CGPathRef CGPath;
+ (instancetype)bezierPathWithOvalInRect:(CGRect)rect;
@end
@protocol UITextInput @end
@protocol UITextInputTraits
- (BOOL)isSecureTextEntry;
@end
@class UIWindow,UIWindowScene,UIViewController,UIEvent;
@interface UIView : NSObject
@property(nonatomic) BOOL hidden;
@property(nonatomic) CGFloat alpha;
@property(nonatomic) BOOL userInteractionEnabled;
@property(nonatomic) BOOL accessibilityElementsHidden;
@property(nonatomic) CGRect frame;
@property(nonatomic) CGRect bounds;
@property(nonatomic) UIColor *backgroundColor;
@property(nonatomic,readonly) CALayer *layer;
@property(nonatomic,readonly) UIView *superview;
@property(nonatomic,readonly) UIWindow *window;
@property(nonatomic,readonly) UIEdgeInsets safeAreaInsets;
@end
@interface UITextField : UIView @end
@interface UITextView : UIView @end
@interface UIViewController : NSObject
@property(nonatomic) UIView *view;
@end
@interface UIScreen : NSObject
@property(nonatomic,readonly) CGFloat scale;
@end
@interface UIWindowScene : NSObject
@property(nonatomic,readonly) UISceneActivationState activationState;
@property(nonatomic,readonly) UIInterfaceOrientation interfaceOrientation;
@end
@interface UIWindow : UIView
@property(nonatomic) UIViewController *rootViewController;
@property(nonatomic) CGFloat windowLevel;
@property(nonatomic,readonly) UIWindowScene *windowScene;
@property(nonatomic,readonly) UIScreen *screen;
- (instancetype)initWithWindowScene:(UIWindowScene *)scene;
- (instancetype)initWithFrame:(CGRect)frame;
- (CGPoint)convertPoint:(CGPoint)point fromWindow:(UIWindow *)window;
@end
@interface UITouch : NSObject
@property(nonatomic,readonly) UIWindow *window;
@property(nonatomic,readonly) UIView *view;
@property(nonatomic,readonly) UITouchPhase phase;
@property(nonatomic,readonly) NSTimeInterval timestamp;
- (CGPoint)locationInView:(UIView *)view;
@end
@interface UIEvent : NSObject
@property(nonatomic,readonly) UIEventType type;
@property(nonatomic,readonly) NSArray<UITouch *> *allTouches;
@end
@interface UIApplication : NSObject
@property(class,nonatomic,readonly) UIApplication *sharedApplication;
@property(nonatomic,readonly) NSInteger applicationState;
- (void)sendEvent:(UIEvent *)event;
@end
@interface PLQueueBridge : NSObject
+ (NSDictionary<NSString *,id> *)diagnosticSnapshot;
@end
extern NSString *const NSLocalizedDescriptionKey;
extern NSString *const UIApplicationWillResignActiveNotification;
extern NSString *NSStringFromClass(Class);
extern Class object_getClass(id);
extern Class class_getSuperclass(Class);
extern Method class_getInstanceMethod(Class,SEL);
extern IMP class_getMethodImplementation(Class,SEL);
extern const char *method_getTypeEncoding(Method);
extern IMP method_getImplementation(Method);
extern IMP method_setImplementation(Method,IMP);
extern unsigned int method_getNumberOfArguments(Method);
extern void method_getReturnType(Method,char *,size_t);
extern BOOL class_addMethod(Class,SEL,IMP,const char *);
extern SEL NSSelectorFromString(NSString *);
extern id objc_msgSend(id,SEL,...);
extern int strcmp(const char *,const char *);
extern CGPoint CGPointMake(CGFloat,CGFloat);
extern CGRect CGRectMake(CGFloat,CGFloat,CGFloat,CGFloat);
extern dispatch_queue_t dispatch_get_main_queue(void);
extern dispatch_time_t dispatch_time(dispatch_time_t,int64_t);
extern void dispatch_after(dispatch_time_t,dispatch_queue_t,void (^)(void));


NS_ASSUME_NONNULL_BEGIN

/// Opt-in, local interaction diagnostics. All calls must run on the main thread.
/// Observes delivery without consuming, synthesizing or replaying any input.
/// It records geometry and native state, never text, screenshots or credentials.
@interface PLInteractionRecorder : NSObject
+ (BOOL)startWithError:(NSError * _Nullable * _Nullable)error NS_SWIFT_NAME(start());
+ (void)stop;
+ (BOOL)isRecording;
/// Constant-size UI state. Does not copy the log or read the native game.
+ (NSDictionary<NSString *, id> *)status;
/// JSON-compatible, bounded report. May be exported with zero table frames.
+ (NSDictionary<NSString *, id> *)report;
@end

NS_ASSUME_NONNULL_END

static const NSTimeInterval PLIRMaximumDuration = 180.0;
static const NSUInteger PLIRMaximumEvents = 300;
static const NSTimeInterval PLIRMoveInterval = 0.1;

// Main-thread-only state. UITouch/UIEvent instances are never retained by the log.
static BOOL PLIRRecording;
static NSUInteger PLIRGeneration;
static NSUInteger PLIRNextTouchID;
static NSTimeInterval PLIRStartedAt;
static NSTimeInterval PLIRStoppedAt;
static NSString *PLIRStopReason;
static NSMutableArray<NSMutableDictionary<NSString *, id> *> *PLIREvents;
static NSMutableDictionary<NSString *, NSNumber *> *PLIRIgnored;
static NSMapTable<UITouch *, NSNumber *> *PLIRTouchIDs;
static NSMutableDictionary<NSNumber *, NSNumber *> *PLIRLastMove;
static IMP PLIRPreviousSendEvent;
static Class PLIRApplicationClass;
static id PLIRInactiveObserver;

@interface PLInteractionRingWindow : UIWindow
@end
@implementation PLInteractionRingWindow
- (BOOL)canBecomeKeyWindow { return NO; }
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
@end

@interface PLInteractionRingController : UIViewController
@end
@implementation PLInteractionRingController
- (BOOL)shouldAutorotate { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskAll; }
@end

static PLInteractionRingWindow *PLIRRingWindow;
static CAShapeLayer *PLIRRingLayer;
static NSUInteger PLIRRingGeneration;

static double PLIRFinite(double value) { return isfinite(value) ? value : 0.0; }
static NSString *PLIRClassName(id object) {
    if (!object) return @"none";
    NSString *name = NSStringFromClass(object_getClass(object));
    return [name substringToIndex:MIN(name.length, (NSUInteger)160)];
}
static NSDictionary *PLIRPoint(CGPoint point) {
    return @{@"x": @(PLIRFinite(point.x)), @"y": @(PLIRFinite(point.y))};
}
static NSDictionary *PLIRRect(CGRect rect) {
    return @{@"x": @(PLIRFinite(rect.origin.x)), @"y": @(PLIRFinite(rect.origin.y)),
             @"width": @(PLIRFinite(rect.size.width)), @"height": @(PLIRFinite(rect.size.height))};
}
static void PLIRCountIgnored(NSString *category) {
    NSUInteger count = [PLIRIgnored[category] unsignedIntegerValue];
    PLIRIgnored[category] = @(MIN(count + 1, (NSUInteger)1000000));
}

// Extra defense around the explicitly sanitized native diagnostic contract.
// Unknown objects are omitted; their description can contain arbitrary values.
static id PLIRBoundedJSON(id value, NSUInteger depth) {
    if (depth > 9 || !value || value == NSNull.null) return NSNull.null;
    if ([value isKindOfClass:NSString.class]) {
        NSString *text = value;
        return [text substringToIndex:MIN(text.length, (NSUInteger)256)];
    }
    if ([value isKindOfClass:NSNumber.class]) return isfinite([value doubleValue]) ? value : NSNull.null;
    if ([value isKindOfClass:NSArray.class]) {
        NSMutableArray *result = [NSMutableArray array];
        for (id element in value) {
            if (result.count >= 48) break;
            [result addObject:PLIRBoundedJSON(element, depth + 1)];
        }
        return result;
    }
    if ([value isKindOfClass:NSDictionary.class]) {
        NSMutableDictionary *result = [NSMutableDictionary dictionary];
        for (id key in value) {
            if (result.count >= 64) break;
            if (![key isKindOfClass:NSString.class] || [key length] > 96) continue;
            NSString *lower = [key lowercaseString];
            BOOL excluded = NO;
            for (NSString *part in @[@"password", @"clipboard", @"license", @"credential", @"token", @"matchid", @"typedtext"])
                if ([lower containsString:part]) { excluded = YES; break; }
            if (!excluded) result[key] = PLIRBoundedJSON(value[key], depth + 1);
        }
        return result;
    }
    return NSNull.null;
}
static NSDictionary *PLIRSnapshot(void) {
    @try {
        id state = PLIRBoundedJSON([PLQueueBridge diagnosticSnapshot], 0);
        return [state isKindOfClass:NSDictionary.class] ? state : @{@"unavailable": @YES};
    } @catch (__unused NSException *exception) {
        // Exception text is deliberately excluded from exports.
        return @{@"unavailable": @YES, @"reason": @"nativeSnapshotException"};
    }
}

static BOOL PLIRClassChainContains(id object, NSArray<NSString *> *names) {
    for (Class cls = object_getClass(object); cls; cls = class_getSuperclass(cls)) {
        NSString *name = NSStringFromClass(cls);
        for (NSString *expected in names) {
            if ([name isEqual:expected] || [name hasSuffix:[@"." stringByAppendingString:expected]]) return YES;
        }
    }
    return NO;
}
static BOOL PLIRKeyboardClassChain(id object) {
    for (Class cls = object_getClass(object); cls; cls = class_getSuperclass(cls)) {
        NSString *name = NSStringFromClass(cls);
        if ([name containsString:@"Keyboard"] || [name containsString:@"InputSet"] ||
            [name containsString:@"TextEffects"]) return YES;
    }
    return NO;
}
static BOOL PLIREditableOrSecureView(UIView *view) {
    if ([view isKindOfClass:UITextField.class] || [view isKindOfClass:UITextView.class]) return YES;
    if ([view conformsToProtocol:@protocol(UITextInputTraits)] &&
        [view respondsToSelector:@selector(isSecureTextEntry)] && [(id<UITextInputTraits>)view isSecureTextEntry]) return YES;
    // WKContentView can implement UITextInput for noneditable ad content too.
    // Conformance alone is not proof of text entry. Only a typed BOOL getter
    // explicitly reporting editing excludes such generic input views.
    if (![view conformsToProtocol:@protocol(UITextInput)]) return NO;
    SEL selector = NSSelectorFromString(@"isEditable");
    Method method = class_getInstanceMethod(object_getClass(view), selector);
    char type[8] = {0};
    if (!method || method_getNumberOfArguments(method) != 2) return NO;
    method_getReturnType(method, type, sizeof(type));
    if (strcmp(type, "B") && strcmp(type, "c")) return NO;
    return ((BOOL (*)(id, SEL))objc_msgSend)(view, selector);
}
static NSString *PLIRExcludedTouch(UITouch *touch) {
    UIWindow *window = touch.window;
    if (!window || window.hidden || window.alpha < 0.01) return @"hiddenOrMissingWindow";
    if (PLIRClassChainContains(window, @[@"PLPassthroughWindow", @"PLInteractionRingWindow"])) return @"sdkpoolWindow";
    if (PLIRKeyboardClassChain(window) || PLIRClassChainContains(window, @[@"UIInputWindow"]))
        return @"keyboardWindow";
    if (@available(iOS 13.0, *)) {
        if (window.windowScene && window.windowScene.activationState != UISceneActivationStateForegroundActive)
            return @"inactiveScene";
    }
    UIView *view = touch.view;
    for (NSUInteger depth = 0; view && depth < 32; depth++, view = view.superview) {
        if (PLIREditableOrSecureView(view) || PLIRKeyboardClassChain(view))
            return @"textInput";
    }
    return nil;
}

static void PLIRHideRing(void) {
    PLIRRingGeneration++;
    PLIRRingWindow.hidden = YES;
    [PLIRRingLayer removeAllAnimations];
}
static void PLIRShowRing(UIWindow *source, CGPoint point) {
    // One reused non-key window. It never calls makeKeyAndVisible or hitTest on
    // the game, and its own touches are excluded even if UIKit changes routing.
    if (!source) return;
    if (!PLIRRingWindow || PLIRRingWindow.windowScene != source.windowScene) {
        PLIRHideRing();
        PLIRRingWindow = source.windowScene
            ? [[PLInteractionRingWindow alloc] initWithWindowScene:source.windowScene]
            : [[PLInteractionRingWindow alloc] initWithFrame:source.frame];
        PLIRRingWindow.userInteractionEnabled = NO;
        PLIRRingWindow.backgroundColor = UIColor.clearColor;
        PLIRRingWindow.accessibilityElementsHidden = YES;
        PLInteractionRingController *controller = [PLInteractionRingController new];
        controller.view.backgroundColor = UIColor.clearColor;
        controller.view.userInteractionEnabled = NO;
        PLIRRingWindow.rootViewController = controller;
        PLIRRingLayer = [CAShapeLayer layer];
        PLIRRingLayer.fillColor = [UIColor colorWithRed:1 green:0.3 blue:0 alpha:0.12].CGColor;
        PLIRRingLayer.strokeColor = [UIColor colorWithRed:1 green:0.45 blue:0.08 alpha:0.92].CGColor;
        PLIRRingLayer.lineWidth = 2.5;
        [controller.view.layer addSublayer:PLIRRingLayer];
    }
    PLIRRingWindow.frame = source.frame;
    PLIRRingWindow.windowLevel = source.windowLevel + 1;
    PLIRRingWindow.rootViewController.view.frame = PLIRRingWindow.bounds;
    CGPoint center = [PLIRRingWindow convertPoint:point fromWindow:source];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    PLIRRingLayer.path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(center.x - 14, center.y - 14, 28, 28)].CGPath;
    [CATransaction commit];
    PLIRRingWindow.hidden = NO;
    NSUInteger generation = ++PLIRRingGeneration;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (generation == PLIRRingGeneration) PLIRHideRing();
    });
}

static void PLIRStop(NSString *reason) {
    if (!PLIRRecording) return;
    PLIRRecording = NO;
    PLIRStoppedAt = NSProcessInfo.processInfo.systemUptime;
    PLIRStopReason = reason;
    PLIRGeneration++; // Invalidate delayed samples from the previous session.
    [PLIRTouchIDs removeAllObjects];
    [PLIRLastMove removeAllObjects];
    PLIRHideRing();
}
static NSString *PLIRPhase(UITouchPhase phase) {
    switch (phase) {
        case UITouchPhaseBegan: return @"began";
        case UITouchPhaseMoved: return @"moved";
        case UITouchPhaseEnded: return @"ended";
        case UITouchPhaseCancelled: return @"cancelled";
        default: return @"stationary";
    }
}

static NSArray<NSMutableDictionary<NSString *, id> *> *PLIRBeforeEvent(UIEvent *event) {
    if (!PLIRRecording || event.type != UIEventTypeTouches) return @[];
    NSTimeInterval now = NSProcessInfo.processInfo.systemUptime;
    if (now - PLIRStartedAt >= PLIRMaximumDuration) { PLIRStop(@"durationLimit"); return @[]; }
    NSMutableArray *accepted = [NSMutableArray array];
    NSDictionary *nativeBefore = nil;
    for (UITouch *touch in event.allTouches) {
        UITouchPhase phase = touch.phase;
        if (phase != UITouchPhaseBegan && phase != UITouchPhaseMoved && phase != UITouchPhaseEnded && phase != UITouchPhaseCancelled) continue;
        NSString *excluded = PLIRExcludedTouch(touch);
        if (excluded) { PLIRCountIgnored(excluded); continue; }
        NSNumber *touchID = [PLIRTouchIDs objectForKey:touch];
        // A session can start while a finger is already down. Its next sample
        // gets an ID but is explicitly marked as missing the original begin.
        BOOL missingBegin = !touchID && phase != UITouchPhaseBegan;
        if (!touchID) {
            touchID = @(++PLIRNextTouchID);
            [PLIRTouchIDs setObject:touchID forKey:touch];
        }
        if (phase == UITouchPhaseMoved) {
            NSTimeInterval last = [PLIRLastMove[touchID] doubleValue];
            if (last > 0 && now - last < PLIRMoveInterval) { PLIRCountIgnored(@"moveThrottled"); continue; }
            PLIRLastMove[touchID] = @(now);
        }
        if (PLIREvents.count >= PLIRMaximumEvents) { PLIRCountIgnored(@"eventLimit"); continue; }
        UIWindow *window = touch.window;
        CGPoint point = [touch locationInView:window];
        CGRect bounds = window.bounds;
        UIInterfaceOrientation orientation = window.windowScene ? window.windowScene.interfaceOrientation : UIInterfaceOrientationUnknown;
        if (!nativeBefore) nativeBefore = PLIRSnapshot();
        NSMutableDictionary *entry = [@{
            @"sequence": @(PLIREvents.count + 1), @"touchID": touchID,
            @"phase": PLIRPhase(phase), @"missingBegin": @(missingBegin),
            @"uptime": @(now), @"elapsedMs": @((now - PLIRStartedAt) * 1000),
            @"touchElapsedMs": @(PLIRFinite((touch.timestamp - PLIRStartedAt) * 1000)),
            @"point": PLIRPoint(point), @"windowBounds": PLIRRect(bounds),
            @"normalized": PLIRPoint(CGPointMake(bounds.size.width > 0 ? (point.x - bounds.origin.x) / bounds.size.width : 0,
                                                 bounds.size.height > 0 ? (point.y - bounds.origin.y) / bounds.size.height : 0)),
            @"safeAreaInsets": @{@"top": @(window.safeAreaInsets.top), @"left": @(window.safeAreaInsets.left),
                                  @"bottom": @(window.safeAreaInsets.bottom), @"right": @(window.safeAreaInsets.right)},
            @"windowClass": PLIRClassName(window), @"viewClass": PLIRClassName(touch.view),
            @"windowLevel": @(PLIRFinite(window.windowLevel)), @"screenScale": @(PLIRFinite(window.screen.scale)),
            @"orientation": @(orientation), @"coordinateSpace": @"UIKitWindowPoints",
            @"before": nativeBefore, @"after": [NSMutableArray array]
        } mutableCopy];
        [PLIREvents addObject:entry];
        [accepted addObject:entry];
        if (phase == UITouchPhaseBegan || phase == UITouchPhaseEnded) PLIRShowRing(window, point);
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            [PLIRTouchIDs removeObjectForKey:touch];
            [PLIRLastMove removeObjectForKey:touchID];
        }
    }
    return accepted;
}

static void PLIRAppendAfter(NSArray<NSMutableDictionary<NSString *, id> *> *entries, NSString *stage) {
    if (!entries.count) return;
    NSDictionary *sample = @{@"stage": stage, @"elapsedMs": @((NSProcessInfo.processInfo.systemUptime - PLIRStartedAt) * 1000),
                             @"state": PLIRSnapshot()};
    for (NSMutableDictionary *entry in entries) {
        NSMutableArray *after = entry[@"after"];
        if (after.count < 4) [after addObject:sample];
    }
}
static void PLIRAfterEvent(NSArray<NSMutableDictionary<NSString *, id> *> *entries, NSUInteger generation) {
    if (!PLIRRecording || generation != PLIRGeneration || !entries.count) return;
    PLIRAppendAfter(entries, @"dispatchReturned");
    // Moved samples already have a fresh before/after. Only boundaries schedule
    // delayed state checks, keeping long drags from creating hundreds of jobs.
    NSMutableArray *boundaries = [NSMutableArray array];
    for (NSMutableDictionary *entry in entries)
        if (![entry[@"phase"] isEqual:@"moved"]) [boundaries addObject:entry];
    for (NSNumber *delay in @[@0.0, @0.3, @0.9]) {
        if (!boundaries.count) break;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay.doubleValue * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!PLIRRecording || generation != PLIRGeneration) return;
            @try { PLIRAppendAfter(boundaries, [NSString stringWithFormat:@"after%.0fms", delay.doubleValue * 1000]); }
            @catch (__unused NSException *exception) { PLIRCountIgnored(@"snapshotException"); }
        });
    }
    if (PLIREvents.count >= PLIRMaximumEvents) PLIRStop(@"eventLimit");
}

static void PLIRSendEvent(UIApplication *application, SEL selector, UIEvent *event) {
    NSArray *entries = nil;
    NSUInteger generation = PLIRGeneration;
    if (NSThread.isMainThread && PLIRRecording) {
        @try { entries = PLIRBeforeEvent(event); }
        @catch (__unused NSException *exception) { PLIRCountIgnored(@"observationException"); }
    }
    // Exactly one call to the implementation present when installed. The game
    // receives its original object and selector; its exceptions are not swallowed.
    ((void (*)(id, SEL, UIEvent *))PLIRPreviousSendEvent)(application, selector, event);
    if (NSThread.isMainThread && entries.count) {
        @try { PLIRAfterEvent(entries, generation); }
        @catch (__unused NSException *exception) { PLIRCountIgnored(@"observationException"); }
    }
}

static BOOL PLIRFail(NSError **error, NSInteger code, NSString *message) {
    if (error) *error = [NSError errorWithDomain:@"SDKPool.InteractionRecorder" code:code
                                      userInfo:@{NSLocalizedDescriptionKey: message}];
    return NO;
}
static BOOL PLIRInstall(NSError **error) {
    Class cls = object_getClass(UIApplication.sharedApplication);
    SEL selector = @selector(sendEvent:);
    if (PLIRPreviousSendEvent) {
        return (cls == PLIRApplicationClass && class_getMethodImplementation(cls, selector) == (IMP)PLIRSendEvent) ||
            PLIRFail(error, 3, @"Outro controle de eventos mudou. Reinicie o jogo para gravar os botões.");
    }
    Method method = class_getInstanceMethod(cls, selector);
    const char *encoding = method ? method_getTypeEncoding(method) : NULL;
    if (!encoding || strcmp(encoding, "v24@0:8@16"))
        return PLIRFail(error, 2, @"A entrega de toques deste aplicativo não é compatível com o gravador.");
    IMP previous = method_getImplementation(method);
    if (!previous || previous == (IMP)PLIRSendEvent)
        return PLIRFail(error, 2, @"Não foi possível observar os toques do aplicativo.");
    PLIRPreviousSendEvent = previous;
    PLIRApplicationClass = cls;
    // Adding a local method when inherited avoids mutating UIApplication or
    // siblings. If already local, replace only this actual application class.
    if (!class_addMethod(cls, selector, (IMP)PLIRSendEvent, encoding))
        PLIRPreviousSendEvent = method_setImplementation(class_getInstanceMethod(cls, selector), (IMP)PLIRSendEvent);
    PLIRInactiveObserver = [NSNotificationCenter.defaultCenter addObserverForName:UIApplicationWillResignActiveNotification
        object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *notification) {
            PLIRStop(@"applicationInactive");
        }];
    return YES;
}

@implementation PLInteractionRecorder
+ (BOOL)startWithError:(NSError **)error {
    if (!NSThread.isMainThread || UIApplication.sharedApplication.applicationState != UIApplicationStateActive)
        return PLIRFail(error, 1, @"Abra o jogo para iniciar a gravação dos botões.");
    if (PLIRRecording) return YES;
    if (!PLIRInstall(error)) return NO;
    PLIREvents = [NSMutableArray array];
    PLIRIgnored = [NSMutableDictionary dictionary];
    PLIRTouchIDs = [NSMapTable weakToStrongObjectsMapTable];
    PLIRLastMove = [NSMutableDictionary dictionary];
    PLIRNextTouchID = 0;
    PLIRStartedAt = NSProcessInfo.processInfo.systemUptime;
    PLIRStoppedAt = 0;
    PLIRStopReason = @"recording";
    PLIRRecording = YES;
    NSUInteger generation = ++PLIRGeneration;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(PLIRMaximumDuration * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (PLIRRecording && generation == PLIRGeneration) PLIRStop(@"durationLimit");
    });
    return YES;
}
+ (void)stop {
    if (!NSThread.isMainThread) return;
    PLIRStop(@"userStopped");
}
+ (BOOL)isRecording { return NSThread.isMainThread && PLIRRecording; }
+ (NSDictionary<NSString *, id> *)status {
    if (!NSThread.isMainThread) return @{@"recording": @NO, @"eventCount": @0, @"stopReason": @"mainThreadRequired"};
    NSTimeInterval end = PLIRRecording ? NSProcessInfo.processInfo.systemUptime : PLIRStoppedAt;
    return @{@"recording": @(PLIRRecording), @"eventCount": @(PLIREvents.count),
             @"stopReason": PLIRStopReason ?: @"notStarted",
             @"durationSeconds": @(PLIRStartedAt > 0 ? MAX(0, end - PLIRStartedAt) : 0)};
}
+ (NSDictionary<NSString *, id> *)report {
    if (!NSThread.isMainThread) return @{@"format": @"SDKPool.Interactions", @"error": @"mainThreadRequired"};
    NSTimeInterval end = PLIRRecording ? NSProcessInfo.processInfo.systemUptime : PLIRStoppedAt;
    NSDictionary *report = @{
        @"format": @"SDKPool.Interactions", @"version": @1,
        @"recording": @(PLIRRecording), @"stopReason": PLIRStopReason ?: @"notStarted",
        @"startedAtUptime": @(PLIRStartedAt), @"durationSeconds": @(PLIRStartedAt > 0 ? MAX(0, end - PLIRStartedAt) : 0),
        @"clock": @"monotonicSystemUptime", @"eventCount": @(PLIREvents.count),
        @"limits": @{@"durationSeconds": @(PLIRMaximumDuration), @"events": @(PLIRMaximumEvents), @"movedIntervalMs": @100},
        @"ignoredSamples": PLIRIgnored ?: @{}, @"events": PLIREvents ?: @[],
        @"privacy": @"No text, key presses, clipboard, credentials, screenshots, input replay or network upload. Editable/secure fields and keyboard windows are excluded.",
        @"finalState": PLIRSnapshot()
    };
    // Deep immutable copy, so delayed observations cannot mutate an export.
    NSData *data = [NSJSONSerialization dataWithJSONObject:report options:0 error:nil];
    return data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] :
        @{@"format": @"SDKPool.Interactions", @"error": @"serializationFailed"};
}
@end