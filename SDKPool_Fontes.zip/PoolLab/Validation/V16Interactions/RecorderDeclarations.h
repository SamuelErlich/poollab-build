// Declaration-only syntax stand-ins. This is NOT an Apple SDK or runtime test.
typedef signed char BOOL;
typedef long NSInteger;
typedef unsigned long NSUInteger;
typedef double NSTimeInterval;
typedef double CGFloat;
typedef unsigned long size_t;
typedef long long int64_t;
typedef unsigned long long uint64_t;
typedef struct { CGFloat x,y; } CGPoint;
typedef struct { CGFloat width,height; } CGSize;
typedef struct { CGPoint origin; CGSize size; } CGRect;
typedef struct { CGFloat top,left,bottom,right; } UIEdgeInsets;
typedef const void *CGColorRef;
typedef const void *CGPathRef;
typedef NSInteger UITouchPhase;
typedef NSInteger UIEventType;
typedef NSInteger UIInterfaceOrientation;
typedef NSUInteger UIInterfaceOrientationMask;
typedef NSInteger UISceneActivationState;
typedef void *dispatch_queue_t;
typedef uint64_t dispatch_time_t;
typedef id (*IMP)(id,SEL,...);
typedef struct objc_method *Method;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define nil ((id)0)
#define NULL ((void *)0)
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define NS_ASSUME_NONNULL_BEGIN
#define NS_ASSUME_NONNULL_END
#define NS_SWIFT_NAME(x) __attribute__((swift_name(#x)))
#define __unused __attribute__((unused))
#define isfinite __builtin_isfinite
#define DISPATCH_TIME_NOW 0
#define NSEC_PER_SEC 1000000000
enum { UITouchPhaseBegan,UITouchPhaseMoved,UITouchPhaseStationary,UITouchPhaseEnded,UITouchPhaseCancelled };
enum { UIEventTypeTouches=0, UISceneActivationStateForegroundActive=0, UIApplicationStateActive=0, UIInterfaceOrientationUnknown=0, UIInterfaceOrientationMaskAll=30 };
typedef struct { unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5]; } NSFastEnumerationState;
__attribute__((objc_root_class)) @interface NSObject
+ (instancetype)new;
+ (instancetype)alloc;
+ (Class)class;
- (Class)class;
- (BOOL)isKindOfClass:(Class)c;
- (BOOL)conformsToProtocol:(Protocol *)protocol;
- (BOOL)respondsToSelector:(SEL)selector;
- (id)copy;
- (id)mutableCopy;
@end
@class NSString,NSDictionary,NSMutableDictionary,NSArray,NSOperationQueue;
@interface NSString : NSObject
@property(nonatomic,readonly) NSUInteger length;
+ (instancetype)stringWithFormat:(NSString *)format,...;
- (NSString *)substringToIndex:(NSUInteger)length;
- (NSString *)lowercaseString;
- (BOOL)containsString:(NSString *)text;
- (BOOL)isEqual:(id)object;
- (BOOL)hasSuffix:(NSString *)suffix;
- (NSString *)stringByAppendingString:(NSString *)suffix;
@end
@interface NSNumber : NSObject
@property(nonatomic,readonly) double doubleValue;
@property(nonatomic,readonly) NSUInteger unsignedIntegerValue;
+ (instancetype)numberWithInt:(int)n;
+ (instancetype)numberWithLong:(long)n;
+ (instancetype)numberWithUnsignedLong:(unsigned long)n;
+ (instancetype)numberWithInteger:(NSInteger)n;
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)n;
+ (instancetype)numberWithDouble:(double)n;
+ (instancetype)numberWithBool:(BOOL)n;
@end
@interface NSArray<__covariant ObjectType> : NSObject
@property(nonatomic,readonly) NSUInteger count;
+ (id)arrayWithObjects:(const id[])objects count:(NSUInteger)count;
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(NSUInteger)count;
@end
@interface NSMutableArray<ObjectType> : NSArray<ObjectType>
+ (instancetype)array;
- (void)addObject:(ObjectType)object;
@end
@interface NSDictionary<__covariant KeyType,__covariant ObjectType> : NSObject
@property(nonatomic,readonly) NSUInteger count;
+ (instancetype)dictionary;
+ (id)dictionaryWithObjects:(const id[])objects forKeys:(const id[])keys count:(NSUInteger)count;
- (ObjectType)objectForKeyedSubscript:(KeyType)key;
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(NSUInteger)count;
@end
@interface NSMutableDictionary<KeyType,ObjectType> : NSDictionary<KeyType,ObjectType>
- (void)setObject:(ObjectType)object forKeyedSubscript:(KeyType)key;
- (void)removeObjectForKey:(KeyType)key;
- (void)removeAllObjects;
@end
@interface NSMapTable<KeyType,ObjectType> : NSObject
+ (instancetype)weakToStrongObjectsMapTable;
- (ObjectType)objectForKey:(KeyType)key;
- (void)setObject:(ObjectType)object forKey:(KeyType)key;
- (void)removeObjectForKey:(KeyType)key;
- (void)removeAllObjects;
@end
@interface NSNull : NSObject
@property(class,nonatomic,readonly) NSNull *null;
@end
@interface NSError : NSObject
+ (instancetype)errorWithDomain:(NSString *)domain code:(NSInteger)code userInfo:(NSDictionary *)info;
@end
@interface NSException : NSObject @end
@interface NSData : NSObject @end
@interface NSJSONSerialization : NSObject
+ (NSData *)dataWithJSONObject:(id)object options:(NSUInteger)options error:(NSError **)error;
+ (id)JSONObjectWithData:(NSData *)data options:(NSUInteger)options error:(NSError **)error;
@end
@interface NSThread : NSObject
+ (BOOL)isMainThread;
@end
@interface NSProcessInfo : NSObject
@property(class,nonatomic,readonly) NSProcessInfo *processInfo;
@property(nonatomic,readonly) NSTimeInterval systemUptime;
@end
@interface NSNotification : NSObject @end
@interface NSOperationQueue : NSObject
@property(class,nonatomic,readonly) NSOperationQueue *mainQueue;
@end
@interface NSNotificationCenter : NSObject
@property(class,nonatomic,readonly) NSNotificationCenter *defaultCenter;
- (id)addObserverForName:(NSString *)name object:(id)object queue:(NSOperationQueue *)queue usingBlock:(void (^)(NSNotification *))block;
@end
@interface UIColor : NSObject
@property(class,nonatomic,readonly) UIColor *clearColor;
@property(nonatomic,readonly) CGColorRef CGColor;
+ (UIColor *)colorWithRed:(CGFloat)r green:(CGFloat)g blue:(CGFloat)b alpha:(CGFloat)a;
@end
@interface CALayer : NSObject
- (void)addSublayer:(CALayer *)layer;
- (void)removeAllAnimations;
@end
@interface CAShapeLayer : CALayer
+ (instancetype)layer;
@property(nonatomic) CGPathRef path;
@property(nonatomic) CGColorRef fillColor;
@property(nonatomic) CGColorRef strokeColor;
@property(nonatomic) CGFloat lineWidth;
@end
@interface CATransaction : NSObject
+ (void)begin;
+ (void)commit;
+ (void)setDisableActions:(BOOL)value;
@end
@interface UIBezierPath : NSObject
@property(nonatomic,readonly) CGPathRef CGPath;
+ (instancetype)bezierPathWithOvalInRect:(CGRect)rect;
@end
@protocol UITextInput @end
@protocol UITextInputTraits
- (BOOL)isSecureTextEntry;
@end
@class UIWindow,UIWindowScene,UIViewController,UIEvent;
@interface UIView : NSObject
@property(nonatomic) BOOL hidden;
@property(nonatomic) CGFloat alpha;
@property(nonatomic) BOOL userInteractionEnabled;
@property(nonatomic) BOOL accessibilityElementsHidden;
@property(nonatomic) CGRect frame;
@property(nonatomic) CGRect bounds;
@property(nonatomic) UIColor *backgroundColor;
@property(nonatomic,readonly) CALayer *layer;
@property(nonatomic,readonly) UIView *superview;
@property(nonatomic,readonly) UIWindow *window;
@property(nonatomic,readonly) UIEdgeInsets safeAreaInsets;
@end
@interface UITextField : UIView @end
@interface UITextView : UIView @end
@interface UIViewController : NSObject
@property(nonatomic) UIView *view;
@end
@interface UIScreen : NSObject
@property(nonatomic,readonly) CGFloat scale;
@end
@interface UIWindowScene : NSObject
@property(nonatomic,readonly) UISceneActivationState activationState;
@property(nonatomic,readonly) UIInterfaceOrientation interfaceOrientation;
@end
@interface UIWindow : UIView
@property(nonatomic) UIViewController *rootViewController;
@property(nonatomic) CGFloat windowLevel;
@property(nonatomic,readonly) UIWindowScene *windowScene;
@property(nonatomic,readonly) UIScreen *screen;
- (instancetype)initWithWindowScene:(UIWindowScene *)scene;
- (instancetype)initWithFrame:(CGRect)frame;
- (CGPoint)convertPoint:(CGPoint)point fromWindow:(UIWindow *)window;
@end
@interface UITouch : NSObject
@property(nonatomic,readonly) UIWindow *window;
@property(nonatomic,readonly) UIView *view;
@property(nonatomic,readonly) UITouchPhase phase;
@property(nonatomic,readonly) NSTimeInterval timestamp;
- (CGPoint)locationInView:(UIView *)view;
@end
@interface UIEvent : NSObject
@property(nonatomic,readonly) UIEventType type;
@property(nonatomic,readonly) NSArray<UITouch *> *allTouches;
@end
@interface UIApplication : NSObject
@property(class,nonatomic,readonly) UIApplication *sharedApplication;
@property(nonatomic,readonly) NSInteger applicationState;
- (void)sendEvent:(UIEvent *)event;
@end
@interface PLQueueBridge : NSObject
+ (NSDictionary<NSString *,id> *)diagnosticSnapshot;
@end
extern NSString *const NSLocalizedDescriptionKey;
extern NSString *const UIApplicationWillResignActiveNotification;
extern NSString *NSStringFromClass(Class);
extern Class object_getClass(id);
extern Class class_getSuperclass(Class);
extern Method class_getInstanceMethod(Class,SEL);
extern IMP class_getMethodImplementation(Class,SEL);
extern const char *method_getTypeEncoding(Method);
extern IMP method_getImplementation(Method);
extern IMP method_setImplementation(Method,IMP);
extern unsigned int method_getNumberOfArguments(Method);
extern void method_getReturnType(Method,char *,size_t);
extern BOOL class_addMethod(Class,SEL,IMP,const char *);
extern SEL NSSelectorFromString(NSString *);
extern id objc_msgSend(id,SEL,...);
extern int strcmp(const char *,const char *);
extern CGPoint CGPointMake(CGFloat,CGFloat);
extern CGRect CGRectMake(CGFloat,CGFloat,CGFloat,CGFloat);
extern dispatch_queue_t dispatch_get_main_queue(void);
extern dispatch_time_t dispatch_time(dispatch_time_t,int64_t);
extern void dispatch_after(dispatch_time_t,dispatch_queue_t,void (^)(void));
