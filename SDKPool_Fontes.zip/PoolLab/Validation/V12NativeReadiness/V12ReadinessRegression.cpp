
#include <cstdint>
#include <cstring>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
using BOOL = bool;
constexpr BOOL YES = true;
constexpr BOOL NO = false;
struct NSError { int code; };
struct Mock;
using id = Mock *;
struct Mock {
    std::string kind;
    std::map<std::string,bool> values;
    std::set<std::string> unavailableMethods, unavailableReads;
    std::map<std::string,int> calls;
    bool spectator=false, turnEnded=false, blocked=false;
    uint64_t touches=0;
    uint32_t number=0;
    uintptr_t cacherOwner=0;
    bool hasCacher=true;
};
static NSError lastError{};
static bool releaseAvailable=true;
static BOOL PLFail(NSError **error, int code, const char *) {
    lastError.code=code; if (error) *error=&lastError; return NO;
}
static BOOL PLCheckMethod(id object, const char *name, const char *, NSError **error) {
    if (!object || object->unavailableMethods.count(name)) return PLFail(error,900,"missing method");
    return YES;
}
static BOOL PLBool(id object, const char *name) {
    ++object->calls[name]; return object->values.at(name);
}
static BOOL PLRead(id object,const char *,const char *name,const char *,void *out,size_t length,NSError **error) {
    if (object->unavailableReads.count(name)) return PLFail(error,901,"missing read");
    const void *value=nullptr; size_t size=0; void *cacher=nullptr;
    if (!std::strcmp(name,"_spectatorMode")) { value=&object->spectator; size=sizeof(bool); }
    else if (!std::strcmp(name,"mPlayerTurnTimeFinished")) { value=&object->turnEnded; size=sizeof(bool); }
    else if (!std::strcmp(name,"mNumCurrentTouches")) { value=&object->touches; size=sizeof(uint64_t); }
    else if (!std::strcmp(name,"number")) { value=&object->number; size=sizeof(uint32_t); }
    else if (!std::strcmp(name,"_cacher")) { cacher=object->hasCacher ? &object->cacherOwner : nullptr; value=&cacher; size=sizeof(void *); }
    if (!value || size!=length) return PLFail(error,902,"invalid fixture read");
    std::memcpy(out,value,length); return YES;
}
static id PLReadObject(id object,const char *,const char *name,const char *,NSError **error) {
    if (object->unavailableReads.count(name)) { PLFail(error,901,"missing read"); return nullptr; }
    return object->blocked ? object : nullptr;
}
static void *PLShotReleaseFunction() { return releaseAvailable ? reinterpret_cast<void *>(1) : nullptr; }
static BOOL PLCopyMemory(uintptr_t source,void *out,size_t length) {
    std::memcpy(out,reinterpret_cast<void *>(source),length); return YES;
}

static BOOL PLReadyToPlanV11(id manager, id cue, const std::vector<id> &sourceBalls, BOOL pendingNomination, NSError **error) {
    for (const char *name : std::vector<const char *>{"isPlayerTurn", "isWaitingForPlayerShot", "isGameStarted",
                            "isInGamePopUp", "visualCueBallControlInputIsActive", "visualEnglishControlIsActive"}) {
        if (!PLCheckMethod(manager, name, "B16@0:8", error)) return NO;
    }
    if (!PLBool(manager, "isGameStarted")) return PLFail(error, 41, "Aguardando o início da partida.");
    if (!PLBool(manager, "isPlayerTurn")) return PLFail(error, 41, "Aguardando a vez do adversário terminar.");
    if (!PLBool(manager, "isWaitingForPlayerShot")) return PLFail(error, 41, "Aguardando o jogo liberar a próxima tacada.");
    BOOL spectator = YES, turnEnded = YES;
    uint64_t touches = 0;
    if (!PLRead(manager, "GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), error) ||
        !PLRead(manager, "GameManager", "mPlayerTurnTimeFinished", "B", &turnEnded, sizeof(turnEnded), error) ||
        !PLRead(manager, "GameManager", "mNumCurrentTouches", "Q", &touches, sizeof(touches), error)) return NO;
    if (spectator) return PLFail(error, 58, "A partida está em modo espectador.");
    if (turnEnded) return PLFail(error, 58, "O tempo desta vez terminou.");
    if (touches) return PLFail(error, 58, "Solte os controles da mesa para liberar o automático.");
    if (PLBool(manager, "isInGamePopUp")) return PLFail(error, 58, "Feche o aviso aberto pelo jogo.");
    if (PLBool(manager, "visualCueBallControlInputIsActive")) return PLFail(error, 58, "Conclua o posicionamento da bola branca.");
    if (PLBool(manager, "visualEnglishControlIsActive")) return PLFail(error, 58, "Feche o controle de efeito do taco.");
    id blocker = PLReadObject(manager, "GameManager", "_inputBlocker", "@\"InputBlocker\"", error);
    if (error && *error) return NO;
    if (blocker) return PLFail(error, 63, "O jogo pausou os controles da mesa.");
    for (const char *name : std::vector<const char *>{"enabled", "inputActive", "hasTouches", "isAnimatingAimAngle", "isAnimatingPower"})
        if (!PLCheckMethod(cue, name, "B16@0:8", error)) return NO;
    if (PLBool(cue, "hasTouches") || PLBool(cue, "isAnimatingAimAngle") || PLBool(cue, "isAnimatingPower"))
        return PLFail(error, 59, "Aguarde a mira terminar de se mover.");
    if (!pendingNomination && (!PLBool(cue, "enabled") || !PLBool(cue, "inputActive")))
        return PLFail(error, 45, "O jogo ainda não liberou o taco.");
    BOOL hasCue = NO;
    for (id ball : sourceBalls) {
        if (!PLCheckMethod(ball, "isMovingOrSpinning", "B16@0:8", error) ||
            !PLCheckMethod(ball, "onTable", "B16@0:8", error)) return NO;
        if (PLBool(ball, "isMovingOrSpinning"))
            return PLFail(error, 42, "Aguarde todas as bolas pararem.");
        uint32_t number = 0;
        if (!PLRead(ball, "Ball", "number", "I", &number, sizeof(number), error)) return NO;
        if (number == 0 && PLBool(ball, "onTable")) hasCue = YES;
    }
    if (!hasCue) return PLFail(error, 43, "Reposicione a bola branca antes da tacada.");
    if (!PLShotReleaseFunction()) return PLFail(error, 60, "O disparo não corresponde ao build verificado.");
    void *cacher = NULL; uintptr_t owner = 0;
    if (!PLRead(manager, "GameManager", "_cacher", "^{GameManagerCacher=@}", &cacher, sizeof(cacher), error) ||
        !cacher || !PLCopyMemory((uintptr_t)cacher, &owner, sizeof(owner)) || owner != (uintptr_t)(void *)manager)
        return PLFail(error, 61, "O controle de tacadas ainda não está disponível.");
    return YES;
}
static BOOL PLReadyToPlanV12(id manager, id cue, const std::vector<id> &sourceBalls, BOOL pendingNomination, NSError **error) {
    for (const char *name : std::vector<const char *>{"isPlayerTurn", "isWaitingForPlayerShot", "isGameStarted",
                            "isInGamePopUp", "visualCueBallControlInputIsActive", "visualEnglishControlIsActive"}) {
        if (!PLCheckMethod(manager, name, "B16@0:8", error)) return NO;
    }
    if (!PLBool(manager, "isGameStarted")) return PLFail(error, 41, "Aguardando o início da partida.");
    if (!PLBool(manager, "isPlayerTurn")) return PLFail(error, 41, "Aguardando a vez do adversário terminar.");
    if (!PLBool(manager, "isWaitingForPlayerShot")) return PLFail(error, 41, "Aguardando o jogo liberar a próxima tacada.");
    BOOL spectator = YES, turnEnded = YES;
    uint64_t touches = 0;
    if (!PLRead(manager, "GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), error) ||
        !PLRead(manager, "GameManager", "mPlayerTurnTimeFinished", "B", &turnEnded, sizeof(turnEnded), error) ||
        !PLRead(manager, "GameManager", "mNumCurrentTouches", "Q", &touches, sizeof(touches), error)) return NO;
    if (spectator) return PLFail(error, 58, "A partida está em modo espectador.");
    if (turnEnded) return PLFail(error, 58, "O tempo desta vez terminou.");
    if (touches) return PLFail(error, 58, "Solte os controles da mesa para liberar o automático.");
    if (PLBool(manager, "isInGamePopUp")) return PLFail(error, 58, "Feche o aviso aberto pelo jogo.");
    if (PLBool(manager, "visualCueBallControlInputIsActive")) return PLFail(error, 58, "Conclua o posicionamento da bola branca.");
    if (PLBool(manager, "visualEnglishControlIsActive")) return PLFail(error, 58, "Feche o controle de efeito do taco.");
    id blocker = PLReadObject(manager, "GameManager", "_inputBlocker", "@\"InputBlocker\"", error);
    if (error && *error) return NO;
    if (blocker) return PLFail(error, 63, "O jogo pausou os controles da mesa.");
    for (const char *name : std::vector<const char *>{"enabled", "inputActive", "hasTouches", "isAnimatingAimAngle", "isAnimatingPower"})
        if (!PLCheckMethod(cue, name, "B16@0:8", error)) return NO;
    if (PLBool(cue, "hasTouches") || PLBool(cue, "isAnimatingAimAngle") || PLBool(cue, "isAnimatingPower"))
        return PLFail(error, 59, "Aguarde a mira terminar de se mover.");
    if (!pendingNomination && (!PLBool(cue, "enabled") || !PLBool(cue, "inputActive")))
        return PLFail(error, 45, "O jogo ainda não liberou o taco.");
    BOOL hasCue = NO;
    for (id ball : sourceBalls) {
        if (!PLCheckMethod(ball, "isMovingOrSpinning", "B16@0:8", error) ||
            !PLCheckMethod(ball, "onTable", "B16@0:8", error)) return NO;
        // Off-table balls can remain in mBalls. Their raw velocity/spin may remain
        // nonzero because the native cloth update skips balls off the table.
        // Match the active-ball scope used by capture and legal-target lookup;
        // native turn/input readiness above still gates every action.
        if (!PLBool(ball, "onTable")) continue;
        if (PLBool(ball, "isMovingOrSpinning"))
            return PLFail(error, 42, "Aguarde todas as bolas pararem.");
        uint32_t number = 0;
        if (!PLRead(ball, "Ball", "number", "I", &number, sizeof(number), error)) return NO;
        if (number == 0) hasCue = YES;
    }
    if (!hasCue) return PLFail(error, 43, "Reposicione a bola branca antes da tacada.");
    if (!PLShotReleaseFunction()) return PLFail(error, 60, "O disparo não corresponde ao build verificado.");
    void *cacher = NULL; uintptr_t owner = 0;
    if (!PLRead(manager, "GameManager", "_cacher", "^{GameManagerCacher=@}", &cacher, sizeof(cacher), error) ||
        !cacher || !PLCopyMemory((uintptr_t)cacher, &owner, sizeof(owner)) || owner != (uintptr_t)(void *)manager)
        return PLFail(error, 61, "O controle de tacadas ainda não está disponível.");
    return YES;
}

struct Fixture {
    Mock manager, cue;
    Mock white, red, blue;
    std::vector<id> balls;
    bool pendingNomination=false;
    Fixture() {
        releaseAvailable=true;
        manager.kind="manager";
        manager.values={{"isPlayerTurn",true},{"isWaitingForPlayerShot",true},{"isGameStarted",true},
            {"isInGamePopUp",false},{"visualCueBallControlInputIsActive",false},{"visualEnglishControlIsActive",false}};
        manager.cacherOwner=reinterpret_cast<uintptr_t>(&manager);
        cue.kind="cue";
        cue.values={{"enabled",true},{"inputActive",true},{"hasTouches",false},{"isAnimatingAimAngle",false},{"isAnimatingPower",false}};
        for (auto *ball : {&white,&red,&blue}) {
            ball->kind="ball";
            ball->values={{"onTable",true},{"isMovingOrSpinning",false}};
        }
        white.number=0; red.number=1; blue.number=2;
        balls={&white,&red,&blue};
    }
};
using Ready=BOOL(*)(id,id,const std::vector<id>&,BOOL,NSError**);
static int failures=0, checks=0;
static void check(const std::string &name,bool actual) {
    ++checks; if (!actual) ++failures;
    std::cout << (actual ? "PASS" : "FAIL") << "\t" << name << "\n";
}
static void scenario(const std::string &name,const std::function<void(Fixture&)> &configure,
                     bool expected,int errorCode,Ready function) {
    Fixture fixture; configure(fixture); NSError *error=nullptr;
    bool actual=function(&fixture.manager,&fixture.cue,fixture.balls,fixture.pendingNomination,&error);
    check(name,actual==expected && (expected ? !error : error && error->code==errorCode));
}
int main() {
    auto keep=[](Fixture&){};
    scenario("V11.initial.stationary.ready",keep,true,0,PLReadyToPlanV11);
    scenario("V12.initial.stationary.ready",keep,true,0,PLReadyToPlanV12);
    auto potted=[](Fixture& f){ f.red.values["onTable"]=false; f.red.values["isMovingOrSpinning"]=true; };
    scenario("V11.post-pot.residual-motion.reproduces-block",potted,false,42,PLReadyToPlanV11);
    scenario("V12.post-pot.residual-motion.ready",potted,true,0,PLReadyToPlanV12);
    scenario("V12.post-pot.off-table-spin.ready",potted,true,0,PLReadyToPlanV12);
    scenario("V12.on-table.motion.blocks",[](Fixture& f){ f.red.values["isMovingOrSpinning"]=true; },false,42,PLReadyToPlanV12);
    scenario("V12.on-table.spin.blocks",[](Fixture& f){ f.blue.values["isMovingOrSpinning"]=true; },false,42,PLReadyToPlanV12);
    scenario("V12.potted-white.blocks",[](Fixture& f){ f.white.values["onTable"]=false; f.white.values["isMovingOrSpinning"]=true; },false,43,PLReadyToPlanV12);
    scenario("V12.missing-white.blocks",[](Fixture& f){ f.balls.erase(f.balls.begin()); },false,43,PLReadyToPlanV12);
    scenario("V12.started.guard",[](Fixture& f){ f.manager.values["isGameStarted"]=false; },false,41,PLReadyToPlanV12);
    scenario("V12.opponent.guard",[](Fixture& f){ f.manager.values["isPlayerTurn"]=false; },false,41,PLReadyToPlanV12);
    scenario("V12.waiting-shot.guard",[](Fixture& f){ f.manager.values["isWaitingForPlayerShot"]=false; },false,41,PLReadyToPlanV12);
    scenario("V12.spectator.guard",[](Fixture& f){ f.manager.spectator=true; },false,58,PLReadyToPlanV12);
    scenario("V12.turn-ended.guard",[](Fixture& f){ f.manager.turnEnded=true; },false,58,PLReadyToPlanV12);
    scenario("V12.table-touch.guard",[](Fixture& f){ f.manager.touches=1; },false,58,PLReadyToPlanV12);
    scenario("V12.popup.guard",[](Fixture& f){ f.manager.values["isInGamePopUp"]=true; },false,58,PLReadyToPlanV12);
    scenario("V12.ball-in-hand.guard",[](Fixture& f){ f.manager.values["visualCueBallControlInputIsActive"]=true; },false,58,PLReadyToPlanV12);
    scenario("V12.english-input.guard",[](Fixture& f){ f.manager.values["visualEnglishControlIsActive"]=true; },false,58,PLReadyToPlanV12);
    scenario("V12.input-blocker.guard",[](Fixture& f){ f.manager.blocked=true; },false,63,PLReadyToPlanV12);
    scenario("V12.cue-touch.guard",[](Fixture& f){ f.cue.values["hasTouches"]=true; },false,59,PLReadyToPlanV12);
    scenario("V12.aim-animation.guard",[](Fixture& f){ f.cue.values["isAnimatingAimAngle"]=true; },false,59,PLReadyToPlanV12);
    scenario("V12.power-animation.guard",[](Fixture& f){ f.cue.values["isAnimatingPower"]=true; },false,59,PLReadyToPlanV12);
    scenario("V12.cue-disabled.guard",[](Fixture& f){ f.cue.values["enabled"]=false; },false,45,PLReadyToPlanV12);
    scenario("V12.cue-input-inactive.guard",[](Fixture& f){ f.cue.values["inputActive"]=false; },false,45,PLReadyToPlanV12);
    scenario("V12.pending-nomination-allows-disabled-cue",[](Fixture& f){ f.pendingNomination=true; f.cue.values["inputActive"]=false; f.cue.values["enabled"]=false; },true,0,PLReadyToPlanV12);
    scenario("V12.pending-nomination-still-blocks-motion",[](Fixture& f){ f.pendingNomination=true; f.blue.values["isMovingOrSpinning"]=true; },false,42,PLReadyToPlanV12);
    scenario("V12.release-fingerprint.guard",[](Fixture&){ releaseAvailable=false; },false,60,PLReadyToPlanV12);
    scenario("V12.missing-cacher.guard",[](Fixture& f){ f.manager.hasCacher=false; },false,61,PLReadyToPlanV12);
    scenario("V12.wrong-cacher-owner.guard",[](Fixture& f){ f.manager.cacherOwner=123; },false,61,PLReadyToPlanV12);
    scenario("V12.manager-method-unavailable.guard",[](Fixture& f){ f.manager.unavailableMethods.insert("isPlayerTurn"); },false,900,PLReadyToPlanV12);
    scenario("V12.ball-method-unavailable.guard",[](Fixture& f){ f.red.unavailableMethods.insert("onTable"); },false,900,PLReadyToPlanV12);
    scenario("V12.ball-motion-method-unavailable.guard",[](Fixture& f){ f.red.unavailableMethods.insert("isMovingOrSpinning"); },false,900,PLReadyToPlanV12);
    scenario("V12.cue-method-unavailable.guard",[](Fixture& f){ f.cue.unavailableMethods.insert("inputActive"); },false,900,PLReadyToPlanV12);
    scenario("V12.manager-ivar-unavailable.guard",[](Fixture& f){ f.manager.unavailableReads.insert("mNumCurrentTouches"); },false,901,PLReadyToPlanV12);
    scenario("V12.ball-number-unavailable.guard",[](Fixture& f){ f.red.unavailableReads.insert("number"); },false,901,PLReadyToPlanV12);
    scenario("V12.blocker-read-error.guard",[](Fixture& f){ f.manager.unavailableReads.insert("_inputBlocker"); },false,901,PLReadyToPlanV12);
    {
        Fixture f; NSError *error=nullptr;
        f.red.values["onTable"]=false; f.red.values["isMovingOrSpinning"]=true;
        check("V12.off-table-dynamics-not-read",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error) && f.red.calls["isMovingOrSpinning"]==0);
    }
    {
        Fixture f; NSError *error=nullptr;
        check("V12.sequence.before-first-shot",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        f.red.values["isMovingOrSpinning"]=true;
        check("V12.sequence.first-shot-motion-blocked",!PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        error=nullptr; f.red.values["onTable"]=false;
        check("V12.sequence.after-first-pot",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        f.blue.values["isMovingOrSpinning"]=true;
        check("V12.sequence.second-shot-motion-blocked",!PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        error=nullptr; f.blue.values["onTable"]=false;
        check("V12.sequence.after-second-pot",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        f.manager.values["isPlayerTurn"]=false;
        check("V12.sequence.opponent-turn-blocked",!PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        error=nullptr; f.manager.values["isPlayerTurn"]=true;
        check("V12.sequence.returned-turn-ready",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
    }
    std::cout<<"TOTAL\t"<<checks<<"\t"<<failures<<"\n";
    return failures ? 1 : 0;
}
