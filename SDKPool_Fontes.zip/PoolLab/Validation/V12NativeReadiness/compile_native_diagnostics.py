#!/usr/bin/env python3
"""Arm64 ARC syntax/type check of the exact changed native declarations/blocks."""
from pathlib import Path
import hashlib
import json
import subprocess
from run_readiness_regression import ROOT, HERE, PROJECT, CLANG, gate

def h(v):
    return hashlib.sha256(v).hexdigest()

source = (PROJECT / "Integrated/PLRuntimeBridge.m").read_text()
declarations = r'''
typedef signed char BOOL;
typedef long NSInteger;
typedef unsigned long NSUInteger;
typedef double NSTimeInterval;
typedef unsigned long long uint64_t;
typedef unsigned long uintptr_t;
typedef unsigned int uint32_t;
typedef int int32_t;
typedef unsigned long size_t;
typedef struct { double x; double y; } CGPoint;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define NULL ((void *)0)
#define nil ((id)0)
__attribute__((objc_root_class)) @interface NSObject
+ (Class)class;
- (BOOL)isKindOfClass:(Class)klass;
@end
@interface NSString : NSObject
+ (instancetype)stringWithFormat:(NSString *)format, ...;
- (instancetype)stringByAppendingString:(NSString *)string;
@end
@interface NSNumber : NSObject
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end
@interface NSError : NSObject
@property(nonatomic,readonly) NSInteger code;
@property(nonatomic,readonly) NSString *localizedDescription;
@end
typedef struct { unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5]; } NSFastEnumerationState;
@interface NSArray<__covariant ObjectType> : NSObject
@property(nonatomic,readonly) NSUInteger count;
+ (instancetype)array;
+ (id)arrayWithObjects:(const id[])objects count:(unsigned long)count;
- (unsigned long)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(unsigned long)count;
- (NSString *)componentsJoinedByString:(NSString *)separator;
@end
@interface NSMutableArray<ObjectType> : NSArray<ObjectType>
- (void)addObject:(ObjectType)object;
@end
@interface NSDictionary<__covariant KeyType,__covariant ObjectType> : NSObject
+ (instancetype)dictionary;
@end
@interface NSMutableDictionary<KeyType,ObjectType> : NSDictionary<KeyType,ObjectType>
- (void)setObject:(ObjectType)object forKeyedSubscript:(KeyType)key;
- (void)addEntriesFromDictionary:(NSDictionary *)dictionary;
@end
@interface NSValue : NSObject @end
@interface UIView : NSObject @end
@interface PLBallSnapshot : NSObject @end
@interface PLGameSnapshot : NSObject @end
extern BOOL PLCheckMethod(id,NSString*,const char*,NSError**);
extern BOOL PLBool(id,NSString*);
extern BOOL PLFail(NSError**,NSInteger,NSString*);
extern BOOL PLRead(id,NSString*,const char*,const char*,void*,size_t,NSError**);
extern id PLReadObject(id,NSString*,const char*,const char*,NSError**);
extern void *PLShotReleaseFunction(void);
extern BOOL PLCopyMemory(uintptr_t,void*,size_t);
extern BOOL PLReadCue(id,id*,double*,double*,NSError**);
extern double PLMinimumShotPower(id);
extern BOOL PLReadSelectedEnglish(id,double[2],NSError**);
extern BOOL PLCenteredEnglish(const double[2]);
'''
start = source.index("@interface PLGameSnapshot ()")
end = source.index("@end", start) + len("@end")
snapshot = source[start:end]
rules_end = source.index("} PLRulesInfo;") + len("} PLRulesInfo;")
rules_start = source.rfind("typedef struct {", 0, rules_end)
rules = source[rules_start:rules_end]
functions = {marker: gate.block(source, marker) for marker in [
    "static BOOL PLReadyToPlan(",
    "static NSDictionary<NSString *, NSString *> *PLInputDiagnostics(",
    "static void PLFillControls(",
]}
diagnostics = "\n".join(line for line in source.splitlines() if
                        'diagnostics[@"nativeReadinessCode"]' in line or
                        '[diagnostics addEntriesFromDictionary:PLInputDiagnostics(' in line)
assert len(diagnostics.splitlines()) == 2
golden_line = next(line for line in source.splitlines() if "result.nativeReadinessErrorCode = 77;" in line)
fixture = declarations + "\n" + snapshot + "\n" + rules
fixture += "\nextern BOOL PLRules(id,id,PLRulesInfo*,NSError**);\n"
fixture += "\n\n".join(functions.values())
fixture += '\nstatic void PLCheckCaptureDiagnostics(id manager,NSArray *sourceBalls,PLGameSnapshot *result,NSMutableDictionary<NSString *,NSString *> *diagnostics,BOOL goldenShot) {\n'
fixture += diagnostics + "\n    if (goldenShot) {\n" + golden_line + "\n    }\n}\n"
fixture_path = HERE / "V12NativeDiagnosticsSyntax.m"
fixture_path.write_text(fixture)
command = [str(CLANG), "-target", "arm64-apple-ios15.0", "-fobjc-arc", "-fsyntax-only", "-Werror", "-Werror=incompatible-pointer-types", str(fixture_path)]
result = subprocess.run(command, capture_output=True, text=True)
(HERE / "V12NativeDiagnosticsCompile.txt").write_text(result.stdout + result.stderr)
report = {
    "format":"SDKPool.V12.NativeDiagnosticsCompile",
    "result":"passed" if result.returncode == 0 else "failed",
    "sourceSHA256":{"Integrated/PLRuntimeBridge.m":h(source.encode())},
    "extractedBlockSHA256":{name:h(block.encode()) for name,block in functions.items()},
    "snapshotPropertiesSHA256":h(snapshot.encode()),
    "diagnosticsStatementsSHA256":h(diagnostics.encode()),
    "goldenShotStatementSHA256":h(golden_line.encode()),
    "fixtureSHA256":h(fixture.encode()),
    "validatorSHA256":h(Path(__file__).read_bytes()),
    "command":command,
    "exitCode":result.returncode,
    "limits":["Exact production functions/declarations and changed capture statements; declaration-only Foundation/native stubs.","No Apple SDK build/link, Objective-C runtime execution, game or iPhone test."]
}
(HERE / "V12NativeDiagnosticsCompile.json").write_text(json.dumps(report,indent=2) + "\n")
print(result.stdout + result.stderr,end="")
print(json.dumps({"result":report["result"],"exitCode":result.returncode}))
raise SystemExit(result.returncode)
