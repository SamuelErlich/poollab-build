#!/usr/bin/env python3
"""Execute native readiness branches from V11 and final V12 sources.

ObjC fast enumeration and object literals are mechanically lowered for a C++
fixture with native accessors mocked. The unchanged ObjC function is separately
syntax-compiled for arm64 iOS. This is not a native runtime/device test.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PROJECT = ROOT / "new_project/PoolLab"
BASELINE = ROOT / "new_project/validation/v11_before_v12/SDKPool_Fontes.zip"
BRIDGE = PROJECT / "Integrated/PLRuntimeBridge.m"
CLANG = ROOT / "new_project/validation/v11_runtime/swift-5.10.1-RELEASE-ubuntu24.04/usr/bin/clang"
spec = importlib.util.spec_from_file_location("v11gate", HERE.parent / "v11_runtime/validate_v11_sources.py")
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)

def digest(value):
    return hashlib.sha256(value).hexdigest()

def lower(value, suffix):
    # These substitutions are limited to language syntax. No conditional,
    # statement ordering, failure, accessor, or value is inserted/removed.
    value = value.replace("PLReadyToPlan(", "PLReadyToPlan" + suffix + "(", 1)
    value, arrays = re.subn(r'for \(NSString \*name in @\[(.*?)\]\)',
                           lambda m: "for (const char *name : std::vector<const char *>{" + m.group(1) + "})",
                           value, flags=re.S)
    assert arrays == 2, arrays
    assert value.count("for (id ball in sourceBalls)") == 1
    value = value.replace("for (id ball in sourceBalls)", "for (id ball : sourceBalls)")
    assert value.count("NSArray *sourceBalls") == 1
    value = value.replace("NSArray *sourceBalls", "const std::vector<id> &sourceBalls")
    value = value.replace('@"', '"').replace("(__bridge void *)", "(void *)")
    return value

CPP_PREFIX = r'''
#include <cstdint>
#include <cstring>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
using BOOL = bool;
constexpr BOOL YES = true;
constexpr BOOL NO = false;
struct NSError { int code; };
struct Mock;
using id = Mock *;
struct Mock {
    std::string kind;
    std::map<std::string,bool> values;
    std::set<std::string> unavailableMethods, unavailableReads;
    std::map<std::string,int> calls;
    bool spectator=false, turnEnded=false, blocked=false;
    uint64_t touches=0;
    uint32_t number=0;
    uintptr_t cacherOwner=0;
    bool hasCacher=true;
};
static NSError lastError{};
static bool releaseAvailable=true;
static BOOL PLFail(NSError **error, int code, const char *) {
    lastError.code=code; if (error) *error=&lastError; return NO;
}
static BOOL PLCheckMethod(id object, const char *name, const char *, NSError **error) {
    if (!object || object->unavailableMethods.count(name)) return PLFail(error,900,"missing method");
    return YES;
}
static BOOL PLBool(id object, const char *name) {
    ++object->calls[name]; return object->values.at(name);
}
static BOOL PLRead(id object,const char *,const char *name,const char *,void *out,size_t length,NSError **error) {
    if (object->unavailableReads.count(name)) return PLFail(error,901,"missing read");
    const void *value=nullptr; size_t size=0; void *cacher=nullptr;
    if (!std::strcmp(name,"_spectatorMode")) { value=&object->spectator; size=sizeof(bool); }
    else if (!std::strcmp(name,"mPlayerTurnTimeFinished")) { value=&object->turnEnded; size=sizeof(bool); }
    else if (!std::strcmp(name,"mNumCurrentTouches")) { value=&object->touches; size=sizeof(uint64_t); }
    else if (!std::strcmp(name,"number")) { value=&object->number; size=sizeof(uint32_t); }
    else if (!std::strcmp(name,"_cacher")) { cacher=object->hasCacher ? &object->cacherOwner : nullptr; value=&cacher; size=sizeof(void *); }
    if (!value || size!=length) return PLFail(error,902,"invalid fixture read");
    std::memcpy(out,value,length); return YES;
}
static id PLReadObject(id object,const char *,const char *name,const char *,NSError **error) {
    if (object->unavailableReads.count(name)) { PLFail(error,901,"missing read"); return nullptr; }
    return object->blocked ? object : nullptr;
}
static void *PLShotReleaseFunction() { return releaseAvailable ? reinterpret_cast<void *>(1) : nullptr; }
static BOOL PLCopyMemory(uintptr_t source,void *out,size_t length) {
    std::memcpy(out,reinterpret_cast<void *>(source),length); return YES;
}
'''

CPP_TESTS = r'''
struct Fixture {
    Mock manager, cue;
    Mock white, red, blue;
    std::vector<id> balls;
    bool pendingNomination=false;
    Fixture() {
        releaseAvailable=true;
        manager.kind="manager";
        manager.values={{"isPlayerTurn",true},{"isWaitingForPlayerShot",true},{"isGameStarted",true},
            {"isInGamePopUp",false},{"visualCueBallControlInputIsActive",false},{"visualEnglishControlIsActive",false}};
        manager.cacherOwner=reinterpret_cast<uintptr_t>(&manager);
        cue.kind="cue";
        cue.values={{"enabled",true},{"inputActive",true},{"hasTouches",false},{"isAnimatingAimAngle",false},{"isAnimatingPower",false}};
        for (auto *ball : {&white,&red,&blue}) {
            ball->kind="ball";
            ball->values={{"onTable",true},{"isMovingOrSpinning",false}};
        }
        white.number=0; red.number=1; blue.number=2;
        balls={&white,&red,&blue};
    }
};
using Ready=BOOL(*)(id,id,const std::vector<id>&,BOOL,NSError**);
static int failures=0, checks=0;
static void check(const std::string &name,bool actual) {
    ++checks; if (!actual) ++failures;
    std::cout << (actual ? "PASS" : "FAIL") << "\t" << name << "\n";
}
static void scenario(const std::string &name,const std::function<void(Fixture&)> &configure,
                     bool expected,int errorCode,Ready function) {
    Fixture fixture; configure(fixture); NSError *error=nullptr;
    bool actual=function(&fixture.manager,&fixture.cue,fixture.balls,fixture.pendingNomination,&error);
    check(name,actual==expected && (expected ? !error : error && error->code==errorCode));
}
int main() {
    auto keep=[](Fixture&){};
    scenario("V11.initial.stationary.ready",keep,true,0,PLReadyToPlanV11);
    scenario("V12.initial.stationary.ready",keep,true,0,PLReadyToPlanV12);
    auto potted=[](Fixture& f){ f.red.values["onTable"]=false; f.red.values["isMovingOrSpinning"]=true; };
    scenario("V11.post-pot.residual-motion.reproduces-block",potted,false,42,PLReadyToPlanV11);
    scenario("V12.post-pot.residual-motion.ready",potted,true,0,PLReadyToPlanV12);
    scenario("V12.post-pot.off-table-spin.ready",potted,true,0,PLReadyToPlanV12);
    scenario("V12.on-table.motion.blocks",[](Fixture& f){ f.red.values["isMovingOrSpinning"]=true; },false,42,PLReadyToPlanV12);
    scenario("V12.on-table.spin.blocks",[](Fixture& f){ f.blue.values["isMovingOrSpinning"]=true; },false,42,PLReadyToPlanV12);
    scenario("V12.potted-white.blocks",[](Fixture& f){ f.white.values["onTable"]=false; f.white.values["isMovingOrSpinning"]=true; },false,43,PLReadyToPlanV12);
    scenario("V12.missing-white.blocks",[](Fixture& f){ f.balls.erase(f.balls.begin()); },false,43,PLReadyToPlanV12);
    scenario("V12.started.guard",[](Fixture& f){ f.manager.values["isGameStarted"]=false; },false,41,PLReadyToPlanV12);
    scenario("V12.opponent.guard",[](Fixture& f){ f.manager.values["isPlayerTurn"]=false; },false,41,PLReadyToPlanV12);
    scenario("V12.waiting-shot.guard",[](Fixture& f){ f.manager.values["isWaitingForPlayerShot"]=false; },false,41,PLReadyToPlanV12);
    scenario("V12.spectator.guard",[](Fixture& f){ f.manager.spectator=true; },false,58,PLReadyToPlanV12);
    scenario("V12.turn-ended.guard",[](Fixture& f){ f.manager.turnEnded=true; },false,58,PLReadyToPlanV12);
    scenario("V12.table-touch.guard",[](Fixture& f){ f.manager.touches=1; },false,58,PLReadyToPlanV12);
    scenario("V12.popup.guard",[](Fixture& f){ f.manager.values["isInGamePopUp"]=true; },false,58,PLReadyToPlanV12);
    scenario("V12.ball-in-hand.guard",[](Fixture& f){ f.manager.values["visualCueBallControlInputIsActive"]=true; },false,58,PLReadyToPlanV12);
    scenario("V12.english-input.guard",[](Fixture& f){ f.manager.values["visualEnglishControlIsActive"]=true; },false,58,PLReadyToPlanV12);
    scenario("V12.input-blocker.guard",[](Fixture& f){ f.manager.blocked=true; },false,63,PLReadyToPlanV12);
    scenario("V12.cue-touch.guard",[](Fixture& f){ f.cue.values["hasTouches"]=true; },false,59,PLReadyToPlanV12);
    scenario("V12.aim-animation.guard",[](Fixture& f){ f.cue.values["isAnimatingAimAngle"]=true; },false,59,PLReadyToPlanV12);
    scenario("V12.power-animation.guard",[](Fixture& f){ f.cue.values["isAnimatingPower"]=true; },false,59,PLReadyToPlanV12);
    scenario("V12.cue-disabled.guard",[](Fixture& f){ f.cue.values["enabled"]=false; },false,45,PLReadyToPlanV12);
    scenario("V12.cue-input-inactive.guard",[](Fixture& f){ f.cue.values["inputActive"]=false; },false,45,PLReadyToPlanV12);
    scenario("V12.pending-nomination-allows-disabled-cue",[](Fixture& f){ f.pendingNomination=true; f.cue.values["inputActive"]=false; f.cue.values["enabled"]=false; },true,0,PLReadyToPlanV12);
    scenario("V12.pending-nomination-still-blocks-motion",[](Fixture& f){ f.pendingNomination=true; f.blue.values["isMovingOrSpinning"]=true; },false,42,PLReadyToPlanV12);
    scenario("V12.release-fingerprint.guard",[](Fixture&){ releaseAvailable=false; },false,60,PLReadyToPlanV12);
    scenario("V12.missing-cacher.guard",[](Fixture& f){ f.manager.hasCacher=false; },false,61,PLReadyToPlanV12);
    scenario("V12.wrong-cacher-owner.guard",[](Fixture& f){ f.manager.cacherOwner=123; },false,61,PLReadyToPlanV12);
    scenario("V12.manager-method-unavailable.guard",[](Fixture& f){ f.manager.unavailableMethods.insert("isPlayerTurn"); },false,900,PLReadyToPlanV12);
    scenario("V12.ball-method-unavailable.guard",[](Fixture& f){ f.red.unavailableMethods.insert("onTable"); },false,900,PLReadyToPlanV12);
    scenario("V12.ball-motion-method-unavailable.guard",[](Fixture& f){ f.red.unavailableMethods.insert("isMovingOrSpinning"); },false,900,PLReadyToPlanV12);
    scenario("V12.cue-method-unavailable.guard",[](Fixture& f){ f.cue.unavailableMethods.insert("inputActive"); },false,900,PLReadyToPlanV12);
    scenario("V12.manager-ivar-unavailable.guard",[](Fixture& f){ f.manager.unavailableReads.insert("mNumCurrentTouches"); },false,901,PLReadyToPlanV12);
    scenario("V12.ball-number-unavailable.guard",[](Fixture& f){ f.red.unavailableReads.insert("number"); },false,901,PLReadyToPlanV12);
    scenario("V12.blocker-read-error.guard",[](Fixture& f){ f.manager.unavailableReads.insert("_inputBlocker"); },false,901,PLReadyToPlanV12);
    {
        Fixture f; NSError *error=nullptr;
        f.red.values["onTable"]=false; f.red.values["isMovingOrSpinning"]=true;
        check("V12.off-table-dynamics-not-read",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error) && f.red.calls["isMovingOrSpinning"]==0);
    }
    {
        Fixture f; NSError *error=nullptr;
        check("V12.sequence.before-first-shot",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        f.red.values["isMovingOrSpinning"]=true;
        check("V12.sequence.first-shot-motion-blocked",!PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        error=nullptr; f.red.values["onTable"]=false;
        check("V12.sequence.after-first-pot",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        f.blue.values["isMovingOrSpinning"]=true;
        check("V12.sequence.second-shot-motion-blocked",!PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        error=nullptr; f.blue.values["onTable"]=false;
        check("V12.sequence.after-second-pot",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        f.manager.values["isPlayerTurn"]=false;
        check("V12.sequence.opponent-turn-blocked",!PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
        error=nullptr; f.manager.values["isPlayerTurn"]=true;
        check("V12.sequence.returned-turn-ready",PLReadyToPlanV12(&f.manager,&f.cue,f.balls,false,&error));
    }
    std::cout<<"TOTAL\t"<<checks<<"\t"<<failures<<"\n";
    return failures ? 1 : 0;
}
'''

OBJC_PREFIX = r'''
typedef signed char BOOL;
typedef unsigned long long uint64_t;
typedef unsigned long uintptr_t;
typedef unsigned int uint32_t;
typedef unsigned long size_t;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define NULL ((void *)0)
__attribute__((objc_root_class)) @interface NSObject @end
@interface NSString : NSObject @end
@interface NSError : NSObject @end
typedef struct { unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5]; } NSFastEnumerationState;
@interface NSArray : NSObject
+ (id)arrayWithObjects:(const id[])objects count:(unsigned long)count;
- (unsigned long)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(unsigned long)count;
@end
extern BOOL PLCheckMethod(id,NSString*,const char*,NSError**);
extern BOOL PLBool(id,NSString*);
extern BOOL PLFail(NSError**,int,NSString*);
extern BOOL PLRead(id,NSString*,const char*,const char*,void*,size_t,NSError**);
extern id PLReadObject(id,NSString*,const char*,const char*,NSError**);
extern void *PLShotReleaseFunction(void);
extern BOOL PLCopyMemory(uintptr_t,void*,size_t);
'''

def main():
    with zipfile.ZipFile(BASELINE) as z:
        baseline = z.read("PoolLab/Integrated/PLRuntimeBridge.m")
    assert digest(baseline) == "28eec08fea64e2e0ffff76055cf712aaecbedd4a33a4a262fb7422933841a6b5", "V11 baseline changed"
    current = BRIDGE.read_bytes()
    old = gate.block(baseline.decode(), "static BOOL PLReadyToPlan(")
    new = gate.block(current.decode(), "static BOOL PLReadyToPlan(")
    cpp = CPP_PREFIX + "\n" + lower(old, "V11") + "\n" + lower(new, "V12") + "\n" + CPP_TESTS
    cpp_path = HERE / "V12ReadinessRegression.cpp"
    cpp_path.write_text(cpp)
    objc_path = HERE / "V12ReadinessSyntax.m"
    objc_path.write_text(OBJC_PREFIX + "\n" + new + "\n")
    commands = [
        [str(CLANG), "-target", "arm64-apple-ios15.0", "-fobjc-arc", "-fsyntax-only", "-Werror", "-Werror=incompatible-pointer-types", str(objc_path)],
        ["c++", "-std=c++17", "-O2", "-Wall", "-Wextra", "-Werror", str(cpp_path), "-o", str(HERE / "readiness_regression")],
        [str(HERE / "readiness_regression")],
    ]
    executions = []
    for command in commands:
        result = subprocess.run(command, text=True, capture_output=True)
        executions.append({"command": command, "exitCode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
        print(result.stdout, end="")
        print(result.stderr, end="")
        if result.returncode: break
    (HERE / "ReadinessExecution.json").write_text(json.dumps(executions, indent=2) + "\n")
    checks = {line.split("\t", 1)[1]: line.startswith("PASS") for line in executions[-1]["stdout"].splitlines() if line.startswith(("PASS\t", "FAIL\t"))}
    report = {
        "format": "SDKPool.V12.NativeReadinessRegression",
        "result": "passed" if len(executions) == 3 and all(x["exitCode"] == 0 for x in executions) else "failed",
        "sourceSHA256": {"Integrated/PLRuntimeBridge.m": digest(current)},
        "baselineSourceSHA256": digest(baseline),
        "baselineReadinessSHA256": digest(old.encode()),
        "finalReadinessSHA256": digest(new.encode()),
        "validatorSHA256": digest(Path(__file__).read_bytes()),
        "fixtureSHA256": digest(cpp_path.read_bytes()),
        "objcFixtureSHA256": digest(objc_path.read_bytes()),
        "checkCount": len(checks),
        "checks": checks,
        "execution": executions,
        "actualProductionBranchesExecuted": True,
        "mechanicalSyntaxChanges": ["Objective-C NSString literals become C string literals", "NSArray iteration becomes C++ vector range iteration", "NSString iteration over an array literal becomes C++ char pointer vector iteration", "__bridge cast qualifier removed", "Function name suffixed for side-by-side baseline and final comparison"],
        "limits": ["Native accessors, errors, memory reads and release fingerprint are mocks.", "Moving-versus-spinning cases exercise the native combined boolean; its implementation is not executed.", "Unmodified final Objective-C function syntax checked for arm64 iOS with declaration-only stubs, without Apple SDK.", "No actual game physics, iPhone callback, Apple SDK link, or UI rendering executed."],
    }
    (HERE / "V12NativeReadinessRegression.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"result": report["result"], "checkCount":len(checks)}))
    return 0 if report["result"] == "passed" else 1

if __name__ == "__main__":
    raise SystemExit(main())
