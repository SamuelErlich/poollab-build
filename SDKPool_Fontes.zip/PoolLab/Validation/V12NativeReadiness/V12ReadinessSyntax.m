
typedef signed char BOOL;
typedef unsigned long long uint64_t;
typedef unsigned long uintptr_t;
typedef unsigned int uint32_t;
typedef unsigned long size_t;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define NULL ((void *)0)
__attribute__((objc_root_class)) @interface NSObject @end
@interface NSString : NSObject @end
@interface NSError : NSObject @end
typedef struct { unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5]; } NSFastEnumerationState;
@interface NSArray : NSObject
+ (id)arrayWithObjects:(const id[])objects count:(unsigned long)count;
- (unsigned long)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(unsigned long)count;
@end
extern BOOL PLCheckMethod(id,NSString*,const char*,NSError**);
extern BOOL PLBool(id,NSString*);
extern BOOL PLFail(NSError**,int,NSString*);
extern BOOL PLRead(id,NSString*,const char*,const char*,void*,size_t,NSError**);
extern id PLReadObject(id,NSString*,const char*,const char*,NSError**);
extern void *PLShotReleaseFunction(void);
extern BOOL PLCopyMemory(uintptr_t,void*,size_t);

static BOOL PLReadyToPlan(id manager, id cue, NSArray *sourceBalls, BOOL pendingNomination, NSError **error) {
    for (NSString *name in @[@"isPlayerTurn", @"isWaitingForPlayerShot", @"isGameStarted",
                            @"isInGamePopUp", @"visualCueBallControlInputIsActive", @"visualEnglishControlIsActive"]) {
        if (!PLCheckMethod(manager, name, "B16@0:8", error)) return NO;
    }
    if (!PLBool(manager, @"isGameStarted")) return PLFail(error, 41, @"Aguardando o início da partida.");
    if (!PLBool(manager, @"isPlayerTurn")) return PLFail(error, 41, @"Aguardando a vez do adversário terminar.");
    if (!PLBool(manager, @"isWaitingForPlayerShot")) return PLFail(error, 41, @"Aguardando o jogo liberar a próxima tacada.");
    BOOL spectator = YES, turnEnded = YES;
    uint64_t touches = 0;
    if (!PLRead(manager, @"GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), error) ||
        !PLRead(manager, @"GameManager", "mPlayerTurnTimeFinished", "B", &turnEnded, sizeof(turnEnded), error) ||
        !PLRead(manager, @"GameManager", "mNumCurrentTouches", "Q", &touches, sizeof(touches), error)) return NO;
    if (spectator) return PLFail(error, 58, @"A partida está em modo espectador.");
    if (turnEnded) return PLFail(error, 58, @"O tempo desta vez terminou.");
    if (touches) return PLFail(error, 58, @"Solte os controles da mesa para liberar o automático.");
    if (PLBool(manager, @"isInGamePopUp")) return PLFail(error, 58, @"Feche o aviso aberto pelo jogo.");
    if (PLBool(manager, @"visualCueBallControlInputIsActive")) return PLFail(error, 58, @"Conclua o posicionamento da bola branca.");
    if (PLBool(manager, @"visualEnglishControlIsActive")) return PLFail(error, 58, @"Feche o controle de efeito do taco.");
    id blocker = PLReadObject(manager, @"GameManager", "_inputBlocker", "@\"InputBlocker\"", error);
    if (error && *error) return NO;
    if (blocker) return PLFail(error, 63, @"O jogo pausou os controles da mesa.");
    for (NSString *name in @[@"enabled", @"inputActive", @"hasTouches", @"isAnimatingAimAngle", @"isAnimatingPower"])
        if (!PLCheckMethod(cue, name, "B16@0:8", error)) return NO;
    if (PLBool(cue, @"hasTouches") || PLBool(cue, @"isAnimatingAimAngle") || PLBool(cue, @"isAnimatingPower"))
        return PLFail(error, 59, @"Aguarde a mira terminar de se mover.");
    if (!pendingNomination && (!PLBool(cue, @"enabled") || !PLBool(cue, @"inputActive")))
        return PLFail(error, 45, @"O jogo ainda não liberou o taco.");
    BOOL hasCue = NO;
    for (id ball in sourceBalls) {
        if (!PLCheckMethod(ball, @"isMovingOrSpinning", "B16@0:8", error) ||
            !PLCheckMethod(ball, @"onTable", "B16@0:8", error)) return NO;
        // Off-table balls can remain in mBalls. Their raw velocity/spin may remain
        // nonzero because the native cloth update skips balls off the table.
        // Match the active-ball scope used by capture and legal-target lookup;
        // native turn/input readiness above still gates every action.
        if (!PLBool(ball, @"onTable")) continue;
        if (PLBool(ball, @"isMovingOrSpinning"))
            return PLFail(error, 42, @"Aguarde todas as bolas pararem.");
        uint32_t number = 0;
        if (!PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), error)) return NO;
        if (number == 0) hasCue = YES;
    }
    if (!hasCue) return PLFail(error, 43, @"Reposicione a bola branca antes da tacada.");
    if (!PLShotReleaseFunction()) return PLFail(error, 60, @"O disparo não corresponde ao build verificado.");
    void *cacher = NULL; uintptr_t owner = 0;
    if (!PLRead(manager, @"GameManager", "_cacher", "^{GameManagerCacher=@}", &cacher, sizeof(cacher), error) ||
        !cacher || !PLCopyMemory((uintptr_t)cacher, &owner, sizeof(owner)) || owner != (uintptr_t)(__bridge void *)manager)
        return PLFail(error, 61, @"O controle de tacadas ainda não está disponível.");
    return YES;
}
