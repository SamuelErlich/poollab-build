SDKPool V12 focused native-readiness validation

44 assertions exercise the actual V11 and V12 PLReadyToPlan branch bodies.
Objective-C literals and enumeration are mechanically lowered to C++ syntax.
Native method calls, memory reads and readiness flags are explicit mocks.
The full change list and executed commands are in the JSON report.

To rerun the generated portable fixture with a C++17 compiler:
  c++ -std=c++17 -O2 -Wall -Wextra -Werror V12ReadinessRegression.cpp -o readiness_regression
  ./readiness_regression

The .m fixtures contain declaration-only Foundation/native stubs and the
exact changed source blocks. They were syntax-checked using clang with
-target arm64-apple-ios15.0 -fobjc-arc -fsyntax-only -Werror.
No Apple SDK link or live game execution is claimed.

The extraction scripts retain their original workspace layout and require
the delivered V11 source archive and the V11 source-gate block extractor.
They are retained as provenance; the generated fixtures above are standalone.
