
typedef signed char BOOL;
typedef long NSInteger;
typedef unsigned long NSUInteger;
typedef double NSTimeInterval;
typedef unsigned long long uint64_t;
typedef unsigned long uintptr_t;
typedef unsigned int uint32_t;
typedef int int32_t;
typedef unsigned long size_t;
typedef struct { double x; double y; } CGPoint;
#define YES ((BOOL)1)
#define NO ((BOOL)0)
#define NULL ((void *)0)
#define nil ((id)0)
__attribute__((objc_root_class)) @interface NSObject
+ (Class)class;
- (BOOL)isKindOfClass:(Class)klass;
@end
@interface NSString : NSObject
+ (instancetype)stringWithFormat:(NSString *)format, ...;
- (instancetype)stringByAppendingString:(NSString *)string;
@end
@interface NSNumber : NSObject
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end
@interface NSError : NSObject
@property(nonatomic,readonly) NSInteger code;
@property(nonatomic,readonly) NSString *localizedDescription;
@end
typedef struct { unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5]; } NSFastEnumerationState;
@interface NSArray<__covariant ObjectType> : NSObject
@property(nonatomic,readonly) NSUInteger count;
+ (instancetype)array;
+ (id)arrayWithObjects:(const id[])objects count:(unsigned long)count;
- (unsigned long)countByEnumeratingWithState:(NSFastEnumerationState *)state objects:(id __unsafe_unretained[])objects count:(unsigned long)count;
- (NSString *)componentsJoinedByString:(NSString *)separator;
@end
@interface NSMutableArray<ObjectType> : NSArray<ObjectType>
- (void)addObject:(ObjectType)object;
@end
@interface NSDictionary<__covariant KeyType,__covariant ObjectType> : NSObject
+ (instancetype)dictionary;
@end
@interface NSMutableDictionary<KeyType,ObjectType> : NSDictionary<KeyType,ObjectType>
- (void)setObject:(ObjectType)object forKeyedSubscript:(KeyType)key;
- (void)addEntriesFromDictionary:(NSDictionary *)dictionary;
@end
@interface NSValue : NSObject @end
@interface UIView : NSObject @end
@interface PLBallSnapshot : NSObject @end
@interface PLGameSnapshot : NSObject @end
extern BOOL PLCheckMethod(id,NSString*,const char*,NSError**);
extern BOOL PLBool(id,NSString*);
extern BOOL PLFail(NSError**,NSInteger,NSString*);
extern BOOL PLRead(id,NSString*,const char*,const char*,void*,size_t,NSError**);
extern id PLReadObject(id,NSString*,const char*,const char*,NSError**);
extern void *PLShotReleaseFunction(void);
extern BOOL PLCopyMemory(uintptr_t,void*,size_t);
extern BOOL PLReadCue(id,id*,double*,double*,NSError**);
extern double PLMinimumShotPower(id);
extern BOOL PLReadSelectedEnglish(id,double[2],NSError**);
extern BOOL PLCenteredEnglish(const double[2]);

@interface PLGameSnapshot ()
@property(nonatomic, readwrite) NSTimeInterval captureTimestamp;
@property(nonatomic, readwrite) uint64_t frameNumber;
@property(nonatomic, readwrite) double projectionResidual;
@property(nonatomic, copy, readwrite) NSDictionary<NSString *, NSString *> *diagnostics;
@property(nonatomic, copy, readwrite) NSArray<PLBallSnapshot *> *balls;
@property(nonatomic, readwrite) double originX;
@property(nonatomic, readwrite) double originY;
@property(nonatomic, readwrite) double width;
@property(nonatomic, readwrite) double height;
@property(nonatomic, readwrite) BOOL playerTurn;
@property(nonatomic, readwrite) BOOL opponentTurn;
@property(nonatomic, readwrite) BOOL opponentPreviewAvailable;
@property(nonatomic, copy, readwrite) NSString *opponentPreviewUnavailableReason;
@property(nonatomic, readwrite) double opponentMaximumShotSpeed;
@property(nonatomic, readwrite) NSTimeInterval opponentAimAge;
@property(nonatomic, readwrite) BOOL aimAvailable;
@property(nonatomic, readwrite) double aimAngle;
@property(nonatomic, readwrite) double cuePower;
@property(nonatomic, readwrite) BOOL shotInputSupported;
@property(nonatomic, copy, readwrite) NSString *shotInputUnavailableReason;
@property(nonatomic, readwrite) double cueEnglishX;
@property(nonatomic, readwrite) double cueEnglishY;
@property(nonatomic, readwrite) double minimumShotPower;
@property(nonatomic, readwrite) double maximumShotSpeed;
@property(nonatomic, readwrite) BOOL physicsCalibrationAvailable;
@property(nonatomic, readwrite) double rollingDeceleration;
@property(nonatomic, readwrite) double slidingDeceleration;
@property(nonatomic, readwrite) double equilibriumTimeFactor;
@property(nonatomic, readwrite) double spinDeceleration;
@property(nonatomic, readwrite) double slidingFrictionCoefficient;
@property(nonatomic, readwrite) double cushionSpinCoupling;
@property(nonatomic, readwrite) double logicalFrameTime;
@property(nonatomic, readwrite) double ballRestitution;
@property(nonatomic, readwrite) double cushionRestitution;
@property(nonatomic, copy, readwrite) NSString *nativeGeometrySource;
@property(nonatomic, readwrite) BOOL nativeGeometryAvailable;
@property(nonatomic, copy, readwrite) NSString *nativeGeometryUnavailableReason;
@property(nonatomic, copy, readwrite) NSArray<NSValue *> *nativeCushionVertices;
@property(nonatomic, copy, readwrite) NSArray<NSValue *> *nativePocketCenters;
@property(nonatomic, copy, readwrite) NSArray<NSValue *> *nativePocketAimPoints;
@property(nonatomic, readwrite) double nativePocketRadius;
@property(nonatomic, readwrite) double nativePocketAttractionCoefficient;
@property(nonatomic, readwrite) BOOL goldenShot;
@property(nonatomic, readwrite) BOOL goldenTargetAvailable;
@property(nonatomic, readwrite) double goldenTargetX;
@property(nonatomic, readwrite) double goldenTargetY;
@property(nonatomic, readwrite) double goldenTargetRadius;
@property(nonatomic, readwrite) NSInteger goldenBallNumber;
@property(nonatomic, readwrite) BOOL canShoot;
@property(nonatomic, readwrite) NSInteger nativeReadinessErrorCode;
@property(nonatomic, readwrite) BOOL isBreakShot;
@property(nonatomic, copy, readwrite) NSArray<NSNumber *> *legalTargetNumbers;
@property(nonatomic, readwrite) BOOL autoShotAvailable;
@property(nonatomic, copy, readwrite) NSString *autoShotUnavailableReason;
@property(nonatomic, copy, readwrite) NSString *shootReadinessReason;
@property(nonatomic, readwrite) CGPoint tableTopLeft;
@property(nonatomic, readwrite) CGPoint tableTopRight;
@property(nonatomic, readwrite) CGPoint tableBottomLeft;
@property(nonatomic, strong, readwrite) UIView *coordinateView;
@end
typedef struct {
    void *rules;
    BOOL nominationRequired;
    BOOL isBreakShot;
    int32_t nominatedPocket;
    int32_t classification;
} PLRulesInfo;
extern BOOL PLRules(id,id,PLRulesInfo*,NSError**);
static BOOL PLReadyToPlan(id manager, id cue, NSArray *sourceBalls, BOOL pendingNomination, NSError **error) {
    for (NSString *name in @[@"isPlayerTurn", @"isWaitingForPlayerShot", @"isGameStarted",
                            @"isInGamePopUp", @"visualCueBallControlInputIsActive", @"visualEnglishControlIsActive"]) {
        if (!PLCheckMethod(manager, name, "B16@0:8", error)) return NO;
    }
    if (!PLBool(manager, @"isGameStarted")) return PLFail(error, 41, @"Aguardando o início da partida.");
    if (!PLBool(manager, @"isPlayerTurn")) return PLFail(error, 41, @"Aguardando a vez do adversário terminar.");
    if (!PLBool(manager, @"isWaitingForPlayerShot")) return PLFail(error, 41, @"Aguardando o jogo liberar a próxima tacada.");
    BOOL spectator = YES, turnEnded = YES;
    uint64_t touches = 0;
    if (!PLRead(manager, @"GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), error) ||
        !PLRead(manager, @"GameManager", "mPlayerTurnTimeFinished", "B", &turnEnded, sizeof(turnEnded), error) ||
        !PLRead(manager, @"GameManager", "mNumCurrentTouches", "Q", &touches, sizeof(touches), error)) return NO;
    if (spectator) return PLFail(error, 58, @"A partida está em modo espectador.");
    if (turnEnded) return PLFail(error, 58, @"O tempo desta vez terminou.");
    if (touches) return PLFail(error, 58, @"Solte os controles da mesa para liberar o automático.");
    if (PLBool(manager, @"isInGamePopUp")) return PLFail(error, 58, @"Feche o aviso aberto pelo jogo.");
    if (PLBool(manager, @"visualCueBallControlInputIsActive")) return PLFail(error, 58, @"Conclua o posicionamento da bola branca.");
    if (PLBool(manager, @"visualEnglishControlIsActive")) return PLFail(error, 58, @"Feche o controle de efeito do taco.");
    id blocker = PLReadObject(manager, @"GameManager", "_inputBlocker", "@\"InputBlocker\"", error);
    if (error && *error) return NO;
    if (blocker) return PLFail(error, 63, @"O jogo pausou os controles da mesa.");
    for (NSString *name in @[@"enabled", @"inputActive", @"hasTouches", @"isAnimatingAimAngle", @"isAnimatingPower"])
        if (!PLCheckMethod(cue, name, "B16@0:8", error)) return NO;
    if (PLBool(cue, @"hasTouches") || PLBool(cue, @"isAnimatingAimAngle") || PLBool(cue, @"isAnimatingPower"))
        return PLFail(error, 59, @"Aguarde a mira terminar de se mover.");
    if (!pendingNomination && (!PLBool(cue, @"enabled") || !PLBool(cue, @"inputActive")))
        return PLFail(error, 45, @"O jogo ainda não liberou o taco.");
    BOOL hasCue = NO;
    for (id ball in sourceBalls) {
        if (!PLCheckMethod(ball, @"isMovingOrSpinning", "B16@0:8", error) ||
            !PLCheckMethod(ball, @"onTable", "B16@0:8", error)) return NO;
        // Off-table balls can remain in mBalls. Their raw velocity/spin may remain
        // nonzero because the native cloth update skips balls off the table.
        // Match the active-ball scope used by capture and legal-target lookup;
        // native turn/input readiness above still gates every action.
        if (!PLBool(ball, @"onTable")) continue;
        if (PLBool(ball, @"isMovingOrSpinning"))
            return PLFail(error, 42, @"Aguarde todas as bolas pararem.");
        uint32_t number = 0;
        if (!PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), error)) return NO;
        if (number == 0) hasCue = YES;
    }
    if (!hasCue) return PLFail(error, 43, @"Reposicione a bola branca antes da tacada.");
    if (!PLShotReleaseFunction()) return PLFail(error, 60, @"O disparo não corresponde ao build verificado.");
    void *cacher = NULL; uintptr_t owner = 0;
    if (!PLRead(manager, @"GameManager", "_cacher", "^{GameManagerCacher=@}", &cacher, sizeof(cacher), error) ||
        !cacher || !PLCopyMemory((uintptr_t)cacher, &owner, sizeof(owner)) || owner != (uintptr_t)(__bridge void *)manager)
        return PLFail(error, 61, @"O controle de tacadas ainda não está disponível.");
    return YES;
}

static NSDictionary<NSString *, NSString *> *PLInputDiagnostics(id manager, NSArray *sourceBalls) {
    // Read-only observations, never a way to clear a native touch or enable a
    // disabled control. Preserve unavailable fields explicitly in exported logs.
    NSMutableDictionary<NSString *, NSString *> *values = [NSMutableDictionary dictionary];
    uint64_t touches = 0;
    values[@"nativeCurrentTouches"] =
        PLRead(manager, @"GameManager", "mNumCurrentTouches", "Q", &touches, sizeof(touches), NULL)
        ? [NSString stringWithFormat:@"%llu", (unsigned long long)touches] : @"unavailable";
    id touchArray = PLReadObject(manager, @"GameManager", "mCurrentTouches", "@\"NSMutableArray\"", NULL);
    values[@"nativeTouchArrayCount"] = [touchArray isKindOfClass:NSArray.class]
        ? [NSString stringWithFormat:@"%llu", (unsigned long long)[touchArray count]] : @"unavailable";
    for (NSString *name in @[@"isPlayerTurn", @"isWaitingForPlayerShot", @"isGameStarted",
                            @"isInGamePopUp", @"visualCueBallControlInputIsActive", @"visualEnglishControlIsActive"]) {
        values[[@"nativeManager." stringByAppendingString:name]] =
            PLCheckMethod(manager, name, "B16@0:8", NULL) ? (PLBool(manager, name) ? @"true" : @"false") : @"unavailable";
    }
    BOOL spectator = NO, turnEnded = NO;
    values[@"nativeSpectatorMode"] =
        PLRead(manager, @"GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), NULL)
        ? (spectator ? @"true" : @"false") : @"unavailable";
    values[@"nativeTurnTimeFinished"] =
        PLRead(manager, @"GameManager", "mPlayerTurnTimeFinished", "B", &turnEnded, sizeof(turnEnded), NULL)
        ? (turnEnded ? @"true" : @"false") : @"unavailable";
    NSError *blockerError = nil;
    id blocker = PLReadObject(manager, @"GameManager", "_inputBlocker", "@\"InputBlocker\"", &blockerError);
    values[@"nativeInputBlocked"] = blockerError ? @"unavailable" : (blocker ? @"true" : @"false");
    id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", NULL);
    uint64_t cueTouches = 0;
    values[@"nativeCueCurrentTouches"] =
        PLRead(cue, @"VisualCue", "mNumCurrentTouches", "Q", &cueTouches, sizeof(cueTouches), NULL)
        ? [NSString stringWithFormat:@"%llu", (unsigned long long)cueTouches] : @"unavailable";
    for (NSString *name in @[@"enabled", @"inputActive", @"hasTouches", @"isAnimatingAimAngle", @"isAnimatingPower"]) {
        values[[@"nativeCue." stringByAppendingString:name]] =
            PLCheckMethod(cue, name, "B16@0:8", NULL) ? (PLBool(cue, name) ? @"true" : @"false") : @"unavailable";
    }
    // Bounded observations of the same copied ball list used for readiness.
    // Include off-table residual motion for diagnosis, never as a shot blocker.
    NSUInteger onTableCount = 0, offTableCount = 0, unreadableCount = 0;
    NSMutableArray<NSString *> *movingOnTable = [NSMutableArray array];
    NSMutableArray<NSString *> *movingOffTable = [NSMutableArray array];
    if (sourceBalls.count > 0 && sourceBalls.count <= 32) {
        for (id ball in sourceBalls) {
            uint32_t number = 0;
            if (!PLCheckMethod(ball, @"onTable", "B16@0:8", NULL) ||
                !PLCheckMethod(ball, @"isMovingOrSpinning", "B16@0:8", NULL) ||
                !PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), NULL)) {
                unreadableCount++;
                continue;
            }
            BOOL onTable = PLBool(ball, @"onTable");
            if (onTable) onTableCount++; else offTableCount++;
            if (PLBool(ball, @"isMovingOrSpinning")) {
                NSMutableArray<NSString *> *moving = onTable ? movingOnTable : movingOffTable;
                [moving addObject:[NSString stringWithFormat:@"%u", number]];
            }
        }
    } else unreadableCount = sourceBalls.count ?: 1;
    values[@"nativeOnTableBallCount"] = [NSString stringWithFormat:@"%lu", (unsigned long)onTableCount];
    values[@"nativeOffTableBallCount"] = [NSString stringWithFormat:@"%lu", (unsigned long)offTableCount];
    values[@"nativeMovingOnTableBalls"] = [movingOnTable componentsJoinedByString:@","];
    values[@"nativeMovingOffTableBalls"] = [movingOffTable componentsJoinedByString:@","];
    values[@"nativeUnreadableBallCount"] = [NSString stringWithFormat:@"%lu", (unsigned long)unreadableCount];
    return values;
}

static void PLFillControls(id manager, id table, NSArray *sourceBalls, PLGameSnapshot *snapshot) {
    snapshot.nativeReadinessErrorCode = 0;
    snapshot.legalTargetNumbers = @[];
    snapshot.autoShotUnavailableReason = @"A mesa ainda não está pronta para a tacada.";
    snapshot.shootReadinessReason = @"A mesa ainda não está pronta para a tacada.";
    snapshot.shotInputUnavailableReason = @"Aguardando a leitura do efeito do taco.";
    id cue = nil; double angle = 0, power = 0; NSError *reason = nil;
    if (!PLReadCue(manager, &cue, &angle, &power, &reason)) {
        snapshot.nativeReadinessErrorCode = reason ? reason.code : 46;
        snapshot.autoShotUnavailableReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático.";
        snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return;
    }
    snapshot.aimAvailable = YES; snapshot.aimAngle = angle; snapshot.cuePower = power;
    snapshot.minimumShotPower = PLMinimumShotPower(cue);
    double english[2] = {0}; NSError *englishError = nil;
    if (PLReadSelectedEnglish(manager, english, &englishError)) {
        snapshot.cueEnglishX = english[0]; snapshot.cueEnglishY = english[1];
        snapshot.shotInputSupported = PLCenteredEnglish(english);
        snapshot.shotInputUnavailableReason = snapshot.shotInputSupported ? @"" :
            @"Centralize o efeito do taco para prever a próxima tacada.";
    } else snapshot.shotInputUnavailableReason = englishError.localizedDescription ?: snapshot.shotInputUnavailableReason;
    PLRulesInfo rules = {0};
    if (!PLRules(manager, table, &rules, &reason)) {
        snapshot.nativeReadinessErrorCode = reason ? reason.code : 52;
        snapshot.autoShotUnavailableReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático.";
        snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return;
    }
    snapshot.isBreakShot = rules.isBreakShot;
    NSMutableArray<NSNumber *> *targets = [NSMutableArray array];
    for (id ball in sourceBalls) {
        int32_t classification = 0, state = 0; uint32_t number = 0;
        if (!PLRead(ball, @"Ball", "classification", "i", &classification, sizeof(classification), &reason) ||
            !PLRead(ball, @"Ball", "state", "i", &state, sizeof(state), &reason) ||
            !PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), &reason)) {
            snapshot.nativeReadinessErrorCode = reason ? reason.code : 21;
            snapshot.autoShotUnavailableReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático.";
            snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return;
        }
        if (state != 1 || number == 0 || number > 15) continue;
        BOOL legal = rules.classification == -1 ? (classification == 1 || classification == 2) : classification == rules.classification;
        if (legal) [targets addObject:@(number)];
    }
    snapshot.legalTargetNumbers = targets;
    // Capability is independent of whose turn it currently is. The controller
    // keeps automatic play armed while canShoot reports a temporary wait.
    snapshot.autoShotAvailable = PLShotReleaseFunction() != NULL;
    snapshot.autoShotUnavailableReason = snapshot.autoShotAvailable ? @"" : @"O disparo não corresponde ao build verificado.";
    if (!snapshot.autoShotAvailable) {
        snapshot.nativeReadinessErrorCode = 60;
        snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return;
    }
    BOOL pendingNomination = rules.nominationRequired && rules.nominatedPocket == 9001;
    if (!PLReadyToPlan(manager, cue, sourceBalls, pendingNomination, &reason)) {
        snapshot.nativeReadinessErrorCode = reason ? reason.code : 65;
        snapshot.shootReadinessReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático."; return;
    }
    if (!snapshot.shotInputSupported) {
        snapshot.nativeReadinessErrorCode = englishError ? englishError.code : 74;
        snapshot.shootReadinessReason = snapshot.shotInputUnavailableReason; return;
    }
    if (!snapshot.physicsCalibrationAvailable) {
        snapshot.nativeReadinessErrorCode = 75;
        snapshot.shootReadinessReason = @"Aguardando a leitura completa da física da mesa."; return;
    }
    snapshot.canShoot = targets.count > 0;
    snapshot.nativeReadinessErrorCode = targets.count ? 0 : 76;
    snapshot.shootReadinessReason = targets.count ? @"" : @"Nenhuma bola permitida está disponível.";
}
static void PLCheckCaptureDiagnostics(id manager,NSArray *sourceBalls,PLGameSnapshot *result,NSMutableDictionary<NSString *,NSString *> *diagnostics,BOOL goldenShot) {
    diagnostics[@"nativeReadinessCode"] = [NSString stringWithFormat:@"%ld", (long)result.nativeReadinessErrorCode];
    [diagnostics addEntriesFromDictionary:PLInputDiagnostics(manager, sourceBalls)];
    if (goldenShot) {
        result.nativeReadinessErrorCode = 77;
    }
}
