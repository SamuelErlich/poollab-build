from pathlib import Path
import runpy,json,hashlib
v=runpy.run_path('new_project/validation/v13_smooth_model/build_harness.py')
out=Path('new_project/validation/v13_smooth_model')
s=(out/'V13SmoothAutomationHarness.swift').read_text()
s=s.replace('final class IntegratedGameModel {','@MainActor\nfinal class IntegratedGameModel {')
s=s.replace('var plannerTask: MockTask?','var plannerTask: Task<Void,Never>?')
s=s.replace('    var isBreakShot = false','    var isBreakShot = false\n    var minimumShotPower = 0.01',1)
s=s.replace('''    var canEnableAutoAim = true, canEnableAutoPlay = true''','''    var canEnableAutoAim = true, canEnableAutoPlay = true
    var canRecommend = true, isCalibrated = true, shotInputSupported = true
    var predictionInputIssue: String?
    var planningMilliseconds = 0.0
    var suggestionIsBreakShot = false
    func setPreview(_ shot: ShotParameters) -> Bool { true }
    func applyAim() {}''')
stub='    func startPlanning(_ purpose: PlanningPurpose) { planRequests.append(purpose); isPlanning = true; planningPurpose = purpose }'
s=s.replace(stub,'\n'.join(v['member'](n) for n in ['startPlanning','accepts','acceptsPlan','minimumPlannerPower']))
s=s.replace('\ntry IntegratedGameModel.run()','')
ix=s.rindex('\n}')
s=s[:ix]+r'''
    static func awaitPlanner(_ model: IntegratedGameModel) async throws {
        let deadline = ProcessInfo.processInfo.systemUptime + 15
        while model.isPlanning && ProcessInfo.processInfo.systemUptime < deadline { try await Task.sleep(nanoseconds:10_000_000) }
    }
    static func runAsync() async throws {
        let model = fixture(); model.setAutoPlay(true)
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); expect(model.isPlanning,"actual detached planner starts")
        let generation = model.plannerGeneration
        model.toggleAutomationPause(); expect(model.plannerGeneration > generation,"pause invalidates pending planner generation")
        try await Task.sleep(nanoseconds:100_000_000)
        expect(PLRuntimeBridge.aims.isEmpty && PLRuntimeBridge.shoots.isEmpty,"cancelled planner cannot start controls")
        model.toggleAutomationPause(); model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); try await awaitPlanner(model)
        expect(!model.isPlanning && model.automaticPlan?.controlSequence != nil && PLRuntimeBridge.shoots.isEmpty,"accepted real planner begins gradual controls without immediate shot")
        expect(model.automaticPlan?.suggestion.id == model.suggestions.first?.id,"gradual sequence owns real top-ranked exact solution")
        model.finish(); expect(PLRuntimeBridge.shoots.count == 1,"real planning to staged controls ends in one release")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.tableState!.balls[1].position.x += 5; model.snapshot!.state = model.tableState!; PLRuntimeBridge.snapshot = model.snapshot
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); try await awaitPlanner(model)
        expect(PLRuntimeBridge.shoots.count == 1 && model.automaticPlan?.controlSequence != nil,"second board gets a new full gradual sequence")
        model.finish(); expect(PLRuntimeBridge.shoots.count == 2,"two actual-planner turns complete continuously")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1; model.advanceAutomation()
        model.tableState!.balls[1].position.x += 5
        let applied = PLRuntimeBridge.aims.count
        try await awaitPlanner(model)
        expect(PLRuntimeBridge.aims.count == applied && PLRuntimeBridge.shoots.count == 2 && model.captureEvents.contains("planningDiscarded"),"changed-board completion cannot start a stale sequence")
        print("{\"result\":\"passed\",\"checks\":\(checks),\"scope\":\"Actual production startPlanning and Task.detached plus V13 Core, progression and dispatch; native I/O mocked\"}")
    }
'''+s[ix:]
s+='\n@main struct Main { static func main() async throws { try await IntegratedGameModel.runAsync() } }\n'
(out/'V13AsyncSmoothAutomationHarness.swift').write_text(s)
metaPath=out/'ExtractedMethods.json';meta=json.loads(metaPath.read_text());meta['asyncMethods']={n:hashlib.sha256(v['member'](n).encode()).hexdigest() for n in ['startPlanning','accepts','acceptsPlan','minimumPlannerPower']};metaPath.write_text(json.dumps(meta,indent=2))
