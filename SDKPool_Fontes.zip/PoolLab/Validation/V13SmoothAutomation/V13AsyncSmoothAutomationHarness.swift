import Foundation
import PoolLabCore
final class MockView {}
typealias PLGameSnapshot = Snapshot
struct Snapshot {
    var state: TableState
    var coordinateView: MockView
    var legalTargetNumbers: [NSNumber]
    var playerTurn = true
    var canShoot = true
    var autoShotAvailable = true
    var shotInputSupported = true
    var captureTimestamp = ProcessInfo.processInfo.systemUptime
    var isBreakShot = false
    var minimumShotPower = 0.01
    var aimAvailable = true
    var aimAngle = 2.9
    var cuePower = 0.0
    var diagnostics: [String:String] = [:]
}
struct Normalized {
    var state: TableState
    var calibrated = true
    var nativePhysics = true
    var predictionIssue: String? = nil
    var moving = false
}
final class MockTask { func cancel() {} }
enum PLRuntimeBridge {
    static var snapshot: Snapshot!
    static var shootError: NSError?
    static var aimError: NSError?
    static var captureError: NSError?
    static var forceStale = false
    static var shoots: [(angle: Double, power: Double, target: Int, pocket: Int)] = []
    static var aims: [(angle: Double, power: Double, target: Int, pocket: Int)] = []
    static func capture() throws -> Snapshot {
        if let e = captureError { throw e }
        var current = snapshot!
        current.captureTimestamp = ProcessInfo.processInfo.systemUptime - (forceStale ? 2 : 0)
        return current
    }
    static func shoot(angle: Double, power: Double, target: Int, pocket: Int) throws {
        shoots.append((angle,power,target,pocket))
        if let e = shootError { throw e }
    }
    static func applyAimProgress(angle: Double, power: Double, target: Int, pocket: Int) throws {
        aims.append((angle,power,target,pocket))
        if let e = aimError { throw e }
        snapshot.aimAngle = angle
        snapshot.cuePower = power
    }
}
@MainActor
final class IntegratedGameModel {
    var aimEnabled = false, autoPlayEnabled = false, automationPaused = false
    var automationArmed: Bool { aimEnabled || autoPlayEnabled }
    var automationIsRunning: Bool { automationArmed && !automationPaused }
    var canEnableAutoAim = true, canEnableAutoPlay = true
    var canRecommend = true, isCalibrated = true, shotInputSupported = true
    var predictionInputIssue: String?
    var planningMilliseconds = 0.0
    var suggestionIsBreakShot = false
    func setPreview(_ shot: ShotParameters) -> Bool { true }
    func applyAim() {}
    var isAuthorized = true, canCalculate = true, canApplyAim = true
    var isPlayerTurn = true, isMoving = false, isLuckyShot = false
    var isWaitingForShot = false, singleShotRequested = false
    var panelIsOpen = false, isPlanning = false, hasTable = true
    var hasFreshCapture = true, hasNativePhysics = true, captureHealthy = true
    var runtimeCanShoot = true, autoShotAvailable = true
    var followGameAim = true, previewIsTemporary = false, suggestionContextIsCurrent = true
    var previewPowerLocked = false
    var lockedPreviewPower: Double?
    var aimActionReadiness = "waiting", autoShotUnavailableReason = "unsupported", liveReadiness = "not ready"
    var automationStatus = "off", status = "", suggestionStatus = ""
    var legalTargets: Set<Int> = [1]
    var tableState: TableState?
    var snapshot: Snapshot?
    var angleDegrees = 0.0, power = 0.5
    private var automaticPlan: AutomaticPlan?, automaticBlockedContext: AutomaticContext?
    private var automaticAttemptContext: AutomaticContext?
    var automaticCommandAttempts = 0
    var automaticControlAttempts = 0
    var lastAutomaticControlMilliseconds = 0.0
    var maximumAutomaticControlMilliseconds = 0.0
    var automaticRetryAfter: TimeInterval = 0
    var lastSubmittedState: TableState?
    var stableSince: TimeInterval? = ProcessInfo.processInfo.systemUptime - 1
    var shotSubmittedAt: TimeInterval?, captureFailureStartedAt: TimeInterval?
    var unsupportedMotionStartedAt: TimeInterval?
    let minimumStableTime = 0.65, unsupportedMotionTimeout = 30.0
    var queueTransition: Int?
    var plannerTask: Task<Void,Never>?
    var plannerGeneration: UInt64 = 0
    enum PlanningPurpose { case suggestions, applyAim, continuousAim, singleShot, autoPlay, luckyShot }
    var planningPurpose: PlanningPurpose?
    var suggestionState: TableState?
    var suggestionAllowed: Set<Int> = []
    var suggestionCoordinateIdentity: ObjectIdentifier?
    var selectedSuggestionID: String?
    var suggestions: [ShotSuggestion] = []
    var luckySuggestion: Int?
    var onOverlayChange: (() -> Void)?
    var planRequests: [PlanningPurpose] = []
    var clearRequests = 0, pollRequests = 0
    var captureEvents: [String] = []
    enum CaptureError: Error { case changedTable }
    static func normalized(_ value: Snapshot) throws -> Normalized { Normalized(state: value.state) }
    static func degrees(_ radians: Double) -> Double { radians * 180 / .pi }
    func recordCaptureEvent(_ name: String, at: TimeInterval, details: [String:String] = [:]) { captureEvents.append(name) }
    func cancelPrediction(clearOverlay: Bool) {}
    func poll() { pollRequests += 1 }
    private func startPlanning(_ purpose: PlanningPurpose) {
        guard canRecommend, let state = tableState, let snapshot else { return }
        if purpose != .suggestions && !canApplyAim { return }
        guard let minimumPower = try? Self.minimumPlannerPower(control: snapshot.minimumShotPower) else {
            stopAutomation(message: "O jogo informou um limite de força inválido.")
            return
        }
        cancelPlanner(clearSuggestions: true)
        let operation = plannerGeneration
        let allowed = legalTargets
        let isBreakShot = snapshot.isBreakShot
        let coordinateIdentity = ObjectIdentifier(snapshot.coordinateView)
        let startedAt = ProcessInfo.processInfo.systemUptime
        planningPurpose = purpose
        isPlanning = true
        status = "Comparando tacadas permitidas na mesa atual…"
        suggestionStatus = "Calculando direção e força na mesa atual…"
        recordCaptureEvent("planningStarted", at: startedAt, details: ["purpose": String(describing: purpose)])
        if purpose == .singleShot || purpose == .autoPlay { automationStatus = "Procurando uma tacada permitida…" }
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try ShotPlanner.suggestions(for: state, includeBanks: true, limit: 4, allowedTargetIDs: allowed,
                    minimumPower: minimumPower, isBreakShot: isBreakShot)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.plannerGeneration else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.planningMilliseconds = max(0, ProcessInfo.processInfo.systemUptime - startedAt) * 1_000
                guard self.acceptsPlan(operation, state: state, allowed: allowed),
                      self.snapshot.map({ ObjectIdentifier($0.coordinateView) }) == coordinateIdentity,
                      self.snapshot?.isBreakShot == isBreakShot else {
                    self.suggestionStatus = "A mesa ou os controles mudaram. Aguarde para calcular novamente."
                    self.recordCaptureEvent("planningDiscarded", at: ProcessInfo.processInfo.systemUptime)
                    return
                }
                self.suggestionState = state
                self.suggestionAllowed = allowed
                self.suggestionCoordinateIdentity = coordinateIdentity
                self.suggestionIsBreakShot = isBreakShot
                self.suggestions = found
                self.recordCaptureEvent("planningCompleted", at: ProcessInfo.processInfo.systemUptime,
                                        details: ["count": String(found.count), "durationMs": String(self.planningMilliseconds)])
                guard let best = found.first else {
                    self.status = "Nenhuma tacada permitida encontrada pelo modelo nesta posição."
                    self.suggestionStatus = self.status
                    if purpose == .autoPlay || purpose == .continuousAim {
                        self.automaticBlockedContext = self.currentAutomaticContext
                        self.waitAutomation(message: "Nenhuma tacada segura encontrada. Aguardando mudança na mesa ou retomar.")
                    } else if purpose == .singleShot { self.stopAutomation(message: self.status) }
                    return
                }
                switch purpose {
                case .suggestions:
                    self.status = "Escolha uma tacada para ver o percurso."
                    self.suggestionStatus = "\(found.count) opções calculadas. Toque em uma para ver a previsão."
                case .applyAim:
                    guard self.setPreview(best.shot) else { return }
                    self.applyAim()
                case .continuousAim, .autoPlay:
                    guard self.automationIsRunning, !self.panelIsOpen,
                          let context = self.currentAutomaticContext else { return }
                    self.automaticPlan = AutomaticPlan(context: context, suggestion: best)
                    self.selectedSuggestionID = best.id
                    self.advanceAutomation()
                case .singleShot:
                    self.execute(best, expectedState: state, allowed: allowed)
                case .luckyShot:
                    break // Lucky Shot uses its own bounded target search.
                }
            } catch {
                guard let self, operation == self.plannerGeneration else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.planningMilliseconds = max(0, ProcessInfo.processInfo.systemUptime - startedAt) * 1_000
                self.status = "Não foi possível calcular a tacada: \(error.localizedDescription)"
                self.suggestionStatus = self.status
                self.recordCaptureEvent("planningFailed", at: ProcessInfo.processInfo.systemUptime,
                                        details: ["reason": String(error.localizedDescription.prefix(200))])
                if purpose == .autoPlay || purpose == .continuousAim {
                    self.pauseAutomaticActions(message: self.status)
                } else if purpose == .singleShot { self.stopAutomation(message: self.status) }
            }
        }
    }
    private func accepts(_ state: TableState) -> Bool {
        isAuthorized && hasFreshCapture && predictionInputIssue == nil && isCalibrated && hasNativePhysics && shotInputSupported && !Task.isCancelled && tableState == state && !isMoving
    }
    private func acceptsPlan(_ operation: UInt64, state: TableState, allowed: Set<Int>) -> Bool {
        operation == plannerGeneration && accepts(state) && canRecommend && legalTargets == allowed
    }
    private static func minimumPlannerPower(control: Double) throws -> Double {
        guard control.isFinite, (0...1).contains(control) else { throw BilliardsError.invalidShot }
        // The native threshold originates as float but is compared as double.
        // Guard the control value before simulation so a q -> p round trip
        // cannot fall one ULP below it. Never clamp an already planned shot.
        return try GameShotCalibration.simulationPower(fromControlPower: min(1, control + 1e-7))
    }
    func clearBoard(message: String, preserveQueueIntent: Bool) { clearRequests += 1; stopAutomation(message:message); hasTable = false }
    func setAutoAimEnabled(_ enabled: Bool) {
        guard enabled != aimEnabled else { return }
        if !enabled {
            stopAutomation(message: "AIM e jogo automático desligados.")
            onOverlayChange?()
            return
        }
        guard canEnableAutoAim else { return }
        aimEnabled = true
        automationPaused = false
        resetAutomaticPlan()
        automationStatus = "AIM ligado. Aguardando sua vez e a mesa parar."
        recordCaptureEvent("continuousAimEnabled", at: ProcessInfo.processInfo.systemUptime)
        poll()
    }

    func setAutoPlay(_ enabled: Bool) {
        guard enabled != autoPlayEnabled else { return }
        if !enabled {
            autoPlayEnabled = false
            singleShotRequested = false
            resetAutomaticPlan()
            automationStatus = automationPaused ? "AIM pausado." : "Auto Play desligado. AIM continua ligado."
            onOverlayChange?()
            return
        }
        guard canEnableAutoPlay else { return }
        aimEnabled = true
        autoPlayEnabled = true
        automationPaused = false
        unsupportedMotionStartedAt = nil
        resetAutomaticPlan()
        recordCaptureEvent("autoPlayEnabled", at: ProcessInfo.processInfo.systemUptime)
        singleShotRequested = false
        automationStatus = "AIM e automático ligados. Aguardando sua vez e a mesa parar."
        poll()
    }

    func toggleAutomationPause() {
        guard automationArmed else { return }
        automationPaused.toggle()
        resetAutomaticPlan()
        singleShotRequested = false
        recordCaptureEvent(automationPaused ? "automationPaused" : "automationResumed",
                           at: ProcessInfo.processInfo.systemUptime)
        automationStatus = automationPaused ? "AIM e automático pausados." : "Retomando com uma nova leitura da mesa."
        if !automationPaused { poll() }
        onOverlayChange?()
    }

    private func resetAutomaticPlan() {
        // Automatic control and the visible forecast use the same live power.
        // A manually locked preview must not conceal the selected shot force.
        previewPowerLocked = false
        lockedPreviewPower = nil
        followGameAim = true
        previewIsTemporary = false
        cancelPlanner(clearSuggestions: true)
        automaticPlan = nil
        automaticBlockedContext = nil
        automaticAttemptContext = nil
        automaticCommandAttempts = 0
        automaticControlAttempts = 0
        automaticRetryAfter = 0
        stableSince = nil
    }

    private func advanceAutomation() {
        guard automationIsRunning || singleShotRequested, isAuthorized, !isWaitingForShot, !isPlanning else { return }
        guard !panelIsOpen else {
            cancelAutomaticControlSequence(reason: "menu", pause: false)
            waitAutomation(message: "Feche o menu para continuar o AIM e o automático.")
            return
        }
        guard canCalculate, isPlayerTurn else {
            cancelAutomaticControlSequence(reason: "unavailable", pause: false)
            waitAutomation(message: aimActionReadiness)
            return
        }
        guard !isLuckyShot else { waitAutomation(message: "AIM contínuo disponível nas partidas de sinuca."); return }
        guard tableState?.balls.contains(where: { $0.id != 0 && !$0.pocketed }) == true else {
            stopAutomation(message: "Mesa concluída. AIM e automático desligados.")
            return
        }
        guard !legalTargets.isEmpty else {
            cancelAutomaticControlSequence(reason: "legalTargetsUnavailable", pause: false)
            waitAutomation(message: "Aguardando o jogo informar as bolas permitidas.")
            return
        }
        guard runtimeCanShoot else {
            let touched = snapshot.map { Self.hasNativeControlTouch($0) } ?? false
            cancelAutomaticControlSequence(reason: touched ? "manualTouch" : "nativeReadiness", pause: touched)
            waitAutomation(message: liveReadiness)
            return
        }
        if autoPlayEnabled || singleShotRequested {
            guard autoShotAvailable else {
                cancelAutomaticControlSequence(reason: "shotUnavailable", pause: false)
                waitAutomation(message: autoShotUnavailableReason)
                return
            }
            guard tableState != lastSubmittedState else {
                waitAutomation(message: "Aguardando confirmação da tacada anterior. Esta posição não será repetida.")
                return
            }
        }
        let now = ProcessInfo.processInfo.systemUptime
        guard now >= automaticRetryAfter else { return }
        guard let stableSince, now - stableSince >= minimumStableTime else {
            waitAutomation(message: "Confirmando que a mesa está parada…")
            return
        }
        guard let context = currentAutomaticContext, context != automaticBlockedContext else { return }
        if let ready = automaticPlan, ready.context == context {
            if (autoPlayEnabled || aimEnabled) && !ready.aimApplied {
                advanceAutomaticControlSequence(ready, at: now)
            }
            return
        }
        startPlanning(autoPlayEnabled ? .autoPlay : (aimEnabled ? .continuousAim : .singleShot))
    }

    private func advanceAutomaticControlSequence(_ plan: AutomaticPlan, at now: TimeInterval) {
        guard automationIsRunning, aimEnabled, !panelIsOpen, canApplyAim,
              currentAutomaticContext == plan.context else { return }
        let controlStartedAt = ProcessInfo.processInfo.systemUptime
        if plan.controlSequence == nil { maximumAutomaticControlMilliseconds = 0 }
        defer {
            lastAutomaticControlMilliseconds = max(0, ProcessInfo.processInfo.systemUptime - controlStartedAt) * 1_000
            maximumAutomaticControlMilliseconds = max(maximumAutomaticControlMilliseconds, lastAutomaticControlMilliseconds)
        }
        do {
            let current = try PLRuntimeBridge.capture()
            if Self.hasNativeControlTouch(current) {
                cancelAutomaticControlSequence(reason: "manualTouch", pause: true)
                return
            }
            let normalized = try Self.normalized(current)
            guard current.playerTurn, current.canShoot, current.shotInputSupported,
                  Self.isFreshSample(current.captureTimestamp, at: ProcessInfo.processInfo.systemUptime),
                  normalized.calibrated, normalized.nativePhysics, normalized.predictionIssue == nil,
                  !normalized.moving, normalized.state == plan.context.state,
                  ObjectIdentifier(current.coordinateView) == plan.context.coordinate,
                  Set(current.legalTargetNumbers.map { $0.intValue }) == plan.context.allowed,
                  current.isBreakShot == plan.context.isBreakShot,
                  plan.context.allowed.contains(plan.suggestion.targetID), current.aimAvailable,
                  current.aimAngle.isFinite, current.cuePower.isFinite, (0...1).contains(current.cuePower),
                  isAuthorized else { throw CaptureError.changedTable }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: plan.suggestion.shot.power)
            var sequence: AutomaticControlSequence
            if let existing = plan.controlSequence {
                sequence = existing
                // Each previous setter already confirmed these exact values.
                // A later external adjustment belongs to the player; never
                // overwrite it or release a shot after it.
                if sequence.hasApplied &&
                    (abs(Self.controlAngleDelta(from: current.aimAngle, to: sequence.lastAngle)) > 0.00001 ||
                     abs(current.cuePower - sequence.lastPower) > 0.00001) {
                    cancelAutomaticControlSequence(reason: "manualControlChange", pause: true)
                    return
                }
                let delta = now - sequence.lastTickAt
                guard delta.isFinite, delta >= 0, delta <= 0.25 else {
                    cancelAutomaticControlSequence(reason: "frameGap", pause: false)
                    return
                }
                // A dropped frame cannot jump the whole pull/release sequence.
                sequence.elapsed += min(delta, 1.0 / 30.0)
                sequence.lastTickAt = now
            } else {
                if automaticAttemptContext != plan.context {
                    automaticAttemptContext = plan.context
                    automaticCommandAttempts = 0
                    automaticControlAttempts = 0
                }
                automaticControlAttempts += 1
                let targetAngle = -plan.suggestion.shot.angleRadians
                let angleDelta = Self.controlAngleDelta(from: current.aimAngle, to: targetAngle)
                sequence = AutomaticControlSequence(startAngle: current.aimAngle, startPower: current.cuePower,
                    targetAngle: targetAngle, targetPower: nativePower, angleDelta: angleDelta,
                    alignmentDuration: 0.45 + 0.65 * abs(angleDelta) / .pi,
                    pullDuration: 0.65 + 0.45 * nativePower, lastTickAt: now,
                    lastAngle: current.aimAngle, lastPower: current.cuePower)
                recordCaptureEvent("controlSequenceStarted", at: now,
                    details: ["target": String(plan.suggestion.targetID), "pocket": String(plan.suggestion.pocketID),
                              "power": String(nativePower)])
            }
            let phaseBefore = plan.controlSequence?.phase
            let aligning = sequence.elapsed < sequence.alignmentDuration
            let controlAngle: Double
            let controlPower: Double
            if aligning {
                let t = Self.smoothControlFraction(sequence.elapsed / sequence.alignmentDuration)
                controlAngle = sequence.startAngle + sequence.angleDelta * t
                controlPower = sequence.startPower * (1 - t)
            } else {
                controlAngle = sequence.targetAngle
                let t = Self.smoothControlFraction((sequence.elapsed - sequence.alignmentDuration) / sequence.pullDuration)
                controlPower = sequence.targetPower * t
            }
            try PLRuntimeBridge.applyAimProgress(angle: controlAngle, power: controlPower,
                target: plan.suggestion.targetID, pocket: plan.suggestion.pocketID)
            sequence.lastAngle = controlAngle
            sequence.lastPower = controlPower
            sequence.hasApplied = true
            automaticPlan?.controlSequence = sequence
            angleDegrees = Self.degrees(-controlAngle)
            power = controlPower
            followGameAim = true
            previewIsTemporary = false
            if phaseBefore != sequence.phase {
                recordCaptureEvent("controlSequencePhase", at: now, details: ["phase": sequence.phase])
                if sequence.phase == "aligning" { automationStatus = "Alinhando o taco na bola \(plan.suggestion.targetID)…" }
                else if sequence.phase == "pulling" { automationStatus = "Ajustando a força para \(Int((nativePower * 100).rounded()))%…" }
                else if sequence.phase == "settling" { automationStatus = "Conferindo a direção e a força antes da tacada…" }
            }
            guard sequence.phase == "ready" else { return }
            automaticPlan?.aimApplied = true
            if autoPlayEnabled {
                execute(plan.suggestion, expectedState: plan.context.state, allowed: plan.context.allowed)
            } else {
                automaticPlan?.controlSequence = nil
                automationStatus = "AIM na bola \(plan.suggestion.targetID), força \(Int((nativePower * 100).rounded()))%. Aguardando sua tacada."
                recordCaptureEvent("continuousAimApplied", at: now,
                    details: ["target": String(plan.suggestion.targetID), "pocket": String(plan.suggestion.pocketID)])
            }
        } catch {
            automaticPlan = nil
            recordCaptureEvent("controlSequenceRejected", at: ProcessInfo.processInfo.systemUptime,
                details: ["code": String((error as NSError).code), "domain": (error as NSError).domain,
                          "attempt": String(automaticControlAttempts)])
            if case CaptureError.changedTable = error {
                stableSince = nil
                waitAutomation(message: "A mesa mudou. Aguardando uma leitura estável para o AIM.")
            } else if (error as NSError).domain == "PoolLab.RuntimeBridge" && (error as NSError).code == 58 {
                pauseAutomaticActions(message: "Controles interrompidos: \(error.localizedDescription)")
            } else if automaticControlAttempts < 2 {
                automaticRetryAfter = ProcessInfo.processInfo.systemUptime + 0.75
                stableSince = nil
                waitAutomation(message: "Aguardando o jogo liberar o ajuste gradual da mira.")
            } else {
                pauseAutomaticActions(message: "AIM pausado: \(error.localizedDescription)")
            }
        }
    }

    private static func hasNativeControlTouch(_ current: PLGameSnapshot) -> Bool {
        ["nativeCurrentTouches", "nativeTouchArrayCount", "nativeCueCurrentTouches"].contains {
            (Int(current.diagnostics[$0] ?? "") ?? 0) > 0
        }
    }

    private static func controlAngleDelta(from start: Double, to target: Double) -> Double {
        (target - start).remainder(dividingBy: 2 * .pi)
    }

    private static func smoothControlFraction(_ value: Double) -> Double {
        let t = min(1, max(0, value))
        return t * t * (3 - 2 * t)
    }

    private func cancelAutomaticControlSequence(reason: String, pause: Bool) {
        guard automaticPlan?.controlSequence != nil || (pause && automaticPlan != nil) else { return }
        automaticPlan = nil
        stableSince = nil
        recordCaptureEvent("controlSequenceCancelled", at: ProcessInfo.processInfo.systemUptime,
                           details: ["reason": reason])
        if pause {
            pauseAutomaticActions(message: "Controle manual detectado. Toque em continuar para retomar o automático.")
        }
        // Leave the cue where it is. Resetting its force here could overwrite
        // the very manual gesture or changed game state that cancelled us.
    }

    private func execute(_ suggestion: ShotSuggestion, expectedState: TableState, allowed: Set<Int>) {
        guard (autoPlayEnabled && automationIsRunning) || singleShotRequested,
              isAuthorized, !isWaitingForShot, !panelIsOpen,
              expectedState != lastSubmittedState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            let currentAllowed = Set(current.legalTargetNumbers.map { $0.intValue })
            guard current.playerTurn, current.canShoot, current.autoShotAvailable, current.shotInputSupported,
                  Self.isFreshSample(current.captureTimestamp, at: ProcessInfo.processInfo.systemUptime),
                  current.isBreakShot == (suggestion.method == .breakShot),
                  normalized.calibrated, normalized.nativePhysics, normalized.predictionIssue == nil, !normalized.moving, normalized.state == expectedState,
                  current.coordinateView === snapshot?.coordinateView,
                  currentAllowed == allowed, allowed.contains(suggestion.targetID),
                  isAuthorized else { throw CaptureError.changedTable }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power)
            if autoPlayEnabled && !singleShotRequested {
                guard let prepared = automaticPlan, prepared.aimApplied,
                      prepared.suggestion.id == suggestion.id,
                      prepared.context == currentAutomaticContext,
                      prepared.controlSequence?.phase == "ready",
                      abs(Self.controlAngleDelta(from: current.aimAngle, to: -suggestion.shot.angleRadians)) <= 0.00001,
                      abs(current.cuePower - nativePower) <= 0.00001,
                      !Self.hasNativeControlTouch(current) else {
                    cancelAutomaticControlSequence(reason: "finalControlMismatch", pause: true)
                    return
                }
            }
            // Mark before entering the game: even a partial runtime failure
            // cannot cause a second invocation for this unchanged board.
            let context = currentAutomaticContext
            if automaticAttemptContext != context {
                automaticAttemptContext = context
                automaticCommandAttempts = 0
            }
            automaticCommandAttempts += 1
            lastSubmittedState = expectedState
            shotSubmittedAt = ProcessInfo.processInfo.systemUptime
            isWaitingForShot = true
            singleShotRequested = false
            recordCaptureEvent("shotSubmitted", at: ProcessInfo.processInfo.systemUptime,
                               details: ["target": String(suggestion.targetID), "pocket": String(suggestion.pocketID),
                                         "method": suggestion.method.rawValue])
            try PLRuntimeBridge.shoot(angle: -suggestion.shot.angleRadians, power: nativePower,
                                      target: suggestion.targetID, pocket: suggestion.pocketID)
            angleDegrees = Self.degrees(suggestion.shot.angleRadians)
            power = nativePower
            followGameAim = true
            automationStatus = "Tacada enviada. Aguardando movimento no jogo…"
            status = suggestion.method == .breakShot ? "Tacada de saída enviada." : "Bola \(suggestion.targetID), caçapa \(suggestion.pocketID + 1)."
            cancelPrediction(clearOverlay: true)
        } catch {
            recordCaptureEvent("automaticShotRejected", at: ProcessInfo.processInfo.systemUptime,
                details: ["code": String((error as NSError).code), "domain": (error as NSError).domain,
                          "attempt": String(automaticCommandAttempts),
                          "shotDispatched": ((error as NSError).userInfo["shotDispatched"] as? Bool).map(String.init) ?? "unknown"])
            shotSubmittedAt = nil
            isWaitingForShot = false
            if (error as NSError).userInfo["shotDispatched"] as? Bool == false {
                // A rejected guard is different from an uncertain release.
                // The bridge explicitly proves that no shot callback ran.
                lastSubmittedState = nil
            }
            automaticPlan = nil
            if case CaptureError.changedTable = error {
                stableSince = nil
                waitAutomation(message: "A mesa mudou. Aguardando nova leitura para calcular a tacada.")
            } else if (error as NSError).userInfo["shotDispatched"] as? Bool == false,
                      autoPlayEnabled, automaticCommandAttempts < 2 {
                automaticRetryAfter = ProcessInfo.processInfo.systemUptime + 0.75
                stableSince = nil
                waitAutomation(message: "O jogo ainda não liberou a tacada. Conferindo novamente.")
            } else {
                pauseAutomaticActions(message: "Tacada automática pausada: \(error.localizedDescription)")
            }
            status = automationStatus
        }
    }

    private func acknowledgeShotProgress() {
        guard isMoving || !isPlayerTurn else { return }
        lastSubmittedState = nil
        automaticPlan = nil
        automaticBlockedContext = nil
        automaticAttemptContext = nil
        automaticCommandAttempts = 0
        automaticControlAttempts = 0
        if isWaitingForShot {
            isWaitingForShot = false
            shotSubmittedAt = nil
            automationStatus = autoPlayEnabled ? "Tacada iniciada. Aguardando as bolas pararem." : "Tacada iniciada no jogo."
            recordCaptureEvent("shotMotionObserved", at: ProcessInfo.processInfo.systemUptime)
        }
    }

    private func waitAutomation(message: String) {
        if (automationIsRunning || singleShotRequested) && automationStatus != message { automationStatus = message }
    }

    private func pauseAutomaticActions(message: String) {
        if automationArmed { automationPaused = true }
        singleShotRequested = false
        cancelPlanner(clearSuggestions: true)
        automaticPlan = nil
        if automationStatus != message { automationStatus = message }
    }

    private func stopAutomation(message: String) {
        if automationArmed || singleShotRequested {
            recordCaptureEvent("automationStopped", at: ProcessInfo.processInfo.systemUptime,
                               details: ["reason": String(message.prefix(256))])
        }
        unsupportedMotionStartedAt = nil
        queueTransition = nil
        if autoPlayEnabled { autoPlayEnabled = false }
        if aimEnabled { aimEnabled = false }
        if automationPaused { automationPaused = false }
        automaticPlan = nil
        automaticBlockedContext = nil
        if singleShotRequested { singleShotRequested = false }
        if planningPurpose == .singleShot || planningPurpose == .autoPlay || planningPurpose == .continuousAim {
            cancelPlanner(clearSuggestions: false)
        }
        if automationStatus != message { automationStatus = message }
    }

    private func handleCaptureFailure(_ error: Error, at now: TimeInterval, transient: Bool) {
        let runtime = error as NSError
        let firstFailure = captureFailureStartedAt == nil
        if firstFailure {
            captureFailureStartedAt = now
            recordCaptureEvent("captureUnavailable", at: now,
                               details: ["domain": runtime.domain, "code": String(runtime.code),
                                         "reason": String(error.localizedDescription.prefix(256))])
        }
        captureHealthy = false
        runtimeCanShoot = false
        stableSince = nil
        // No fresh-reading gate can authorize a shot during even one failure.
        if firstFailure {
            automaticPlan = nil
            cancelPrediction(clearOverlay: true)
            cancelPlanner(clearSuggestions: true)
            if queueTransition == nil && (automationArmed || singleShotRequested) {
                waitAutomation(message: "Aguardando uma nova leitura da mesa.")
            }
        }
        // Expected native transitions do not repeatedly reset the panel's
        // entire table state. Hide estimates immediately, then clear a lasting
        // loss after a bounded grace period. Authorization failures never use it.
        let failureAge = max(0, now - (captureFailureStartedAt ?? now))
        if transient && hasTable && failureAge < 3 {
            onOverlayChange?()
            return
        }
        clearBoard(message: "Leitura indisponível: \(error.localizedDescription)",
                   preserveQueueIntent: queueTransition != nil && transient)
    }

    func panelOpened() {
        panelIsOpen = true
        if planningPurpose == .singleShot || planningPurpose == .autoPlay || planningPurpose == .continuousAim {
            cancelPlanner(clearSuggestions: true)
        }
        automaticPlan = nil
        if (automationArmed && !automationPaused) || singleShotRequested {
            automationStatus = "Feche o menu para continuar o AIM e o automático."
        }
        onOverlayChange?()
    }

    func panelClosed() {
        let keepSelectedPreview = selectedSuggestionID != nil && suggestionContextIsCurrent
            && !autoPlayEnabled && !singleShotRequested && !followGameAim && previewIsTemporary
        panelIsOpen = false
        if !keepSelectedPreview { selectedSuggestionID = nil }
        if automationArmed || singleShotRequested { stableSince = ProcessInfo.processInfo.systemUptime }
        if previewIsTemporary && !keepSelectedPreview {
            previewIsTemporary = false
            followGameAim = true
            poll()
        }
        onOverlayChange?()
    }

    private func cancelPlanner(clearSuggestions: Bool) {
        plannerGeneration &+= 1
        plannerTask?.cancel()
        plannerTask = nil
        planningPurpose = nil
        if isPlanning { isPlanning = false }
        if clearSuggestions {
            suggestionState = nil
            suggestionAllowed = []
            suggestionCoordinateIdentity = nil
            if selectedSuggestionID != nil {
                selectedSuggestionID = nil
                followGameAim = true
                previewIsTemporary = false
            }
            if !suggestions.isEmpty { suggestions = [] }
            if suggestionStatus != "Calcule uma sugestão quando a mesa estiver pronta." {
                suggestionStatus = "Calcule uma sugestão quando a mesa estiver pronta."
            }
            if luckySuggestion != nil { luckySuggestion = nil }
        }
    }

    private func pauseAutomationForUnsupportedMotion(issue: String, at now: TimeInterval) {
        guard automationArmed || singleShotRequested else { return }
        // A native pocket animation can leave the independent solver's rectangle.
        // Keep only already-armed intent, never a plan or release permission.
        guard automationIsRunning, isAuthorized, hasFreshCapture else {
            waitAutomation(message: issue)
            return
        }
        automaticPlan = nil
        if unsupportedMotionStartedAt == nil {
            unsupportedMotionStartedAt = now
            recordCaptureEvent("autoPlayPausedForNativeMotion", at: now)
        }
        guard let since = unsupportedMotionStartedAt, now - since < unsupportedMotionTimeout else {
            pauseAutomaticActions(message: "A mesa não voltou a uma geometria suportada em 30 segundos. Confira a partida.")
            return
        }
        let message = "Automático aguardando as bolas e a caçapa terminarem o movimento."
        waitAutomation(message: message)
    }

    private static func isFreshSample(_ timestamp: TimeInterval, at now: TimeInterval) -> Bool {
        timestamp.isFinite && now.isFinite && timestamp <= now + 0.01 && now - timestamp <= 0.25
    }

    private struct AutomaticContext: Equatable {
        let state: TableState
        let allowed: Set<Int>
        let coordinate: ObjectIdentifier
        let isBreakShot: Bool
    }

    private struct AutomaticPlan {
        let context: AutomaticContext
        let suggestion: ShotSuggestion
        var aimApplied = false
        var controlSequence: AutomaticControlSequence?
    }

    private struct AutomaticControlSequence {
        let startAngle: Double
        let startPower: Double
        let targetAngle: Double
        let targetPower: Double
        let angleDelta: Double
        let alignmentDuration: TimeInterval
        let pullDuration: TimeInterval
        var lastTickAt: TimeInterval
        var elapsed: TimeInterval = 0
        var lastAngle: Double
        var lastPower: Double
        var hasApplied = false
        var phase: String {
            if elapsed < alignmentDuration { return "aligning" }
            if elapsed < alignmentDuration + pullDuration { return "pulling" }
            if elapsed < alignmentDuration + pullDuration + 0.18 { return "settling" }
            return "ready"
        }
    }

    private var currentAutomaticContext: AutomaticContext? {
        guard let tableState, let snapshot else { return nil }
        return AutomaticContext(state: tableState, allowed: legalTargets,
            coordinate: ObjectIdentifier(snapshot.coordinateView), isBreakShot: snapshot.isBreakShot)
    }
    static var checks = 0
    static func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
        checks += 1
        if !condition() { fatalError("CHECK \(checks): \(message)") }
    }
    static func fixture() -> IntegratedGameModel {
        let model = IntegratedGameModel()
        let state = TableState(table: PoolTable(), balls: [PoolBall(id:0,position:Vector2(x:40,y:50)),PoolBall(id:1,position:Vector2(x:101,y:50))])
        model.tableState = state
        model.snapshot = Snapshot(state:state,coordinateView:MockView(),legalTargetNumbers:[1])
        PLRuntimeBridge.snapshot = model.snapshot
        PLRuntimeBridge.shootError = nil; PLRuntimeBridge.aimError = nil; PLRuntimeBridge.captureError = nil
        PLRuntimeBridge.forceStale = false
        PLRuntimeBridge.shoots = []; PLRuntimeBridge.aims = []
        return model
    }
    func prepare(_ suggestion: ShotSuggestion) {
        isPlanning = false; plannerTask = nil; planningPurpose = nil
        automaticPlan = AutomaticPlan(context:currentAutomaticContext!,suggestion:suggestion)
        stableSince = ProcessInfo.processInfo.systemUptime - 1
    }
    func tick(_ delta: Double = 1.0 / 60.0) {
        if automaticPlan?.controlSequence != nil {
            automaticPlan!.controlSequence!.lastTickAt = ProcessInfo.processInfo.systemUptime - delta
        }
        snapshot = PLRuntimeBridge.snapshot
        advanceAutomation()
    }
    func finish() {
        for _ in 0..<240 {
            if automaticPlan?.aimApplied == true || automationPaused || isWaitingForShot { return }
            tick()
        }
    }
    static func run() throws {
        let seed = fixture()
        let suggestion = try ShotPlanner.suggestions(for:seed.tableState!,includeBanks:true,limit:1,allowedTargetIDs:[1]).first!
        let nativePower = try GameShotCalibration.controlPower(fromSimulationPower:suggestion.shot.power)
        expect(abs(controlAngleDelta(from:179 * .pi / 180,to:-179 * .pi / 180) - 2 * .pi / 180) < 1e-12,"shortest circular path crosses wrap in two degrees")
        expect(smoothControlFraction(-1) == 0 && smoothControlFraction(2) == 1 && smoothControlFraction(0.5) == 0.5,"easing bounded exact endpoints")

        let aim = fixture(); aim.setAutoAimEnabled(true); aim.prepare(suggestion); aim.tick()
        expect(PLRuntimeBridge.aims.count == 1 && PLRuntimeBridge.shoots.isEmpty && aim.automaticPlan?.aimApplied == false,"first tick initializes without instant final aim or release")
        let originalAngle = PLRuntimeBridge.aims[0].angle
        for _ in 0..<8 { aim.tick() }
        expect(PLRuntimeBridge.aims.count == 9 && PLRuntimeBridge.aims.last!.angle != originalAngle,"direction advances across display frames")
        expect(PLRuntimeBridge.aims.allSatisfy { $0.power == 0 },"rotation precedes power pull")
        expect(aim.automaticPlan!.controlSequence!.phase == "aligning","initial phase is alignment")
        var pulls: [Double] = []
        var observedSettling = false
        for _ in 0..<220 {
            aim.tick()
            if aim.automaticPlan?.controlSequence?.phase == "pulling" { pulls.append(PLRuntimeBridge.aims.last!.power) }
            if aim.automaticPlan?.controlSequence?.phase == "settling" { observedSettling = true }
            if aim.automaticPlan?.aimApplied == true { break }
        }
        expect(pulls.count > 20 && zip(pulls,pulls.dropFirst()).allSatisfy { $0 <= $1 },"power ramps monotonically through intermediate samples")
        expect(observedSettling && aim.automaticPlan?.aimApplied == true,"settling then final completion")
        expect(abs(PLRuntimeBridge.aims.last!.angle + suggestion.shot.angleRadians) < 1e-12,"exact selected final angle preserved")
        expect(abs(PLRuntimeBridge.aims.last!.power - nativePower) < 1e-12,"exact calibrated final power preserved without rescaling")
        expect(PLRuntimeBridge.shoots.isEmpty,"AIM-only never releases")
        let applied = PLRuntimeBridge.aims.count
        for _ in 0..<20 { aim.tick() }
        expect(PLRuntimeBridge.aims.count == applied,"AIM remains applied once on unchanged board")

        let auto = fixture(); auto.setAutoPlay(true); auto.prepare(suggestion); auto.tick()
        expect(PLRuntimeBridge.shoots.isEmpty,"Auto Play cannot release on first tick")
        auto.finish()
        expect(PLRuntimeBridge.shoots.count == 1 && auto.isWaitingForShot,"Auto Play releases once only after full sequence")
        expect(PLRuntimeBridge.shoots[0].power == nativePower && PLRuntimeBridge.shoots[0].angle == -suggestion.shot.angleRadians,"release uses exact same solution shown during alignment")
        expect(PLRuntimeBridge.aims.allSatisfy { $0.target == suggestion.targetID && $0.pocket == suggestion.pocketID },"every progress step keeps selected target and pocket")
        for _ in 0..<20 { auto.tick() }
        expect(PLRuntimeBridge.shoots.count == 1,"pending dispatch remains latched")
        auto.isMoving = true; auto.acknowledgeShotProgress(); auto.isMoving = false
        auto.tableState!.balls[1].position.x += 4; auto.snapshot!.state = auto.tableState!; PLRuntimeBridge.snapshot = auto.snapshot
        auto.prepare(suggestion); auto.tick(); auto.finish()
        expect(PLRuntimeBridge.shoots.count == 2,"second settled own turn performs a fresh complete sequence")

        let pause = fixture(); pause.setAutoPlay(true); pause.prepare(suggestion); pause.tick(); pause.tick(); pause.toggleAutomationPause(); pause.tick()
        expect(pause.automaticPlan == nil && pause.automationPaused && PLRuntimeBridge.shoots.isEmpty,"pause cancels controls before release")
        let beforeResume = PLRuntimeBridge.aims.count
        pause.toggleAutomationPause(); pause.tick()
        expect(PLRuntimeBridge.aims.count == beforeResume && PLRuntimeBridge.shoots.isEmpty,"resume cannot release stale half-finished sequence")
        pause.prepare(suggestion); pause.tick(); pause.finish()
        expect(PLRuntimeBridge.shoots.count == 1,"resume can perform a fresh full sequence")

        let menu = fixture(); menu.setAutoPlay(true); menu.prepare(suggestion); menu.tick(); menu.panelOpened(); menu.tick()
        expect(menu.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"menu clears in-progress sequence")
        menu.panelClosed(); menu.tick()
        expect(PLRuntimeBridge.shoots.isEmpty,"menu close waits for fresh stable plan")

        let touched = fixture(); touched.setAutoPlay(true); touched.prepare(suggestion); touched.tick()
        PLRuntimeBridge.snapshot.diagnostics["nativeCurrentTouches"] = "1"; touched.runtimeCanShoot = false; touched.tick()
        expect(touched.automationPaused && touched.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"actual native touch pauses and cancels sequence")
        let touchedFresh = fixture(); touchedFresh.setAutoPlay(true); touchedFresh.prepare(suggestion); touchedFresh.tick()
        PLRuntimeBridge.snapshot.diagnostics["nativeCueCurrentTouches"] = "1"; PLRuntimeBridge.snapshot.canShoot = false; touchedFresh.tick()
        expect(touchedFresh.automationPaused && PLRuntimeBridge.shoots.isEmpty,"touch discovered by immediate fresh read pauses before generic readiness failure")

        let manual = fixture(); manual.setAutoPlay(true); manual.prepare(suggestion); manual.tick()
        PLRuntimeBridge.snapshot.aimAngle += 0.05; manual.tick()
        expect(manual.automationPaused && manual.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"external angle change takes ownership and inhibits release")
        let manualPower = fixture(); manualPower.setAutoPlay(true); manualPower.prepare(suggestion); manualPower.tick()
        PLRuntimeBridge.snapshot.cuePower += 0.02; manualPower.tick()
        expect(manualPower.automationPaused && PLRuntimeBridge.shoots.isEmpty,"external force change also inhibits release")

        let gap = fixture(); gap.setAutoPlay(true); gap.prepare(suggestion); gap.tick(); gap.tick(0.3)
        expect(gap.automaticPlan == nil && !gap.automationPaused && PLRuntimeBridge.shoots.isEmpty,"250ms capture gap cancels rather than snapping to release")
        let dropped = fixture(); dropped.setAutoPlay(true); dropped.prepare(suggestion); dropped.tick(); dropped.tick(0.20)
        expect(dropped.automaticPlan!.controlSequence!.elapsed <= 1.0 / 30.0 + 1e-7,"single slow frame advances at most one thirtieth of a second")

        let stale = fixture(); stale.setAutoPlay(true); stale.prepare(suggestion); stale.tick(); PLRuntimeBridge.forceStale = true; stale.tick()
        expect(stale.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"stale native capture cancels sequence")
        let changed = fixture(); changed.setAutoPlay(true); changed.prepare(suggestion); changed.tick(); PLRuntimeBridge.snapshot.state.balls[1].position.x += 1; changed.tick()
        expect(changed.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"changed exact table invalidates progressive plan")
        let opponent = fixture(); opponent.setAutoPlay(true); opponent.prepare(suggestion); opponent.tick(); opponent.isPlayerTurn = false; opponent.canCalculate = false; opponent.tick()
        expect(opponent.automaticPlan == nil && opponent.autoPlayEnabled && PLRuntimeBridge.shoots.isEmpty,"opponent turn cancels sequence while preserving mode intent")
        let moving = fixture(); moving.setAutoPlay(true); moving.prepare(suggestion); moving.tick(); moving.isMoving = true; moving.acknowledgeShotProgress(); moving.canCalculate = false; moving.tick()
        expect(moving.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"measured movement cannot finish old sequence")

        let capture = fixture(); capture.setAutoPlay(true); capture.prepare(suggestion); capture.tick()
        capture.handleCaptureFailure(NSError(domain:"PoolLab.RuntimeBridge",code:20),at:ProcessInfo.processInfo.systemUptime,transient:true)
        expect(capture.automaticPlan == nil && !capture.captureHealthy && capture.autoPlayEnabled,"capture loss clears progression and keeps intended mode")

        let uncertain = fixture(); uncertain.setAutoPlay(true); uncertain.prepare(suggestion); uncertain.tick()
        PLRuntimeBridge.shootError = NSError(domain:"PoolLab.RuntimeBridge",code:73,userInfo:["shotDispatched":true]); uncertain.finish()
        expect(uncertain.automationPaused && uncertain.lastSubmittedState != nil && PLRuntimeBridge.shoots.count == 1,"uncertain native release retains duplicate latch")
        uncertain.toggleAutomationPause(); uncertain.prepare(suggestion); uncertain.finish()
        expect(PLRuntimeBridge.shoots.count == 1,"resume cannot repeat uncertain dispatch on unchanged board")

        let rejected = fixture(); rejected.setAutoPlay(true); rejected.prepare(suggestion); rejected.tick()
        PLRuntimeBridge.aimError = NSError(domain:"PoolLab.RuntimeBridge",code:45); rejected.tick()
        expect(!rejected.automationPaused && rejected.automaticPlan == nil && rejected.automaticControlAttempts == 1,"first pre-release control failure permits one bounded restart")
        rejected.automaticRetryAfter = 0; rejected.prepare(suggestion); rejected.tick()
        expect(rejected.automationPaused && rejected.automaticControlAttempts == 2 && PLRuntimeBridge.shoots.isEmpty,"second control failure pauses without firing")
        let touchError = fixture(); touchError.setAutoPlay(true); touchError.prepare(suggestion); touchError.tick()
        PLRuntimeBridge.aimError = NSError(domain:"PoolLab.RuntimeBridge",code:58); touchError.tick()
        expect(touchError.automationPaused && PLRuntimeBridge.shoots.isEmpty,"native setter touch-race error pauses without retry")

        let unavailable = fixture(); unavailable.setAutoPlay(true); unavailable.prepare(suggestion); unavailable.tick()
        unavailable.autoShotAvailable = false; unavailable.tick()
        expect(unavailable.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"temporary shot support loss discards half-prepared controls")
        unavailable.autoShotAvailable = true; unavailable.tick()
        expect(PLRuntimeBridge.shoots.isEmpty,"restored shot support cannot release old partial sequence")
        unavailable.prepare(suggestion); unavailable.tick(); unavailable.finish()
        expect(PLRuntimeBridge.shoots.count == 1,"support recovery accepts a fresh complete sequence")
        let inputLost = fixture(); inputLost.setAutoPlay(true); inputLost.prepare(suggestion); inputLost.tick()
        inputLost.canCalculate = false; inputLost.tick()
        expect(inputLost.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"loss of supported calibrated input clears sequence")
        inputLost.canCalculate = true; inputLost.tick()
        expect(PLRuntimeBridge.shoots.isEmpty,"restored input awaits a fresh stabilized plan")
        let legalLost = fixture(); legalLost.setAutoPlay(true); legalLost.prepare(suggestion); legalLost.tick()
        legalLost.legalTargets = []; legalLost.tick()
        expect(legalLost.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"legal target disappearance clears sequence")

        let finalGuard = fixture(); finalGuard.setAutoPlay(true); finalGuard.prepare(suggestion)
        finalGuard.execute(suggestion,expectedState:finalGuard.tableState!,allowed:[1])
        expect(PLRuntimeBridge.shoots.isEmpty && finalGuard.automationPaused,"auto execute refuses unanimated plan without a completed progressive sequence")
        let disabled = fixture(); disabled.setAutoPlay(true); disabled.prepare(suggestion); disabled.tick(); disabled.setAutoAimEnabled(false); disabled.tick()
        expect(!disabled.automationArmed && disabled.automaticPlan == nil && PLRuntimeBridge.shoots.isEmpty,"switch off cancels sequence")
        let none = fixture(); none.setAutoPlay(true); none.automaticBlockedContext = none.currentAutomaticContext; none.stableSince = ProcessInfo.processInfo.systemUptime - 1; none.tick()
        expect(none.planRequests.isEmpty && PLRuntimeBridge.shoots.isEmpty,"no verified planner result never forces a speculative shot")
        print("{\"result\":\"passed\",\"checks\":\(checks),\"scope\":\"Exact source-extracted V13 progressive automation methods, deterministic display steps, mocked native I/O, actual Core fixture shot\"}")
    }
    static func awaitPlanner(_ model: IntegratedGameModel) async throws {
        let deadline = ProcessInfo.processInfo.systemUptime + 15
        while model.isPlanning && ProcessInfo.processInfo.systemUptime < deadline { try await Task.sleep(nanoseconds:10_000_000) }
    }
    static func runAsync() async throws {
        let model = fixture(); model.setAutoPlay(true)
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); expect(model.isPlanning,"actual detached planner starts")
        let generation = model.plannerGeneration
        model.toggleAutomationPause(); expect(model.plannerGeneration > generation,"pause invalidates pending planner generation")
        try await Task.sleep(nanoseconds:100_000_000)
        expect(PLRuntimeBridge.aims.isEmpty && PLRuntimeBridge.shoots.isEmpty,"cancelled planner cannot start controls")
        model.toggleAutomationPause(); model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); try await awaitPlanner(model)
        expect(!model.isPlanning && model.automaticPlan?.controlSequence != nil && PLRuntimeBridge.shoots.isEmpty,"accepted real planner begins gradual controls without immediate shot")
        expect(model.automaticPlan?.suggestion.id == model.suggestions.first?.id,"gradual sequence owns real top-ranked exact solution")
        model.finish(); expect(PLRuntimeBridge.shoots.count == 1,"real planning to staged controls ends in one release")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.tableState!.balls[1].position.x += 5; model.snapshot!.state = model.tableState!; PLRuntimeBridge.snapshot = model.snapshot
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1
        model.advanceAutomation(); try await awaitPlanner(model)
        expect(PLRuntimeBridge.shoots.count == 1 && model.automaticPlan?.controlSequence != nil,"second board gets a new full gradual sequence")
        model.finish(); expect(PLRuntimeBridge.shoots.count == 2,"two actual-planner turns complete continuously")
        model.isMoving = true; model.acknowledgeShotProgress(); model.isMoving = false
        model.stableSince = ProcessInfo.processInfo.systemUptime - 1; model.advanceAutomation()
        model.tableState!.balls[1].position.x += 5
        let applied = PLRuntimeBridge.aims.count
        try await awaitPlanner(model)
        expect(PLRuntimeBridge.aims.count == applied && PLRuntimeBridge.shoots.count == 2 && model.captureEvents.contains("planningDiscarded"),"changed-board completion cannot start a stale sequence")
        print("{\"result\":\"passed\",\"checks\":\(checks),\"scope\":\"Actual production startPlanning and Task.detached plus V13 Core, progression and dispatch; native I/O mocked\"}")
    }

}

@main struct Main { static func main() async throws { try await IntegratedGameModel.runAsync() } }
