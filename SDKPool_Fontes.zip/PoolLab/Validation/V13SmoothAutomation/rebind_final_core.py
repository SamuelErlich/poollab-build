from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path('new_project/PoolLab');out=Path('new_project/validation/v13_smooth_model');frozen=out/'final_core_inputs';frozen.mkdir(exist_ok=True);binary=out/'final_core';binary.mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=['PracticeGeometry','BilliardsTypes','BilliardsEngine','GameShotCalibration','ShotPlanner','LuckyShotPlanner','TableStateCodec']
sourceMap={};inputMap={}
for name in names:
 rel=f'Sources/PoolLabCore/{name}.swift';src=root/rel;dst=frozen/src.name
 shutil.copy2(src,dst)
 sourceMap[rel]=digest(src);inputMap[str(dst)]=digest(dst);assert sourceMap[rel]==inputMap[str(dst)]
assert sourceMap['Sources/PoolLabCore/ShotPlanner.swift']=='120d4cef75e0c4dafe0d9d3b174fad920acbfaa3875a19bccf7bf4d0964bc161'
assert sourceMap['Sources/PoolLabCore/BilliardsTypes.swift']=='c1980d5f38dc0f0cf93995ff42cadaf673e072de134ae820aa6bc5404bd6e42f'
manifest={'sourceSHA256':sourceMap,'retainedInputSHA256':inputMap}
(out/'V13FinalCoreInputs.json').write_text(json.dumps(manifest,indent=2))
compiler=['python3','new_project/validation/v11_runtime/scoped_swiftc.py']
coreCommand=compiler+['-O','-enable-testing','-emit-library','-emit-module','-module-name','PoolLabCore']+[str(frozen/f'{name}.swift') for name in names]+['-o',str(binary/'libPoolLabCore.so')]
if '--finish' not in sys.argv:
 subprocess.run(coreCommand,check=True)
for path,sha in inputMap.items(): assert digest(path)==sha
for rel,sha in sourceMap.items(): assert digest(root/rel)==sha
commands={'core':coreCommand}
for kind,sources,flags,filename in [('synchronous','V13SmoothAutomationHarness.swift',[],'V13SmoothAutomationResults.json'),('asynchronous','V13AsyncSmoothAutomationHarness.swift',['-O','-parse-as-library'],'V13AsyncSmoothAutomationResults.json')]:
 executable=out/f'final_{kind}'
 command=compiler+flags+['-I',str(binary),'-L',str(binary),'-lPoolLabCore',str(out/sources),'-o',str(executable)]
 if '--finish' not in sys.argv:
  subprocess.run(command,check=True)
 commands[kind]=command
if '--finish' not in sys.argv:
 print('Compiled. Launch final_synchronous and final_asynchronous directly from the shell, then run this script with --finish.')
 raise SystemExit(0)
for kind,filename in [('synchronous','V13SmoothAutomationResults.json'),('asynchronous','V13AsyncSmoothAutomationResults.json')]:
 sourceResult=out/('Final'+filename)
 value=json.loads(sourceResult.read_text());assert value['result']=='passed'
 shutil.copy2(sourceResult,out/filename)
print('final Core +57 assertions passed')
reportPath=root/'Validation/V13SmoothAutomationAudit.json';report=json.loads(reportPath.read_text())
assert report['sourceSHA256']['Integrated/IntegratedGameModel.swift']==digest(root/'Integrated/IntegratedGameModel.swift')
report['compiledFixtureCoreSHA256']=digest(binary/'libPoolLabCore.so')
report['compiledCoreSourceSHA256']=sourceMap
report['compiledCoreInputReceipt']={'manifestBeforeCompilation':True,'inputsFrozenBeforeCompilation':True,'inputsRecheckedAfterCompilation':True,'productionSourcesRecheckedAfterCompilation':True,'compilerCommands':commands,'portableCompilerWrapperSHA256':digest(compiler[1])}
report['testResults']['synchronous']=json.loads((out/'V13SmoothAutomationResults.json').read_text())
report['testResults']['asynchronous']=json.loads((out/'V13AsyncSmoothAutomationResults.json').read_text())
dest=root/'Validation/V13SmoothAutomation';(dest/'CoreInputs').mkdir(exist_ok=True)
for name in names:
 dst=dest/'CoreInputs'/f'{name}.swift';shutil.copy2(frozen/f'{name}.swift',dst);report['fixtureSHA256'][str(dst.relative_to(root))]=digest(dst)
for name in ['V13FinalCoreInputs.json','V13SmoothAutomationResults.json','V13AsyncSmoothAutomationResults.json','rebind_final_core.py']:
 dst=dest/name;shutil.copy2(out/name,dst);report['fixtureSHA256'][str(dst.relative_to(root))]=digest(dst)
readme=dest/'README.txt';text=readme.read_text();text+='\nFinal source binding: V13FinalCoreInputs.json was written before the final\nscoped compilation from frozen CoreInputs. The source digests were checked\nbefore and after compilation; both48 synchronous and9 asynchronous assertions\nwere then rerun against that exact compiled module. rebind_final_core.py\nrecords the reproducible commands and binding procedure.\n';readme.write_text(text);report['fixtureSHA256'][str(readme.relative_to(root))]=digest(readme)
report['notes'].append('Final delivery rebinding rebuilt exactly7 frozen Core inputs matching final planner/types hashes and reran only the same57 focused assertions.')
reportPath.write_text(json.dumps(report,indent=2));print(json.dumps({'reportSHA256':digest(reportPath),'finalCoreLibrarySHA256':report['compiledFixtureCoreSHA256'],'sourceSHA256':sourceMap},indent=2))
