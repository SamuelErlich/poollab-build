V13 progressive AIM / Auto Play validation

The production model methods and nested control state are extracted verbatim.
Only native bridge I/O, UI/authorization collaborators and capture values are
mocked. A fixture shot is obtained from the actual compiled V13 PoolLabCore.
The display clock advances deterministically; no real game or UIKit is run.

48 synchronous assertions cover visible intermediate direction/power, shortest
rotation, exact final calibration, pause/menu/manual touch or manual control
change cancellation, capture/readiness/target/turn invalidation, frame gaps,
second-turn continuity, single dispatch, uncertain release latch and bounded
control retry. 9 async assertions run the actual production startPlanning and
Task.detached acceptance/cancellation with the actual V13 planner.

Reproduce from the workspace that contains new_project/PoolLab:
python3 new_project/validation/v13_smooth_model/build_async_harness.py
python3 new_project/validation/v11_runtime/scoped_swiftc.py -I new_project/validation/v13_planner -L new_project/validation/v13_planner -lPoolLabCore new_project/validation/v13_smooth_model/V13SmoothAutomationHarness.swift -o new_project/validation/v13_smooth_model/v13_smooth
new_project/validation/v13_smooth_model/v13_smooth
python3 new_project/validation/v11_runtime/scoped_swiftc.py -O -parse-as-library -I new_project/validation/v13_planner -L new_project/validation/v13_planner -lPoolLabCore new_project/validation/v13_smooth_model/V13AsyncSmoothAutomationHarness.swift -o new_project/validation/v13_smooth_model/v13_async_smooth
new_project/validation/v13_smooth_model/v13_async_smooth

Compiler: official scoped Swift 5.10.1 Ubuntu24.04 frontend wrapper.
The async fixture uses -O as the previous V11 fixture did. An initial unoptimized
async launch aborted inside the Linux runtime; the optimized build exited0
and passed all9 assertions. Historical V11 optimized control also exited0.
This does not verify an Apple SDK build, real native callbacks, frame time on an
iPhone, or linkage from native cue power to the external power-bar UI.

Final source binding: V13FinalCoreInputs.json was written before the final
scoped compilation from frozen CoreInputs. The source digests were checked
before and after compilation; both48 synchronous and9 asynchronous assertions
were then rerun against that exact compiled module. rebind_final_core.py
records the reproducible commands and binding procedure.
