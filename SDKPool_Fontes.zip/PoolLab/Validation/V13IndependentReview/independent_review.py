"""Independent read-only V13 comparison against the delivered V12 archive.

Run from workspace root. This does not assert iPhone behavior or compilation.
"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path('new_project/PoolLab')
BASELINE = Path('new_project/validation/v12_before_v13/SDKPool_Fontes.zip')
OUTPUT = Path('new_project/validation/v13_review/V13IndependentReview.json')

def digest(data):
    return hashlib.sha256(data).hexdigest()

checks = []
def check(condition, name):
    checks.append({'id': name, 'passed': bool(condition)})

with zipfile.ZipFile(BASELINE) as archive:
    baseline = {name.removeprefix('PoolLab/'): archive.read(name)
                for name in archive.namelist()
                if name.startswith('PoolLab/') and not name.endswith('/')}

def declaration(text, signature):
    start = text.index(signature)
    line_start = text.rfind('\n', 0, start) + 1
    indent = text[line_start:start]
    assert not indent.strip(), signature
    opening = text.index('{', start)
    first_end = text.find('\n', opening)
    # Some short property declarations fit on one line.
    if '}' in text[opening:first_end]:
        return text[start:first_end].rstrip()
    closing = re.search(r'^' + re.escape(indent) + r'\}', text[opening:], re.M)
    assert closing, signature
    return text[start:opening + closing.end()]

previous_preservation = json.loads(baseline['Validation/V11IndependentPreservation.json'])
protected = []
for item in previous_preservation['protectedDeclarations']:
    relative, signature = item['file'], item['declaration']
    previous = declaration(baseline[relative].decode(), signature)
    current = declaration((ROOT / relative).read_text(), signature)
    # The account view contains only the public release label change.
    comparison = current.replace('SDKPool 1.11 · compilação 13', 'SDKPool 1.10 · compilação 12')
    identical = comparison == previous
    check(identical, 'protected:' + relative + ':' + signature)
    protected.append({'file': relative, 'declaration': signature,
                      'preservedToV12': identical, 'sha256': digest(current.encode())})

native_path = 'Integrated/PLRuntimeBridge.m'
native = (ROOT / native_path).read_text()
addition = declaration(native, '+ (BOOL)applyProgressAngle:')
check(native.replace(addition + '\n\n', '', 1).encode() == baseline[native_path],
      'native_source_byte_identical_after_removing_single_progressive_addition')
check(not any(marker in addition for marker in ['PLShotReleaseFunction', 'didDispatch', 'pl_shootAngle:', 'release)(']),
      'progressive_native_addition_cannot_dispatch_release')
check('power < 0 || power > 1' in addition and 'hasMinimumPowerRatio' not in addition,
      'progressive_control_allows_intermediate_zero_without_minimum_release_guard')
for marker in ['PLCapture(error)', 'snapshot.canShoot', 'snapshot.autoShotAvailable',
               'snapshot.legalTargetNumbers', 'PLReadyToPlan(manager, cue',
               'freshManager != manager', 'freshTable != table',
               'freshRules.rules != rules.rules', 'PLCenteredEnglish(finalEnglish)',
               'fabs(remainder(verifiedAngle-angle', 'fabs(verifiedPower-power)']:
    check(marker in addition, 'progressive_guard:' + marker)
check(declaration(native, 'static BOOL PLReadyToPlan(') ==
      declaration(baseline[native_path].decode(), 'static BOOL PLReadyToPlan('),
      'v12_off_table_residual_spin_fix_and_input_readiness_preserved')

protected_sources = sorted(path for path in baseline
                           if path.startswith('Sources/') and path.endswith('.swift')
                           and path not in {'Sources/PoolLabCore/ShotPlanner.swift',
                                            'Sources/PoolLabCore/BilliardsTypes.swift'})
for relative in protected_sources:
    check((ROOT / relative).read_bytes() == baseline[relative], 'unchanged_core_auth:' + relative)

production_roots = {'.github', 'Integrated', 'Sources', 'Resources', 'iOS', 'Tests', 'scripts', 'PoolLab.xcodeproj'}
production_paths = sorted(path for path in baseline if path.split('/')[0] in production_roots or path == 'Package.swift')
actual_paths = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()
                      and (p.relative_to(ROOT).parts[0] in production_roots or p.relative_to(ROOT).as_posix() == 'Package.swift'))
added = sorted(set(actual_paths) - set(production_paths))
check(set(production_paths) <= set(actual_paths) and added == ['Tests/PoolLabCoreTests/V13PlannerTests.swift'],
      'production_inventory_preserved_plus_one_new_planner_test_file')
source_hashes = {relative: digest((ROOT / relative).read_bytes()) for relative in actual_paths}
changed = [relative for relative in production_paths if (ROOT / relative).read_bytes() != baseline[relative]]
allowed = {'Integrated/IntegratedGameModel.swift', 'Integrated/PoolLabIntegration.swift',
           'Integrated/PLRuntimeBridge.m', 'Integrated/PLRuntimeBridge.h',
           'Sources/PoolLabCore/BilliardsTypes.swift', 'Sources/PoolLabCore/ShotPlanner.swift',
           'Tests/PoolLabCoreTests/ShotPlannerTests.swift',
           'iOS/PracticeView.swift', 'PoolLab.xcodeproj/project.pbxproj',
           'scripts/build_integration_framework.sh', 'scripts/upgrade_poollab_ipa.py'}
check(set(changed) <= allowed, 'changes_restricted_to_reviewed_production_files')

types_path = 'Sources/PoolLabCore/BilliardsTypes.swift'
types = (ROOT / types_path).read_text()
types_normalized = types.replace(declaration(types, 'public enum ShotMethod:'),
                                 declaration(baseline[types_path].decode(), 'public enum ShotMethod:'))
check(types_normalized.encode() == baseline[types_path],
      'physics_types_byte_identical_except_shot_method_labels')
ui_path = 'Integrated/PoolLabIntegration.swift'
check((ROOT / ui_path).read_text().replace('SDKPool 1.11 · compilação 13',
      'SDKPool 1.10 · compilação 12').encode() == baseline[ui_path],
      'entire_integrated_ui_unchanged_except_visible_version_label')

model = (ROOT / 'Integrated/IntegratedGameModel.swift').read_text()
for signature in ['private static func minimumPlannerPower(', 'private func handleCaptureFailure(',
                  'func panelOpened(', 'func panelClosed(', 'func toggleAutomationPause(',
                  'private func stopAutomation(', 'private func pauseAutomaticActions(']:
    check(declaration(model, signature) ==
          declaration(baseline['Integrated/IntegratedGameModel.swift'].decode(), signature),
          'preserved_control_boundary:' + signature)

planner = (ROOT / 'Sources/PoolLabCore/ShotPlanner.swift').read_text()

report = {
    'format': 'SDKPool.V13.IndependentIntegrationReview',
    'result': 'passed' if all(item['passed'] for item in checks) else 'failed',
    'scope': 'Independent read-only source comparison and boundary review; no iPhone execution claim.',
    'baselineArchiveSHA256': digest(BASELINE.read_bytes()),
    'sourceSHA256': source_hashes,
    'changedProductionFiles': changed,
    'addedProductionFiles': added,
    'protectedDeclarations': protected,
    'checks': checks,
    'checkCount': len(checks),
    'reviewFindings': [
        {'id': 'progressive_controls', 'result': 'passed', 'finding':
         'The existing capture/display loop advances a shortest-angle smoothstep alignment, native power pull and settling hold. Each step fresh-checks board, turn, targets, view, break mode, authority, native readiness and prior control readback. This changes cue controls without injecting touches.'},
        {'id': 'interruption_and_release', 'result': 'passed', 'finding':
         'Pause, menu, capture failure and changed board clear the pending plan. Manual touch or changed control values cancel the sequence and pause. A frame gap above250ms discards progress. Final Auto Play release requires the same prepared suggestion/context, ready phase and exact selected angle/power readback; the existing uncertain-dispatch state remains intact.'},
        {'id': 'lower_power', 'result': 'passed', 'finding':
         'Power candidates are simulated before selection. Bounded weaker probes retain only verified successes, and the3.5percent reserve is itself simulated. No selected shot is raised or clamped by Model after its simulation. Native minimum power is converted with the retained preplanning round-trip guard.'},
        {'id': 'angle_domain_fix', 'result': 'resolved_during_review', 'finding':
         'Independent review found that rounding the model angle before bridge negation and0..2pi normalization gave a different native launch angle. The planner now quantizes in the normalized native domain, maps overflow to0, then returns the corresponding model angle. Ordinary and break searches use this conversion.'},
        {'id': 'expanded_route_acceptance', 'result': 'passed', 'finding':
         'New cue-first-cushion and two-object-cushion routes are considered only after the initial direct/single-bank phase returns no valid shot. Final acceptance verifies the first legal target, intended pocket event, settled outcome, no scratch or illegal8, and exact cushion counts matching the reported method. Scores are deterministic relative costs, not probabilities.'},
        {'id': 'search_bounds', 'result': 'qualified', 'finding':
         'Ordinary search is capped at24initial and32fallback candidates, each with at most8power samples, plus96angular and48power refinement simulations; break search remains49. Cancellation is checked in the search and unchanged engine. Bounded work does not establish an iPhone wall-clock deadline or an exhaustive solution.'},
        {'id': 'preservation', 'result': 'passed', 'finding':
         'The prediction/render declarations, engine and calibration remain exact V12 sources. The full integrated UI differs only in the visible release version. Removing the single new progressive native method yields the complete V12 native source, including the off-table residual-spin correction and original release callback.'},
        {'id': 'historical_test_expectations', 'result': 'reviewed', 'finding':
         'Two existing planner tests replaced fixed coarse power expectations with strictly lower positive power expectations; their direction and verified outcome assertions remain. This is consistent with the requested lower-power refinement, not removal of the outcome contract.'},
    ],
    'limitations': [
        'No Apple SDK build, touch rendering verification, or iPhone execution in this review.',
        'The native release callback and mandatory-cushion rule restrictions remain unchanged.',
        'A bounded planner result is a model-verified candidate, not a guaranteed pot or probability.',
        'The gradual method sets native cue values; the independent PowerBar widget is not proven to animate like a real finger drag.',
        'Each progressive step performs additional guarded native captures on the existing loop. Device frame cost during these phases has not been measured; additive controlStepCostMs and controlSequenceMaxCostMs telemetry can expose it.',
        'Native commit also rounds live positions; this review does not claim complete equivalence between predicted and native launch physics.',
    ],
}
OUTPUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'result': report['result'], 'checks': len(checks),
                  'failed': [item['id'] for item in checks if not item['passed']],
                  'changed': changed, 'output': str(OUTPUT)}, indent=2))
raise SystemExit(0 if report['result'] == 'passed' else 1)
