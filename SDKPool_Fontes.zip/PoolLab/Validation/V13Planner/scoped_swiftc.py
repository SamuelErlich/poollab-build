#!/usr/bin/env python3
"""Scoped Swift frontend/compiler+link helper for portable SDKPool fixtures.

Intentionally supports only -o, -I, -L, -l, -O/-Onone, -emit-library,
-emit-module, -emit-module-path, -module-name, -parse-as-library,
-enable-testing and -parse. It does not impersonate a complete Swift driver.
The resulting executable must be launched directly from the shell.
"""
from pathlib import Path
import os, re, subprocess, sys
ROOT = Path(__file__).resolve().parent
USR = ROOT / 'swift-5.10.1-RELEASE-ubuntu24.04/usr'
FRONTEND = USR / 'bin/swift-frontend'
CLANG = USR / 'bin/clang'
RUNTIME = USR / 'lib/swift/linux'
args = sys.argv[1:]
front, link, sources = [], [], []
out = None
module = None
module_path = None
library = False
emit_module = False
parse = False
i = 0
while i < len(args):
    a = args[i]
    if a in ('-o','-module-name','-emit-module-path','-I','-L','-l'):
        if i+1 >= len(args): raise SystemExit(f'missing argument for {a}')
        v=args[i+1]; i+=2
        if a=='-o': out=Path(v)
        elif a=='-module-name': module=v
        elif a=='-emit-module-path': module_path=Path(v)
        elif a=='-I': front += [a,v]
        elif a=='-L': link += [a,v,'-Wl,-rpath,'+str(Path(v).resolve())]
        else: link += ['-l'+v]
        continue
    if a=='-emit-library': library=True
    elif a=='-emit-module': emit_module=True
    elif a=='-parse': parse=True
    elif a in ('-O','-Onone','-parse-as-library','-enable-testing'):
        front.append(a)
    elif a.startswith('-I') and len(a)>2: front += ['-I',a[2:]]
    elif a.startswith('-L') and len(a)>2:
        v=a[2:]; link += ['-L',v,'-Wl,-rpath,'+str(Path(v).resolve())]
    elif a.startswith('-l') and len(a)>2: link.append(a)
    elif a.endswith('.swift'): sources.append(a)
    else: raise SystemExit(f'unsupported scoped compiler option: {a}')
    i+=1
if not sources: raise SystemExit('no Swift sources')
if parse:
    raise SystemExit(subprocess.run([str(FRONTEND),'-parse',*front,*sources]).returncode)
if out is None: raise SystemExit('explicit -o is required')
out=out.resolve(); out.parent.mkdir(parents=True,exist_ok=True)
if module is None: module=re.sub(r'[^a-zA-Z0-9_]','_',out.stem)
obj=out.with_suffix(out.suffix+'.o')
if emit_module and module_path is None: module_path=out.parent/(module+'.swiftmodule')
command=[str(FRONTEND),'-c',*front,'-module-name',module,*sources,'-o',str(obj)]
if library and '-parse-as-library' not in front: command.append('-parse-as-library')
if module_path:
    module_path=module_path.resolve(); module_path.parent.mkdir(parents=True,exist_ok=True)
    command += ['-emit-module-path',str(module_path)]
subprocess.run(command,check=True)
autolink=out.with_suffix(out.suffix+'.autolink')
subprocess.run([str(USR/'bin/swift-autolink-extract'),str(obj),'-o',str(autolink)],check=True)
command=[str(CLANG),str(obj),str(RUNTIME/'x86_64/swiftrt.o'),'-L',str(RUNTIME),'-Wl,-rpath,'+str(RUNTIME),'@'+str(autolink),*link,'-o',str(out)]
if library: command.insert(1,'-shared')
subprocess.run(command,check=True)
print(out)
