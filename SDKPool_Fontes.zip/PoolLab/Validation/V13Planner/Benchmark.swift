import Foundation
@testable import PoolLabCore
@main struct Benchmark {
 static func main() throws {
  struct Record: Decodable { let index: Int; let state: TableState }
  let directory=CommandLine.arguments[1]
  let records=try JSONDecoder().decode([Record].self,from:Data(contentsOf:URL(fileURLWithPath:directory+"/recordedJSON.json")))
  let geometry=try JSONDecoder().decode(NativeTableGeometry.self,from:Data(contentsOf:URL(fileURLWithPath:directory+"/geometryJSON.json")))
  var table=records[0].state.table;table.nativeGeometry=geometry;table.pocketRadius=table.ballRadius
  var dense=records[0].state;dense.table=table
  dense.balls=dense.balls.map { PoolBall(id:$0.id,position:$0.position,pocketed:$0.pocketed) }
  let normal=TableState(table:table,balls:TableState.straightShot.balls)
  let advanced=TableState(table:table,balls:[PoolBall(id:0,position:Vector2(x:30,y:50)),PoolBall(id:1,position:Vector2(x:100,y:35))])
  var sixteen=TableState(table:table,balls:[PoolBall(id:0,position:Vector2(x:30,y:50))])
  for row in 0..<3 { for column in 0..<5 { sixteen.balls.append(PoolBall(id:1+row*5+column,position:Vector2(x:70+Double(column)*25,y:20+Double(row)*25))) } }
  let targetPocket = [("nativeDirect",normal,Optional(1)),("nativeKickFallback",advanced,Optional(3)),("nativeSevenBallSyntheticRest",dense,Optional<Int>.none),("nativeSixteenBallSynthetic",sixteen,Optional<Int>.none)]
  var rows:[[String:Any]]=[]
  for (name,state,pocket) in targetPocket {
   var times:[Double]=[];var last:[ShotSuggestion]=[]
   for _ in 0..<7 {
    let start=DispatchTime.now().uptimeNanoseconds
    last=try ShotPlanner.suggestions(for:state,pocketID:pocket,limit:5,allowedTargetIDs:Set(1...15).subtracting([8]))
    times.append(Double(DispatchTime.now().uptimeNanoseconds-start)/1_000_000)
   }
   rows.append(["fixture":name,"balls":state.balls.count,"suggestions":last.count,"methods":last.map(\.method.rawValue),"powers":last.map(\.shot.power),"minMS":times.min()!,"maxMS":times.max()!,"meanMS":times.reduce(0,+)/Double(times.count)])
  }
  let out:[String:Any] = ["environment":"Linux x86_64 Swift5.10.1 -O; not iPhone timing","repetitions":7,"maximumNormalAndFallbackSimulations":ShotPlanner.maximumSimulations,"maximumBreakSimulations":ShotPlanner.maximumBreakSimulations,"fixtures":rows]
  print(String(data:try JSONSerialization.data(withJSONObject:out,options:[.prettyPrinted,.sortedKeys]),encoding:.utf8)!)
 }
}
