V13 planner evidence

PlannerTests.txt: executed51 XCTest cases (32 original planner,9 V13,10 unchanged native geometry),0 failures.
Timing.json:7 runs of4 fixed synthetic layouts using native coefficients and geometry. Linux-O measurements, not iPhone.
The native recordedJSON fixture is historical V10 captured motion; the benchmark explicitly zeroes velocity/spin to create a synthetic stationary7-ball layout. The16-ball grid is also synthetic.

Executed command from workspace root:
python3 new_project/validation/v13_planner/run_tests.py
The runner compiles selected production Core files plus the tests in this source archive. It uses new_project/validation/v11_runtime/scoped_swiftc.py with the official Swift5.10.1 Ubuntu24.04 toolchain directory next to that helper. Copy the included helper into that runtime directory if recreating this exact Linux workspace arrangement.
The Swift main.swift manifest can also be built with a normal compatible Swift toolchain and the production Core module using -enable-testing.

Benchmark command:
benchmark <directory containing geometryJSON.json and recordedJSON.json>

No toolchain or executable is included. No Apple SDK or iPhone run is claimed.
