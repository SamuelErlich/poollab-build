// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "PoolLab",
    platforms: [.iOS(.v15), .macOS(.v12)],
    products: [.library(name: "PoolLabCore", targets: ["PoolLabCore"])],
    targets: [
        .target(name: "PoolLabCore"),
        .testTarget(name: "PoolLabCoreTests", dependencies: ["PoolLabCore"])
    ]
)
