#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Value snapshot copied from the game on its rendering thread.
@interface PLBallSnapshot : NSObject
@property(nonatomic, readonly) NSInteger number;
@property(nonatomic, readonly) double x;
@property(nonatomic, readonly) double y;
@property(nonatomic, readonly) double vx;
@property(nonatomic, readonly) double vy;
@property(nonatomic, readonly) double radius;
/// Native angular velocity: physical X/Y axes and the perpendicular Z axis.
/// These are not screen-scaled; reflecting physical Y also changes handedness.
@property(nonatomic, readonly) double spinX;
@property(nonatomic, readonly) double spinY;
@property(nonatomic, readonly) double spinZ;
/// Current visual center measured from the game's scene graph, in coordinateView.
@property(nonatomic, readonly) CGPoint visualCenter;
@end

@interface PLGameSnapshot : NSObject
/// Monotonic time of this in-process copy; never a server timestamp.
@property(nonatomic, readonly) NSTimeInterval captureTimestamp;
@property(nonatomic, readonly) uint64_t frameNumber;
/// Largest physical-to-visual residual, in native scene units.
@property(nonatomic, readonly) double projectionResidual;
/// Read-only observations for on-device diagnosis; contains no memory addresses.
@property(nonatomic, copy, readonly) NSDictionary<NSString *, NSString *> *diagnostics;
@property(nonatomic, copy, readonly) NSArray<PLBallSnapshot *> *balls;
@property(nonatomic, readonly) double originX;
@property(nonatomic, readonly) double originY;
@property(nonatomic, readonly) double width;
@property(nonatomic, readonly) double height;
@property(nonatomic, readonly) BOOL playerTurn;
@property(nonatomic, readonly) BOOL opponentTurn;
/// Only true after both angle and power updates were accepted in this opponent
/// turn and the opponent's native cue-strength and table physics are readable.
@property(nonatomic, readonly) BOOL opponentPreviewAvailable;
@property(nonatomic, copy, readonly) NSString *opponentPreviewUnavailableReason;
@property(nonatomic, readonly) double opponentMaximumShotSpeed;
/// Seconds since the latest accepted remote aim update; -1 when not available.
@property(nonatomic, readonly) NSTimeInterval opponentAimAge;
/// Current native cue direction in physical, Y-up radians.
@property(nonatomic, readonly) BOOL aimAvailable;
@property(nonatomic, readonly) double aimAngle;
@property(nonatomic, readonly) double cuePower;
/// Pending-shot modelling currently requires the selected native English to be
/// centered. Moving-ball continuation uses the captured spin independently.
@property(nonatomic, readonly) BOOL shotInputSupported;
@property(nonatomic, copy, readonly) NSString *shotInputUnavailableReason;
@property(nonatomic, readonly) double cueEnglishX;
@property(nonatomic, readonly) double cueEnglishY;
/// Live lower limit accepted by the native power bar, in control-power units.
/// Zero means the lower limit could not be established.
@property(nonatomic, readonly) double minimumShotPower;
/// Live native maximum shot speed, in the game's physical units; zero if unavailable.
@property(nonatomic, readonly) double maximumShotSpeed;
/// True only for a complete verified profile with no local physics areas.
@property(nonatomic, readonly) BOOL physicsCalibrationAvailable;
@property(nonatomic, readonly) double rollingDeceleration;
@property(nonatomic, readonly) double slidingDeceleration;
@property(nonatomic, readonly) double equilibriumTimeFactor;
@property(nonatomic, readonly) double spinDeceleration;
@property(nonatomic, readonly) double slidingFrictionCoefficient;
@property(nonatomic, readonly) double cushionSpinCoupling;
@property(nonatomic, readonly) double logicalFrameTime;
@property(nonatomic, readonly) double ballRestitution;
@property(nonatomic, readonly) double cushionRestitution;
/// Exact selected native polygon, including pocket jaws, copied in physical Y-up
/// coordinates. No repeated final vertex: the last edge closes to vertex zero.
/// Pocket arrays use native IDs; the engine maps IDs with {5,4,3,0,1,2}.
/// nativePocketRadius is the attraction region, NOT the pot threshold. The native
/// pot test uses each ball's own radius around its pocket center.
@property(nonatomic, readonly) BOOL nativeGeometryAvailable;
@property(nonatomic, copy, readonly) NSString *nativeGeometryUnavailableReason;
@property(nonatomic, copy, readonly) NSArray<NSValue *> *nativeCushionVertices;
@property(nonatomic, copy, readonly) NSArray<NSValue *> *nativePocketCenters;
@property(nonatomic, copy, readonly) NSArray<NSValue *> *nativePocketAimPoints;
@property(nonatomic, readonly) double nativePocketRadius;
@property(nonatomic, readonly) double nativePocketAttractionCoefficient;
@property(nonatomic, readonly) BOOL goldenShot;
@property(nonatomic, readonly) BOOL goldenTargetAvailable;
@property(nonatomic, readonly) double goldenTargetX;
@property(nonatomic, readonly) double goldenTargetY;
/// Zero means the scoring ring radius has not been established.
@property(nonatomic, readonly) double goldenTargetRadius;
@property(nonatomic, readonly) NSInteger goldenBallNumber;
/// Readiness for planning/nomination now. The final shot validates the cue again.
@property(nonatomic, readonly) BOOL canShoot;
/// Verified Standard8BallRule phase 1; the planner still validates rack geometry.
@property(nonatomic, readonly) BOOL isBreakShot;
@property(nonatomic, copy, readonly) NSArray<NSNumber *> *legalTargetNumbers;
/// Structural support for these rules/callbacks, independent of the current turn.
@property(nonatomic, readonly) BOOL autoShotAvailable;
@property(nonatomic, copy, readonly) NSString *autoShotUnavailableReason;
/// Temporary readiness blocker; empty only when canShoot is true.
@property(nonatomic, copy, readonly) NSString *shootReadinessReason;
/// Corners in coordinateView's UIKit coordinate system. Physical Y increases upward.
/// topLeft maps (originX, originY + height).
/// topRight maps (originX + width, originY + height).
/// bottomLeft maps (originX, originY).
/// For a Y-down engine: localY = originY + height - physicalY; negate aim angle.
@property(nonatomic, readonly) CGPoint tableTopLeft;
@property(nonatomic, readonly) CGPoint tableTopRight;
@property(nonatomic, readonly) CGPoint tableBottomLeft;
@property(nonatomic, strong, readonly) UIView *coordinateView;
@end

@interface PLRuntimeBridge : NSObject
/// Swift: try PLRuntimeBridge.capture()
+ (nullable PLGameSnapshot *)captureWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(capture());
/// Swift: try PLRuntimeBridge.apply(angle: radiansYUp, power: valueInZeroToOne)
/// Updates the cue controls only; never triggers a shot.
/// Revalidates native input ownership and rest (including spin), then confirms
/// both the applied direction and power through a fresh cue read.
+ (BOOL)applyAngle:(double)angle power:(double)power
             error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(apply(angle:power:));
/// Applies one freshly validated planner result, including the normal pocket
/// nomination callback when required. Updates direction and power only; this
/// method never invokes the shot-release callback.
+ (BOOL)applyPlannedAngle:(double)angle power:(double)power target:(NSInteger)target
                 pocket:(NSInteger)pocket error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(applyPlannedAim(angle:power:target:pocket:));
/// Applies an intermediate gradual-aim or cue-pull sample. Accepts power in
/// [0,1], including below the shot minimum, because this method never releases
/// a shot. Nomination, target, native input ownership and readback are checked
/// exactly as for planned aim. Final dispatch must use the validated shoot API.
+ (BOOL)applyProgressAngle:(double)angle power:(double)power target:(NSInteger)target
                  pocket:(NSInteger)pocket error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(applyAimProgress(angle:power:target:pocket:));
/// Uses the game's normal shot-release callback after freshly validating its state.
/// Pocket IDs follow the planner's order: top-left, top-middle, top-right,
/// bottom-left, bottom-middle, bottom-right. Nothing is dispatched on validation failure.
/// Failure userInfo["shotDispatched"] is false only when the native callback
/// was never entered; true requires observing native state before any retry.
+ (BOOL)shootAngle:(double)angle power:(double)power target:(NSInteger)target
            pocket:(NSInteger)pocket error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(shoot(angle:power:target:pocket:));
@end

NS_ASSUME_NONNULL_END
