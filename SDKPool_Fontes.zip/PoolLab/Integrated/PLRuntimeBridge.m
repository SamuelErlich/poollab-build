#import "PLRuntimeBridge.h"
#import <objc/message.h>
#import <objc/runtime.h>
#import <math.h>
#import <string.h>
#import <stdatomic.h>
#import <stdbool.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach/mach.h>
#import <mach/vm_map.h>

_Static_assert(sizeof(vm_address_t) >= sizeof(uintptr_t), "VM addresses must preserve native pointers.");
_Static_assert(sizeof(vm_size_t) >= sizeof(size_t), "VM sizes must preserve native lengths.");

/* Contract sources: Validation/NativeLiveBridgeEvidence.json and
 * Validation/V5NativePhysicsBridgeEvidence.json.
 * Only the supplied 56.31.0 (5330), arm64, executable was inspected.
 * ObjC ivar offsets are resolved at runtime, with exact encoding and size checks.
 * MCNumber aggregates deliberately use memcpy: their C++ getter return ABI uses
 * x8, even for one double, and is incompatible with a CGFloat/CGPoint cast.
 */

static NSString *const PLErrorDomain = @"PoolLab.RuntimeBridge";
static void PLInstallOpponentObserver(void);

@interface PLBallSnapshot ()
@property(nonatomic, readwrite) NSInteger number;
@property(nonatomic, readwrite) double x;
@property(nonatomic, readwrite) double y;
@property(nonatomic, readwrite) double vx;
@property(nonatomic, readwrite) double vy;
@property(nonatomic, readwrite) double radius;
@property(nonatomic, readwrite) double spinX;
@property(nonatomic, readwrite) double spinY;
@property(nonatomic, readwrite) double spinZ;
@property(nonatomic, readwrite) CGPoint visualCenter;
@end
@implementation PLBallSnapshot
@end

@interface PLGameSnapshot ()
@property(nonatomic, readwrite) NSTimeInterval captureTimestamp;
@property(nonatomic, readwrite) uint64_t frameNumber;
@property(nonatomic, readwrite) double projectionResidual;
@property(nonatomic, copy, readwrite) NSDictionary<NSString *, NSString *> *diagnostics;
@property(nonatomic, copy, readwrite) NSArray<PLBallSnapshot *> *balls;
@property(nonatomic, readwrite) double originX;
@property(nonatomic, readwrite) double originY;
@property(nonatomic, readwrite) double width;
@property(nonatomic, readwrite) double height;
@property(nonatomic, readwrite) BOOL playerTurn;
@property(nonatomic, readwrite) BOOL opponentTurn;
@property(nonatomic, readwrite) BOOL opponentPreviewAvailable;
@property(nonatomic, copy, readwrite) NSString *opponentPreviewUnavailableReason;
@property(nonatomic, readwrite) double opponentMaximumShotSpeed;
@property(nonatomic, readwrite) NSTimeInterval opponentAimAge;
@property(nonatomic, readwrite) BOOL aimAvailable;
@property(nonatomic, readwrite) double aimAngle;
@property(nonatomic, readwrite) double cuePower;
@property(nonatomic, readwrite) BOOL shotInputSupported;
@property(nonatomic, copy, readwrite) NSString *shotInputUnavailableReason;
@property(nonatomic, readwrite) double cueEnglishX;
@property(nonatomic, readwrite) double cueEnglishY;
@property(nonatomic, readwrite) double minimumShotPower;
@property(nonatomic, readwrite) double maximumShotSpeed;
@property(nonatomic, readwrite) BOOL physicsCalibrationAvailable;
@property(nonatomic, readwrite) double rollingDeceleration;
@property(nonatomic, readwrite) double slidingDeceleration;
@property(nonatomic, readwrite) double equilibriumTimeFactor;
@property(nonatomic, readwrite) double spinDeceleration;
@property(nonatomic, readwrite) double slidingFrictionCoefficient;
@property(nonatomic, readwrite) double cushionSpinCoupling;
@property(nonatomic, readwrite) double logicalFrameTime;
@property(nonatomic, readwrite) double ballRestitution;
@property(nonatomic, readwrite) double cushionRestitution;
@property(nonatomic, copy, readwrite) NSString *nativeGeometrySource;
@property(nonatomic, readwrite) BOOL nativeGeometryAvailable;
@property(nonatomic, copy, readwrite) NSString *nativeGeometryUnavailableReason;
@property(nonatomic, copy, readwrite) NSArray<NSValue *> *nativeCushionVertices;
@property(nonatomic, copy, readwrite) NSArray<NSValue *> *nativePocketCenters;
@property(nonatomic, copy, readwrite) NSArray<NSValue *> *nativePocketAimPoints;
@property(nonatomic, readwrite) double nativePocketRadius;
@property(nonatomic, readwrite) double nativePocketAttractionCoefficient;
@property(nonatomic, readwrite) BOOL goldenShot;
@property(nonatomic, readwrite) BOOL goldenTargetAvailable;
@property(nonatomic, readwrite) double goldenTargetX;
@property(nonatomic, readwrite) double goldenTargetY;
@property(nonatomic, readwrite) double goldenTargetRadius;
@property(nonatomic, readwrite) NSInteger goldenBallNumber;
@property(nonatomic, readwrite) BOOL canShoot;
@property(nonatomic, readwrite) BOOL isBreakShot;
@property(nonatomic, copy, readwrite) NSArray<NSNumber *> *legalTargetNumbers;
@property(nonatomic, readwrite) BOOL autoShotAvailable;
@property(nonatomic, copy, readwrite) NSString *autoShotUnavailableReason;
@property(nonatomic, copy, readwrite) NSString *shootReadinessReason;
@property(nonatomic, readwrite) CGPoint tableTopLeft;
@property(nonatomic, readwrite) CGPoint tableTopRight;
@property(nonatomic, readwrite) CGPoint tableBottomLeft;
@property(nonatomic, strong, readwrite) UIView *coordinateView;
@end
@implementation PLGameSnapshot
@end

static BOOL PLFail(NSError **error, NSInteger code, NSString *description) {
    if (error) *error = [NSError errorWithDomain:PLErrorDomain code:code
                                      userInfo:@{NSLocalizedDescriptionKey: description}];
    return NO;
}

static BOOL PLCheckMethod(id object, NSString *name, const char *encoding, NSError **error) {
    Method method = class_getInstanceMethod(object_getClass(object), NSSelectorFromString(name));
    const char *actual = method ? method_getTypeEncoding(method) : NULL;
    if (!actual || strcmp(actual, encoding) != 0) {
        return PLFail(error, 10, [NSString stringWithFormat:@"Método incompatível: %@.%@.",
                                 NSStringFromClass(object_getClass(object)), name]);
    }
    return YES;
}

static Ivar PLCheckIvar(id object, NSString *className, const char *name,
                        const char *encoding, size_t length, NSError **error) {
    Class expected = NSClassFromString(className);
    if (!expected || !object || ![object isKindOfClass:expected]) {
        PLFail(error, 11, [NSString stringWithFormat:@"Objeto %@ indisponível.", className]);
        return NULL;
    }
    Ivar ivar = class_getInstanceVariable(expected, name);
    const char *actual = ivar ? ivar_getTypeEncoding(ivar) : NULL;
    if (!actual || strcmp(actual, encoding) != 0) {
        PLFail(error, 12, [NSString stringWithFormat:@"Campo incompatível: %@.%s.", className, name]);
        return NULL;
    }
    NSUInteger encodedSize = 0, alignment = 0;
    NSGetSizeAndAlignment(actual, &encodedSize, &alignment);
    ptrdiff_t offset = ivar_getOffset(ivar);
    size_t instanceSize = class_getInstanceSize(object_getClass(object));
    if (encodedSize != length || alignment == 0 || offset < 0 ||
        (size_t)offset > instanceSize || length > instanceSize - (size_t)offset) {
        PLFail(error, 13, [NSString stringWithFormat:@"Tamanho incompatível: %@.%s.", className, name]);
        return NULL;
    }
    return ivar;
}

static BOOL PLRead(id object, NSString *className, const char *name,
                   const char *encoding, void *destination, size_t length, NSError **error) {
    Ivar ivar = PLCheckIvar(object, className, name, encoding, length, error);
    if (!ivar) return NO;
    memcpy(destination, (const uint8_t *)(__bridge const void *)object + ivar_getOffset(ivar), length);
    return YES;
}

static id PLReadObject(id object, NSString *className, const char *name,
                       const char *encoding, NSError **error) {
    Ivar ivar = PLCheckIvar(object, className, name, encoding, sizeof(id), error);
    return ivar ? object_getIvar(object, ivar) : nil;
}

static id PLObject(id object, NSString *name) {
    return ((id (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static BOOL PLBool(id object, NSString *name) {
    return ((BOOL (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static CGPoint PLPoint(id object, NSString *name) {
    return ((CGPoint (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static CGPoint PLTransformPoint(id object, NSString *selector, CGPoint point) {
    return ((CGPoint (*)(id, SEL, CGPoint))objc_msgSend)(object,
                                        NSSelectorFromString(selector), point);
}
static BOOL PLFinitePoint(CGPoint point) { return isfinite(point.x) && isfinite(point.y); }

// A stale C++ pointer must fail a read instead of becoming a process crash.
static BOOL PLCopyMemory(uintptr_t address, void *output, size_t length) {
    if (!address || !output || !length || address > UINTPTR_MAX - length) return NO;
    vm_size_t copied = 0;
    kern_return_t result = vm_read_overwrite(mach_task_self(), (vm_address_t)address,
        (vm_size_t)length, (vm_address_t)(uintptr_t)output, &copied);
    return result == KERN_SUCCESS && copied == length;
}

static CGRect PLRect(id object, NSString *name) {
    return ((CGRect (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}

static BOOL PLUsableView(UIView *view) {
    if (!view.window || view.bounds.size.width <= 0 || view.bounds.size.height <= 0) return NO;
    for (UIView *ancestor = view; ancestor; ancestor = ancestor.superview)
        if (ancestor.hidden || ancestor.alpha <= 0.01) return NO;
    return YES;
}

static UIView *PLCoordinateView(id logicalView, CGRect *logicalBounds, NSError **error) {
    // The shipped engine's CCGLView is an NSObject, NOT its UIKit render surface.
    // CCGLView_MCPlatform is the actual UIView; convertToWindowSpace: emits
    // coordinates in CCGLView.bounds, so convert their scale exactly once below.
    if (!PLCheckMethod(logicalView, @"bounds", "{CGRect={CGPoint=dd}{CGSize=dd}}16@0:8", error)) return nil;
    CGRect sourceBounds = PLRect(logicalView, @"bounds");
    if (!PLFinitePoint(sourceBounds.origin) || !isfinite(sourceBounds.size.width) ||
        !isfinite(sourceBounds.size.height) || sourceBounds.size.width <= 0 || sourceBounds.size.height <= 0) {
        PLFail(error, 24, @"A área de desenho do jogo ainda não está pronta."); return nil;
    }
    if ([logicalView isKindOfClass:UIView.class] && PLUsableView(logicalView)) {
        *logicalBounds = sourceBounds; return logicalView;
    }
    Class renderClass = NSClassFromString(@"CCGLView_MCPlatform");
    if (!renderClass || ![renderClass isSubclassOfClass:UIView.class]) {
        PLFail(error, 24, @"A superfície gráfica desta versão não foi encontrada."); return nil;
    }
    NSMutableOrderedSet<UIWindow *> *windows = [NSMutableOrderedSet orderedSet];
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        [windows addObjectsFromArray:((UIWindowScene *)scene).windows];
    }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    [windows addObjectsFromArray:UIApplication.sharedApplication.windows];
#pragma clang diagnostic pop
    NSMutableArray<UIView *> *queue = [NSMutableArray array];
    for (UIWindow *window in windows) {
        if (!window.hidden && window.alpha > 0.01 && (!window.windowScene ||
            window.windowScene.activationState == UISceneActivationStateForegroundActive)) [queue addObject:window];
    }
    UIView *match = nil;
    NSUInteger cursor = 0;
    while (cursor < queue.count && cursor < 8192) {
        UIView *candidate = queue[cursor++];
        if (candidate.hidden || candidate.alpha <= 0.01) continue;
        if ([candidate isKindOfClass:renderClass] && PLUsableView(candidate)) {
            if (match && match != candidate) {
                PLFail(error, 24, @"Há mais de uma mesa visível. Aguarde a transição."); return nil;
            }
            match = candidate;
        }
        if (queue.count + candidate.subviews.count <= 8192) [queue addObjectsFromArray:candidate.subviews];
    }
    if (!match) { PLFail(error, 24, @"A imagem da mesa ainda não está visível."); return nil; }
    *logicalBounds = sourceBounds;
    return match;
}

static CGPoint PLRenderPoint(CGPoint point, CGRect source, UIView *destination) {
    CGRect bounds = destination.bounds;
    return CGPointMake(bounds.origin.x + (point.x-source.origin.x)*bounds.size.width/source.size.width,
                       bounds.origin.y + (point.y-source.origin.y)*bounds.size.height/source.size.height);
}

static CGPoint PLRenderScenePoint(id parent, id director, CGPoint localPoint, CGPoint renderOrigin) {
    // drawScene temporarily translates its scene root by _safeAreaInPoints.origin
    // before visit, then restores it (0x1015d4064..0x1015d40e8). Our capture runs
    // outside visit, so apply that translation to the copied world coordinate.
    // convertToUI adds the same origin AFTER projection/Y-flip. Remove that
    // post-projection adjustment: otherwise Y is offset twice by the safe inset.
    // No mutation of the scene, projection matrix, UIKit frames, or native state.
    CGPoint world = PLTransformPoint(parent, @"convertToWorldSpace:", localPoint);
    world.x += renderOrigin.x; world.y += renderOrigin.y;
    CGPoint point = PLTransformPoint(director, @"convertToUI:", world);
    return CGPointMake(point.x-renderOrigin.x, point.y-renderOrigin.y);
}

static BOOL PLInspectExecutable(NSError **error) {
    const struct mach_header *header = _dyld_get_image_header(0);
    if (!header || header->magic != MH_MAGIC_64 || header->cputype != CPU_TYPE_ARM64 ||
        header->ncmds > 4096 || header->sizeofcmds > 1024*1024)
        return PLFail(error, 8, @"Executável incompatível com esta integração.");
    const uint8_t expectedUUID[16] = {
        0xc2, 0x35, 0xdc, 0xcd, 0x99, 0x7e, 0x3d, 0x31,
        0xa9, 0x8f, 0xea, 0xa8, 0xbd, 0xdd, 0x2b, 0xfb
    };
    const uint8_t *cursor = (const uint8_t *)header + sizeof(struct mach_header_64);
    size_t remaining = header->sizeofcmds;
    for (uint32_t i = 0; i < header->ncmds; ++i) {
        if (remaining < sizeof(struct load_command)) break;
        const struct load_command *command = (const struct load_command *)cursor;
        if (command->cmdsize < sizeof(*command) || command->cmdsize > remaining) break;
        if (command->cmd == LC_UUID && command->cmdsize >= sizeof(struct uuid_command)) {
            const struct uuid_command *uuid = (const struct uuid_command *)command;
            if (memcmp(uuid->uuid, expectedUUID, sizeof(expectedUUID)) == 0) return YES;
            break;
        }
        remaining -= command->cmdsize;
        cursor += command->cmdsize;
    }
    return PLFail(error, 9, @"O executável não corresponde ao build verificado.");
}

static BOOL PLExpectedExecutable(NSError **error) {
    // Main-image UUID/load commands are immutable for the life of this process.
    // Mutable cue/ball/turn data and write-site fingerprints remain fresh reads.
    static dispatch_once_t onceToken;
    static BOOL verified = NO;
    static NSError *failure = nil;
    dispatch_once(&onceToken, ^{
        NSError *localFailure = nil;
        verified = PLInspectExecutable(&localFailure);
        failure = localFailure;
    });
    if (!verified && error) *error = failure;
    return verified;
}

static BOOL PLEnvironment(id __strong *manager, id __strong *director, NSError **error) {
#if !defined(__arm64__)
    return PLFail(error, 1, @"A integração exige o executável arm64 do iPhone.");
#else
    if (![NSThread isMainThread]) return PLFail(error, 2, @"A captura precisa acontecer na thread principal.");
    NSBundle *bundle = NSBundle.mainBundle;
    if (![bundle.bundleIdentifier isEqualToString:@"com.miniclip.8ballpoolmult"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"] isEqual:@"56.31.0"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleVersion"] isEqual:@"5330"]) {
        return PLFail(error, 3, @"Esta integração foi preparada para 8 Ball Pool 56.31.0, build 5330.");
    }
    if (!PLExpectedExecutable(error)) return NO;
    Class managerClass = NSClassFromString(@"GameManager");
    Class directorClass = NSClassFromString(@"CCDirector");
    if (!managerClass || !directorClass)
        return PLFail(error, 7, @"As classes desta versão do jogo não foram encontradas.");
    if (!PLCheckMethod(managerClass, @"isGameManagerInitialized", "B16@0:8", error) ||
        !PLCheckMethod(managerClass, @"sharedGameManager", "@16@0:8", error) ||
        !PLCheckMethod(directorClass, @"sharedDirector", "@16@0:8", error)) return NO;
    // sharedGameManager creates an instance if absent; do not initialize game state.
    if (!PLBool(managerClass, @"isGameManagerInitialized"))
        return PLFail(error, 4, @"Abra uma mesa para conectar o menu ao jogo.");
    id game = PLObject(managerClass, @"sharedGameManager");
    id render = PLObject(directorClass, @"sharedDirector");
    if (!game || !render || ![game isKindOfClass:managerClass] || ![render isKindOfClass:directorClass])
        return PLFail(error, 5, @"Objetos do jogo ainda não estão disponíveis.");
    if (!PLCheckMethod(render, @"runningThread", "@16@0:8", error) ||
        !PLCheckMethod(render, @"view", "@16@0:8", error)) return NO;
    NSThread *renderThread = PLObject(render, @"runningThread");
    if (![renderThread isKindOfClass:NSThread.class] || renderThread != NSThread.currentThread)
        return PLFail(error, 6, @"A mesa está sendo atualizada em outra thread. Captura pausada.");
    *manager = game;
    *director = render;
    PLInstallOpponentObserver();
    return YES;
#endif
}

static const char *const PLPhysicsType =
    "{BallPhysicsProperties=\"position\"{?=\"x\"{MCNumber=\"mValue\"d}\"y\"{MCNumber=\"mValue\"d}}"
    "\"velocity\"{?=\"x\"{MCNumber=\"mValue\"d}\"y\"{MCNumber=\"mValue\"d}}"
    "\"radius\"{MCNumber=\"mValue\"d}\"spin\"{?=\"x\"{MCNumber=\"mValue\"d}"
    "\"y\"{MCNumber=\"mValue\"d}\"z\"{MCNumber=\"mValue\"d}}"
    "\"mass\"{MCNumber=\"mValue\"d}\"volume\"{MCNumber=\"mValue\"d}}";
static const char *const PLBoundsType =
    "{MCRect=\"origin\"{?=\"x\"{MCNumber=\"mValue\"d}\"y\"{MCNumber=\"mValue\"d}}"
    "\"size\"{?=\"width\"{MCNumber=\"mValue\"d}\"height\"{MCNumber=\"mValue\"d}}}";
static const char *const PLPointType = "{CGPoint=\"x\"d\"y\"d}";

static void *PLVerifiedFunction(uintptr_t rva, const uint8_t *expected, size_t length) {
    uintptr_t address = (uintptr_t)_dyld_get_image_header(0) + rva;
    // Bounded full getter fingerprints include the 84-byte selected-shape getter.
    uint8_t actual[128] = {0};
    if (length > sizeof(actual) || !PLCopyMemory(address, actual, length) ||
        memcmp(actual, expected, length) != 0) return NULL;
    return (void *)address;
}

static void *PLShotReleaseFunction(void) {
    // GameManager.ccTouchesEnded: calls this exact GameManagerCacher callback.
    // It retains ordinary cue charge accounting, shot assembly and state changes.
    static const uint8_t bytes[] = {
        0xff,0xc3,0x01,0xd1,0xfc,0x6f,0x01,0xa9,0xfa,0x67,0x02,0xa9,0xf8,0x5f,0x03,0xa9,
        0xf6,0x57,0x04,0xa9,0xf4,0x4f,0x05,0xa9,0xfd,0x7b,0x06,0xa9,0xfd,0x83,0x01,0x91
    };
    return PLVerifiedFunction(0xcec5d8, bytes, sizeof(bytes));
}

static BOOL PLReadCue(id manager, id __strong *cueResult, double *angle, double *power, NSError **error) {
    id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", error);
    void *guide = NULL;
    if (!cue || !PLRead(cue, @"VisualCue", "mVisualGuide", "^v", &guide, sizeof(guide), error) ||
        !PLRead(cue, @"VisualCue", "mPower", "{MCNumber=\"mValue\"d}", power, sizeof(*power), error) ||
        !guide || !PLCopyMemory((uintptr_t)guide+0x28, angle, sizeof(*angle)) ||
        !isfinite(*angle) || !isfinite(*power) || *power < 0 || *power > 1) {
        if (!error || !*error) PLFail(error, 46, @"A mira ainda não está pronta.");
        return NO;
    }
    *angle = remainder(*angle, 2.0*M_PI);
    *cueResult = cue;
    return YES;
}

static double PLMinimumShotPower(id cue) {
    // hasMinimumPowerRatio compares this float directly with mPower, >=.
    id bar = PLReadObject(cue, @"VisualCue", "_powerBarView",
                          "@\"GamePowerBarView<FTUEHighlightNodeProtocol>\"", NULL);
    if (!bar || !PLCheckMethod(bar, @"getMinimumPower", "f16@0:8", NULL)) return 0;
    float minimum = ((float (*)(id, SEL))objc_msgSend)(bar, NSSelectorFromString(@"getMinimumPower"));
    if (!isfinite(minimum) || minimum <= 0 || minimum >= 1) return 0;
    return (double)minimum;
}

typedef struct { uintptr_t manager, table, cue; } PLRemoteContext;
static IMP PLOriginalOpponentTurn = NULL, PLOriginalAimEvents = NULL;
static Method PLOpponentTurnMethod = NULL, PLAimEventsMethod = NULL;
static BOOL PLOpponentObserverInstalled = NO;
static atomic_bool PLRemoteThreadViolation = ATOMIC_VAR_INIT(false);
static uint64_t PLRemoteEpoch = 1;
static PLRemoteContext PLRemoteAcceptedContext = {0};
static uint8_t PLRemoteAcceptedFields = 0;
static NSTimeInterval PLRemoteReceivedAt = 0;

static void PLResetRemoteReceipt(void) {
    PLRemoteAcceptedContext = (PLRemoteContext){0};
    PLRemoteAcceptedFields = 0;
    PLRemoteReceivedAt = 0;
}

static BOOL PLRemoteContextsEqual(PLRemoteContext first, PLRemoteContext second) {
    return first.manager && first.manager == second.manager &&
        first.table == second.table && first.cue == second.cue;
}

static void PLRecordRemoteFields(PLRemoteContext before, PLRemoteContext after, uint64_t epoch,
                                  uint8_t fields, uint8_t confirmed, NSTimeInterval receivedAt) {
    if (epoch != PLRemoteEpoch || !PLRemoteContextsEqual(before, after)) { PLResetRemoteReceipt(); return; }
    if (!PLRemoteContextsEqual(PLRemoteAcceptedContext, after)) {
        PLResetRemoteReceipt(); PLRemoteAcceptedContext = after;
    }
    PLRemoteAcceptedFields = (PLRemoteAcceptedFields & ~fields) | (confirmed & fields & 6);
    if (confirmed & fields & 6) PLRemoteReceivedAt = receivedAt;
}

static BOOL PLReadRemoteContext(id manager, PLRemoteContext *context) {
    if (!NSThread.isMainThread) return NO;
    for (NSString *name in @[@"isOpponentTurn", @"isOnNetworkedGame", @"isGameStarted", @"isOnStandardLocalGame"])
        if (!PLCheckMethod(manager, name, "B16@0:8", NULL)) return NO;
    if (!PLBool(manager, @"isOpponentTurn") || !PLBool(manager, @"isOnNetworkedGame") ||
        !PLBool(manager, @"isGameStarted") || PLBool(manager, @"isOnStandardLocalGame")) return NO;
    BOOL spectator = YES;
    if (!PLRead(manager, @"GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), NULL) || spectator) return NO;
    id table = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", NULL);
    id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", NULL);
    if (!table || !cue) return NO;
    *context = (PLRemoteContext){(uintptr_t)(__bridge void *)manager,
        (uintptr_t)(__bridge void *)table, (uintptr_t)(__bridge void *)cue};
    return YES;
}

static BOOL PLReadRemotePacket(const void *packet, uint8_t *fields, double *angle, double *power) {
    // This is the native protobuf object's copied representation, not raw wire
    // bytes. Its verified copy constructor preserves flags/+0x28/+0x30 values.
    uintptr_t base = (uintptr_t)packet, items = 0; int32_t count = 0;
    *fields = 0;
    if (!base || base > UINTPTR_MAX-0x38 ||
        !PLCopyMemory(base+0x28, &items, sizeof(items)) ||
        !PLCopyMemory(base+0x30, &count, sizeof(count)) ||
        count < 1 || count > 128 || !items) return NO;
    uintptr_t entries[128] = {0};
    if (!PLCopyMemory(items, entries, (size_t)count*sizeof(uintptr_t))) return NO;
    for (int32_t index = 0; index < count; ++index) {
        uint32_t flags = 0; double value = 0;
        uintptr_t item = entries[index];
        if (!item || item > UINTPTR_MAX-0x38 || !PLCopyMemory(item+0x20, &flags, sizeof(flags))) return NO;
        if (flags & 2) {
            if (!PLCopyMemory(item+0x28, &value, sizeof(value)) || !isfinite(value)) return NO;
            *angle = value; *fields |= 2;
        }
        if (flags & 4) {
            if (!PLCopyMemory(item+0x30, &value, sizeof(value)) || !isfinite(value) || value < 0 || value > 1) return NO;
            *power = value; *fields |= 4;
        }
    }
    return YES;
}

static void PLOpponentTurnObserved(id manager, SEL selector) {
    if (NSThread.isMainThread) { ++PLRemoteEpoch; PLResetRemoteReceipt(); }
    else atomic_store_explicit(&PLRemoteThreadViolation, true, memory_order_release);
    // Original exceptions/behavior are preserved. No game state is replaced.
    ((void (*)(id, SEL))PLOriginalOpponentTurn)(manager, selector);
}

static void PLAimEventsObserved(id manager, SEL selector, const void *packet) {
    PLRemoteContext before = {0}; uint8_t fields = 0;
    double angle = 0, power = 0; uint64_t epoch = 0; BOOL inspected = NO;
    if (NSThread.isMainThread) {
        @try {
            epoch = PLRemoteEpoch;
            inspected = PLReadRemoteContext(manager, &before) &&
                PLReadRemotePacket(packet, &fields, &angle, &power);
            if (!inspected) PLResetRemoteReceipt();
        } @catch (NSException *exception) { PLResetRemoteReceipt(); }
    } else atomic_store_explicit(&PLRemoteThreadViolation, true, memory_order_release);
    @try { ((void (*)(id, SEL, const void *))PLOriginalAimEvents)(manager, selector, packet); }
    @catch (NSException *exception) { if (NSThread.isMainThread) PLResetRemoteReceipt(); @throw; }
    if (!inspected || !NSThread.isMainThread) return;
    @try {
        PLRemoteContext after = {0};
        if (epoch != PLRemoteEpoch || !PLReadRemoteContext(manager, &after) || !PLRemoteContextsEqual(before, after)) {
            PLResetRemoteReceipt(); return;
        }
        id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", NULL);
        uint8_t confirmed = 0; double nativeTarget = 0;
        if ((fields & 2) && PLRead(cue, @"VisualCue", "mAnimateAimAngleTarget", "{MCNumber=\"mValue\"d}",
                                    &nativeTarget, sizeof(nativeTarget), NULL) && nativeTarget == angle) confirmed |= 2;
        if ((fields & 4) && PLRead(cue, @"VisualCue", "mAnimatePowerTarget", "{MCNumber=\"mValue\"d}",
                                    &nativeTarget, sizeof(nativeTarget), NULL) && nativeTarget == power) confirmed |= 4;
        // A changed field the game did not accept invalidates previous evidence
        // for that field. Never promote a stale value to current-turn freshness.
        PLRecordRemoteFields(before, after, epoch, fields, confirmed, NSProcessInfo.processInfo.systemUptime);
    } @catch (NSException *exception) { PLResetRemoteReceipt(); }
}

static void PLInstallOpponentObserver(void) {
    // Installation is gated by exact Objective-C ABI, original IMP addresses and
    // instruction fingerprints. Existing replacements are not overwritten.
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        static const uint8_t opponentTurnBytes[] = {
            0xff,0x03,0x02,0xd1,0xe9,0x23,0x01,0x6d,0xfc,0x6f,0x02,0xa9,0xfa,0x67,0x03,0xa9,
            0xf8,0x5f,0x04,0xa9,0xf6,0x57,0x05,0xa9,0xf4,0x4f,0x06,0xa9,0xfd,0x7b,0x07,0xa9
        };
        static const uint8_t aimEventsBytes[] = {
            0xff,0x83,0x03,0xd1,0xfc,0x6f,0x08,0xa9,0xfa,0x67,0x09,0xa9,0xf8,0x5f,0x0a,0xa9,
            0xf6,0x57,0x0b,0xa9,0xf4,0x4f,0x0c,0xa9,0xfd,0x7b,0x0d,0xa9,0xfd,0x43,0x03,0x91
        };
        Class managerClass = NSClassFromString(@"GameManager");
        Method turn = class_getInstanceMethod(managerClass, NSSelectorFromString(@"enterStateOpponentTurn"));
        Method aim = class_getInstanceMethod(managerClass, NSSelectorFromString(@"networkEventAimEvents:"));
        IMP expectedTurn = (IMP)PLVerifiedFunction(0x121b9c, opponentTurnBytes, sizeof(opponentTurnBytes));
        IMP expectedAim = (IMP)PLVerifiedFunction(0x12af88, aimEventsBytes, sizeof(aimEventsBytes));
        if (!turn || !aim || !expectedTurn || !expectedAim ||
            strcmp(method_getTypeEncoding(turn), "v16@0:8") != 0 ||
            strcmp(method_getTypeEncoding(aim), "v24@0:8r^v16") != 0 ||
            method_getImplementation(turn) != expectedTurn || method_getImplementation(aim) != expectedAim) return;
        PLOriginalOpponentTurn = expectedTurn; PLOriginalAimEvents = expectedAim;
        IMP previousTurn = method_setImplementation(turn, (IMP)PLOpponentTurnObserved);
        if (previousTurn != expectedTurn) { method_setImplementation(turn, previousTurn); return; }
        IMP previousAim = method_setImplementation(aim, (IMP)PLAimEventsObserved);
        if (previousAim != expectedAim) {
            method_setImplementation(aim, previousAim); method_setImplementation(turn, previousTurn); return;
        }
        PLOpponentTurnMethod = turn; PLAimEventsMethod = aim;
        PLOpponentObserverInstalled = YES;
    });
}

static void PLFillOpponentPreview(id manager, PLGameSnapshot *snapshot) {
    snapshot.opponentAimAge = -1;
    snapshot.opponentPreviewUnavailableReason = @"Aguardando a vez do adversário.";
    if (!PLCheckMethod(manager, @"isOpponentTurn", "B16@0:8", NULL)) return;
    snapshot.opponentTurn = PLBool(manager, @"isOpponentTurn");
    if (!snapshot.opponentTurn) { PLResetRemoteReceipt(); return; }
    if (atomic_load_explicit(&PLRemoteThreadViolation, memory_order_acquire)) {
        PLResetRemoteReceipt(); snapshot.opponentPreviewUnavailableReason = @"A recepção da mira ocorreu fora da thread validada. Reinicie o jogo."; return;
    }
    if (!PLOpponentObserverInstalled ||
        method_getImplementation(PLOpponentTurnMethod) != (IMP)PLOpponentTurnObserved ||
        method_getImplementation(PLAimEventsMethod) != (IMP)PLAimEventsObserved) {
        snapshot.opponentPreviewUnavailableReason = @"A recepção de mira desta versão não está disponível."; return;
    }
    PLRemoteContext context = {0};
    if (!PLReadRemoteContext(manager, &context) || !PLRemoteContextsEqual(context, PLRemoteAcceptedContext)) {
        PLResetRemoteReceipt(); snapshot.opponentPreviewUnavailableReason = @"Aguardando dados da mira nesta vez do adversário."; return;
    }
    id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", NULL);
    if (!cue || !PLCheckMethod(cue, @"enabled", "B16@0:8", NULL) || !PLBool(cue, @"enabled")) {
        PLResetRemoteReceipt(); snapshot.opponentPreviewUnavailableReason = @"O adversário está posicionando a bola ou escolhendo a caçapa."; return;
    }
    for (PLBallSnapshot *ball in snapshot.balls) if (hypot(ball.vx, ball.vy) > 0.001) {
        PLResetRemoteReceipt(); snapshot.opponentPreviewUnavailableReason = @"Bolas em movimento: acompanhando a tacada real."; return;
    }
    if ((PLRemoteAcceptedFields & 6) != 6 || !PLRemoteReceivedAt) {
        snapshot.opponentPreviewUnavailableReason = @"Aguardando direção e força recebidas nesta vez do adversário."; return;
    }
    snapshot.opponentAimAge = fmax(0, NSProcessInfo.processInfo.systemUptime-PLRemoteReceivedAt);
    uint32_t cueData[6] = {0};
    if (!PLRead(manager, @"GameManager", "_opponentCueData",
                "{OpponentSelectedCueData=\"cueId\"i\"cueLevel\"i\"cueStats\"{CueStatsWithBonus=\"_power\"I\"_spin\"I\"_aim\"I\"_time\"I}}",
                cueData, sizeof(cueData), NULL) || (int32_t)cueData[0] < 0 || (int32_t)cueData[1] < 0 || cueData[2] > 15) {
        snapshot.opponentPreviewUnavailableReason = @"As propriedades do taco do adversário ainda não estão disponíveis."; return;
    }
    float speed = 0;
    if (!PLCopyMemory((uintptr_t)_dyld_get_image_header(0)+0x34c2dac+cueData[2]*sizeof(float), &speed, sizeof(speed)) ||
        !isfinite(speed) || speed <= 0 || speed > 10000) {
        snapshot.opponentPreviewUnavailableReason = @"A força máxima do taco do adversário ainda não foi confirmada."; return;
    }
    snapshot.opponentMaximumShotSpeed = speed;
    if (!snapshot.aimAvailable || !snapshot.physicsCalibrationAvailable) {
        snapshot.opponentPreviewUnavailableReason = @"A previsão aguarda a leitura completa da mira e da física."; return;
    }
    if (!snapshot.shotInputSupported) {
        snapshot.opponentPreviewUnavailableReason = @"A prévia do adversário aguarda uma mira sem efeito."; return;
    }
    snapshot.opponentPreviewAvailable = YES;
    snapshot.opponentPreviewUnavailableReason = @"";
}

static double PLGoldenTargetRadius(id properties) {
    @try {
    static const char *encoding = "{GoldenShotTable=\"_id\"{basic_string<char, std::char_traits<char>, std::allocator<char>>=\"\"{?=\"__rep_\"(__rep=\"__s\"{__short=\"__data_\"[23c]\"__size_\"b7\"__is_long_\"b1}\"__l\"{__long=\"__data_\"*\"__size_\"Q\"__cap_\"b63\"__is_long_\"b1})}}\"_goldenBall\"{GoldenBall=\"position\"{Pos2D=\"x\"f\"y\"f}}\"_cueBall\"{CueBall=\"position\"{Pos2D=\"x\"f\"y\"f}}\"_obstacleBalls\"{vector<pool::goldenShot::GoldenShotTable::ObstacleBall, std::allocator<pool::goldenShot::GoldenShotTable::ObstacleBall>>=\"__begin_\"^{ObstacleBall}\"__end_\"^{ObstacleBall}\"\"{?=\"__cap_\"^{ObstacleBall}}}\"_targetArea\"{TargetArea=\"scale\"f\"position\"{Pos2D=\"x\"f\"y\"f}\"targets\"{vector<pool::goldenShot::GoldenShotTable::Target, std::allocator<pool::goldenShot::GoldenShotTable::Target>>=\"__begin_\"^{Target}\"__end_\"^{Target}\"\"{?=\"__cap_\"^{Target}}}}}";
    uint8_t record[104] = {0};
    if (!PLRead(properties, @"BallPropertiesGoldenShot", "_tableProperties", encoding,
                record, sizeof(record), NULL)) return 0;
    float scale = 0; uintptr_t begin = 0, end = 0;
    memcpy(&scale, record+0x40, sizeof(scale));
    memcpy(&begin, record+0x50, sizeof(begin)); memcpy(&end, record+0x58, sizeof(end));
    if (!isfinite(scale) || scale <= 0 || scale > 100 || !begin || end < begin || end-begin != 4*0x20) return 0;
    uint8_t targets[4*0x20] = {0};
    if (!PLCopyMemory(begin, targets, sizeof(targets))) return 0;
    double minimum = INFINITY;
    for (NSUInteger index = 0; index < 4; ++index) {
        float radius = 0;
        memcpy(&radius, targets+index*0x20+0x18, sizeof(radius));
        double physicalRadius = (double)radius*(double)scale;
        if (!isfinite(physicalRadius) || physicalRadius <= 0 || physicalRadius > 10000) return 0;
        minimum = fmin(minimum, physicalRadius);
    }
    return minimum;
    } @catch (NSException *exception) {
        return 0;
    }
}

typedef struct { uint32_t power, spin, aim, time; } PLCueStatsWithBonus;
static double PLMaximumShotSpeed(id manager) {
    // The global last-used speed can still belong to the opponent. Resolve the
    // currently selected cue exactly as the native release callback does.
    Class userClass = NSClassFromString(@"UserInfo");
    if (!userClass || !PLCheckMethod(userClass, @"sharedUserInfo", "@16@0:8", NULL) ||
        !PLCheckMethod(manager, @"isOnNetworkedGame", "B16@0:8", NULL)) return 0;
    id user = PLObject(userClass, @"sharedUserInfo");
    if (!user || !PLCheckMethod(user, @"selectedCueId", "i16@0:8", NULL) ||
        !PLCheckMethod(user, @"getCueStatsWithBonus:", "{CueStatsWithBonus=IIII}20@0:8i16", NULL) ||
        !PLCheckMethod(user, @"getCueChargesLeft:", "i20@0:8i16", NULL)) return 0;
    int32_t cueID = ((int32_t (*)(id, SEL))objc_msgSend)(user, NSSelectorFromString(@"selectedCueId"));
    PLCueStatsWithBonus stats = ((PLCueStatsWithBonus (*)(id, SEL, int32_t))objc_msgSend)(
        user, NSSelectorFromString(@"getCueStatsWithBonus:"), cueID);
    uint32_t powerIndex = stats.power;
    if (PLBool(manager, @"isOnNetworkedGame")) {
        int32_t charges = ((int32_t (*)(id, SEL, int32_t))objc_msgSend)(
            user, NSSelectorFromString(@"getCueChargesLeft:"), cueID);
        if (charges < 0) {
            // -1 is a display sentinel based on CueInfo's first field, not a
            // proven unlimited-charge marker. The release path uses the raw
            // counter at ownedCue+0x24 instead (0x1002c947c..0x1002c9484).
            // getOwnedCueWithId: uses the same read-only service accessor as
            // getCueChargesLeft:, so inspect that counter without consuming it.
            if (!PLCheckMethod(user, @"getOwnedCueWithId:",
                "r^{CueParameters={CueParametersData={CueStats=IIII}{CueSeenState=iiB}{CueInfo=iiiiiB}iiBB}}20@0:8i16", NULL)) return 0;
            const void *owned = ((const void *(*)(id, SEL, int32_t))objc_msgSend)(
                user, NSSelectorFromString(@"getOwnedCueWithId:"), cueID);
            if (!owned || !PLCopyMemory((uintptr_t)owned+0x24, &charges, sizeof(charges))) return 0;
        }
        if (charges <= 0) powerIndex = 0;
    }
    if (powerIndex > 15) return 0;
    float speed = 0;
    if (!PLCopyMemory((uintptr_t)_dyld_get_image_header(0)+0x34c2dac+powerIndex*sizeof(float), &speed, sizeof(speed)) ||
        !isfinite(speed) || speed <= 0 || speed > 10000) return 0;
    return (double)speed;
}

typedef struct {
    void *rules;
    BOOL nominationRequired;
    BOOL isBreakShot;
    int32_t nominatedPocket;
    int32_t classification;
} PLRulesInfo;

static BOOL PLIsStandardEightBallRule(uintptr_t rules) {
    // GameRules is a non-polymorphic component owner: its first word is a rule
    // identifier, NOT a vtable. Resolve IBaseRule from its native component tree
    // exactly as the game does, then inspect the component's dynamic type.
    static const uint8_t componentLookupBytes[] = {
        0xf8,0x5f,0xbc,0xa9,0xf6,0x57,0x01,0xa9,0xf4,0x4f,0x02,0xa9,0xfd,0x7b,0x03,0xa9,
        0xfd,0xc3,0x00,0x91,0xf3,0x03,0x00,0xaa,0x76,0x8e,0x40,0xf8,0x56,0x02,0x00,0xb4
    };
    void *lookup = PLVerifiedFunction(0x8348, componentLookupBytes, sizeof(componentLookupBytes));
    if (!lookup || !rules || rules > UINTPTR_MAX-0x38) return NO;
    uintptr_t image = (uintptr_t)_dyld_get_image_header(0);
    uintptr_t key = image+0x3ec18b8; // typeid(IBaseRule), used as the map key.
    uintptr_t node = ((uintptr_t (*)(uintptr_t, const uintptr_t *))lookup)(rules+0x28, &key);
    if (!node || node == rules+0x30 || node > UINTPTR_MAX-0x30) return NO;
    uintptr_t component = 0, vtable = 0, typeInfo = 0;
    return PLCopyMemory(node+0x28, &component, sizeof(component)) && component &&
        PLCopyMemory(component, &vtable, sizeof(vtable)) &&
        vtable >= sizeof(uintptr_t) && vtable % sizeof(uintptr_t) == 0 &&
        PLCopyMemory(vtable-sizeof(uintptr_t), &typeInfo, sizeof(typeInfo)) &&
        typeInfo == image+0x3ebd2b8;
}

static BOOL PLRules(id manager, id table, PLRulesInfo *info, NSError **error) {
    if (!PLCheckMethod(manager, @"is9BallGame", "B16@0:8", error) ||
        !PLCheckMethod(table, @"ballProperties", "@16@0:8", error)) return NO;
    id properties = PLObject(table, @"ballProperties");
    Class eightBall = NSClassFromString(@"BallProperties8Ball");
    if (PLBool(manager, @"is9BallGame") || !eightBall || ![properties isKindOfClass:eightBall])
        return PLFail(error, 51, @"O automático desta versão está preparado para mesas de 8 bolas.");
    void *rules = NULL;
    if (!PLRead(manager, @"GameManager", "_rules", "^v", &rules, sizeof(rules), error)) return NO;
    uint8_t record[0x120] = {0};
    if (!rules || !PLCopyMemory((uintptr_t)rules, record, sizeof(record)))
        return PLFail(error, 52, @"As regras da partida ainda não estão disponíveis.");
    // Native classification lookup 0x100aac4a8 uses these two vectors.
    // Its index helper matches playerID strings, not PoolPlayer object identity:
    // the manager and rules can hold distinct objects for the same player.
    uintptr_t classesBegin = 0, classesEnd = 0, playersBegin = 0, playersEnd = 0;
    memcpy(&classesBegin, record+0xc8, 8); memcpy(&classesEnd, record+0xd0, 8);
    memcpy(&playersBegin, record+0xe0, 8); memcpy(&playersEnd, record+0xe8, 8);
    int32_t classifications[2] = {0}; uintptr_t players[2] = {0};
    if (!classesBegin || classesEnd < classesBegin || classesEnd-classesBegin != sizeof(classifications) ||
        !playersBegin || playersEnd < playersBegin || playersEnd-playersBegin != sizeof(players) ||
        !PLCopyMemory(classesBegin, classifications, sizeof(classifications)) ||
        !PLCopyMemory(playersBegin, players, sizeof(players)))
        return PLFail(error, 53, @"A distribuição das bolas não está pronta para o automático.");
    id player = PLReadObject(manager, @"GameManager", "mPlayer", "@\"PoolPlayer\"", error);
    if (!player) return PLFail(error, 54, @"Seu jogador ainda não está disponível nesta mesa.");
    static const uint8_t playerIndexBytes[] = {
        0xf8,0x5f,0xbc,0xa9,0xf6,0x57,0x01,0xa9,0xf4,0x4f,0x02,0xa9,0xfd,0x7b,0x03,0xa9,
        0xfd,0xc3,0x00,0x91,0x17,0x60,0x4e,0xa9,0xff,0x02,0x18,0xeb,0x20,0x02,0x00,0x54
    };
    void *lookup = PLVerifiedFunction(0xaac4ec, playerIndexBytes, sizeof(playerIndexBytes));
    if (!lookup || !players[0] || !players[1] || players[0] == players[1] ||
        !PLCheckMethod(player, @"playerID", "@16@0:8", error))
        return PLFail(error, 54, @"A consulta de jogadores não corresponde ao build verificado.");
    int32_t index = ((int32_t (*)(void *, id))lookup)(rules, player);
    if (index < 0 || index > 1)
        return PLFail(error, 54, @"Não foi possível identificar suas bolas nesta partida.");
    int32_t classification = classifications[index];
    if (classification != -1 && classification != 1 && classification != 2 && classification != 4)
        return PLFail(error, 55, @"Esta regra de bolas ainda não é compatível com o automático.");
    int32_t nominationMode = 0;
    memcpy(&nominationMode, record+0x68, sizeof(nominationMode));
    if (nominationMode == 5 || (classification == 4 && nominationMode >= 3 && nominationMode <= 5))
        return PLFail(error, 62, @"Esta tacada exige tabela. O automático aguarda uma regra compatível.");
    static const uint8_t nominationBytes[] = {
        0xff,0xc3,0x00,0xd1,0xf4,0x4f,0x01,0xa9,0xfd,0x7b,0x02,0xa9,0xfd,0x83,0x00,0x91
    };
    void *function = PLVerifiedFunction(0xaad870, nominationBytes, sizeof(nominationBytes));
    if (!function) return PLFail(error, 56, @"A consulta de caçapas não corresponde ao build verificado.");
    info->rules = rules;
    info->classification = classification;
    info->nominationRequired = ((BOOL (*)(void *))function)(rules);
    int32_t phase = 0;
    memcpy(&phase, record+0x104, sizeof(phase));
    // Only the inspected Standard8BallRule state 1 is a supported break. The
    // scene may reuse other rule subclasses; do not infer a break from layout.
    if (phase == 1 && !info->nominationRequired && PLIsStandardEightBallRule((uintptr_t)rules))
        info->isBreakShot = YES;
    memcpy(&info->nominatedPocket, record+0x118, sizeof(info->nominatedPocket));
    if (info->nominationRequired && info->nominatedPocket != 9001 &&
        (info->nominatedPocket < 0 || info->nominatedPocket > 5))
        return PLFail(error, 57, @"A caçapa selecionada não está em um estado reconhecido.");
    return YES;
}

static BOOL PLReadyToPlan(id manager, id cue, NSArray *sourceBalls, BOOL pendingNomination, NSError **error) {
    for (NSString *name in @[@"isPlayerTurn", @"isWaitingForPlayerShot", @"isGameStarted",
                            @"isInGamePopUp", @"visualCueBallControlInputIsActive", @"visualEnglishControlIsActive"]) {
        if (!PLCheckMethod(manager, name, "B16@0:8", error)) return NO;
    }
    if (!PLBool(manager, @"isGameStarted")) return PLFail(error, 41, @"Aguardando o início da partida.");
    if (!PLBool(manager, @"isPlayerTurn")) return PLFail(error, 41, @"Aguardando a vez do adversário terminar.");
    if (!PLBool(manager, @"isWaitingForPlayerShot")) return PLFail(error, 41, @"Aguardando o jogo liberar a próxima tacada.");
    BOOL spectator = YES, turnEnded = YES;
    uint64_t touches = 0;
    if (!PLRead(manager, @"GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), error) ||
        !PLRead(manager, @"GameManager", "mPlayerTurnTimeFinished", "B", &turnEnded, sizeof(turnEnded), error) ||
        !PLRead(manager, @"GameManager", "mNumCurrentTouches", "Q", &touches, sizeof(touches), error)) return NO;
    if (spectator) return PLFail(error, 58, @"A partida está em modo espectador.");
    if (turnEnded) return PLFail(error, 58, @"O tempo desta vez terminou.");
    if (touches) return PLFail(error, 58, @"Solte os controles da mesa para liberar o automático.");
    if (PLBool(manager, @"isInGamePopUp")) return PLFail(error, 58, @"Feche o aviso aberto pelo jogo.");
    if (PLBool(manager, @"visualCueBallControlInputIsActive")) return PLFail(error, 58, @"Conclua o posicionamento da bola branca.");
    if (PLBool(manager, @"visualEnglishControlIsActive")) return PLFail(error, 58, @"Feche o controle de efeito do taco.");
    id blocker = PLReadObject(manager, @"GameManager", "_inputBlocker", "@\"InputBlocker\"", error);
    if (error && *error) return NO;
    if (blocker) return PLFail(error, 63, @"O jogo pausou os controles da mesa.");
    for (NSString *name in @[@"enabled", @"inputActive", @"hasTouches", @"isAnimatingAimAngle", @"isAnimatingPower"])
        if (!PLCheckMethod(cue, name, "B16@0:8", error)) return NO;
    if (PLBool(cue, @"hasTouches") || PLBool(cue, @"isAnimatingAimAngle") || PLBool(cue, @"isAnimatingPower"))
        return PLFail(error, 59, @"Aguarde a mira terminar de se mover.");
    if (!pendingNomination && (!PLBool(cue, @"enabled") || !PLBool(cue, @"inputActive")))
        return PLFail(error, 45, @"O jogo ainda não liberou o taco.");
    BOOL hasCue = NO;
    for (id ball in sourceBalls) {
        if (!PLCheckMethod(ball, @"isMovingOrSpinning", "B16@0:8", error) ||
            !PLCheckMethod(ball, @"onTable", "B16@0:8", error)) return NO;
        if (PLBool(ball, @"isMovingOrSpinning"))
            return PLFail(error, 42, @"Aguarde todas as bolas pararem.");
        uint32_t number = 0;
        if (!PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), error)) return NO;
        if (number == 0 && PLBool(ball, @"onTable")) hasCue = YES;
    }
    if (!hasCue) return PLFail(error, 43, @"Reposicione a bola branca antes da tacada.");
    if (!PLShotReleaseFunction()) return PLFail(error, 60, @"O disparo não corresponde ao build verificado.");
    void *cacher = NULL; uintptr_t owner = 0;
    if (!PLRead(manager, @"GameManager", "_cacher", "^{GameManagerCacher=@}", &cacher, sizeof(cacher), error) ||
        !cacher || !PLCopyMemory((uintptr_t)cacher, &owner, sizeof(owner)) || owner != (uintptr_t)(__bridge void *)manager)
        return PLFail(error, 61, @"O controle de tacadas ainda não está disponível.");
    return YES;
}

static NSDictionary<NSString *, NSString *> *PLInputDiagnostics(id manager) {
    // Read-only observations, never a way to clear a native touch or enable a
    // disabled control. Preserve unavailable fields explicitly in exported logs.
    NSMutableDictionary<NSString *, NSString *> *values = [NSMutableDictionary dictionary];
    uint64_t touches = 0;
    values[@"nativeCurrentTouches"] =
        PLRead(manager, @"GameManager", "mNumCurrentTouches", "Q", &touches, sizeof(touches), NULL)
        ? [NSString stringWithFormat:@"%llu", (unsigned long long)touches] : @"unavailable";
    id touchArray = PLReadObject(manager, @"GameManager", "mCurrentTouches", "@\"NSMutableArray\"", NULL);
    values[@"nativeTouchArrayCount"] = [touchArray isKindOfClass:NSArray.class]
        ? [NSString stringWithFormat:@"%llu", (unsigned long long)[touchArray count]] : @"unavailable";
    for (NSString *name in @[@"isPlayerTurn", @"isWaitingForPlayerShot", @"isGameStarted",
                            @"isInGamePopUp", @"visualCueBallControlInputIsActive", @"visualEnglishControlIsActive"]) {
        values[[@"nativeManager." stringByAppendingString:name]] =
            PLCheckMethod(manager, name, "B16@0:8", NULL) ? (PLBool(manager, name) ? @"true" : @"false") : @"unavailable";
    }
    BOOL spectator = NO, turnEnded = NO;
    values[@"nativeSpectatorMode"] =
        PLRead(manager, @"GameManager", "_spectatorMode", "B", &spectator, sizeof(spectator), NULL)
        ? (spectator ? @"true" : @"false") : @"unavailable";
    values[@"nativeTurnTimeFinished"] =
        PLRead(manager, @"GameManager", "mPlayerTurnTimeFinished", "B", &turnEnded, sizeof(turnEnded), NULL)
        ? (turnEnded ? @"true" : @"false") : @"unavailable";
    NSError *blockerError = nil;
    id blocker = PLReadObject(manager, @"GameManager", "_inputBlocker", "@\"InputBlocker\"", &blockerError);
    values[@"nativeInputBlocked"] = blockerError ? @"unavailable" : (blocker ? @"true" : @"false");
    id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", NULL);
    uint64_t cueTouches = 0;
    values[@"nativeCueCurrentTouches"] =
        PLRead(cue, @"VisualCue", "mNumCurrentTouches", "Q", &cueTouches, sizeof(cueTouches), NULL)
        ? [NSString stringWithFormat:@"%llu", (unsigned long long)cueTouches] : @"unavailable";
    for (NSString *name in @[@"enabled", @"inputActive", @"hasTouches", @"isAnimatingAimAngle", @"isAnimatingPower"]) {
        values[[@"nativeCue." stringByAppendingString:name]] =
            PLCheckMethod(cue, name, "B16@0:8", NULL) ? (PLBool(cue, name) ? @"true" : @"false") : @"unavailable";
    }
    return values;
}

typedef struct {
    uintptr_t buckets;
    uint64_t bucketCount;
    uintptr_t firstNode;
    uint64_t count;
} PLNativeMapHeader;

// Read-only traversal of the inspected libc++ unordered_map linked list.
// Hashing is deliberately unnecessary: validate the entire bounded list instead.
static BOOL PLLookupNativeMap(uintptr_t mapAddress, uint64_t wantedKey, BOOL wideKey,
                              BOOL *found, uintptr_t *value) {
    enum { MaximumEntries = 256 };
    PLNativeMapHeader before = {0}, after = {0};
    *found = NO; *value = 0;
    if (!mapAddress || mapAddress % sizeof(uintptr_t) ||
        !PLCopyMemory(mapAddress, &before, sizeof(before)) || before.count > MaximumEntries ||
        (before.count == 0 && before.firstNode != 0) ||
        (before.count > 0 && (!before.firstNode || !before.buckets || !before.bucketCount))) return NO;
    uintptr_t visited[MaximumEntries] = {0};
    uint64_t keys[MaximumEntries] = {0};
    uintptr_t node = before.firstNode;
    for (uint64_t index = 0; index < before.count; ++index) {
        if (!node || node % sizeof(uintptr_t)) return NO;
        for (uint64_t previous = 0; previous < index; ++previous)
            if (visited[previous] == node) return NO;
        uint8_t record[32] = {0};
        if (!PLCopyMemory(node, record, sizeof(record))) return NO;
        uint64_t key = 0; uintptr_t next = 0, entryValue = 0;
        memcpy(&next, record, sizeof(next));
        memcpy(&key, record+16, wideKey ? sizeof(uint64_t) : sizeof(uint32_t));
        memcpy(&entryValue, record+24, sizeof(entryValue));
        for (uint64_t previous = 0; previous < index; ++previous)
            if (keys[previous] == key) return NO;
        visited[index] = node; keys[index] = key;
        if (key == wantedKey) { *found = YES; *value = entryValue; }
        node = next;
    }
    if (node || !PLCopyMemory(mapAddress, &after, sizeof(after)) ||
        memcmp(&before, &after, sizeof(before)) != 0) return NO;
    return YES;
}

static BOOL PLRandomizerForKey(uint32_t key, BOOL *found, uintptr_t *randomizer) {
    return PLLookupNativeMap((uintptr_t)_dyld_get_image_header(0)+0x4f6ec38,
                             key, NO, found, randomizer);
}

static BOOL PLRandomizerType(uintptr_t randomizer, uintptr_t *typeInfo) {
    uintptr_t vtable = 0;
    if (!randomizer || randomizer % sizeof(uintptr_t) ||
        !PLCopyMemory(randomizer, &vtable, sizeof(vtable)) || vtable < sizeof(uintptr_t) ||
        vtable % sizeof(uintptr_t) ||
        !PLCopyMemory(vtable-sizeof(uintptr_t), typeInfo, sizeof(*typeInfo))) return NO;
    return YES;
}

static BOOL PLReadScalarOverride(id table, uint32_t key, double baseValue, double *output) {
    BOOL found = NO; uintptr_t randomizer = 0;
    if (!PLRandomizerForKey(key, &found, &randomizer)) return NO;
    if (!found || !randomizer) { *output = baseValue; return YES; }
    uintptr_t image = (uintptr_t)_dyld_get_image_header(0), typeInfo = 0;
    if (!PLRandomizerType(randomizer, &typeInfo) ||
        (typeInfo != image+0x3ebeb28 && typeInfo != image+0x3ebeb70 && typeInfo != image+0x3ebeb88)) return NO;
    uintptr_t parameters = 0;
    if (!PLLookupNativeMap(randomizer+8, (uintptr_t)(__bridge void *)table, YES, &found, &parameters)) return NO;
    if (!found || !parameters) { *output = baseValue; return YES; }
    uintptr_t parametersVtable = 0, cachedValue = 0;
    uint8_t usesCache = 0, active = 0;
    if (parameters % sizeof(uintptr_t) ||
        !PLCopyMemory(parameters, &parametersVtable, sizeof(parametersVtable)) ||
        parametersVtable != image+0x3ebeca0 ||
        !PLCopyMemory(randomizer+0x51, &usesCache, sizeof(usesCache)) ||
        !PLCopyMemory(parameters+0x20, &cachedValue, sizeof(cachedValue))) return NO;
    if (usesCache == 1 && cachedValue) {
        if (cachedValue % sizeof(double) ||
            !PLCopyMemory(cachedValue, output, sizeof(*output)) || !isfinite(*output)) return NO;
        return YES;
    }
    // Native 0x10036221c falls through to 0x100361bf0 without an enabled cache.
    // Inactive NumberParameterRandomiser parameters return the input unchanged
    // (0x100361c34..0x100361c84), and 0x1003622f0 is identity postprocessing.
    // Angle/range subclasses may transform that input: do not infer their value.
    if (typeInfo == image+0x3ebeb28 &&
        PLCopyMemory(parameters+8, &active, sizeof(active)) && (active & 1) == 0) {
        *output = baseValue; return YES;
    }
    // Never invoke a randomizer or its virtual generator: that would advance
    // the game's RNG or create state just to draw a prediction.
    return NO;
}

static BOOL PLBallNormalUnmodified(id table) {
    BOOL found = NO; uintptr_t randomizer = 0;
    if (!PLRandomizerForKey(0x82921313, &found, &randomizer)) return NO;
    if (!found || !randomizer) return YES;
    uintptr_t image = (uintptr_t)_dyld_get_image_header(0), typeInfo = 0;
    // This property changes a normal vector, not a scalar restitution factor.
    // Only confirmed absence/inactivity is supported by the scalar planner.
    if (!PLRandomizerType(randomizer, &typeInfo) || typeInfo != image+0x3ebeb58) return NO;
    uintptr_t parameters = 0;
    if (!PLLookupNativeMap(randomizer+8, (uintptr_t)(__bridge void *)table, YES, &found, &parameters)) return NO;
    if (!found || !parameters) return YES;
    uintptr_t parametersVtable = 0; uint8_t active = 0;
    if (parameters % sizeof(uintptr_t) ||
        !PLCopyMemory(parameters, &parametersVtable, sizeof(parametersVtable)) ||
        parametersVtable != image+0x3ebecd8 ||
        !PLCopyMemory(parameters+8, &active, sizeof(active))) return NO;
    // Native 0x100361b7c checks bit 0 before ball-normal modification.
    return (active & 1) == 0;
}

static const char *const PLPhysicsAreasType =
    "{vector<std::shared_ptr<PhysicsArea>, std::allocator<std::shared_ptr<PhysicsArea>>>="
    "\"__begin_\"^v\"__end_\"^v\"\"{?=\"__cap_\"^v}}";

static BOOL PLPhysicsAreasAreEmpty(const uintptr_t areas[3]) {
    if (!areas[0]) return areas[1] == 0 && areas[2] == 0;
    return areas[0] == areas[1] && areas[2] >= areas[1] &&
           areas[0] % sizeof(uintptr_t) == 0 &&
           (areas[2]-areas[0]) % (2*sizeof(uintptr_t)) == 0;
}

static double PLLogicalFrameTime(id table) {
    // Both original getters return the nontrivial MCNumber through x8. Read
    // their backing global only after confirming the instance/class paths.
    static const uint8_t logicalFrameBytes[] = {
        0x29,0x3b,0x02,0xb0,0x20,0xa9,0x45,0xf9,0xcc,0xcc,0xc4,0x14
    };
    static const uint8_t defaultFrameBytes[] = {
        0x49,0x51,0x02,0x90,0x20,0xa1,0x41,0xfd,0x00,0x01,0x00,0xfd,0xc0,0x03,0x5f,0xd6
    };
    Class tableClass = NSClassFromString(@"Table");
    if (!tableClass || !PLCheckMethod(table, @"getLogicalFrameTime", "{MCNumber=d}16@0:8", NULL) ||
        !PLCheckMethod(tableClass, @"getDefaultLogicalFrameTime", "{MCNumber=d}16@0:8", NULL)) return 0;
    void *instanceGetter = PLVerifiedFunction(0xa7248, logicalFrameBytes, sizeof(logicalFrameBytes));
    void *classGetter = PLVerifiedFunction(0xa7254, defaultFrameBytes, sizeof(defaultFrameBytes));
    Method instanceMethod = class_getInstanceMethod(object_getClass(table), NSSelectorFromString(@"getLogicalFrameTime"));
    Method classMethod = class_getClassMethod(tableClass, NSSelectorFromString(@"getDefaultLogicalFrameTime"));
    if (!instanceGetter || !classGetter || method_getImplementation(instanceMethod) != (IMP)instanceGetter ||
        method_getImplementation(classMethod) != (IMP)classGetter) return 0;
    double value = 0;
    if (!PLCopyMemory((uintptr_t)_dyld_get_image_header(0)+0x4acf340, &value, sizeof(value)) ||
        !isfinite(value) || value <= 0 || value > 0.1) return 0;
    return value;
}

static NSString *PLFillPhysics(id table, PLGameSnapshot *snapshot) {
    void *ruleset = NULL; uint32_t rulesetID = UINT32_MAX;
    if (!PLRead(table, @"Table", "_ruleset", "^v", &ruleset, sizeof(ruleset), NULL) ||
        !ruleset || !PLCopyMemory((uintptr_t)ruleset+0x12c, &rulesetID, sizeof(rulesetID)))
        return @"As propriedades físicas da regra ainda não estão disponíveis.";
    // IDs above 53 enable the property lookup path, but do not prove that this
    // particular table has an override. Confirm absence or read an existing cache.
    static const char *encoding = "{FrictionProperties=\"_coefficientOfSlidingFriction\"{MCNumber=\"mValue\"d}\"_coefficientOfRollingFriction\"{MCNumber=\"mValue\"d}\"_coefficientOfSpinningFriction\"{MCNumber=\"mValue\"d}\"_timeOfequilibriumFactor\"{MCNumber=\"mValue\"d}\"_velocityReductionSlidingFactor\"{MCNumber=\"mValue\"d}\"_velocityReductionRollingFactor\"{MCNumber=\"mValue\"d}\"_deltaSpinFactor\"{MCNumber=\"mValue\"d}\"_table\"@\"Table\"}";
    uint8_t friction[64] = {0};
    if (!PLRead(table, @"Table", "_frictionProperties", encoding, friction, sizeof(friction), NULL))
        return @"A estrutura do atrito da mesa não corresponde ao build verificado.";
    uintptr_t areas[3] = {0}, confirmedAreas[3] = {0};
    if (!PLRead(table, @"Table", "_physicsAreas", PLPhysicsAreasType, areas, sizeof(areas), NULL) ||
        !PLPhysicsAreasAreEmpty(areas))
        return @"Esta mesa contém regiões de atrito que ainda não estão modeladas.";
    double rolling = 0, cushion = 0, sliding = 0, equilibrium = 0, spin = 0, coefficient = 0, coupling = 0;
    uintptr_t owner = 0;
    memcpy(&rolling, friction+40, sizeof(rolling)); memcpy(&owner, friction+56, sizeof(owner));
    memcpy(&coefficient, friction, sizeof(coefficient)); memcpy(&equilibrium, friction+24, sizeof(equilibrium));
    memcpy(&sliding, friction+32, sizeof(sliding)); memcpy(&spin, friction+48, sizeof(spin));
    double frameTime = PLLogicalFrameTime(table);
    if ((owner && owner != (uintptr_t)(__bridge void *)table) ||
        !PLCopyMemory((uintptr_t)_dyld_get_image_header(0)+0x4ae1550, &cushion, sizeof(cushion)) ||
        !PLCopyMemory((uintptr_t)_dyld_get_image_header(0)+0x4ae1560, &coupling, sizeof(coupling)))
        return @"Os coeficientes físicos ainda não estão disponíveis.";
    if (rulesetID > 53) {
        // Every scalar friction getter forwards the stored owner (including
        // cushion response/coupling). A null owner takes the native base path.
        if (owner && !PLReadScalarOverride(table, 0x04f05190, rolling, &rolling))
            return @"O atrito desta mesa depende de um valor dinâmico ainda não confirmado.";
        if (owner && !PLReadScalarOverride(table, 0xccda5f3b, sliding, &sliding))
            return @"O deslizamento desta mesa depende de um valor dinâmico ainda não confirmado.";
        if (owner && !PLReadScalarOverride(table, 0x10ba1e13, spin, &spin))
            return @"A rotação desta mesa depende de um valor dinâmico ainda não confirmado.";
        if (owner && !PLReadScalarOverride(table, 0x178e63e2, coupling, &coupling))
            return @"O efeito na tabela depende de um valor dinâmico ainda não confirmado.";
        if (owner && !PLReadScalarOverride(table, 0x59bb3a48, cushion, &cushion))
            return @"A resposta da tabela depende de um valor dinâmico ainda não confirmado.";
        if (!PLBallNormalUnmodified(table))
            return @"Esta mesa aplica uma alteração de colisão ainda não compatível com a previsão.";
    }
    if (!isfinite(rolling) || rolling <= 0 || rolling > 10000 ||
        !isfinite(sliding) || sliding <= 0 || sliding > 10000 ||
        !isfinite(equilibrium) || equilibrium <= 0 || equilibrium > 1000000 ||
        !isfinite(spin) || spin < 0 || spin > 10000000 ||
        !isfinite(coefficient) || coefficient < 0 || coefficient > 10 ||
        !isfinite(coupling) || coupling < 0 || coupling > 10 || frameTime <= 0 ||
        !isfinite(cushion) || cushion <= 0 || cushion > 1)
        return @"Os coeficientes físicos estão fora do intervalo validado.";
    if (!PLRead(table, @"Table", "_physicsAreas", PLPhysicsAreasType, confirmedAreas, sizeof(confirmedAreas), NULL) ||
        memcmp(areas, confirmedAreas, sizeof(areas)) != 0)
        return @"As regiões físicas da mesa mudaram durante a leitura.";
    snapshot.rollingDeceleration = rolling;
    snapshot.slidingDeceleration = sliding;
    // Native code uses this stored factor directly, even after scalar overrides.
    snapshot.equilibriumTimeFactor = equilibrium;
    snapshot.spinDeceleration = spin;
    snapshot.slidingFrictionCoefficient = coefficient;
    snapshot.cushionSpinCoupling = coupling;
    snapshot.logicalFrameTime = frameTime;
    snapshot.ballRestitution = 1.0; // Native equal-mass normal velocity exchange.
    snapshot.cushionRestitution = cushion;
    snapshot.physicsCalibrationAvailable = YES;
    return @"";
}

static BOOL PLReadSelectedEnglish(id manager, double english[2], NSError **error) {
    id control = PLReadObject(manager, @"GameManager", "mVisualEnglishControl", "@\"VisualEnglishControl\"", error);
    Class expected = NSClassFromString(@"VisualEnglishControl");
    if (!control || !expected || ![control isKindOfClass:expected] ||
        !PLCheckMethod(control, @"isAnimatingEnglish", "B16@0:8", error))
        return PLFail(error, 74, @"A leitura do efeito do taco ainda não está disponível.");
    // Same selection as native shot helper 0x100019ca8: while animating the
    // game submits the target, not the current interpolated display value.
    BOOL animating = PLBool(control, @"isAnimatingEnglish");
    static const char *encoding = "{?=\"x\"{MCNumber=\"mValue\"d}\"y\"{MCNumber=\"mValue\"d}}";
    if (!PLRead(control, @"VisualEnglishControl", animating ? "mAnimateEnglishTarget" : "mEnglish",
                encoding, english, 2*sizeof(double), error)) return NO;
    if (!isfinite(english[0]) || !isfinite(english[1]) || fabs(english[0]) > 1 || fabs(english[1]) > 1)
        return PLFail(error, 74, @"O efeito do taco contém valores ainda não compatíveis.");
    return YES;
}

static BOOL PLCenteredEnglish(const double english[2]) {
    return english[0] == 0 && english[1] == 0;
}

static void PLFillControls(id manager, id table, NSArray *sourceBalls, PLGameSnapshot *snapshot) {
    snapshot.legalTargetNumbers = @[];
    snapshot.autoShotUnavailableReason = @"A mesa ainda não está pronta para a tacada.";
    snapshot.shootReadinessReason = @"A mesa ainda não está pronta para a tacada.";
    snapshot.shotInputUnavailableReason = @"Aguardando a leitura do efeito do taco.";
    id cue = nil; double angle = 0, power = 0; NSError *reason = nil;
    if (!PLReadCue(manager, &cue, &angle, &power, &reason)) {
        snapshot.autoShotUnavailableReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático.";
        snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return;
    }
    snapshot.aimAvailable = YES; snapshot.aimAngle = angle; snapshot.cuePower = power;
    snapshot.minimumShotPower = PLMinimumShotPower(cue);
    double english[2] = {0}; NSError *englishError = nil;
    if (PLReadSelectedEnglish(manager, english, &englishError)) {
        snapshot.cueEnglishX = english[0]; snapshot.cueEnglishY = english[1];
        snapshot.shotInputSupported = PLCenteredEnglish(english);
        snapshot.shotInputUnavailableReason = snapshot.shotInputSupported ? @"" :
            @"Centralize o efeito do taco para prever a próxima tacada.";
    } else snapshot.shotInputUnavailableReason = englishError.localizedDescription ?: snapshot.shotInputUnavailableReason;
    PLRulesInfo rules = {0};
    if (!PLRules(manager, table, &rules, &reason)) {
        snapshot.autoShotUnavailableReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático.";
        snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return;
    }
    snapshot.isBreakShot = rules.isBreakShot;
    NSMutableArray<NSNumber *> *targets = [NSMutableArray array];
    for (id ball in sourceBalls) {
        int32_t classification = 0, state = 0; uint32_t number = 0;
        if (!PLRead(ball, @"Ball", "classification", "i", &classification, sizeof(classification), &reason) ||
            !PLRead(ball, @"Ball", "state", "i", &state, sizeof(state), &reason) ||
            !PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), &reason)) {
            snapshot.autoShotUnavailableReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático.";
            snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return;
        }
        if (state != 1 || number == 0 || number > 15) continue;
        BOOL legal = rules.classification == -1 ? (classification == 1 || classification == 2) : classification == rules.classification;
        if (legal) [targets addObject:@(number)];
    }
    snapshot.legalTargetNumbers = targets;
    // Capability is independent of whose turn it currently is. The controller
    // keeps automatic play armed while canShoot reports a temporary wait.
    snapshot.autoShotAvailable = PLShotReleaseFunction() != NULL;
    snapshot.autoShotUnavailableReason = snapshot.autoShotAvailable ? @"" : @"O disparo não corresponde ao build verificado.";
    if (!snapshot.autoShotAvailable) { snapshot.shootReadinessReason = snapshot.autoShotUnavailableReason; return; }
    BOOL pendingNomination = rules.nominationRequired && rules.nominatedPocket == 9001;
    if (!PLReadyToPlan(manager, cue, sourceBalls, pendingNomination, &reason)) {
        snapshot.shootReadinessReason = reason.localizedDescription ?: @"A mesa ainda não está pronta para o automático."; return;
    }
    if (!snapshot.shotInputSupported) {
        snapshot.shootReadinessReason = snapshot.shotInputUnavailableReason; return;
    }
    if (!snapshot.physicsCalibrationAvailable) {
        snapshot.shootReadinessReason = @"Aguardando a leitura completa da física da mesa."; return;
    }
    snapshot.canShoot = targets.count > 0;
    snapshot.shootReadinessReason = targets.count ? @"" : @"Nenhuma bola permitida está disponível.";
}


static const char *const PLPointVectorType =
    "{vector<MCNumberPoint, std::allocator<MCNumberPoint>>=\"__begin_\"^{?}\"__end_\"^{?}\"\"{?=\"__cap_\"^{?}}}";

static NSArray<NSValue *> *PLCopyPointVector(id owner, NSString *className,
    const char *ivarName, NSUInteger minimum, NSUInteger maximum, const double bounds[4]) {
    uintptr_t header[3] = {0}, after[3] = {0};
    if (!PLRead(owner, className, ivarName, PLPointVectorType, header, sizeof(header), NULL) ||
        !header[0] || header[0] % sizeof(double) || header[1] < header[0] || header[2] < header[1] ||
        (header[1]-header[0]) % (2*sizeof(double)) ||
        (header[2]-header[0]) % (2*sizeof(double)) ||
        (header[2]-header[0]) / (2*sizeof(double)) > 1024) return nil;
    NSUInteger count = (header[1]-header[0]) / (2*sizeof(double));
    if (count < minimum || count > maximum || count > 256) return nil;
    double points[256][2];
    if (!PLCopyMemory(header[0], points, count*sizeof(points[0])) ||
        !PLRead(owner, className, ivarName, PLPointVectorType, after, sizeof(after), NULL) ||
        memcmp(header, after, sizeof(header)) != 0) return nil;
    NSMutableArray<NSValue *> *result = [NSMutableArray arrayWithCapacity:count];
    for (NSUInteger i = 0; i < count; i++) {
        double x = points[i][0], y = points[i][1];
        if (!isfinite(x) || !isfinite(y) ||
            x < bounds[0]-bounds[2] || x > bounds[0]+2*bounds[2] ||
            y < bounds[1]-bounds[3] || y > bounds[1]+2*bounds[3]) return nil;
        [result addObject:[NSValue valueWithCGPoint:CGPointMake(x, y)]];
    }
    return [result copy];
}

static BOOL PLGeometryMethod(id object, NSString *name, const char *encoding,
                             uintptr_t rva, const uint8_t *bytes, size_t length) {
    if (!PLCheckMethod(object, name, encoding, NULL)) return NO;
    IMP expected = (IMP)PLVerifiedFunction(rva, bytes, length);
    Method method = class_getInstanceMethod(object_getClass(object), NSSelectorFromString(name));
    return expected && method && method_getImplementation(method) == expected;
}

static NSString *PLFillNativeGeometry(id table, const double bounds[4], PLGameSnapshot *snapshot) {
    snapshot.nativeCushionVertices = @[];
    snapshot.nativePocketCenters = @[];
    snapshot.nativePocketAimPoints = @[];
    id properties = PLReadObject(table, @"Table", "mTableProperties", "@\"<TableProperties>\"", NULL);
    Class standard = NSClassFromString(@"TenByFiveTableProperties");
    Class narrow = NSClassFromString(@"TenByFiveNarrowTableProperties");
    Class actual = properties ? object_getClass(properties) : Nil;
    BOOL isNarrow = narrow && actual == narrow;
    if (!actual || (!isNarrow && (!standard || actual != standard)))
        return @"A geometria desta mesa ainda não corresponde aos tipos verificados.";
    NSString *propertiesName = isNarrow ? @"TenByFiveNarrowTableProperties" : @"TenByFiveTableProperties";
    // tableShape chooses normal/tight geometry from the current native rule.
    // Its consumer at 0x100011078 walks every adjacent pair, including last→0.
    static const uint8_t selectedShapeBytes[] = {0xf4,0x4f,0xbe,0xa9,0xfd,0x7b,0x01,0xa9,0xfd,0x43,0x00,0x91,0xf3,0x03,0x00,0xaa,0x08,0x3c,0x02,0x90,0x08,0xed,0x8f,0xb9,0x00,0x68,0x68,0xf8,0x14,0x3c,0x02,0xb0,0x94,0xd2,0x00,0x91,0xe0,0x00,0x00,0xb4,0x01,0x10,0x80,0x52,0xdf,0x27,0x28,0x94,0x08,0x3c,0x02,0xb0,0x08,0xe1,0x00,0x91,0x1f,0x00,0x00,0x71,0x14,0x11,0x94,0x9a,0x88,0x02,0x80,0xb9,0x60,0x02,0x08,0x8b,0xfd,0x7b,0x41,0xa9,0xf4,0x4f,0xc2,0xa8,0xc0,0x03,0x5f,0xd6};
    static const uint8_t pocketRadiusBytes[] = {0x09,0x04,0xe8,0xd2,0x09,0x01,0x00,0xf9,0xc0,0x03,0x5f,0xd6};
    static const uint8_t pocketForceBytes[] = {0xc8,0x55,0x02,0xb0,0x01,0x71,0x43,0xfd,0x01,0x09,0x61,0x1e,0xe2,0x2b,0xc0,0x3d,0x00,0x90,0xc1,0x4f,0x40,0xd4,0x60,0x4e,0xe0,0x2b,0x80,0x3d,0xe0,0x1b,0x80,0x3d,0xe2,0x83,0x01,0x91,0xe0,0x03,0x14,0xaa,0x36,0x09,0xcb,0x94,0xe8,0x83,0x01,0x91,0xe0,0x03,0x14,0xaa,0xfb,0x4c,0xc9,0x94,0xe0,0x33,0x40,0xfd,0x00,0x08,0x60,0x1e,0x20,0x21,0x60,0x1e,0x64,0x00,0x00,0x54};
    if (!PLGeometryMethod(table, @"tableShape", "r^v16@0:8", 0xa3118,
                           selectedShapeBytes, sizeof(selectedShapeBytes)) ||
        !PLGeometryMethod(properties, @"getPocketRadius", "{MCNumber=d}16@0:8",
                           isNarrow ? 0xfd258 : 0xebee0, pocketRadiusBytes, sizeof(pocketRadiusBytes)) ||
        !PLVerifiedFunction(0x118e0, pocketForceBytes, sizeof(pocketForceBytes)))
        return @"Os métodos de geometria não correspondem ao executável verificado.";
    Ivar normal = PLCheckIvar(table, @"Table", "mTableShape", PLPointVectorType, 3*sizeof(uintptr_t), NULL);
    Ivar tight = PLCheckIvar(table, @"Table", "mTightTableShape", PLPointVectorType, 3*sizeof(uintptr_t), NULL);
    if (!normal || !tight) return @"Os contornos da tabela não estão disponíveis.";
    uintptr_t selected = (uintptr_t)((const void *(*)(id, SEL))objc_msgSend)(table, NSSelectorFromString(@"tableShape"));
    uintptr_t objectAddress = (uintptr_t)(__bridge const void *)table;
    const char *shapeName = NULL;
    if (selected == objectAddress+(uintptr_t)ivar_getOffset(normal)) shapeName = "mTableShape";
    else if (selected == objectAddress+(uintptr_t)ivar_getOffset(tight)) shapeName = "mTightTableShape";
    else return @"O jogo selecionou um contorno ainda não verificado.";
    NSArray<NSValue *> *vertices = PLCopyPointVector(table, @"Table", shapeName, 12, 256, bounds);
    NSArray<NSValue *> *centers = PLCopyPointVector(properties, propertiesName, "mPockets", 6, 6, bounds);
    NSArray<NSValue *> *aim = PLCopyPointVector(properties, propertiesName, "mPocketAimPoints", 6, 6, bounds);
    if (!vertices || !centers || !aim) return @"A geometria da tabela mudou durante a leitura.";
    for (NSUInteger i = 0; i < vertices.count; i++) {
        CGPoint a = vertices[i].CGPointValue, b = vertices[(i+1)%vertices.count].CGPointValue;
        if (hypot(a.x-b.x, a.y-b.y) < 1e-7)
            return @"O contorno da tabela contém um segmento inválido.";
    }
    double attraction = 0;
    // The verified force block reads this double and multiplies (center-pos)*dt.
    // MCNumber radius getter writes the exact double 8.0 through x8; no invalid
    // scalar-return ABI call is used here. Pot capture itself uses ball.radius.
    if (!PLCopyMemory((uintptr_t)_dyld_get_image_header(0)+0x4aca6e0, &attraction, sizeof(attraction)) ||
        !isfinite(attraction) || attraction <= 0 || attraction > 1000000)
        return @"A atração das caçapas ainda não está disponível.";
    uintptr_t confirmed = (uintptr_t)((const void *(*)(id, SEL))objc_msgSend)(table, NSSelectorFromString(@"tableShape"));
    if (confirmed != selected || properties != PLReadObject(table, @"Table", "mTableProperties", "@\"<TableProperties>\"", NULL))
        return @"A regra da geometria mudou durante a leitura.";
    snapshot.nativeCushionVertices = vertices;
    snapshot.nativePocketCenters = centers;
    snapshot.nativePocketAimPoints = aim;
    snapshot.nativePocketRadius = 8.0;
    snapshot.nativePocketAttractionCoefficient = attraction;
    snapshot.nativeGeometrySource = [NSString stringWithFormat:@"%@.%s", propertiesName, shapeName];
    snapshot.nativeGeometryAvailable = YES;
    return @"";
}

static PLGameSnapshot *PLCapture(NSError **error) {
    NSTimeInterval captureStarted = NSProcessInfo.processInfo.systemUptime;
    id manager = nil, director = nil;
    if (!PLEnvironment(&manager, &director, error)) return nil;
    if (!PLCheckMethod(director, @"convertToUI:", "{CGPoint=dd}32@0:8{CGPoint=dd}16", error) ||
        !PLCheckMethod(director, @"useSafeAreaOrigin", "B16@0:8", error)) return nil;
    CGPoint renderOrigin = CGPointZero;
    if (PLBool(director, @"useSafeAreaOrigin")) {
        CGRect safeArea = CGRectZero;
        if (!PLRead(director, @"CCDirector", "_safeAreaInPoints",
                    "{CGRect=\"origin\"{CGPoint=\"x\"d\"y\"d}\"size\"{CGSize=\"width\"d\"height\"d}}",
                    &safeArea, sizeof(safeArea), error)) return nil;
        if (!PLFinitePoint(safeArea.origin)) { PLFail(error, 24, @"A origem da imagem ainda está em transição."); return nil; }
        renderOrigin = safeArea.origin;
    }
    uint64_t nativeFrame = 0;
    if (!PLRead(director, @"CCDirector", "_totalFrames", "Q", &nativeFrame, sizeof(nativeFrame), error)) return nil;
    if (!PLCheckMethod(manager, @"isPlayerTurn", "B16@0:8", error)) return nil;
    id table = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
    if (!table) { if (!error || !*error) PLFail(error, 20, @"Nenhuma mesa disponível."); return nil; }
    id source = PLReadObject(table, @"Table", "mBalls", "@\"NSArray\"", error);
    if (!source || ![source isKindOfClass:NSArray.class]) {
        if (!error || !*error) PLFail(error, 21, @"A lista de bolas não está disponível.");
        return nil;
    }
    NSArray *sourceBalls = [source copy];
    if (sourceBalls.count == 0 || sourceBalls.count > 32) {
        PLFail(error, 22, @"Quantidade de bolas incompatível."); return nil;
    }
    if (!PLCheckMethod(manager, @"isOnGoldenShotMode", "B16@0:8", error)) return nil;
    BOOL goldenShot = PLBool(manager, @"isOnGoldenShotMode");
    double bounds[4] = {0};
    if (!PLRead(table, @"Table", "mTableCollisionBounds", PLBoundsType, bounds, sizeof(bounds), error)) return nil;
    if (!isfinite(bounds[0]) || !isfinite(bounds[1]) || !isfinite(bounds[2]) || !isfinite(bounds[3]) ||
        bounds[2] <= 0 || bounds[3] <= 0 || bounds[2] > 100000 || bounds[3] > 100000) {
        PLFail(error, 23, @"Dimensões da mesa inválidas."); return nil;
    }
    CGRect logicalBounds = CGRectZero;
    UIView *view = PLCoordinateView(PLObject(director, @"view"), &logicalBounds, error);
    if (!view) return nil;
    NSMutableArray<PLBallSnapshot *> *values = [NSMutableArray array];
    NSMutableArray<NSValue *> *visualPositions = [NSMutableArray array];
    NSMutableIndexSet *numbers = [NSMutableIndexSet indexSet];
    id parent = nil;
    CGPoint commonOrigin = CGPointZero;
    double numerator = 0, denominator = 0;
    NSUInteger obstacleNumber = 2;
    for (id ball in sourceBalls) {
        Class ballClass = NSClassFromString(@"Ball");
        if (!ballClass || ![ball isKindOfClass:ballClass] ||
            !PLCheckMethod(ball, @"onTable", "B16@0:8", error)) {
            if (!error || !*error) PLFail(error, 25, @"Objeto de bola incompatível.");
            return nil;
        }
        uint32_t number = 0;
        if (!PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), error)) return nil;
        if (goldenShot) {
            int32_t classification = 0;
            if (!PLRead(ball, @"Ball", "classification", "i", &classification, sizeof(classification), error)) return nil;
            // Lucky Shot uses one golden ball numbered 1000 and several obstacles
            // all numbered 1001. These are snapshot IDs only, never native writes.
            if (number == 0) number = 0;
            else if (number == 1000 && classification == 7) number = 1;
            else if (number == 1001 && classification == 8) number = (uint32_t)obstacleNumber++;
            else { PLFail(error, 26, @"O desafio contém uma bola ainda não reconhecida."); return nil; }
        }
        if (number > 31 || [numbers containsIndex:number]) {
            PLFail(error, 26, @"Numeração de bolas incompatível."); return nil;
        }
        [numbers addIndex:number];
        if (!PLBool(ball, @"onTable")) continue;
        double physics[10] = {0};
        if (!PLRead(ball, @"Ball", "_physicsProperties", PLPhysicsType, physics, sizeof(physics), error)) return nil;
        for (NSUInteger i = 0; i < 10; ++i) {
            if (!isfinite(physics[i])) { PLFail(error, 27, @"A mesa contém valores físicos inválidos."); return nil; }
        }
        double radius = physics[4];
        if (radius <= 0 || radius * 2 >= fmin(bounds[2], bounds[3]) ||
            physics[0] < bounds[0] - radius * 5 || physics[0] > bounds[0] + bounds[2] + radius * 5 ||
            physics[1] < bounds[1] - radius * 5 || physics[1] > bounds[1] + bounds[3] + radius * 5) {
            PLFail(error, 28, @"Bola fora dos limites esperados. Aguarde a mesa parar."); return nil;
        }
        id visual = PLReadObject(ball, @"Ball", "visualBall", "@\"ProjectedSphere\"", error);
        Class sphereClass = NSClassFromString(@"ProjectedSphere");
        if (!visual || !sphereClass || ![visual isKindOfClass:sphereClass] ||
            !PLCheckMethod(visual, @"position", "{CGPoint=dd}16@0:8", error) ||
            !PLCheckMethod(visual, @"parent", "@16@0:8", error)) {
            if (!error || !*error) PLFail(error, 29, @"Posição visual da bola indisponível.");
            return nil;
        }
        id candidateParent = PLObject(visual, @"parent");
        if (!candidateParent || !PLCheckMethod(candidateParent, @"convertToWorldSpace:", "{CGPoint=dd}32@0:8{CGPoint=dd}16", error)) {
            if (!error || !*error) PLFail(error, 30, @"Transformação da mesa indisponível.");
            return nil;
        }
        CGPoint origin;
        if (!PLRead(ball, @"Ball", "mVisualTableOrigin", PLPointType, &origin, sizeof(origin), error)) return nil;
        CGPoint position = PLPoint(visual, @"position");
        if (!PLFinitePoint(origin) || !PLFinitePoint(position)) {
            PLFail(error, 31, @"Coordenadas visuais inválidas."); return nil;
        }
        if (parent && (parent != candidateParent || hypot(origin.x-commonOrigin.x, origin.y-commonOrigin.y) > 0.01)) {
            PLFail(error, 32, @"A mesa está em transição. Aguarde um instante."); return nil;
        }
        parent = candidateParent;
        commonOrigin = origin;
        numerator += physics[0] * (position.x-origin.x) + physics[1] * (position.y-origin.y);
        denominator += physics[0]*physics[0] + physics[1]*physics[1];
        PLBallSnapshot *value = [PLBallSnapshot new];
        value.number = number; value.x = physics[0]; value.y = physics[1];
        value.vx = physics[2]; value.vy = physics[3]; value.radius = radius;
        value.spinX = physics[5]; value.spinY = physics[6]; value.spinZ = physics[7];
        value.visualCenter = PLRenderPoint(PLRenderScenePoint(candidateParent, director, position, renderOrigin), logicalBounds, view);
        if (!PLFinitePoint(value.visualCenter)) { PLFail(error, 31, @"O centro visual da bola ainda não está disponível."); return nil; }
        [values addObject:value];
        [visualPositions addObject:[NSValue valueWithCGPoint:position]];
    }
    if (values.count == 0 || !parent || denominator < 1e-8) {
        PLFail(error, 33, @"Ainda não há uma mesa pronta para leitura."); return nil;
    }
    double scale = numerator / denominator;
    if (!isfinite(scale) || scale <= 0 || scale > 1000) {
        PLFail(error, 34, @"Escala visual da mesa inválida."); return nil;
    }
    double maximumResidual = 0;
    for (NSUInteger i = 0; i < values.count; ++i) {
        PLBallSnapshot *ball = values[i];
        CGPoint measured = visualPositions[i].CGPointValue;
        double residual = hypot(measured.x-commonOrigin.x-ball.x*scale,
                                measured.y-commonOrigin.y-ball.y*scale);
        maximumResidual = fmax(maximumResidual, residual);
        if (!isfinite(residual) || residual > 1.0) {
            PLFail(error, 35, @"A imagem e a física estão atualizando. Aguarde um instante."); return nil;
        }
    }
    CGPoint topLeft = PLRenderScenePoint(parent, director, CGPointMake(commonOrigin.x+bounds[0]*scale,
                                           commonOrigin.y+(bounds[1]+bounds[3])*scale), renderOrigin);
    CGPoint topRight = PLRenderScenePoint(parent, director, CGPointMake(commonOrigin.x+(bounds[0]+bounds[2])*scale,
                                            commonOrigin.y+(bounds[1]+bounds[3])*scale), renderOrigin);
    CGPoint bottomLeft = PLRenderScenePoint(parent, director, CGPointMake(commonOrigin.x+bounds[0]*scale,
                                              commonOrigin.y+bounds[1]*scale), renderOrigin);
    topLeft = PLRenderPoint(topLeft, logicalBounds, view);
    topRight = PLRenderPoint(topRight, logicalBounds, view);
    bottomLeft = PLRenderPoint(bottomLeft, logicalBounds, view);
    if (!PLFinitePoint(topLeft) || !PLFinitePoint(topRight) || !PLFinitePoint(bottomLeft)) {
        PLFail(error, 36, @"Não foi possível posicionar a sobreposição."); return nil;
    }
    double ax = topRight.x-topLeft.x, ay = topRight.y-topLeft.y;
    double bx = bottomLeft.x-topLeft.x, by = bottomLeft.y-topLeft.y;
    CGPoint bottomRight = CGPointMake(topRight.x+bx, topRight.y+by);
    CGRect visible = CGRectInset(view.bounds, -2, -2);
    if (hypot(ax, ay) < 20 || hypot(bx, by) < 20 || fabs(ax*by-ay*bx) < 400 ||
        !CGRectContainsPoint(visible, topLeft) || !CGRectContainsPoint(visible, topRight) ||
        !CGRectContainsPoint(visible, bottomLeft) || !CGRectContainsPoint(visible, bottomRight)) {
        PLFail(error, 37, @"A mesa não cabe na área visível. Aguarde a animação terminar."); return nil;
    }
    PLGameSnapshot *result = [PLGameSnapshot new];
    result.captureTimestamp = captureStarted;
    result.frameNumber = nativeFrame;
    result.projectionResidual = maximumResidual;
    result.balls = values; result.originX = bounds[0]; result.originY = bounds[1];
    result.width = bounds[2]; result.height = bounds[3];
    result.playerTurn = PLBool(manager, @"isPlayerTurn");
    result.tableTopLeft = topLeft; result.tableTopRight = topRight; result.tableBottomLeft = bottomLeft;
    result.coordinateView = view;
    result.maximumShotSpeed = PLMaximumShotSpeed(manager);
    NSString *physicsBlocker = PLFillPhysics(table, result);
    result.nativeGeometryUnavailableReason = PLFillNativeGeometry(table, bounds, result);
    result.goldenShot = goldenShot;
    result.goldenBallNumber = goldenShot ? 1 : -1;
    PLFillControls(manager, table, sourceBalls, result);
    PLFillOpponentPreview(manager, result);
    if (goldenShot) {
        // Read the target without treating a scoring ring as a pocket or making
        // a claim of full Lucky Shot obstacle/spin equivalence.
        result.canShoot = NO; result.autoShotAvailable = NO; result.legalTargetNumbers = @[];
        result.autoShotUnavailableReason = @"Lucky Shot: alvo disponível; disparo automático ainda não validado.";
        result.shootReadinessReason = result.autoShotUnavailableReason;
        if (PLCheckMethod(table, @"ballProperties", "@16@0:8", NULL)) {
            id properties = PLObject(table, @"ballProperties");
            Class expected = NSClassFromString(@"BallPropertiesGoldenShot");
            if (expected && [properties isKindOfClass:expected] &&
                PLCheckMethod(properties, @"isRacked", "B16@0:8", NULL) && PLBool(properties, @"isRacked") &&
                PLCheckMethod(properties, @"getTargetAreaPosition", "{CGPoint=dd}16@0:8", NULL)) {
                CGPoint target = PLPoint(properties, @"getTargetAreaPosition");
                if (PLFinitePoint(target) && target.x >= bounds[0] && target.x <= bounds[0]+bounds[2] &&
                    target.y >= bounds[1] && target.y <= bounds[1]+bounds[3]) {
                    result.goldenTargetAvailable = YES;
                    result.goldenTargetX = target.x; result.goldenTargetY = target.y;
                    result.goldenTargetRadius = PLGoldenTargetRadius(properties);
                }
            }
        }
    }
    NSMutableDictionary<NSString *, NSString *> *diagnostics = [@{
        @"source": @"native-memory-and-scene-graph",
        @"projection": @"world-plus-render-origin-before-projection",
        @"nativeFrame": [NSString stringWithFormat:@"%llu", (unsigned long long)nativeFrame],
        @"safeRenderOrigin": NSStringFromCGPoint(renderOrigin),
        @"logicalBounds": NSStringFromCGRect(logicalBounds),
        @"renderBounds": NSStringFromCGRect(view.bounds),
        @"renderFrame": NSStringFromCGRect(view.frame),
        @"visualScale": [NSString stringWithFormat:@"%.9g", scale],
        @"projectionResidual": [NSString stringWithFormat:@"%.6g", maximumResidual],
        @"aimAvailable": result.aimAvailable ? @"true" : @"false",
        @"nativeAimRadians": [NSString stringWithFormat:@"%.12g", result.aimAngle],
        @"nativePower": [NSString stringWithFormat:@"%.9g", result.cuePower],
        @"shotInputSupported": result.shotInputSupported ? @"true" : @"false",
        @"shotInputBlocker": result.shotInputUnavailableReason,
        @"selectedEnglish": [NSString stringWithFormat:@"%.9g,%.9g", result.cueEnglishX, result.cueEnglishY],
        @"opponentTurn": result.opponentTurn ? @"true" : @"false",
        @"opponentPreviewAvailable": result.opponentPreviewAvailable ? @"true" : @"false",
        @"opponentPreviewBlocker": result.opponentPreviewUnavailableReason,
        @"opponentMaximumShotSpeed": [NSString stringWithFormat:@"%.9g", result.opponentMaximumShotSpeed],
        @"opponentAimAge": [NSString stringWithFormat:@"%.3f", result.opponentAimAge],
        @"opponentAimEpoch": [NSString stringWithFormat:@"%llu", (unsigned long long)PLRemoteEpoch],
        @"opponentReceivedFields": [NSString stringWithFormat:@"%u", (unsigned)PLRemoteAcceptedFields],
        @"minimumShotPower": [NSString stringWithFormat:@"%.9g", result.minimumShotPower],
        @"maximumShotSpeed": [NSString stringWithFormat:@"%.9g", result.maximumShotSpeed],
        @"physicsCalibrated": result.physicsCalibrationAvailable ? @"true" : @"false",
        @"physicsBlocker": physicsBlocker,
        @"nativeGeometryAvailable": result.nativeGeometryAvailable ? @"true" : @"false",
        @"nativeGeometryBlocker": result.nativeGeometryUnavailableReason ?: @"",
        @"nativeGeometrySource": result.nativeGeometrySource ?: @"unavailable",
        @"nativeCushionVertexCount": [NSString stringWithFormat:@"%lu", (unsigned long)result.nativeCushionVertices.count],
        @"nativePocketAttractionRadius": [NSString stringWithFormat:@"%.9g", result.nativePocketRadius],
        @"nativePocketAttractionCoefficient": [NSString stringWithFormat:@"%.9g", result.nativePocketAttractionCoefficient],
        @"rollingDeceleration": [NSString stringWithFormat:@"%.9g", result.rollingDeceleration],
        @"slidingDeceleration": [NSString stringWithFormat:@"%.9g", result.slidingDeceleration],
        @"equilibriumTimeFactor": [NSString stringWithFormat:@"%.9g", result.equilibriumTimeFactor],
        @"spinDeceleration": [NSString stringWithFormat:@"%.9g", result.spinDeceleration],
        @"slidingFrictionCoefficient": [NSString stringWithFormat:@"%.9g", result.slidingFrictionCoefficient],
        @"cushionSpinCoupling": [NSString stringWithFormat:@"%.9g", result.cushionSpinCoupling],
        @"logicalFrameTime": [NSString stringWithFormat:@"%.9g", result.logicalFrameTime],
        @"ballRestitution": [NSString stringWithFormat:@"%.9g", result.ballRestitution],
        @"cushionRestitution": [NSString stringWithFormat:@"%.9g", result.cushionRestitution],
        @"autoShotAvailable": result.autoShotAvailable ? @"true" : @"false",
        @"capabilityBlocker": result.autoShotUnavailableReason ?: @"",
        @"canShoot": result.canShoot ? @"true" : @"false",
        @"isBreakShot": result.isBreakShot ? @"true" : @"false",
        @"readinessBlocker": result.shootReadinessReason ?: @""
    } mutableCopy];
    [diagnostics addEntriesFromDictionary:PLInputDiagnostics(manager)];
    diagnostics[@"captureMilliseconds"] = [NSString stringWithFormat:@"%.3f",
        (NSProcessInfo.processInfo.systemUptime-captureStarted)*1000];
    result.diagnostics = diagnostics;
    return result;
}

@implementation PLRuntimeBridge
+ (PLGameSnapshot *)captureWithError:(NSError **)error {
    if (error) *error = nil;
    @try { return PLCapture(error); }
    @catch (NSException *exception) {
        PLFail(error, 90, @"A estrutura da mesa não corresponde à versão esperada. Leitura pausada.");
        return nil;
    }
}

+ (BOOL)applyAngle:(double)angle power:(double)power error:(NSError **)error {
    if (error) *error = nil;
    if (!isfinite(angle) || !isfinite(power) || power < 0 || power > 1)
        return PLFail(error, 40, @"Use um ângulo válido e força entre 0 e 1.");
#if !defined(__arm64__)
    return PLFail(error, 1, @"O ajuste exige o executável arm64 do iPhone.");
#else
    @try {
        PLGameSnapshot *snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.playerTurn) return PLFail(error, 41, @"O ajuste fica disponível na sua vez.");
        BOOL hasCueBall = NO;
        for (PLBallSnapshot *ball in snapshot.balls) {
            if (ball.number == 0) hasCueBall = YES;
            if (hypot(ball.vx, ball.vy) > 0.001)
                return PLFail(error, 42, @"Aguarde todas as bolas pararem antes de ajustar a mira.");
        }
        if (!hasCueBall) return PLFail(error, 43, @"Reposicione a bola branca antes de ajustar a mira.");
        id manager = nil, director = nil;
        if (!PLEnvironment(&manager, &director, error)) return NO;
        id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", error);
        if (!cue || ![cue isKindOfClass:NSClassFromString(@"VisualCue")]) {
            if (!error || !*error) PLFail(error, 44, @"Controle do taco indisponível.");
            return NO;
        }
        if (!PLCheckMethod(cue, @"enabled", "B16@0:8", error) ||
            !PLCheckMethod(cue, @"setAimAngle:", "v24@0:8{MCNumber=d}16", error) ||
            !PLCheckMethod(cue, @"setPower:", "v24@0:8{MCNumber=d}16", error)) return NO;
        if (!PLBool(cue, @"enabled")) return PLFail(error, 45, @"O jogo ainda não liberou o taco.");
        // A stationary snapshot alone does not establish input ownership: a
        // popup, active touch, ball-in-hand or residual spin can still be live.
        // Re-read the native objects and use the same readiness contract as a
        // final shot before either setter is allowed to change the controls.
        id table = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
        if (!table) return NO;
        id sourceBalls = PLReadObject(table, @"Table", "mBalls", "@\"NSArray\"", error);
        if (![sourceBalls isKindOfClass:NSArray.class] ||
            [sourceBalls count] == 0 || [sourceBalls count] > 32)
            return PLFail(error, 21, @"A lista de bolas não está disponível para ajustar a mira.");
        if (!PLReadyToPlan(manager, cue, [sourceBalls copy], NO, error)) return NO;
        void *guide = NULL;
        double currentPower = 0;
        if (!PLRead(cue, @"VisualCue", "mVisualGuide", "^v", &guide, sizeof(guide), error) ||
            !PLRead(cue, @"VisualCue", "mPower", "{MCNumber=\"mValue\"d}",
                    &currentPower, sizeof(currentPower), error)) return NO;
        if (!guide || !isfinite(currentPower)) return PLFail(error, 46, @"A mira ainda não está pronta.");
        double normalizedAngle = fmod(angle, 2.0*M_PI);
        if (normalizedAngle < 0) normalizedAngle += 2.0*M_PI;
        /* ARM64 machine ABI, intentionally NOT a C double parameter:
         * setAimAngle: 0x1001d1500 and setPower: 0x1001d1548 load [x2].
         * The game's nontrivial MCNumber value is passed indirectly in x2.
         * Both return void. All method type encodings are checked above.
         * setPower clamps [0,1], proven by initializer 0x1001d502c..503c.
         * We call the original setters so each updates its visual state.
         */
        typedef void (*PLIndirectNumberSetter)(id, SEL, const double *);
        ((PLIndirectNumberSetter)objc_msgSend)(cue, NSSelectorFromString(@"setAimAngle:"), &normalizedAngle);
        ((PLIndirectNumberSetter)objc_msgSend)(cue, NSSelectorFromString(@"setPower:"), &power);
        id appliedCue = nil; double appliedAngle = 0, appliedPower = 0;
        if (!PLReadCue(manager, &appliedCue, &appliedAngle, &appliedPower, error)) return NO;
        if (appliedCue != cue || fabs(remainder(appliedAngle-normalizedAngle, 2.0*M_PI)) > 1e-7 ||
            fabs(appliedPower-power) > 1e-8)
            return PLFail(error, 47, @"O jogo não confirmou a direção e a força solicitadas.");
        // This method only updates controls. shootAngle: dispatches separately.
        return YES;
    } @catch (NSException *exception) {
        return PLFail(error, 91, @"O jogo recusou o ajuste dos controles.");
    }
#endif
}

+ (BOOL)applyPlannedAngle:(double)angle power:(double)power target:(NSInteger)target
                 pocket:(NSInteger)pocket error:(NSError **)error {
    if (error) *error = nil;
    if (!isfinite(angle) || !isfinite(power) || power <= 0 || power > 1 ||
        target < 1 || target > 15 || pocket < 0 || pocket > 5)
        return PLFail(error, 64, @"A mira precisa de uma bola, caçapa e força válidas.");
#if !defined(__arm64__)
    return PLFail(error, 1, @"O ajuste exige o executável arm64 do iPhone.");
#else
    @try {
        PLGameSnapshot *snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.canShoot || !snapshot.autoShotAvailable)
            return PLFail(error, 65, snapshot.autoShotAvailable ? snapshot.shootReadinessReason : snapshot.autoShotUnavailableReason);
        if (snapshot.minimumShotPower > 0 && power < snapshot.minimumShotPower)
            return PLFail(error, 72, @"Essa força está abaixo do mínimo permitido pelo taco.");
        if (![snapshot.legalTargetNumbers containsObject:@(target)])
            return PLFail(error, 66, @"Essa bola não pertence ao seu alvo permitido nesta vez.");
        id manager = nil, director = nil;
        if (!PLEnvironment(&manager, &director, error)) return NO;
        id table = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
        PLRulesInfo rules = {0};
        if (!table || !PLRules(manager, table, &rules, error)) return NO;
        static const uint32_t gamePocketForPlanner[6] = {5, 4, 3, 0, 1, 2};
        uint32_t gamePocket = gamePocketForPlanner[pocket];
        if (rules.nominationRequired && rules.nominatedPocket != (int32_t)gamePocket) {
            if (!PLCheckMethod(manager, @"pocketNominationCallback:", "v24@0:8@16", error)) return NO;
            // The normal callback may reset the cue, so nominate before setting
            // either value. No input flag or rule field is written directly.
            ((void (*)(id, SEL, id))objc_msgSend)(manager,
                NSSelectorFromString(@"pocketNominationCallback:"), @(gamePocket));
            PLRulesInfo afterNomination = {0};
            if (!PLRules(manager, table, &afterNomination, error) ||
                afterNomination.rules != rules.rules || afterNomination.nominatedPocket != (int32_t)gamePocket)
                return PLFail(error, 67, @"O jogo não confirmou a caçapa escolhida.");
        }
        snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.canShoot || !snapshot.autoShotAvailable || ![snapshot.legalTargetNumbers containsObject:@(target)])
            return PLFail(error, 68, @"A mesa mudou antes do ajuste da mira.");
        id freshManager = nil, freshDirector = nil;
        if (!PLEnvironment(&freshManager, &freshDirector, error) || freshManager != manager)
            return PLFail(error, 69, @"A partida mudou antes do ajuste da mira.");
        id freshTable = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
        if (freshTable != table) return PLFail(error, 69, @"A mesa mudou antes do ajuste da mira.");
        PLRulesInfo freshRules = {0};
        if (!PLRules(manager, table, &freshRules, error) || freshRules.rules != rules.rules ||
            freshRules.classification != rules.classification || freshRules.isBreakShot != rules.isBreakShot ||
            (freshRules.nominationRequired && freshRules.nominatedPocket != (int32_t)gamePocket))
            return PLFail(error, 70, @"As regras ou a caçapa mudaram antes do ajuste da mira.");
        if (![self applyAngle:angle power:power error:error]) return NO;
        if (!PLEnvironment(&freshManager, &freshDirector, error) || freshManager != manager ||
            PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error) != table)
            return PLFail(error, 69, @"A partida mudou durante o ajuste da mira.");
        id cue = nil; double verifiedAngle = 0, verifiedPower = 0;
        if (!PLReadCue(manager, &cue, &verifiedAngle, &verifiedPower, error)) return NO;
        id balls = PLReadObject(table, @"Table", "mBalls", "@\"NSArray\"", error);
        if (![balls isKindOfClass:NSArray.class] || !PLReadyToPlan(manager, cue, [balls copy], NO, error)) return NO;
        if (!PLRules(manager, table, &freshRules, error) || freshRules.rules != rules.rules ||
            freshRules.classification != rules.classification || freshRules.isBreakShot != rules.isBreakShot ||
            (freshRules.nominationRequired && freshRules.nominatedPocket != (int32_t)gamePocket))
            return PLFail(error, 70, @"As regras ou a caçapa mudaram durante o ajuste da mira.");
        if (fabs(remainder(verifiedAngle-angle, 2.0*M_PI)) > 1e-7 || fabs(verifiedPower-power) > 1e-8)
            return PLFail(error, 71, @"O jogo não confirmou a direção e a força da mira.");
        if (!PLCheckMethod(cue, @"hasMinimumPowerRatio", "B16@0:8", error)) return NO;
        if (!PLBool(cue, @"hasMinimumPowerRatio"))
            return PLFail(error, 72, @"Essa força está abaixo do mínimo permitido pelo taco.");
        double finalEnglish[2] = {0};
        if (!PLReadSelectedEnglish(manager, finalEnglish, error)) return NO;
        if (!PLCenteredEnglish(finalEnglish))
            return PLFail(error, 74, @"O efeito do taco mudou. Centralize o efeito para continuar.");
        // The caller retains this plan for manual play or a separately validated
        // shoot() call. Success here never means that a shot was dispatched.
        return YES;
    } @catch (NSException *exception) {
        return PLFail(error, 91, @"O jogo recusou o ajuste da mira planejada.");
    }
#endif
}

+ (BOOL)pl_shootAngle:(double)angle power:(double)power target:(NSInteger)target
               pocket:(NSInteger)pocket didDispatch:(BOOL *)didDispatch error:(NSError **)error {
    if (error) *error = nil;
    if (!isfinite(angle) || !isfinite(power) || power <= 0 || power > 1 ||
        target < 1 || target > 15 || pocket < 0 || pocket > 5)
        return PLFail(error, 64, @"A tacada precisa de uma bola, caçapa e força válidas.");
#if !defined(__arm64__)
    return PLFail(error, 1, @"O disparo exige o executável arm64 do iPhone.");
#else
    @try {
        PLGameSnapshot *snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.canShoot || !snapshot.autoShotAvailable)
            return PLFail(error, 65, snapshot.autoShotAvailable ? snapshot.shootReadinessReason : snapshot.autoShotUnavailableReason);
        if (snapshot.minimumShotPower > 0 && power < snapshot.minimumShotPower)
            return PLFail(error, 72, @"Essa força está abaixo do mínimo permitido pelo taco.");
        if (![snapshot.legalTargetNumbers containsObject:@(target)])
            return PLFail(error, 66, @"Essa bola não pertence ao seu alvo permitido nesta vez.");
        id manager = nil, director = nil;
        if (!PLEnvironment(&manager, &director, error)) return NO;
        id table = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
        PLRulesInfo rules = {0};
        if (!table || !PLRules(manager, table, &rules, error)) return NO;
        static const uint32_t gamePocketForPlanner[6] = {5, 4, 3, 0, 1, 2};
        uint32_t gamePocket = gamePocketForPlanner[pocket];
        if (rules.nominationRequired && rules.nominatedPocket != (int32_t)gamePocket) {
            if (!PLCheckMethod(manager, @"pocketNominationCallback:", "v24@0:8@16", error)) return NO;
            // The normal button callback also enqueues the ordinary aim event.
            // It may reset angle and power, so always nominate BEFORE setting them.
            ((void (*)(id, SEL, id))objc_msgSend)(manager,
                NSSelectorFromString(@"pocketNominationCallback:"), @(gamePocket));
            PLRulesInfo afterNomination = {0};
            if (!PLRules(manager, table, &afterNomination, error) ||
                afterNomination.rules != rules.rules || afterNomination.nominatedPocket != (int32_t)gamePocket)
                return PLFail(error, 67, @"O jogo não confirmou a caçapa escolhida.");
        }
        snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.canShoot || !snapshot.autoShotAvailable || ![snapshot.legalTargetNumbers containsObject:@(target)])
            return PLFail(error, 68, @"A mesa mudou antes da tacada. O automático foi pausado.");
        if (![self applyAngle:angle power:power error:error]) return NO;
        id freshManager = nil, freshDirector = nil;
        if (!PLEnvironment(&freshManager, &freshDirector, error) || freshManager != manager)
            return PLFail(error, 69, @"A partida mudou antes do disparo.");
        id freshTable = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
        if (freshTable != table) return PLFail(error, 69, @"A mesa mudou antes do disparo.");
        id cue = nil; double verifiedAngle = 0, verifiedPower = 0;
        if (!PLReadCue(manager, &cue, &verifiedAngle, &verifiedPower, error)) return NO;
        id balls = PLReadObject(table, @"Table", "mBalls", "@\"NSArray\"", error);
        if (![balls isKindOfClass:NSArray.class] || !PLReadyToPlan(manager, cue, [balls copy], NO, error)) return NO;
        PLRulesInfo freshRules = {0};
        if (!PLRules(manager, table, &freshRules, error) || freshRules.rules != rules.rules ||
            freshRules.classification != rules.classification ||
            freshRules.isBreakShot != rules.isBreakShot ||
            (freshRules.nominationRequired && freshRules.nominatedPocket != (int32_t)gamePocket))
            return PLFail(error, 70, @"As regras ou a caçapa mudaram antes da tacada.");
        if (fabs(remainder(verifiedAngle-angle, 2.0*M_PI)) > 1e-7 || fabs(verifiedPower-power) > 1e-8)
            return PLFail(error, 71, @"O jogo não confirmou a direção e a força da tacada.");
        if (!PLCheckMethod(cue, @"hasMinimumPowerRatio", "B16@0:8", error)) return NO;
        if (!PLBool(cue, @"hasMinimumPowerRatio"))
            return PLFail(error, 72, @"Essa força está abaixo do mínimo permitido pelo taco.");
        double finalEnglish[2] = {0};
        if (!PLReadSelectedEnglish(manager, finalEnglish, error)) return NO;
        if (!PLCenteredEnglish(finalEnglish))
            return PLFail(error, 74, @"O efeito do taco mudou antes da tacada. Centralize o efeito para continuar.");
        void *cacher = NULL; uintptr_t owner = 0;
        if (!PLRead(manager, @"GameManager", "_cacher", "^{GameManagerCacher=@}", &cacher, sizeof(cacher), error) ||
            !cacher || !PLCopyMemory((uintptr_t)cacher, &owner, sizeof(owner)) || owner != (uintptr_t)(__bridge void *)manager)
            return PLFail(error, 61, @"O controle de tacadas não está mais disponível.");
        void *release = PLShotReleaseFunction();
        if (!release) return PLFail(error, 60, @"O disparo não corresponde ao build verificado.");
        *didDispatch = YES;
        ((void (*)(void *))release)(cacher);
        // The native callback advances state 4 to 5 and disables the cue.
        // Failure here is not retried by this method, since a charge may be consumed.
        if (PLBool(manager, @"isWaitingForPlayerShot") && PLBool(cue, @"enabled"))
            return PLFail(error, 73, @"O jogo não confirmou o início da tacada. Automático pausado.");
        return YES;
    } @catch (NSException *exception) {
        return PLFail(error, 92, @"O jogo recusou a tacada automática.");
    }
#endif
}

+ (BOOL)shootAngle:(double)angle power:(double)power target:(NSInteger)target
            pocket:(NSInteger)pocket error:(NSError **)error {
    if (error) *error = nil;
    NSError *nativeError = nil;
    BOOL didDispatch = NO;
    BOOL success = [self pl_shootAngle:angle power:power target:target pocket:pocket
                           didDispatch:&didDispatch error:&nativeError];
    if (!success && error) {
        NSMutableDictionary *details = nativeError.userInfo.mutableCopy ?: [NSMutableDictionary dictionary];
        if (!details[NSLocalizedDescriptionKey]) details[NSLocalizedDescriptionKey] = @"O jogo recusou a tacada automática.";
        // False proves that the native release callback was never entered.
        // True is conservative: the callback may have consumed the shot even
        // when a later exception or state-confirmation check reported failure.
        details[@"shotDispatched"] = @(didDispatch);
        *error = [NSError errorWithDomain:nativeError.domain ?: PLErrorDomain
                                    code:nativeError ? nativeError.code : 92 userInfo:details];
    }
    return success;
}
@end
