#import <UIKit/UIKit.h>
#import <PoolLabIntegration/PoolLabIntegration-Swift.h>

/// Register after dyld has finished invoking constructors. Starting repeatedly
/// is safe: the Swift bootstrap retains exactly one scene-aware coordinator.
__attribute__((constructor))
static void PLInstallIntegrationBootstrap(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        [center addObserverForName:UIApplicationDidFinishLaunchingNotification
                            object:nil queue:NSOperationQueue.mainQueue
                        usingBlock:^(__unused NSNotification *notification) {
            [PLIntegrationBootstrap start];
        }];
        [center addObserverForName:UIApplicationDidBecomeActiveNotification
                            object:nil queue:NSOperationQueue.mainQueue
                        usingBlock:^(__unused NSNotification *notification) {
            [PLIntegrationBootstrap start];
        }];
        [PLIntegrationBootstrap start];
    });
}
