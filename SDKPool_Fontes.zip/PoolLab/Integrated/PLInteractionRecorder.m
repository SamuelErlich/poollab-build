#import "PLInteractionRecorder.h"
#import "PLQueueBridge.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <math.h>
#import <string.h>

static const NSTimeInterval PLIRMaximumDuration = 180.0;
static const NSUInteger PLIRMaximumEvents = 300;
static const NSTimeInterval PLIRMoveInterval = 0.1;

// Main-thread-only state. UITouch/UIEvent instances are never retained by the log.
static BOOL PLIRRecording;
static NSUInteger PLIRGeneration;
static NSUInteger PLIRNextTouchID;
static NSTimeInterval PLIRStartedAt;
static NSTimeInterval PLIRStoppedAt;
static NSString *PLIRStopReason;
static NSMutableArray<NSMutableDictionary<NSString *, id> *> *PLIREvents;
static NSMutableDictionary<NSString *, NSNumber *> *PLIRIgnored;
static NSMapTable<UITouch *, NSNumber *> *PLIRTouchIDs;
static NSMutableDictionary<NSNumber *, NSNumber *> *PLIRLastMove;
static IMP PLIRPreviousSendEvent;
static Class PLIRApplicationClass;
static id PLIRInactiveObserver;

@interface PLInteractionRingWindow : UIWindow
@end
@implementation PLInteractionRingWindow
- (BOOL)canBecomeKeyWindow { return NO; }
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
@end

@interface PLInteractionRingController : UIViewController
@end
@implementation PLInteractionRingController
- (BOOL)shouldAutorotate { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskAll; }
@end

static PLInteractionRingWindow *PLIRRingWindow;
static CAShapeLayer *PLIRRingLayer;
static NSUInteger PLIRRingGeneration;

static double PLIRFinite(double value) { return isfinite(value) ? value : 0.0; }
static NSString *PLIRClassName(id object) {
    if (!object) return @"none";
    NSString *name = NSStringFromClass(object_getClass(object));
    return [name substringToIndex:MIN(name.length, (NSUInteger)160)];
}
static NSDictionary *PLIRPoint(CGPoint point) {
    return @{@"x": @(PLIRFinite(point.x)), @"y": @(PLIRFinite(point.y))};
}
static NSDictionary *PLIRRect(CGRect rect) {
    return @{@"x": @(PLIRFinite(rect.origin.x)), @"y": @(PLIRFinite(rect.origin.y)),
             @"width": @(PLIRFinite(rect.size.width)), @"height": @(PLIRFinite(rect.size.height))};
}
static void PLIRCountIgnored(NSString *category) {
    NSUInteger count = [PLIRIgnored[category] unsignedIntegerValue];
    PLIRIgnored[category] = @(MIN(count + 1, (NSUInteger)1000000));
}

// Extra defense around the explicitly sanitized native diagnostic contract.
// Unknown objects are omitted; their description can contain arbitrary values.
static id PLIRBoundedJSON(id value, NSUInteger depth) {
    if (depth > 9 || !value || value == NSNull.null) return NSNull.null;
    if ([value isKindOfClass:NSString.class]) {
        NSString *text = value;
        return [text substringToIndex:MIN(text.length, (NSUInteger)256)];
    }
    if ([value isKindOfClass:NSNumber.class]) return isfinite([value doubleValue]) ? value : NSNull.null;
    if ([value isKindOfClass:NSArray.class]) {
        NSMutableArray *result = [NSMutableArray array];
        for (id element in value) {
            if (result.count >= 48) break;
            [result addObject:PLIRBoundedJSON(element, depth + 1)];
        }
        return result;
    }
    if ([value isKindOfClass:NSDictionary.class]) {
        NSMutableDictionary *result = [NSMutableDictionary dictionary];
        for (id key in value) {
            if (result.count >= 64) break;
            if (![key isKindOfClass:NSString.class] || [key length] > 96) continue;
            NSString *lower = [key lowercaseString];
            BOOL excluded = NO;
            for (NSString *part in @[@"password", @"clipboard", @"license", @"credential", @"token", @"matchid", @"typedtext"])
                if ([lower containsString:part]) { excluded = YES; break; }
            if (!excluded) result[key] = PLIRBoundedJSON(value[key], depth + 1);
        }
        return result;
    }
    return NSNull.null;
}
static NSDictionary *PLIRSnapshot(void) {
    @try {
        id state = PLIRBoundedJSON([PLQueueBridge diagnosticSnapshot], 0);
        return [state isKindOfClass:NSDictionary.class] ? state : @{@"unavailable": @YES};
    } @catch (__unused NSException *exception) {
        // Exception text is deliberately excluded from exports.
        return @{@"unavailable": @YES, @"reason": @"nativeSnapshotException"};
    }
}

static BOOL PLIRClassChainContains(id object, NSArray<NSString *> *names) {
    for (Class cls = object_getClass(object); cls; cls = class_getSuperclass(cls)) {
        NSString *name = NSStringFromClass(cls);
        for (NSString *expected in names) {
            if ([name isEqual:expected] || [name hasSuffix:[@"." stringByAppendingString:expected]]) return YES;
        }
    }
    return NO;
}
static BOOL PLIRKeyboardClassChain(id object) {
    for (Class cls = object_getClass(object); cls; cls = class_getSuperclass(cls)) {
        NSString *name = NSStringFromClass(cls);
        if ([name containsString:@"Keyboard"] || [name containsString:@"InputSet"] ||
            [name containsString:@"TextEffects"]) return YES;
    }
    return NO;
}
static BOOL PLIREditableOrSecureView(UIView *view) {
    if ([view isKindOfClass:UITextField.class] || [view isKindOfClass:UITextView.class]) return YES;
    if ([view conformsToProtocol:@protocol(UITextInputTraits)] &&
        [view respondsToSelector:@selector(isSecureTextEntry)] && [(id<UITextInputTraits>)view isSecureTextEntry]) return YES;
    // WKContentView can implement UITextInput for noneditable ad content too.
    // Conformance alone is not proof of text entry. Only a typed BOOL getter
    // explicitly reporting editing excludes such generic input views.
    if (![view conformsToProtocol:@protocol(UITextInput)]) return NO;
    SEL selector = NSSelectorFromString(@"isEditable");
    Method method = class_getInstanceMethod(object_getClass(view), selector);
    char type[8] = {0};
    if (!method || method_getNumberOfArguments(method) != 2) return NO;
    method_getReturnType(method, type, sizeof(type));
    if (strcmp(type, "B") && strcmp(type, "c")) return NO;
    return ((BOOL (*)(id, SEL))objc_msgSend)(view, selector);
}
static NSString *PLIRExcludedTouch(UITouch *touch) {
    UIWindow *window = touch.window;
    if (!window || window.hidden || window.alpha < 0.01) return @"hiddenOrMissingWindow";
    if (PLIRClassChainContains(window, @[@"PLPassthroughWindow", @"PLInteractionRingWindow"])) return @"sdkpoolWindow";
    if (PLIRKeyboardClassChain(window) || PLIRClassChainContains(window, @[@"UIInputWindow"]))
        return @"keyboardWindow";
    if (@available(iOS 13.0, *)) {
        if (window.windowScene && window.windowScene.activationState != UISceneActivationStateForegroundActive)
            return @"inactiveScene";
    }
    UIView *view = touch.view;
    for (NSUInteger depth = 0; view && depth < 32; depth++, view = view.superview) {
        if (PLIREditableOrSecureView(view) || PLIRKeyboardClassChain(view))
            return @"textInput";
    }
    return nil;
}

static void PLIRHideRing(void) {
    PLIRRingGeneration++;
    PLIRRingWindow.hidden = YES;
    [PLIRRingLayer removeAllAnimations];
}
static void PLIRShowRing(UIWindow *source, CGPoint point) {
    // One reused non-key window. It never calls makeKeyAndVisible or hitTest on
    // the game, and its own touches are excluded even if UIKit changes routing.
    if (!source) return;
    if (!PLIRRingWindow || PLIRRingWindow.windowScene != source.windowScene) {
        PLIRHideRing();
        PLIRRingWindow = source.windowScene
            ? [[PLInteractionRingWindow alloc] initWithWindowScene:source.windowScene]
            : [[PLInteractionRingWindow alloc] initWithFrame:source.frame];
        PLIRRingWindow.userInteractionEnabled = NO;
        PLIRRingWindow.backgroundColor = UIColor.clearColor;
        PLIRRingWindow.accessibilityElementsHidden = YES;
        PLInteractionRingController *controller = [PLInteractionRingController new];
        controller.view.backgroundColor = UIColor.clearColor;
        controller.view.userInteractionEnabled = NO;
        PLIRRingWindow.rootViewController = controller;
        PLIRRingLayer = [CAShapeLayer layer];
        PLIRRingLayer.fillColor = [UIColor colorWithRed:1 green:0.3 blue:0 alpha:0.12].CGColor;
        PLIRRingLayer.strokeColor = [UIColor colorWithRed:1 green:0.45 blue:0.08 alpha:0.92].CGColor;
        PLIRRingLayer.lineWidth = 2.5;
        [controller.view.layer addSublayer:PLIRRingLayer];
    }
    PLIRRingWindow.frame = source.frame;
    PLIRRingWindow.windowLevel = source.windowLevel + 1;
    PLIRRingWindow.rootViewController.view.frame = PLIRRingWindow.bounds;
    CGPoint center = [PLIRRingWindow convertPoint:point fromWindow:source];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    PLIRRingLayer.path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(center.x - 14, center.y - 14, 28, 28)].CGPath;
    [CATransaction commit];
    PLIRRingWindow.hidden = NO;
    NSUInteger generation = ++PLIRRingGeneration;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (generation == PLIRRingGeneration) PLIRHideRing();
    });
}

static void PLIRStop(NSString *reason) {
    if (!PLIRRecording) return;
    PLIRRecording = NO;
    PLIRStoppedAt = NSProcessInfo.processInfo.systemUptime;
    PLIRStopReason = reason;
    PLIRGeneration++; // Invalidate delayed samples from the previous session.
    [PLIRTouchIDs removeAllObjects];
    [PLIRLastMove removeAllObjects];
    PLIRHideRing();
}
static NSString *PLIRPhase(UITouchPhase phase) {
    switch (phase) {
        case UITouchPhaseBegan: return @"began";
        case UITouchPhaseMoved: return @"moved";
        case UITouchPhaseEnded: return @"ended";
        case UITouchPhaseCancelled: return @"cancelled";
        default: return @"stationary";
    }
}

static NSArray<NSMutableDictionary<NSString *, id> *> *PLIRBeforeEvent(UIEvent *event) {
    if (!PLIRRecording || event.type != UIEventTypeTouches) return @[];
    NSTimeInterval now = NSProcessInfo.processInfo.systemUptime;
    if (now - PLIRStartedAt >= PLIRMaximumDuration) { PLIRStop(@"durationLimit"); return @[]; }
    NSMutableArray *accepted = [NSMutableArray array];
    NSDictionary *nativeBefore = nil;
    for (UITouch *touch in event.allTouches) {
        UITouchPhase phase = touch.phase;
        if (phase != UITouchPhaseBegan && phase != UITouchPhaseMoved && phase != UITouchPhaseEnded && phase != UITouchPhaseCancelled) continue;
        NSString *excluded = PLIRExcludedTouch(touch);
        if (excluded) { PLIRCountIgnored(excluded); continue; }
        NSNumber *touchID = [PLIRTouchIDs objectForKey:touch];
        // A session can start while a finger is already down. Its next sample
        // gets an ID but is explicitly marked as missing the original begin.
        BOOL missingBegin = !touchID && phase != UITouchPhaseBegan;
        if (!touchID) {
            touchID = @(++PLIRNextTouchID);
            [PLIRTouchIDs setObject:touchID forKey:touch];
        }
        if (phase == UITouchPhaseMoved) {
            NSTimeInterval last = [PLIRLastMove[touchID] doubleValue];
            if (last > 0 && now - last < PLIRMoveInterval) { PLIRCountIgnored(@"moveThrottled"); continue; }
            PLIRLastMove[touchID] = @(now);
        }
        if (PLIREvents.count >= PLIRMaximumEvents) { PLIRCountIgnored(@"eventLimit"); continue; }
        UIWindow *window = touch.window;
        CGPoint point = [touch locationInView:window];
        CGRect bounds = window.bounds;
        UIInterfaceOrientation orientation = window.windowScene ? window.windowScene.interfaceOrientation : UIInterfaceOrientationUnknown;
        if (!nativeBefore) nativeBefore = PLIRSnapshot();
        NSMutableDictionary *entry = [@{
            @"sequence": @(PLIREvents.count + 1), @"touchID": touchID,
            @"phase": PLIRPhase(phase), @"missingBegin": @(missingBegin),
            @"uptime": @(now), @"elapsedMs": @((now - PLIRStartedAt) * 1000),
            @"touchElapsedMs": @(PLIRFinite((touch.timestamp - PLIRStartedAt) * 1000)),
            @"point": PLIRPoint(point), @"windowBounds": PLIRRect(bounds),
            @"normalized": PLIRPoint(CGPointMake(bounds.size.width > 0 ? (point.x - bounds.origin.x) / bounds.size.width : 0,
                                                 bounds.size.height > 0 ? (point.y - bounds.origin.y) / bounds.size.height : 0)),
            @"safeAreaInsets": @{@"top": @(window.safeAreaInsets.top), @"left": @(window.safeAreaInsets.left),
                                  @"bottom": @(window.safeAreaInsets.bottom), @"right": @(window.safeAreaInsets.right)},
            @"windowClass": PLIRClassName(window), @"viewClass": PLIRClassName(touch.view),
            @"windowLevel": @(PLIRFinite(window.windowLevel)), @"screenScale": @(PLIRFinite(window.screen.scale)),
            @"orientation": @(orientation), @"coordinateSpace": @"UIKitWindowPoints",
            @"before": nativeBefore, @"after": [NSMutableArray array]
        } mutableCopy];
        [PLIREvents addObject:entry];
        [accepted addObject:entry];
        if (phase == UITouchPhaseBegan || phase == UITouchPhaseEnded) PLIRShowRing(window, point);
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            [PLIRTouchIDs removeObjectForKey:touch];
            [PLIRLastMove removeObjectForKey:touchID];
        }
    }
    return accepted;
}

static void PLIRAppendAfter(NSArray<NSMutableDictionary<NSString *, id> *> *entries, NSString *stage) {
    if (!entries.count) return;
    NSDictionary *sample = @{@"stage": stage, @"elapsedMs": @((NSProcessInfo.processInfo.systemUptime - PLIRStartedAt) * 1000),
                             @"state": PLIRSnapshot()};
    for (NSMutableDictionary *entry in entries) {
        NSMutableArray *after = entry[@"after"];
        if (after.count < 4) [after addObject:sample];
    }
}
static void PLIRAfterEvent(NSArray<NSMutableDictionary<NSString *, id> *> *entries, NSUInteger generation) {
    if (!PLIRRecording || generation != PLIRGeneration || !entries.count) return;
    PLIRAppendAfter(entries, @"dispatchReturned");
    // Moved samples already have a fresh before/after. Only boundaries schedule
    // delayed state checks, keeping long drags from creating hundreds of jobs.
    NSMutableArray *boundaries = [NSMutableArray array];
    for (NSMutableDictionary *entry in entries)
        if (![entry[@"phase"] isEqual:@"moved"]) [boundaries addObject:entry];
    for (NSNumber *delay in @[@0.0, @0.3, @0.9]) {
        if (!boundaries.count) break;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay.doubleValue * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!PLIRRecording || generation != PLIRGeneration) return;
            @try { PLIRAppendAfter(boundaries, [NSString stringWithFormat:@"after%.0fms", delay.doubleValue * 1000]); }
            @catch (__unused NSException *exception) { PLIRCountIgnored(@"snapshotException"); }
        });
    }
    if (PLIREvents.count >= PLIRMaximumEvents) PLIRStop(@"eventLimit");
}

static void PLIRSendEvent(UIApplication *application, SEL selector, UIEvent *event) {
    NSArray *entries = nil;
    NSUInteger generation = PLIRGeneration;
    if (NSThread.isMainThread && PLIRRecording) {
        @try { entries = PLIRBeforeEvent(event); }
        @catch (__unused NSException *exception) { PLIRCountIgnored(@"observationException"); }
    }
    // Exactly one call to the implementation present when installed. The game
    // receives its original object and selector; its exceptions are not swallowed.
    ((void (*)(id, SEL, UIEvent *))PLIRPreviousSendEvent)(application, selector, event);
    if (NSThread.isMainThread && entries.count) {
        @try { PLIRAfterEvent(entries, generation); }
        @catch (__unused NSException *exception) { PLIRCountIgnored(@"observationException"); }
    }
}

static BOOL PLIRFail(NSError **error, NSInteger code, NSString *message) {
    if (error) *error = [NSError errorWithDomain:@"SDKPool.InteractionRecorder" code:code
                                      userInfo:@{NSLocalizedDescriptionKey: message}];
    return NO;
}
static BOOL PLIRInstall(NSError **error) {
    Class cls = object_getClass(UIApplication.sharedApplication);
    SEL selector = @selector(sendEvent:);
    if (PLIRPreviousSendEvent) {
        return (cls == PLIRApplicationClass && class_getMethodImplementation(cls, selector) == (IMP)PLIRSendEvent) ||
            PLIRFail(error, 3, @"Outro controle de eventos mudou. Reinicie o jogo para gravar os botões.");
    }
    Method method = class_getInstanceMethod(cls, selector);
    const char *encoding = method ? method_getTypeEncoding(method) : NULL;
    if (!encoding || strcmp(encoding, "v24@0:8@16"))
        return PLIRFail(error, 2, @"A entrega de toques deste aplicativo não é compatível com o gravador.");
    IMP previous = method_getImplementation(method);
    if (!previous || previous == (IMP)PLIRSendEvent)
        return PLIRFail(error, 2, @"Não foi possível observar os toques do aplicativo.");
    PLIRPreviousSendEvent = previous;
    PLIRApplicationClass = cls;
    // Adding a local method when inherited avoids mutating UIApplication or
    // siblings. If already local, replace only this actual application class.
    if (!class_addMethod(cls, selector, (IMP)PLIRSendEvent, encoding))
        PLIRPreviousSendEvent = method_setImplementation(class_getInstanceMethod(cls, selector), (IMP)PLIRSendEvent);
    PLIRInactiveObserver = [NSNotificationCenter.defaultCenter addObserverForName:UIApplicationWillResignActiveNotification
        object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *notification) {
            PLIRStop(@"applicationInactive");
        }];
    return YES;
}

@implementation PLInteractionRecorder
+ (BOOL)startWithError:(NSError **)error {
    if (!NSThread.isMainThread || UIApplication.sharedApplication.applicationState != UIApplicationStateActive)
        return PLIRFail(error, 1, @"Abra o jogo para iniciar a gravação dos botões.");
    if (PLIRRecording) return YES;
    if (!PLIRInstall(error)) return NO;
    PLIREvents = [NSMutableArray array];
    PLIRIgnored = [NSMutableDictionary dictionary];
    PLIRTouchIDs = [NSMapTable weakToStrongObjectsMapTable];
    PLIRLastMove = [NSMutableDictionary dictionary];
    PLIRNextTouchID = 0;
    PLIRStartedAt = NSProcessInfo.processInfo.systemUptime;
    PLIRStoppedAt = 0;
    PLIRStopReason = @"recording";
    PLIRRecording = YES;
    NSUInteger generation = ++PLIRGeneration;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(PLIRMaximumDuration * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (PLIRRecording && generation == PLIRGeneration) PLIRStop(@"durationLimit");
    });
    return YES;
}
+ (void)stop {
    if (!NSThread.isMainThread) return;
    PLIRStop(@"userStopped");
}
+ (BOOL)isRecording { return NSThread.isMainThread && PLIRRecording; }
+ (NSDictionary<NSString *, id> *)status {
    if (!NSThread.isMainThread) return @{@"recording": @NO, @"eventCount": @0, @"stopReason": @"mainThreadRequired"};
    NSTimeInterval end = PLIRRecording ? NSProcessInfo.processInfo.systemUptime : PLIRStoppedAt;
    return @{@"recording": @(PLIRRecording), @"eventCount": @(PLIREvents.count),
             @"stopReason": PLIRStopReason ?: @"notStarted",
             @"durationSeconds": @(PLIRStartedAt > 0 ? MAX(0, end - PLIRStartedAt) : 0)};
}
+ (NSDictionary<NSString *, id> *)report {
    if (!NSThread.isMainThread) return @{@"format": @"SDKPool.Interactions", @"error": @"mainThreadRequired"};
    NSTimeInterval end = PLIRRecording ? NSProcessInfo.processInfo.systemUptime : PLIRStoppedAt;
    NSDictionary *report = @{
        @"format": @"SDKPool.Interactions", @"version": @1,
        @"recording": @(PLIRRecording), @"stopReason": PLIRStopReason ?: @"notStarted",
        @"startedAtUptime": @(PLIRStartedAt), @"durationSeconds": @(PLIRStartedAt > 0 ? MAX(0, end - PLIRStartedAt) : 0),
        @"clock": @"monotonicSystemUptime", @"eventCount": @(PLIREvents.count),
        @"limits": @{@"durationSeconds": @(PLIRMaximumDuration), @"events": @(PLIRMaximumEvents), @"movedIntervalMs": @100},
        @"ignoredSamples": PLIRIgnored ?: @{}, @"events": PLIREvents ?: @[],
        @"privacy": @"No text, key presses, clipboard, credentials, screenshots, input replay or network upload. Editable/secure fields and keyboard windows are excluded.",
        @"finalState": PLIRSnapshot()
    };
    // Deep immutable copy, so delayed observations cannot mutate an export.
    NSData *data = [NSJSONSerialization dataWithJSONObject:report options:0 error:nil];
    return data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] :
        @{@"format": @"SDKPool.Interactions", @"error": @"serializationFailed"};
}
@end
