#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Opt-in, local interaction diagnostics. All calls must run on the main thread.
/// Observes delivery without consuming, synthesizing or replaying any input.
/// It records geometry and native state, never text, screenshots or credentials.
@interface PLInteractionRecorder : NSObject
+ (BOOL)startWithError:(NSError * _Nullable * _Nullable)error NS_SWIFT_NAME(start());
+ (void)stop;
+ (BOOL)isRecording;
/// Constant-size UI state. Does not copy the log or read the native game.
+ (NSDictionary<NSString *, id> *)status;
/// JSON-compatible, bounded report. May be exported with zero table frames.
+ (NSDictionary<NSString *, id> *)report;
@end

NS_ASSUME_NONNULL_END
