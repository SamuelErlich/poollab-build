#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Optional suppression of future, non-rewarded interstitial ad breaks.
/// Rewarded ads and an ad break that already started keep their normal flow.
@interface PLAdControl : NSObject
/// Swift: try PLAdControl.setBlocking(enabled: true)
/// Call on the main thread after authorization; disable on logout/inactivity.
+ (BOOL)setBlockingEnabled:(BOOL)enabled
                     error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(setBlocking(enabled:));
@end

NS_ASSUME_NONNULL_END
