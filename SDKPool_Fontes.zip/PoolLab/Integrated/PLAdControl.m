#import "PLAdControl.h"
#import <objc/runtime.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <dlfcn.h>
#import <stdatomic.h>
#import <stdbool.h>
#import <string.h>
#import <stdlib.h>

// Static contract: Validation/AdControlEvidence.json. This gate precedes
// presentation and lets the game take its existing "no interstitial" branch.
// Do not replace SDK callbacks, rewarded-ad methods, tokens or purchase status.
static NSString *const PLAdErrorDomain = @"PoolLab.AdControl";
static atomic_bool PLAdBlocking = false;
static _Atomic(IMP) PLAdOriginalIMP = NULL;
static Class PLAdManagerClass = Nil;
static Method PLAdGateMethod = NULL;
static BOOL PLAdInstallConflict = NO;

static BOOL PLAdFail(NSError **error, NSInteger code, NSString *message) {
    if (error) *error = [NSError errorWithDomain:PLAdErrorDomain code:code
                                      userInfo:@{NSLocalizedDescriptionKey: message}];
    return NO;
}

static BOOL PLAdReadiness(id receiver, SEL selector) {
    IMP original = atomic_load_explicit(&PLAdOriginalIMP, memory_order_acquire);
    if (atomic_load_explicit(&PLAdBlocking, memory_order_acquire) &&
        object_getClass(receiver) == PLAdManagerClass) return NO;
    return original ? ((BOOL (*)(id, SEL))original)(receiver, selector) : NO;
}

static BOOL PLAdExpectedHost(NSError **error) {
#if !defined(__arm64__)
    return PLAdFail(error, 2, @"Esta opção exige a versão arm64 do iPhone.");
#else
    NSBundle *bundle = NSBundle.mainBundle;
    if (![bundle.bundleIdentifier isEqualToString:@"com.miniclip.8ballpoolmult"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"] isEqual:@"56.31.0"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleVersion"] isEqual:@"5330"])
        return PLAdFail(error, 3, @"O bloqueio foi preparado para 8 Ball Pool 56.31.0, build 5330.");
    const struct mach_header *header = _dyld_get_image_header(0);
    if (!header || header->magic != MH_MAGIC_64 || header->cputype != CPU_TYPE_ARM64 ||
        header->ncmds > 4096 || header->sizeofcmds > 1024 * 1024)
        return PLAdFail(error, 4, @"O executável não corresponde à versão verificada.");
    const uint8_t expectedUUID[16] = {
        0xc2, 0x35, 0xdc, 0xcd, 0x99, 0x7e, 0x3d, 0x31,
        0xa9, 0x8f, 0xea, 0xa8, 0xbd, 0xdd, 0x2b, 0xfb
    };
    const uint8_t *cursor = (const uint8_t *)header + sizeof(struct mach_header_64);
    size_t remaining = header->sizeofcmds;
    for (uint32_t i = 0; i < header->ncmds; ++i) {
        if (remaining < sizeof(struct load_command)) break;
        const struct load_command *command = (const struct load_command *)cursor;
        if (command->cmdsize < sizeof(*command) || command->cmdsize > remaining) break;
        if (command->cmd == LC_UUID && command->cmdsize >= sizeof(struct uuid_command)) {
            const struct uuid_command *uuid = (const struct uuid_command *)command;
            if (memcmp(uuid->uuid, expectedUUID, sizeof(expectedUUID)) == 0) return YES;
            break;
        }
        remaining -= command->cmdsize;
        cursor += command->cmdsize;
    }
    return PLAdFail(error, 4, @"O executável não corresponde à versão verificada.");
#endif
}

static BOOL PLAdInstall(NSError **error) {
    if (PLAdInstallConflict)
        return PLAdFail(error, 7, @"A apresentação de anúncios mudou durante a ativação. Reinicie o app.");
    if (PLAdGateMethod) {
        if (method_getImplementation(PLAdGateMethod) == (IMP)PLAdReadiness) return YES;
        atomic_store_explicit(&PLAdBlocking, false, memory_order_release);
        return PLAdFail(error, 7, @"Outro componente alterou a apresentação de anúncios. Opção pausada.");
    }
    Class managerClass = NSClassFromString(@"AdsManager");
    if (!managerClass)
        return PLAdFail(error, 5, @"O controle de anúncios desta versão não foi encontrado.");
    SEL selector = NSSelectorFromString(@"isReadyToShowInterstitial");
    // Require the method to be declared by AdsManager, never an inherited or
    // unrelated global method. Resolving it does not initialize the singleton.
    unsigned int count = 0;
    Method *methods = class_copyMethodList(managerClass, &count);
    Method gate = NULL;
    for (unsigned int i = 0; i < count; ++i) {
        if (sel_isEqual(method_getName(methods[i]), selector)) { gate = methods[i]; break; }
    }
    free(methods);
    const char *encoding = gate ? method_getTypeEncoding(gate) : NULL;
    if (!encoding || strcmp(encoding, "B16@0:8") != 0)
        return PLAdFail(error, 6, @"A apresentação de anúncios tem uma estrutura diferente.");
    IMP original = method_getImplementation(gate);
    Dl_info origin = {0};
    if (!original || !dladdr((const void *)original, &origin) ||
        origin.dli_fbase != (const void *)_dyld_get_image_header(0))
        return PLAdFail(error, 7, @"A apresentação de anúncios já foi alterada por outro componente.");
    PLAdManagerClass = managerClass;
    // Publish the original before installing the interceptor. Calls from any
    // thread keep a valid fallback even while the main thread changes the flag.
    atomic_store_explicit(&PLAdOriginalIMP, original, memory_order_release);
    IMP previous = method_setImplementation(gate, (IMP)PLAdReadiness);
    atomic_store_explicit(&PLAdOriginalIMP, previous, memory_order_release);
    PLAdGateMethod = gate;
    if (previous != original) {
        // Preserve a concurrent replacement as the pass-through target instead
        // of overwriting it again or suppressing an unverified call path.
        PLAdInstallConflict = YES;
        return PLAdFail(error, 7, @"Outro componente alterou os anúncios durante a ativação.");
    }
    return YES;
}

@implementation PLAdControl
+ (BOOL)setBlockingEnabled:(BOOL)enabled error:(NSError **)error {
    if (error) *error = nil;
    // Disabling is always fail-safe, including a late lifecycle notification.
    if (!enabled) atomic_store_explicit(&PLAdBlocking, false, memory_order_release);
    if (![NSThread isMainThread])
        return PLAdFail(error, 1, @"Altere esta opção pela tela principal do menu.");
    if (!enabled) return YES;
    if (!PLAdExpectedHost(error) || !PLAdInstall(error)) return NO;
    atomic_store_explicit(&PLAdBlocking, true, memory_order_release);
    return YES;
}
@end
