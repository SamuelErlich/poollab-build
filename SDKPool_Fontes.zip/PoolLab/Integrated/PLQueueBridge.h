#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PLQueueSnapshot : NSObject
@property(nonatomic, readonly) BOOL ready;
@property(nonatomic, readonly) BOOL isResultScreen;
@property(nonatomic, copy, readonly) NSString *resultToken;
@property(nonatomic, copy, readonly) NSString *unavailableReason;
/// V15 navigation uses one revalidated action per observed scene visit.
@property(nonatomic, copy, readonly) NSString *actionToken;
@property(nonatomic, copy, readonly) NSString *navigationAction;
@property(nonatomic, copy, readonly) NSString *sceneName;
@property(nonatomic, copy, readonly) NSString *selectedTier;
@property(nonatomic, copy, readonly) NSString *observedMatchID;
@property(nonatomic, readonly) BOOL isInMatch;
@property(nonatomic, readonly) BOOL isMatchmaking;
@end

/// Reuses the game's normal matchmaking entry point for the observed match's
/// unchanged tier. It never selects a new tier, accepts a purchase, or rematches.
@interface PLQueueBridge : NSObject
+ (nullable PLQueueSnapshot *)captureWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(capture());
+ (BOOL)startNextMatchForToken:(NSString *)token error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(startNextMatch(token:));
/// Return to the native map carousel, select its foreground/centered ordinary
/// coin map, and dismiss specifically verified news/promotion windows. Unknown
/// windows wait for the user. This does not select the most expensive map.
+ (nullable PLQueueSnapshot *)captureNavigationWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(captureNavigation());
+ (BOOL)performNavigationForToken:(NSString *)token error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(performNavigation(token:));
@end

NS_ASSUME_NONNULL_END
