#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PLQueueSnapshot : NSObject
@property(nonatomic, readonly) BOOL ready;
@property(nonatomic, readonly) BOOL isResultScreen;
@property(nonatomic, copy, readonly) NSString *resultToken;
@property(nonatomic, copy, readonly) NSString *unavailableReason;
@end

/// Reuses the game's normal matchmaking entry point for the observed match's
/// unchanged tier. It never selects a new tier, accepts a purchase, or rematches.
@interface PLQueueBridge : NSObject
+ (nullable PLQueueSnapshot *)captureWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(capture());
+ (BOOL)startNextMatchForToken:(NSString *)token error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(startNextMatch(token:));
@end

NS_ASSUME_NONNULL_END
