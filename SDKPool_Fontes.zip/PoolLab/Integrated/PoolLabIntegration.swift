import UIKit
import SwiftUI
import PoolLabCore

@MainActor
private enum PLBrandAssets {
    static let mark = UIImage(named: "SDKPoolMark", in: Bundle(for: PLIntegrationBootstrap.self), compatibleWith: nil)
}

// Pure geometry is also exercised by the portable layout validation.
private enum PLOverlayGeometry {
    static func panelFrame(in safe: CGRect) -> CGRect {
        let width = min(520, max(0, safe.width))
        let height = min(720, max(0, safe.height))
        return CGRect(x: safe.midX - width / 2, y: safe.midY - height / 2, width: width, height: height)
    }

    static func buttonFrame(in safe: CGRect, anchor: CGPoint) -> CGRect {
        let size = min(48, max(0, min(safe.width, safe.height)))
        let x = safe.minX + max(0, safe.width - size) * min(1, max(0, anchor.x))
        let y = safe.minY + max(0, safe.height - size) * min(1, max(0, anchor.y))
        return CGRect(x: x, y: y, width: size, height: size)
    }
}

@objc(PLIntegrationBootstrap)
@MainActor
public final class PLIntegrationBootstrap: NSObject {
    private static var retainedCoordinator: PLIntegrationCoordinator?

    @objc public static func start() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { start() }
            return
        }
        if retainedCoordinator == nil { retainedCoordinator = PLIntegrationCoordinator() }
        retainedCoordinator?.installIfNeeded()
    }
}

@MainActor
private final class PLIntegrationCoordinator {
    private let authorization: AppModel
    private let game: IntegratedGameModel
    private var window: PLPassthroughWindow?
    private var observers: [NSObjectProtocol] = []

    init() {
        authorization = AppModel(configurationBundle: Bundle(for: PLIntegrationBootstrap.self))
        game = IntegratedGameModel(authorization: authorization)
        observe(UIApplication.didBecomeActiveNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIApplication.willResignActiveNotification) { [weak self] _ in self?.suspend() }
        observe(UIApplication.didEnterBackgroundNotification) { [weak self] _ in self?.suspend() }
        observe(UIScene.didActivateNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIScene.willDeactivateNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.suspend()
        }
        observe(UIScene.didDisconnectNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.removeWindow()
            self.installIfNeeded()
        }
    }

    func installIfNeeded() {
        guard UIApplication.shared.applicationState == .active else { return }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .filter { $0.activationState == .foregroundActive }
        let scene = scenes.first { candidate in
            candidate.windows.contains { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
        } ?? scenes.first { candidate in
            candidate.windows.contains { !$0.isHidden && !($0 is PLPassthroughWindow) }
        }
        // The target also supports the pre-UIScene AppDelegate lifecycle.
        // UIApplication.windows is intentionally used only for that fallback.
        let candidates = scene?.windows ?? UIApplication.shared.windows
        let host = candidates.first { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
            ?? candidates.first { !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
        guard let host else { return }
        let frame = scene?.coordinateSpace.bounds ?? host.frame
        if let window, window.windowScene === scene {
            window.frame = frame
            window.isHidden = false
            game.becameActive()
            return
        }
        removeWindow()
        let controller = PLOverlayController(model: game, hostWindow: host)
        let overlay: PLPassthroughWindow
        if let scene { overlay = PLPassthroughWindow(windowScene: scene) }
        else { overlay = PLPassthroughWindow(frame: frame) }
        overlay.frame = frame
        overlay.windowLevel = UIWindow.Level(rawValue: UIWindow.Level.normal.rawValue + 1)
        overlay.backgroundColor = .clear
        overlay.overrideUserInterfaceStyle = .dark
        overlay.rootViewController = controller
        overlay.isHidden = false
        // The closed overlay never takes focus. Login borrows it only after a tap.
        window = overlay
        game.becameActive()
    }

    private func suspend() {
        game.becameInactive()
        window?.returnKeyboardFocus()
        window?.isHidden = true
    }

    private func removeWindow() {
        game.becameInactive()
        window?.returnKeyboardFocus()
        window?.isHidden = true
        window?.rootViewController = nil
        window = nil
    }

    private func observe(_ name: Notification.Name, action: @escaping @MainActor (Notification) -> Void) {
        let token = NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { note in
            Task { @MainActor in action(note) }
        }
        observers.append(token)
    }
}

private final class PLPassthroughWindow: UIWindow {
    private weak var previousKeyWindow: UIWindow?

    func borrowKeyboardFocus() {
        guard !isKeyWindow else { return }
        let candidates = windowScene?.windows ?? UIApplication.shared.windows
        previousKeyWindow = candidates.first { $0.isKeyWindow && $0 !== self }
        makeKey()
    }

    func returnKeyboardFocus() {
        endEditing(true)
        if isKeyWindow {
            let candidates = windowScene?.windows ?? UIApplication.shared.windows
            let candidate = previousKeyWindow ?? candidates.first { $0 !== self && !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
            candidate?.makeKey()
        }
        previousKeyWindow = nil
    }

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let target = super.hitTest(point, with: event)
        if target === self || target === rootViewController?.view { return nil }
        return target
    }
}

private final class PLPassthroughView: UIView {
    weak var floatingButton: UIView?
    weak var panel: UIView?

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard !isHidden, alpha > 0.01, isUserInteractionEnabled else { return nil }
        for candidate in [floatingButton, panel].compactMap({ $0 }) {
            guard !candidate.isHidden, candidate.alpha > 0.01, candidate.isUserInteractionEnabled else { continue }
            let converted = convert(point, to: candidate)
            if candidate.point(inside: converted, with: event) {
                return candidate.hitTest(converted, with: event)
            }
        }
        return nil
    }
}

@MainActor
private final class PLOverlayController: UIViewController {
    private let model: IntegratedGameModel
    private weak var hostWindow: UIWindow?
    private let floatingButton = UIButton(type: .system)
    private let panelContainer = UIView()
    private var panelHost: UIHostingController<PLIntegratedPanel>?
    private let trajectories = CALayer()
    private let luckyTarget = CAShapeLayer()
    private let liveGuide = CAShapeLayer()
    private let livePositions = CAShapeLayer()
    private let pocketMarkers = CAShapeLayer()
    private let predictionAlert = CATextLayer()
    private var paths: [Int: CAShapeLayer] = [:]
    private var endpoints: [Int: CAShapeLayer] = [:]
    private var endpointLabels: [Int: CATextLayer] = [:]
    private var panelOpen = false
    private var buttonAnchor = CGPoint(x: 1, y: 0.18)
    private var keyboardTop: CGFloat?
    private var keyboardObservers: [NSObjectProtocol] = []

    init(model: IntegratedGameModel, hostWindow: UIWindow) {
        self.model = model
        self.hostWindow = hostWindow
        super.init(nibName: nil, bundle: nil)
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        hostWindow?.rootViewController?.supportedInterfaceOrientations ?? .allButUpsideDown
    }

    override var shouldAutorotate: Bool {
        hostWindow?.rootViewController?.shouldAutorotate ?? true
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func loadView() {
        let root = PLPassthroughView()
        root.backgroundColor = .clear
        root.floatingButton = floatingButton
        root.panel = panelContainer
        view = root
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        trajectories.masksToBounds = true
        view.layer.addSublayer(trajectories)
        luckyTarget.fillColor = nil
        luckyTarget.strokeColor = UIColor.systemYellow.cgColor
        luckyTarget.lineWidth = 2
        trajectories.addSublayer(luckyTarget)
        liveGuide.fillColor = nil
        liveGuide.strokeColor = UIColor.white.withAlphaComponent(0.9).cgColor
        liveGuide.lineWidth = 1.25
        liveGuide.lineCap = .round
        trajectories.addSublayer(liveGuide)
        livePositions.fillColor = nil
        livePositions.strokeColor = UIColor.white.withAlphaComponent(0.75).cgColor
        livePositions.lineWidth = 1
        trajectories.addSublayer(livePositions)
        pocketMarkers.fillColor = nil
        pocketMarkers.strokeColor = UIColor.systemYellow.cgColor
        pocketMarkers.lineWidth = 2
        pocketMarkers.lineCap = .round
        pocketMarkers.lineJoin = .round
        trajectories.addSublayer(pocketMarkers)
        predictionAlert.alignmentMode = .center
        predictionAlert.font = UIFont.systemFont(ofSize: 11, weight: .semibold)
        predictionAlert.fontSize = 11
        predictionAlert.foregroundColor = UIColor.white.cgColor
        predictionAlert.backgroundColor = UIColor.black.withAlphaComponent(0.75).cgColor
        predictionAlert.cornerRadius = 7
        predictionAlert.isHidden = true
        view.layer.addSublayer(predictionAlert)
        floatingButton.setImage(PLBrandAssets.mark?.withRenderingMode(.alwaysOriginal), for: .normal)
        floatingButton.imageView?.contentMode = .scaleAspectFit
        floatingButton.backgroundColor = UIColor(red: 0.09, green: 0.094, blue: 0.11, alpha: 1)
        floatingButton.layer.cornerRadius = 14
        floatingButton.imageView?.layer.cornerRadius = 14
        floatingButton.imageView?.clipsToBounds = true
        floatingButton.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
        floatingButton.layer.borderWidth = 1
        floatingButton.layer.shadowColor = UIColor.black.cgColor
        floatingButton.layer.shadowOpacity = 0.35
        floatingButton.layer.shadowRadius = 6
        floatingButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        floatingButton.accessibilityLabel = "Abrir SDKPool"
        floatingButton.accessibilityHint = "Arraste o botão para mudar sua posição"
        floatingButton.addTarget(self, action: #selector(togglePanel), for: .touchUpInside)
        floatingButton.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(moveButton(_:))))
        view.addSubview(floatingButton)

        panelContainer.backgroundColor = UIColor(red: 0.055, green: 0.059, blue: 0.071, alpha: 1)
        panelContainer.layer.cornerRadius = 20
        panelContainer.layer.borderWidth = 1
        panelContainer.layer.borderColor = UIColor.white.withAlphaComponent(0.12).cgColor
        panelContainer.clipsToBounds = true
        view.addSubview(panelContainer)
        let host = UIHostingController(rootView: PLIntegratedPanel(
            model: model, authorization: model.authorization,
            close: { [weak self] in self?.closePanel() },
            beginLogin: { [weak self] in self?.focusLogin() },
            shareDiagnostics: { [weak self] in self?.shareDiagnostics() },
            accessChanged: { [weak self] allowed in
                if allowed { (self?.view.window as? PLPassthroughWindow)?.returnKeyboardFocus() }
            }
        ))
        host.view.backgroundColor = .clear
        addChild(host)
        panelContainer.addSubview(host.view)
        host.didMove(toParent: self)
        panelHost = host
        model.onOverlayChange = { [weak self] in self?.drawTrajectories() }
        for name in [UIResponder.keyboardWillChangeFrameNotification, UIResponder.keyboardWillHideNotification] {
            keyboardObservers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] note in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    if note.name == UIResponder.keyboardWillHideNotification { self.keyboardTop = nil }
                    else if let frame = note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
                        let local = self.view.convert(frame, from: nil)
                        self.keyboardTop = local.intersects(self.view.bounds) ? local.minY : nil
                    }
                    self.view.setNeedsLayout()
                }
            })
        }
    }

    deinit {
        for observer in keyboardObservers { NotificationCenter.default.removeObserver(observer) }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        var safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 60, safe.height > 60 else { return }
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        floatingButton.frame = PLOverlayGeometry.buttonFrame(in: safe, anchor: buttonAnchor)
        floatingButton.isHidden = panelOpen
        if panelOpen, let keyboardTop {
            safe.size.height = max(0, min(safe.maxY, keyboardTop - 8) - safe.minY)
        }
        panelContainer.frame = PLOverlayGeometry.panelFrame(in: safe)
        panelHost?.view.frame = panelContainer.bounds
        panelContainer.isHidden = !panelOpen
        trajectories.bounds = view.bounds
        trajectories.position = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
        let alertWidth = min(310, safe.width)
        predictionAlert.frame = CGRect(x: view.bounds.midX - alertWidth / 2, y: safe.maxY - 24, width: alertWidth, height: 22)
        CATransaction.commit()
        // Closing is always available in the fixed panel header. The floating
        // button is hidden while open so it cannot cover a tab or input field.
        view.bringSubviewToFront(floatingButton)
        drawTrajectories()
    }

    @objc private func togglePanel() {
        panelOpen.toggle()
        panelContainer.isHidden = !panelOpen
        floatingButton.isHidden = panelOpen
        view.setNeedsLayout()
        if panelOpen { model.panelOpened(); focusLogin() }
        else { (view.window as? PLPassthroughWindow)?.returnKeyboardFocus(); model.panelClosed() }
    }

    private func closePanel() {
        panelOpen = false
        (view.window as? PLPassthroughWindow)?.returnKeyboardFocus()
        panelContainer.isHidden = true
        floatingButton.isHidden = false
        view.setNeedsLayout()
        model.panelClosed()
    }

    private func shareDiagnostics() {
        do {
            let url = try model.exportTelemetry()
            let activity = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            activity.popoverPresentationController?.sourceView = panelContainer
            activity.popoverPresentationController?.sourceRect = panelContainer.bounds
            present(activity, animated: true)
        } catch {
            let alert = UIAlertController(title: "Não foi possível exportar", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }

    private func focusLogin() {
        guard panelOpen, !model.authorization.canUseModules else { return }
        (view.window as? PLPassthroughWindow)?.borrowKeyboardFocus()
    }

    @objc private func moveButton(_ gesture: UIPanGestureRecognizer) {
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 48, safe.height > 48 else { return }
        let delta = gesture.translation(in: view)
        let position = CGPoint(x: min(safe.maxX - 24, max(safe.minX + 24, floatingButton.center.x + delta.x)),
                               y: min(safe.maxY - 24, max(safe.minY + 24, floatingButton.center.y + delta.y)))
        buttonAnchor = CGPoint(x: (position.x - safe.minX - 24) / (safe.width - 48),
                               y: (position.y - safe.minY - 24) / (safe.height - 48))
        gesture.setTranslation(.zero, in: view)
        view.setNeedsLayout()
    }

    private func drawTrajectories() {
        guard isViewLoaded, let window = view.window else { return }
        let current = model.overlayPaths(in: window)
        let visible = Set(current.map { $0.0 })
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        let guidePoints = model.overlayLiveGuide(in: window)
        let guidePath = UIBezierPath()
        if let first = guidePoints.first {
            guidePath.move(to: view.convert(first, from: window))
            for point in guidePoints.dropFirst() { guidePath.addLine(to: view.convert(point, from: window)) }
        }
        liveGuide.path = guidePoints.isEmpty ? nil : guidePath.cgPath
        let livePath = UIBezierPath()
        let liveBalls = model.overlayLiveBallPositions(in: window)
        for (_, point, radius) in liveBalls {
            let local = view.convert(point, from: window)
            livePath.append(UIBezierPath(ovalIn: CGRect(x: local.x - radius, y: local.y - radius, width: 2 * radius, height: 2 * radius)))
        }
        livePositions.path = liveBalls.isEmpty ? nil : livePath.cgPath
        for (id, layer) in paths where !visible.contains(id) { layer.path = nil }
        for (id, points) in current {
            let layer: CAShapeLayer
            if let previous = paths[id] { layer = previous }
            else {
                layer = CAShapeLayer()
                layer.fillColor = nil
                layer.lineCap = .round
                layer.lineJoin = .round
                trajectories.addSublayer(layer)
                paths[id] = layer
            }
            let path = UIBezierPath()
            if let first = points.first {
                path.move(to: view.convert(first, from: window))
                for point in points.dropFirst() { path.addLine(to: view.convert(point, from: window)) }
            }
            layer.path = path.cgPath
            layer.lineWidth = CGFloat(model.pathWidth) * (id == 0 ? 1.15 : 1)
            layer.strokeColor = styledColor(id).cgColor
            layer.lineDashPattern = model.pathStyle == "dashed" ? (id == 0 ? [7, 4] : [4, 3]) : nil
            layer.shadowColor = styledColor(id).cgColor
            layer.shadowOffset = .zero
            layer.shadowOpacity = model.pathStyle == "neon" ? 0.7 : 0
            layer.shadowRadius = model.pathStyle == "neon" ? 3 : 0
        }
        let finalPositions = model.overlayFinalPositions(in: window)
        let visibleFinal = Set(finalPositions.map { $0.0 })
        for (id, layer) in endpoints where !visibleFinal.contains(id) { layer.isHidden = true }
        for (id, layer) in endpointLabels where !visibleFinal.contains(id) { layer.isHidden = true }
        for (id, center, radius, pocketed) in finalPositions {
            let circle: CAShapeLayer
            let label: CATextLayer
            if let existing = endpoints[id], let existingLabel = endpointLabels[id] {
                circle = existing; label = existingLabel
            } else {
                circle = CAShapeLayer()
                circle.fillColor = UIColor.black.withAlphaComponent(0.48).cgColor
                trajectories.addSublayer(circle)
                endpoints[id] = circle
                label = CATextLayer()
                label.alignmentMode = .center
                label.foregroundColor = UIColor.white.cgColor
                label.font = UIFont.systemFont(ofSize: 10, weight: .bold)
                trajectories.addSublayer(label)
                endpointLabels[id] = label
            }
            let local = view.convert(center, from: window)
            let size = max(7, radius)
            circle.isHidden = false
            circle.path = UIBezierPath(ovalIn: CGRect(x: local.x - size, y: local.y - size,
                                                     width: size * 2, height: size * 2)).cgPath
            circle.lineWidth = CGFloat(model.pathWidth)
            circle.strokeColor = styledColor(id).cgColor
            let filled = model.projectedBallStyle == "filled"
            circle.fillColor = filled
                ? (id == 0 ? UIColor.white.withAlphaComponent(0.78) : (id == 8 ? UIColor(white: 0.04, alpha: 0.85) : Self.traceColor(id).withAlphaComponent(0.78))).cgColor
                : UIColor.black.withAlphaComponent(0.2).cgColor
            label.foregroundColor = filled && [0, 1, 9].contains(id) ? UIColor.black.cgColor : UIColor.white.cgColor
            circle.lineDashPattern = pocketed ? [2, 2] : nil
            label.isHidden = !model.showFinalNumbers
            label.contentsScale = window.screen.scale
            label.fontSize = min(12, max(9, size))
            label.string = id == 0 ? "●" : "\(id)"
            label.frame = CGRect(x: local.x - size, y: local.y - label.fontSize * 0.65,
                                 width: size * 2, height: label.fontSize * 1.5)
            label.opacity = Float(model.pathOpacity)
        }
        if let center = model.overlayLuckyTarget(in: window) {
            let point = view.convert(center, from: window)
            let marker = UIBezierPath()
            marker.move(to: CGPoint(x: point.x - 8, y: point.y)); marker.addLine(to: CGPoint(x: point.x + 8, y: point.y))
            marker.move(to: CGPoint(x: point.x, y: point.y - 8)); marker.addLine(to: CGPoint(x: point.x, y: point.y + 8))
            luckyTarget.path = marker.cgPath
        } else { luckyTarget.path = nil }
        let markerPath = UIBezierPath()
        let pockets = model.overlayPocketMarkers(in: window)
        for (inner, center) in pockets {
            let from = view.convert(inner, from: window), to = view.convert(center, from: window)
            if model.pocketMarkerStyle == "ring" {
                markerPath.append(UIBezierPath(ovalIn: CGRect(x: to.x - 9, y: to.y - 9, width: 18, height: 18)))
            } else {
                markerPath.move(to: from); markerPath.addLine(to: to)
                let angle = atan2(to.y - from.y, to.x - from.x)
                for offset in [-CGFloat.pi / 5, CGFloat.pi / 5] {
                    markerPath.move(to: CGPoint(x: to.x - 8 * cos(angle + offset), y: to.y - 8 * sin(angle + offset)))
                    markerPath.addLine(to: to)
                }
            }
        }
        pocketMarkers.path = pockets.isEmpty ? nil : markerPath.cgPath
        pocketMarkers.opacity = Float(model.pathOpacity)
        predictionAlert.contentsScale = window.screen.scale
        predictionAlert.string = model.currentPredictionAlert
        predictionAlert.isHidden = model.currentPredictionAlert == nil
        CATransaction.commit()
    }

    private func styledColor(_ id: Int) -> UIColor {
        let color: UIColor
        switch model.pathColorMode {
        case "mint": color = UIColor(red: 0.28, green: 0.95, blue: 0.82, alpha: 1)
        case "white": color = .white
        default: color = Self.traceColor(id)
        }
        return color.withAlphaComponent(CGFloat(model.pathOpacity))
    }

    private static func traceColor(_ id: Int) -> UIColor {
        switch id {
        case 0: return UIColor(red: 0.28, green: 0.95, blue: 0.82, alpha: 0.96)
        case 1, 9: return .systemYellow
        case 2, 10: return .systemBlue
        case 3, 11: return .systemRed
        case 4, 12: return .systemPurple
        case 5, 13: return .systemOrange
        case 6, 14: return .systemGreen
        case 7, 15: return .systemPink
        default: return .white
        }
    }
}

@MainActor
private struct PLIntegratedPanel: View {
    @ObservedObject var model: IntegratedGameModel
    @ObservedObject var authorization: AppModel
    let close: () -> Void
    let beginLogin: () -> Void
    let shareDiagnostics: () -> Void
    let accessChanged: (Bool) -> Void
    @State private var section = 0
    @State private var showTwoFactor = false
    @State private var confirmForget = false

    var body: some View {
        VStack(spacing: 0) {
            header
            if authorization.canUseModules { navigation }
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if authorization.canUseModules {
                        if section == 0 { tableControls }
                        else if section == 1 { diagnostics }
                        else { account }
                    } else { login }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .font(.callout)
        .foregroundColor(.white)
        .tint(PoolTheme.accent)
        .background(PoolTheme.background)
        // Live samples change values, never the panel's geometry or transition.
        .transaction { $0.animation = nil; $0.disablesAnimations = true }
        .onChange(of: authorization.canUseModules) { allowed in
            model.authorizationChanged()
            accessChanged(allowed)
        }
        .confirmationDialog("Remover a chave salva neste iPhone?", isPresented: $confirmForget, titleVisibility: .visible) {
            Button("Remover chave e sair", role: .destructive) {
                Task { await authorization.forgetLicense() }
            }
            Button("Cancelar", role: .cancel) { }
        } message: {
            Text("Na próxima abertura, será necessário informar a chave novamente.")
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            if let logo = PLBrandAssets.mark {
                Image(uiImage: logo).resizable().scaledToFit()
                    .frame(width: 38, height: 38)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .accessibilityHidden(true)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("SDKPool").font(.headline.weight(.bold))
                Text("CONTROLE DA MESA").font(.system(size: 10, weight: .semibold))
                    .tracking(1.2).foregroundColor(PoolTheme.secondary)
            }
            Spacer(minLength: 8)
            Button(action: close) {
                Image(systemName: "xmark").font(.body.weight(.semibold))
                    .frame(width: 44, height: 44)
                    .background(PoolTheme.elevated)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Fechar painel e voltar à partida")
        }
        .padding(.horizontal, 16).padding(.vertical, 10)
    }

    private var navigation: some View {
        HStack(spacing: 4) {
            navigationButton("Mesa", symbol: "circle.grid.2x2", index: 0)
            navigationButton("Dados", symbol: "waveform.path.ecg", index: 1)
            navigationButton("Conta", symbol: "person.crop.circle", index: 2)
        }
        .padding(4).background(PoolTheme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .padding(.horizontal, 16).padding(.bottom, 4)
    }

    private func navigationButton(_ label: String, symbol: String, index: Int) -> some View {
        Button { section = index } label: {
            VStack(spacing: 4) {
                Image(systemName: symbol).font(.system(size: 15, weight: .semibold))
                Text(label).font(.caption.weight(.semibold))
            }
            .frame(maxWidth: .infinity, minHeight: 48)
            .foregroundColor(section == index ? .white : PoolTheme.secondary)
            .background(section == index ? PoolTheme.elevated : Color.clear)
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(section == index ? [.isSelected] : [])
    }

    private var tableStatus: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Label(model.hasTable ? "Mesa conectada" : "Aguardando a mesa",
                      systemImage: model.hasTable ? "checkmark.circle.fill" : "circle.dashed")
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(model.hasTable ? PoolTheme.success : PoolTheme.secondary)
                Spacer(minLength: 4)
                Text(model.hasTable ? (model.isPlayerTurn ? "Sua vez" : "Adversário") : "")
                    .font(.caption.weight(.semibold)).foregroundColor(PoolTheme.secondary)
            }
            // Reserve two lines. A worker start/finish must never push controls.
            Text(model.status).font(.caption).foregroundColor(PoolTheme.secondary)
                .lineLimit(2).frame(maxWidth: .infinity, minHeight: 32, alignment: .topLeading)
        }
        .padding(12).background(PoolTheme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private var tableControls: some View {
        VStack(alignment: .leading, spacing: 16) {
            tableStatus
            panelCard("Previsão ao vivo", symbol: "point.topleft.down.to.point.bottomright.curvepath") {
                controlToggle("Linhas do percurso", value: model.showTrajectories, set: model.setShowTrajectories)
                controlToggle("Posições finais das bolas", value: model.showFinalPositions, set: model.setShowFinalPositions)
                controlToggle("Caçapas previstas", value: model.showPocketMarkers, set: model.setShowPocketMarkers)
                Divider().overlay(PoolTheme.border)
                HStack {
                    Text("Força antes de puxar").font(.subheadline.weight(.semibold))
                    Spacer()
                    Text("\(Int((model.referencePreviewPower * 100).rounded()))%")
                        .monospacedDigit().foregroundColor(PoolTheme.accent)
                }
                Slider(value: Binding(get: { model.referencePreviewPower }, set: model.setReferencePreviewPower), in: 0.05...1, step: 0.01)
                    .frame(minHeight: 44)
                    .accessibilityLabel("Força de referência antes de puxar o taco")
                Text(model.previewPowerCaption).font(.caption).foregroundColor(PoolTheme.secondary)
                    .frame(maxWidth: .infinity, minHeight: 32, alignment: .topLeading)
            }
            DisclosureGroup("Aparência das linhas") { styleControls.padding(.top, 12) }
                .font(.subheadline.weight(.semibold)).padding(12)
                .background(PoolTheme.surface).clipShape(RoundedRectangle(cornerRadius: 12))
            Text("Mantenha o efeito centralizado antes da tacada. Ao puxar o taco, a prévia passa a usar a força escolhida no jogo.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var styleControls: some View {
        VStack(alignment: .leading, spacing: 12) {
            controlToggle("Percurso de todas as bolas", value: model.showAllPaths, set: model.setShowAllPaths)
            controlToggle("Números nas posições finais", value: model.showFinalNumbers, set: model.setShowFinalNumbers)
            Text("Cor das linhas").font(.caption).foregroundColor(PoolTheme.secondary)
            Picker("Cor das linhas", selection: Binding(get: { model.pathColorMode }, set: model.setPathColorMode)) {
                Text("Por bola").tag("balls")
                Text("Verde").tag("mint")
                Text("Branco").tag("white")
            }.pickerStyle(.segmented).frame(minHeight: 44)
            HStack {
                Text("Espessura")
                Spacer()
                Text(String(format: "%.1f", model.pathWidth)).monospacedDigit()
            }
            Slider(value: Binding(get: { model.pathWidth }, set: model.setPathWidth), in: 1...4, step: 0.25)
                .frame(minHeight: 44).accessibilityLabel("Espessura das linhas")
            HStack {
                Text("Opacidade")
                Spacer()
                Text("\(Int((model.pathOpacity * 100).rounded()))%").monospacedDigit()
            }
            Slider(value: Binding(get: { model.pathOpacity }, set: model.setPathOpacity), in: 0.3...1, step: 0.05)
                .frame(minHeight: 44).accessibilityLabel("Opacidade das linhas")
        }.font(.callout)
    }

    private var diagnostics: some View {
        VStack(alignment: .leading, spacing: 16) {
            panelCard("Leitura ao vivo", symbol: "waveform.path.ecg") {
                HStack {
                    diagnosticValue("Capturas/s", String(format: "%.1f", model.captureRate))
                    Spacer()
                    diagnosticValue("Cálculo", String(format: "%.0f ms", model.predictionMilliseconds))
                }
                HStack {
                    diagnosticValue("Idade da amostra", String(format: "%.1f ms", model.sampleAgeMilliseconds))
                    Spacer()
                    diagnosticValue("Leitura", String(format: "%.1f ms", model.captureMilliseconds))
                }
                Text(model.hasNativePhysics ? "Física lida do jogo" : "Perfil físico indisponível")
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(model.hasNativePhysics ? PoolTheme.success : PoolTheme.warning)
                Text(model.liveReadiness).font(.caption).fixedSize(horizontal: false, vertical: true)
                Text(model.status).font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                controlToggle("Conferir centros das bolas", value: model.showLivePositions, set: model.setShowLivePositions)
            }
            panelCard("Diagnóstico da partida", symbol: "doc.text.magnifyingglass") {
                Text(model.telemetryStatus).font(.caption).foregroundColor(PoolTheme.secondary)
                Button(model.telemetryRecording ? "Parar gravação" : "Gravar 30 segundos") { model.toggleTelemetry() }
                    .frame(maxWidth: .infinity, minHeight: 44).buttonStyle(.bordered)
                    .disabled(!model.hasTable && !model.telemetryRecording)
                Button { shareDiagnostics() } label: {
                    Label("Exportar diagnóstico", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.bordered).disabled(model.telemetryFrames == 0)
                Text("Registra a partida e os bloqueios do cálculo. A chave de acesso não entra no arquivo.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
            }
            DisclosureGroup("Detalhes da leitura") {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(model.nativeDiagnostics.keys.sorted(), id: \.self) { key in
                        Text("\(key): \(model.nativeDiagnostics[key] ?? "")")
                            .font(.system(.caption, design: .monospaced))
                            .textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
                    }
                }.frame(maxWidth: .infinity, alignment: .leading).padding(.top, 12)
            }.font(.subheadline.weight(.semibold))
            Text("SDKPool 1.4 · compilação 6").font(.caption).foregroundColor(PoolTheme.secondary)
        }
    }

    private var account: some View {
        VStack(alignment: .leading, spacing: 16) {
            panelCard("Seu acesso", symbol: "checkmark.shield") {
                Label(authorization.statusText, systemImage: "checkmark.circle.fill")
                    .foregroundColor(PoolTheme.success)
                Text(authorization.hasRememberedLicense
                     ? "A chave está salva neste iPhone. O acesso será validado automaticamente ao abrir o jogo."
                     : "A chave não está salva neste dispositivo.")
                    .font(.callout).foregroundColor(PoolTheme.secondary)
                if let notice = authorization.credentialNotice {
                    Text(notice).font(.caption).foregroundColor(PoolTheme.warning)
                }
            }
            Button("Encerrar esta sessão") { Task { await authorization.signOut() } }
                .frame(maxWidth: .infinity, minHeight: 44).buttonStyle(.bordered)
            Text("A chave continua salva. Use a opção abaixo para removê-la do dispositivo.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
            Button("Remover chave salva", role: .destructive) { confirmForget = true }
                .frame(maxWidth: .infinity, minHeight: 44).buttonStyle(.bordered)
                .disabled(!authorization.hasRememberedLicense)
            Text("SDKPool 1.4 · compilação 6").font(.caption).foregroundColor(PoolTheme.secondary)
        }
    }

    private var login: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(authorization.hasRememberedLicense ? "Bom ter você de volta" : "Ative seu acesso")
                .font(.title3.bold())
            Text("Depois de validar, a chave fica salva neste iPhone.")
                .font(.callout).foregroundColor(PoolTheme.secondary)
            if let issue = authorization.configurationIssue {
                Text(issue).font(.caption).foregroundColor(PoolTheme.warning)
            }
            if authorization.session != nil {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(authorization.statusText).font(.callout)
                }.frame(minHeight: 44)
                Button("Encerrar esta sessão") { Task { await authorization.signOut() } }
                    .frame(minHeight: 44).buttonStyle(.bordered)
            } else {
                Text("Chave de acesso").font(.subheadline.weight(.semibold))
                SecureField("Cole ou digite sua chave", text: $authorization.licenseKey)
                    .textInputAutocapitalization(.never).disableAutocorrection(true)
                    .poolField()
                if #available(iOS 16.0, *) {
                    PasteButton(payloadType: String.self) { values in
                        if let value = values.first { _ = authorization.pasteLicense(value) }
                    }
                    .labelStyle(.titleAndIcon).frame(minHeight: 44)
                    .accessibilityLabel("Colar chave de acesso")
                } else {
                    Button { authorization.pasteFromClipboard() } label: {
                        Label("Colar chave", systemImage: "doc.on.clipboard")
                            .frame(minHeight: 44)
                    }.buttonStyle(.bordered)
                }
                if let notice = authorization.clipboardNotice {
                    Text(notice).font(.caption).foregroundColor(PoolTheme.secondary)
                }
                DisclosureGroup("Código adicional", isExpanded: $showTwoFactor) {
                    TextField("Código de autenticação", text: $authorization.twoFactorCode)
                        .keyboardType(.numberPad).textContentType(.oneTimeCode)
                        .poolField().padding(.top, 10)
                }.font(.subheadline).frame(minHeight: 44)
                if case .error(let error) = authorization.phase {
                    Text(error).font(.callout).foregroundColor(PoolTheme.warning)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Button {
                    Task { await authorization.activate(); model.authorizationChanged() }
                } label: {
                    HStack(spacing: 10) {
                        if authorization.phase == .authenticating { ProgressView().tint(.white) }
                        Text(authorization.phase == .authenticating ? "Validando acesso…" : "Entrar e salvar chave")
                    }
                }
                .buttonStyle(PoolPrimaryButtonStyle())
                .disabled(authorization.configurationIssue != nil || authorization.phase == .authenticating ||
                          (authorization.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !authorization.hasRememberedLicense))
                if authorization.hasRememberedLicense {
                    Button("Usar outra chave") { confirmForget = true }
                        .frame(minHeight: 44).buttonStyle(.bordered)
                }
            }
            if let notice = authorization.credentialNotice {
                Text(notice).font(.caption).foregroundColor(PoolTheme.warning)
            }
            Text("É necessário ter conexão para validar o acesso.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
        }
        .simultaneousGesture(TapGesture().onEnded { beginLogin() })
    }

    private func controlToggle(_ title: String, value: Bool, set: @escaping (Bool) -> Void) -> some View {
        Toggle(title, isOn: Binding(get: { value }, set: set))
            .font(.callout).frame(minHeight: 44)
    }

    private func diagnosticValue(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption).foregroundColor(PoolTheme.secondary)
            Text(value).font(.system(.callout, design: .monospaced).weight(.semibold))
        }.frame(maxWidth: .infinity, alignment: .leading)
    }

    private func panelCard<Content: View>(_ title: String, symbol: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(title, systemImage: symbol).font(.subheadline.weight(.semibold))
            content()
        }
        .padding(14).frame(maxWidth: .infinity, alignment: .leading)
        .background(PoolTheme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(PoolTheme.border, lineWidth: 1))
    }
}
