import UIKit
import SwiftUI
import PoolLabCore

@MainActor
private enum PLBrandAssets {
    static let mark = UIImage(named: "SDKPoolMark", in: Bundle(for: PLIntegrationBootstrap.self), compatibleWith: nil)
}

// Pure geometry is also exercised by the portable layout validation.
private enum PLOverlayGeometry {
    static func panelFrame(in safe: CGRect, authorized: Bool = true) -> CGRect {
        let width = min(authorized ? 780 : 480, max(0, safe.width))
        let height = min(authorized && safe.width >= 680 ? 520 : 680, max(0, safe.height))
        return CGRect(x: safe.midX - width / 2, y: safe.midY - height / 2, width: width, height: height)
    }

    static func usesColumns(width: CGFloat, accessibility: Bool) -> Bool {
        width >= 680 && !accessibility
    }

    static func buttonFrame(in safe: CGRect, anchor: CGPoint) -> CGRect {
        let size = min(48, max(0, min(safe.width, safe.height)))
        let x = safe.minX + max(0, safe.width - size) * min(1, max(0, anchor.x))
        let y = safe.minY + max(0, safe.height - size) * min(1, max(0, anchor.y))
        return CGRect(x: x, y: y, width: size, height: size)
    }
}

// Small render gate kept independent of UIKit so coalescing and suspended
// windows can be checked without claiming an iPhone compositor test.
private struct PLOverlayDrawGate {
    private(set) var needsDraw = true
    private(set) var requests = 0
    private(set) var coalescedRequests = 0

    mutating func request() {
        requests += 1
        if needsDraw { coalescedRequests += 1 }
        needsDraw = true
    }

    mutating func consume(canRender: Bool) -> Bool {
        guard needsDraw, canRender else { return false }
        needsDraw = false
        return true
    }

    mutating func resetIntervalMetrics() {
        requests = 0
        coalescedRequests = 0
    }
}

@objc(PLIntegrationBootstrap)
@MainActor
public final class PLIntegrationBootstrap: NSObject {
    private static var retainedCoordinator: PLIntegrationCoordinator?

    @objc public static func start() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { start() }
            return
        }
        if retainedCoordinator == nil { retainedCoordinator = PLIntegrationCoordinator() }
        retainedCoordinator?.installIfNeeded()
    }
}

@MainActor
private final class PLIntegrationCoordinator {
    private let authorization: AppModel
    private let game: IntegratedGameModel
    private var window: PLPassthroughWindow?
    private var observers: [NSObjectProtocol] = []

    init() {
        authorization = AppModel(configurationBundle: Bundle(for: PLIntegrationBootstrap.self))
        game = IntegratedGameModel(authorization: authorization)
        observe(UIApplication.didBecomeActiveNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIApplication.willResignActiveNotification) { [weak self] _ in self?.suspend(reason: "application.willResignActive") }
        observe(UIApplication.didEnterBackgroundNotification) { [weak self] _ in self?.suspend(reason: "application.didEnterBackground") }
        observe(UIScene.didActivateNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIScene.willDeactivateNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.suspend(reason: "scene.willDeactivate")
        }
        observe(UIScene.didDisconnectNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.removeWindow(reason: "scene.didDisconnect")
            self.installIfNeeded()
        }
        for name in [UIWindow.didBecomeKeyNotification, UIWindow.didResignKeyNotification] {
            observe(name) { [weak self] note in
                guard let self, let changed = note.object as? UIWindow,
                      changed === self.window || changed.windowScene === self.window?.windowScene else { return }
                self.game.recordOverlayEvent("overlay.key.changed", details: [
                    "notification": note.name.rawValue,
                    "windowType": String(describing: type(of: changed)),
                    "isOverlay": String(changed === self.window),
                    "isHidden": String(changed.isHidden),
                    "windowLevel": String(Double(changed.windowLevel.rawValue))
                ])
            }
        }
    }

    func installIfNeeded() {
        game.recordOverlayEvent("overlay.install.request", details: ["applicationState": String(UIApplication.shared.applicationState.rawValue)])
        guard UIApplication.shared.applicationState == .active else { return }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .filter { $0.activationState == .foregroundActive }
        let scene = scenes.first { candidate in
            candidate.windows.contains { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
        } ?? scenes.first { candidate in
            candidate.windows.contains { !$0.isHidden && !($0 is PLPassthroughWindow) }
        }
        // The target also supports the pre-UIScene AppDelegate lifecycle.
        // UIApplication.windows is intentionally used only for that fallback.
        let candidates = scene?.windows ?? UIApplication.shared.windows
        let host = candidates.first { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
            ?? candidates.first { !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
        guard let host else {
            game.recordOverlayEvent("overlay.install.noHost")
            return
        }
        let frame = scene?.coordinateSpace.bounds ?? host.frame
        if let window, window.windowScene === scene {
            if window.frame != frame { window.frame = frame }
            if window.isHidden {
                window.isHidden = false
                game.recordOverlayEvent("overlay.visibility", details: ["visible": "true", "reason": "install.existing"])
            }
            game.becameActive()
            return
        }
        removeWindow(reason: "install.newScene")
        let controller = PLOverlayController(model: game, hostWindow: host)
        let overlay: PLPassthroughWindow
        if let scene { overlay = PLPassthroughWindow(windowScene: scene) }
        else { overlay = PLPassthroughWindow(frame: frame) }
        overlay.frame = frame
        overlay.windowLevel = UIWindow.Level(rawValue: UIWindow.Level.normal.rawValue + 1)
        overlay.backgroundColor = .clear
        overlay.overrideUserInterfaceStyle = .dark
        overlay.rootViewController = controller
        overlay.isHidden = false
        // The closed overlay never takes focus. Login borrows it only after a tap.
        window = overlay
        overlay.recordEvent = { [weak game] name, details in game?.recordOverlayEvent(name, details: details) }
        game.recordOverlayEvent("overlay.mount", details: ["frame": String(describing: frame), "usesScene": String(scene != nil)])
        game.becameActive()
    }

    private func suspend(reason: String) {
        game.recordOverlayEvent("overlay.lifecycle.suspend", details: ["reason": reason])
        game.becameInactive()
        window?.returnKeyboardFocus()
        if let window, !window.isHidden {
            window.isHidden = true
            game.recordOverlayEvent("overlay.visibility", details: ["visible": "false", "reason": reason])
        }
    }

    private func removeWindow(reason: String) {
        guard let window else { return }
        game.recordOverlayEvent("overlay.unmount", details: ["reason": reason])
        game.becameInactive()
        window.returnKeyboardFocus()
        window.isHidden = true
        window.rootViewController = nil
        self.window = nil
    }

    private func observe(_ name: Notification.Name, action: @escaping @MainActor (Notification) -> Void) {
        let token = NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { note in
            Task { @MainActor in action(note) }
        }
        observers.append(token)
    }
}

@MainActor
private final class PLPassthroughWindow: UIWindow {
    private weak var previousKeyWindow: UIWindow?
    var recordEvent: (@MainActor (String, [String: String]) -> Void)?

    func borrowKeyboardFocus() {
        guard !isKeyWindow else { return }
        let candidates = windowScene?.windows ?? UIApplication.shared.windows
        previousKeyWindow = candidates.first { $0.isKeyWindow && $0 !== self }
        recordEvent?("overlay.key.borrow", [:])
        makeKey()
    }

    func returnKeyboardFocus() {
        endEditing(true)
        if isKeyWindow {
            let candidates = windowScene?.windows ?? UIApplication.shared.windows
            let candidate = previousKeyWindow ?? candidates.first { $0 !== self && !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
            candidate?.makeKey()
            recordEvent?("overlay.key.return", ["hostAvailable": String(candidate != nil)])
        }
        previousKeyWindow = nil
    }

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let target = super.hitTest(point, with: event)
        if target === self || target === rootViewController?.view { return nil }
        return target
    }
}

private final class PLPassthroughView: UIView {
    weak var floatingButton: UIView?
    weak var panel: UIView?

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard !isHidden, alpha > 0.01, isUserInteractionEnabled else { return nil }
        for candidate in [floatingButton, panel].compactMap({ $0 }) {
            guard !candidate.isHidden, candidate.alpha > 0.01, candidate.isUserInteractionEnabled else { continue }
            let converted = convert(point, to: candidate)
            if candidate.point(inside: converted, with: event) {
                return candidate.hitTest(converted, with: event)
            }
        }
        return nil
    }
}

@MainActor
private final class PLOverlayFrameTarget: NSObject {
    weak var owner: PLOverlayController?

    init(owner: PLOverlayController) { self.owner = owner }

    @objc func tick(_ link: CADisplayLink) { owner?.renderPendingOverlay(at: link.timestamp) }
}

@MainActor
private final class PLOverlayController: UIViewController {
    private let model: IntegratedGameModel
    private weak var hostWindow: UIWindow?
    private let floatingButton = UIButton(type: .system)
    private let panelContainer = UIView()
    private var panelHost: UIHostingController<PLIntegratedPanel>?
    private let trajectories = CALayer()
    private let luckyTarget = CAShapeLayer()
    private let liveGuide = CAShapeLayer()
    private let livePositions = CAShapeLayer()
    private let pocketMarkers = CAShapeLayer()
    private let predictionAlert = CALayer()
    private let predictionAlertTitle = CATextLayer()
    private let predictionAlertDetail = CATextLayer()
    private let predictionAlertAccent = CALayer()
    private var predictionAlertText: String?
    private var predictionAlertScratch = false
    private var predictionAlertLayoutKey: String?
    private var paths: [Int: CAShapeLayer] = [:]
    private var endpoints: [Int: CAShapeLayer] = [:]
    private var endpointLabels: [Int: CATextLayer] = [:]
    private var panelOpen = false
    private var buttonAnchor = CGPoint(x: 1, y: 0.18)
    private var keyboardTop: CGFloat?
    private var keyboardObservers: [NSObjectProtocol] = []
    private var lastLayout: OverlayLayout?
    private var lastDrawReport = ProcessInfo.processInfo.systemUptime
    private var drawCount = 0
    private var emptyDrawCount = 0
    private var predictionVisibilityChanges = 0
    private var lastPredictionVisible: Bool?
    private var renderAgeCount = 0
    private var renderAgeTotalMilliseconds = 0.0
    private var renderAgeMaximumMilliseconds = 0.0
    private var displayLink: CADisplayLink?
    private var frameTarget: PLOverlayFrameTarget?
    private var drawGate = PLOverlayDrawGate()

    private struct OverlayLayout: Equatable {
        var bounds: CGRect
        var safeArea: UIEdgeInsets
        var panel: CGRect
        var button: CGRect
        var panelOpen: Bool
    }

    init(model: IntegratedGameModel, hostWindow: UIWindow) {
        self.model = model
        self.hostWindow = hostWindow
        super.init(nibName: nil, bundle: nil)
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        hostWindow?.rootViewController?.supportedInterfaceOrientations ?? .allButUpsideDown
    }

    override var shouldAutorotate: Bool {
        hostWindow?.rootViewController?.shouldAutorotate ?? true
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func loadView() {
        let root = PLPassthroughView()
        root.backgroundColor = .clear
        root.floatingButton = floatingButton
        root.panel = panelContainer
        view = root
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        trajectories.masksToBounds = true
        view.layer.addSublayer(trajectories)
        luckyTarget.fillColor = nil
        luckyTarget.strokeColor = UIColor.systemYellow.cgColor
        luckyTarget.lineWidth = 2
        trajectories.addSublayer(luckyTarget)
        liveGuide.fillColor = nil
        liveGuide.strokeColor = UIColor.white.withAlphaComponent(0.9).cgColor
        liveGuide.lineWidth = 1.25
        liveGuide.lineCap = .round
        trajectories.addSublayer(liveGuide)
        livePositions.fillColor = nil
        livePositions.strokeColor = UIColor.white.withAlphaComponent(0.75).cgColor
        livePositions.lineWidth = 1
        trajectories.addSublayer(livePositions)
        pocketMarkers.fillColor = nil
        pocketMarkers.strokeColor = UIColor.systemYellow.cgColor
        pocketMarkers.lineWidth = 2
        pocketMarkers.lineCap = .round
        pocketMarkers.lineJoin = .round
        trajectories.addSublayer(pocketMarkers)
        predictionAlert.backgroundColor = UIColor(red: 0.075, green: 0.035, blue: 0.02, alpha: 0.97).cgColor
        predictionAlert.cornerRadius = 12
        predictionAlert.borderWidth = 1.5
        predictionAlert.shadowColor = UIColor.black.cgColor
        predictionAlert.shadowOpacity = 0.4
        predictionAlert.shadowRadius = 4
        predictionAlert.shadowOffset = CGSize(width: 0, height: 2)
        predictionAlert.isHidden = true
        predictionAlertAccent.cornerRadius = 2
        predictionAlert.addSublayer(predictionAlertAccent)
        for text in [predictionAlertTitle, predictionAlertDetail] {
            text.alignmentMode = .center
            text.foregroundColor = UIColor.white.cgColor
            text.isWrapped = true
            text.truncationMode = .none
            predictionAlert.addSublayer(text)
        }
        view.layer.addSublayer(predictionAlert)
        floatingButton.setImage(PLBrandAssets.mark?.withRenderingMode(.alwaysOriginal), for: .normal)
        floatingButton.imageView?.contentMode = .scaleAspectFit
        floatingButton.backgroundColor = UIColor(red: 0.16, green: 0.07, blue: 0.04, alpha: 1)
        floatingButton.layer.cornerRadius = 14
        floatingButton.imageView?.layer.cornerRadius = 14
        floatingButton.imageView?.clipsToBounds = true
        floatingButton.layer.borderColor = UIColor(red: 1, green: 0.38, blue: 0.13, alpha: 0.9).cgColor
        floatingButton.layer.borderWidth = 1.5
        floatingButton.layer.shadowColor = UIColor.black.cgColor
        floatingButton.layer.shadowOpacity = 0.35
        floatingButton.layer.shadowRadius = 6
        floatingButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        floatingButton.accessibilityLabel = "Abrir SDKPool"
        floatingButton.accessibilityHint = "Arraste o botão para mudar sua posição"
        floatingButton.addTarget(self, action: #selector(togglePanel), for: .touchUpInside)
        floatingButton.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(moveButton(_:))))
        view.addSubview(floatingButton)

        panelContainer.backgroundColor = UIColor(red: 0.024, green: 0.024, blue: 0.035, alpha: 1)
        panelContainer.layer.cornerRadius = 26
        panelContainer.layer.borderWidth = 1
        panelContainer.layer.borderColor = UIColor.white.withAlphaComponent(0.12).cgColor
        panelContainer.clipsToBounds = true
        view.addSubview(panelContainer)
        let host = UIHostingController(rootView: PLIntegratedPanel(
            model: model, authorization: model.authorization,
            close: { [weak self] in self?.closePanel() },
            beginLogin: { [weak self] in self?.focusLogin() },
            shareDiagnostics: { [weak self] in self?.shareDiagnostics() },
            accessChanged: { [weak self] allowed in
                if allowed { (self?.view.window as? PLPassthroughWindow)?.returnKeyboardFocus() }
                self?.view.setNeedsLayout()
            }
        ))
        host.view.backgroundColor = .clear
        addChild(host)
        panelContainer.addSubview(host.view)
        host.didMove(toParent: self)
        panelHost = host
        model.onOverlayChange = { [weak self] in self?.requestOverlayDraw() }
        let target = PLOverlayFrameTarget(owner: self)
        let link = CADisplayLink(target: target, selector: #selector(PLOverlayFrameTarget.tick(_:)))
        link.preferredFramesPerSecond = 60
        frameTarget = target
        displayLink = link
        link.add(to: .main, forMode: .common)
        model.recordOverlayEvent("overlay.controller.loaded")
        for name in [UIResponder.keyboardWillChangeFrameNotification, UIResponder.keyboardWillHideNotification] {
            keyboardObservers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] note in
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    let previousTop = self.keyboardTop
                    if note.name == UIResponder.keyboardWillHideNotification { self.keyboardTop = nil }
                    else if let frame = note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
                        let local = self.view.convert(frame, from: nil)
                        self.keyboardTop = local.intersects(self.view.bounds) ? local.minY : nil
                    }
                    if self.keyboardTop != previousTop {
                        self.model.recordOverlayEvent("overlay.keyboard.frame", details: [
                            "top": self.keyboardTop.map { String(Double($0)) } ?? "none"
                        ])
                        self.view.setNeedsLayout()
                    }
                }
            })
        }
    }

    deinit {
        displayLink?.invalidate()
        for observer in keyboardObservers { NotificationCenter.default.removeObserver(observer) }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        var safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 60, safe.height > 60 else { return }
        let buttonFrame = PLOverlayGeometry.buttonFrame(in: safe, anchor: buttonAnchor)
        if panelOpen, let keyboardTop {
            safe.size.height = max(0, min(safe.maxY, keyboardTop - 8) - safe.minY)
        }
        let panelFrame = PLOverlayGeometry.panelFrame(in: safe, authorized: model.authorization.canUseModules)
        let layout = OverlayLayout(bounds: view.bounds, safeArea: view.safeAreaInsets,
                                   panel: panelFrame, button: buttonFrame, panelOpen: panelOpen)
        let hostedFrame = CGRect(origin: .zero, size: panelFrame.size)
        // SwiftUI value updates can request a parent layout with identical
        // geometry. They must not rewrite frames or rebuild the entire HUD.
        guard lastLayout != layout || panelHost?.view.frame != hostedFrame else { return }
        lastLayout = layout
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        if floatingButton.frame != buttonFrame { floatingButton.frame = buttonFrame }
        floatingButton.isHidden = panelOpen
        if panelContainer.frame != panelFrame { panelContainer.frame = panelFrame }
        if let hostedView = panelHost?.view, hostedView.frame != panelContainer.bounds {
            hostedView.frame = panelContainer.bounds
        }
        panelContainer.isHidden = !panelOpen
        trajectories.bounds = view.bounds
        trajectories.position = CGPoint(x: view.bounds.midX, y: view.bounds.midY)
        layoutPredictionAlert()
        CATransaction.commit()
        model.recordOverlayEvent("overlay.layout.changed", details: [
            "bounds": String(describing: layout.bounds),
            "panelFrame": String(describing: layout.panel),
            "buttonFrame": String(describing: layout.button),
            "panelOpen": String(panelOpen)
        ])
        // Closing is always available in the fixed panel header. The floating
        // button is hidden while open so it cannot cover a tab or input field.
        view.bringSubviewToFront(floatingButton)
        requestOverlayDraw()
    }

    @objc private func togglePanel() {
        panelOpen.toggle()
        model.recordOverlayEvent("overlay.panel.visibility", details: ["open": String(panelOpen), "reason": "button"])
        panelContainer.isHidden = !panelOpen
        floatingButton.isHidden = panelOpen
        view.setNeedsLayout()
        if panelOpen { model.panelOpened(); focusLogin() }
        else { (view.window as? PLPassthroughWindow)?.returnKeyboardFocus(); model.panelClosed() }
    }

    private func closePanel() {
        guard panelOpen else { return }
        panelOpen = false
        model.recordOverlayEvent("overlay.panel.visibility", details: ["open": "false", "reason": "close"])
        (view.window as? PLPassthroughWindow)?.returnKeyboardFocus()
        panelContainer.isHidden = true
        floatingButton.isHidden = false
        view.setNeedsLayout()
        model.panelClosed()
    }

    private func shareDiagnostics() {
        do {
            let url = try model.exportTelemetry()
            let activity = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            activity.popoverPresentationController?.sourceView = panelContainer
            activity.popoverPresentationController?.sourceRect = panelContainer.bounds
            present(activity, animated: true)
        } catch {
            let alert = UIAlertController(title: "Não foi possível exportar", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }

    private func focusLogin() {
        guard panelOpen, !model.authorization.canUseModules else { return }
        (view.window as? PLPassthroughWindow)?.borrowKeyboardFocus()
    }

    @objc private func moveButton(_ gesture: UIPanGestureRecognizer) {
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 48, safe.height > 48 else { return }
        let delta = gesture.translation(in: view)
        let position = CGPoint(x: min(safe.maxX - 24, max(safe.minX + 24, floatingButton.center.x + delta.x)),
                               y: min(safe.maxY - 24, max(safe.minY + 24, floatingButton.center.y + delta.y)))
        buttonAnchor = CGPoint(x: (position.x - safe.minX - 24) / (safe.width - 48),
                               y: (position.y - safe.minY - 24) / (safe.height - 48))
        gesture.setTranslation(.zero, in: view)
        view.setNeedsLayout()
    }

    private func requestOverlayDraw() {
        drawGate.request()
    }

    fileprivate func renderPendingOverlay(at timestamp: TimeInterval) {
        // Read the native centers before drawing, on this same display tick.
        // There is no second timer, interpolation, or simulated live position.
        let window = viewIfLoaded?.window
        let canRender = UIApplication.shared.applicationState == .active && window?.isHidden == false
        guard canRender else { return }
        model.captureFrame(at: timestamp)
        guard drawGate.consume(canRender: canRender) else { return }
        drawTrajectories()
    }

    private func drawTrajectories() {
        guard isViewLoaded, let window = view.window else { return }
        let current = model.overlayPaths(in: window)
        let visible = Set(current.map { $0.0 })
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        let guidePoints = model.overlayLiveGuide(in: window)
        let guidePath = UIBezierPath()
        if let first = guidePoints.first {
            guidePath.move(to: view.convert(first, from: window))
            for point in guidePoints.dropFirst() { guidePath.addLine(to: view.convert(point, from: window)) }
        }
        liveGuide.path = guidePoints.isEmpty ? nil : guidePath.cgPath
        let livePath = UIBezierPath()
        let liveBalls = model.overlayLiveBallPositions(in: window)
        for (_, point, radius) in liveBalls {
            let local = view.convert(point, from: window)
            livePath.append(UIBezierPath(ovalIn: CGRect(x: local.x - radius, y: local.y - radius, width: 2 * radius, height: 2 * radius)))
        }
        livePositions.path = liveBalls.isEmpty ? nil : livePath.cgPath
        for (id, layer) in paths where !visible.contains(id) { layer.path = nil }
        for (id, points) in current {
            let layer: CAShapeLayer
            if let previous = paths[id] { layer = previous }
            else {
                layer = CAShapeLayer()
                layer.fillColor = nil
                layer.lineCap = .round
                layer.lineJoin = .round
                trajectories.addSublayer(layer)
                paths[id] = layer
            }
            let path = UIBezierPath()
            if let first = points.first {
                path.move(to: view.convert(first, from: window))
                for point in points.dropFirst() { path.addLine(to: view.convert(point, from: window)) }
            }
            layer.path = path.cgPath
            layer.lineWidth = CGFloat(model.pathWidth) * (id == 0 ? 1.15 : 1)
            layer.strokeColor = styledColor(id).cgColor
            layer.lineDashPattern = model.pathStyle == "dashed" ? (id == 0 ? [7, 4] : [4, 3]) : nil
            layer.shadowColor = styledColor(id).cgColor
            layer.shadowOffset = .zero
            layer.shadowOpacity = model.pathStyle == "neon" ? 0.7 : 0
            layer.shadowRadius = model.pathStyle == "neon" ? 3 : 0
        }
        let finalPositions = model.overlayFinalPositions(in: window)
        let visibleFinal = Set(finalPositions.map { $0.0 })
        for (id, layer) in endpoints where !visibleFinal.contains(id) { layer.isHidden = true }
        for (id, layer) in endpointLabels where !visibleFinal.contains(id) { layer.isHidden = true }
        for (id, center, radius, pocketed) in finalPositions {
            let circle: CAShapeLayer
            let label: CATextLayer
            if let existing = endpoints[id], let existingLabel = endpointLabels[id] {
                circle = existing; label = existingLabel
            } else {
                circle = CAShapeLayer()
                circle.fillColor = UIColor.black.withAlphaComponent(0.48).cgColor
                trajectories.addSublayer(circle)
                endpoints[id] = circle
                label = CATextLayer()
                label.alignmentMode = .center
                label.foregroundColor = UIColor.white.cgColor
                label.font = UIFont.systemFont(ofSize: 10, weight: .bold)
                trajectories.addSublayer(label)
                endpointLabels[id] = label
            }
            let local = view.convert(center, from: window)
            let size = max(7, radius)
            circle.isHidden = false
            circle.path = UIBezierPath(ovalIn: CGRect(x: local.x - size, y: local.y - size,
                                                     width: size * 2, height: size * 2)).cgPath
            circle.lineWidth = CGFloat(model.pathWidth)
            circle.strokeColor = styledColor(id).cgColor
            let filled = model.projectedBallStyle == "filled"
            circle.fillColor = filled
                ? (id == 0 ? UIColor.white.withAlphaComponent(0.78) : (id == 8 ? UIColor(white: 0.04, alpha: 0.85) : Self.traceColor(id).withAlphaComponent(0.78))).cgColor
                : UIColor.black.withAlphaComponent(0.2).cgColor
            label.foregroundColor = filled && [0, 1, 9].contains(id) ? UIColor.black.cgColor : UIColor.white.cgColor
            circle.lineDashPattern = pocketed ? [2, 2] : nil
            label.isHidden = !model.showFinalNumbers
            label.contentsScale = window.screen.scale
            label.fontSize = min(12, max(9, size))
            let labelText = id == 0 ? "●" : "\(id)"
            if label.string as? String != labelText { label.string = labelText }
            let labelFrame = CGRect(x: local.x - size, y: local.y - label.fontSize * 0.65,
                                    width: size * 2, height: label.fontSize * 1.5)
            if label.frame != labelFrame { label.frame = labelFrame }
            label.opacity = Float(model.pathOpacity)
        }
        if let center = model.overlayLuckyTarget(in: window) {
            let point = view.convert(center, from: window)
            let marker = UIBezierPath()
            marker.move(to: CGPoint(x: point.x - 8, y: point.y)); marker.addLine(to: CGPoint(x: point.x + 8, y: point.y))
            marker.move(to: CGPoint(x: point.x, y: point.y - 8)); marker.addLine(to: CGPoint(x: point.x, y: point.y + 8))
            luckyTarget.path = marker.cgPath
        } else { luckyTarget.path = nil }
        let markerPath = UIBezierPath()
        let pockets = model.overlayPocketMarkers(in: window)
        for (inner, center) in pockets {
            let from = view.convert(inner, from: window), to = view.convert(center, from: window)
            if model.pocketMarkerStyle == "ring" {
                markerPath.append(UIBezierPath(ovalIn: CGRect(x: to.x - 9, y: to.y - 9, width: 18, height: 18)))
            } else {
                markerPath.move(to: from); markerPath.addLine(to: to)
                let angle = atan2(to.y - from.y, to.x - from.x)
                for offset in [-CGFloat.pi / 5, CGFloat.pi / 5] {
                    markerPath.move(to: CGPoint(x: to.x - 8 * cos(angle + offset), y: to.y - 8 * sin(angle + offset)))
                    markerPath.addLine(to: to)
                }
            }
        }
        pocketMarkers.path = pockets.isEmpty ? nil : markerPath.cgPath
        pocketMarkers.opacity = Float(model.pathOpacity)
        updatePredictionAlert(in: window)
        CATransaction.commit()
        reportDraw(paths: current.count, finalPositions: finalPositions.count, guidePoints: guidePoints.count)
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        if previousTraitCollection?.preferredContentSizeCategory != traitCollection.preferredContentSizeCategory {
            predictionAlertLayoutKey = nil
            requestOverlayDraw()
        }
    }

    private func updatePredictionAlert(in window: UIWindow) {
        let text = model.currentPredictionAlert
        let scratch = model.currentPredictionIsScratch
        if text != predictionAlertText || scratch != predictionAlertScratch {
            predictionAlertText = text
            predictionAlertScratch = scratch
            let color = scratch
                ? UIColor(red: 1, green: 0.29, blue: 0.27, alpha: 1)
                : UIColor(red: 1, green: 0.56, blue: 0.2, alpha: 1)
            predictionAlert.borderColor = color.cgColor
            predictionAlertAccent.backgroundColor = color.cgColor
            predictionAlertTitle.foregroundColor = color.cgColor
            predictionAlertTitle.string = scratch ? "RISCO DE FALTA" : "PREVISÃO DE CAÇAPA"
            let balls = model.currentPredictedPocketBalls
            predictionAlertDetail.string = text.map { _ in
                scratch ? "Branca na caçapa"
                    : "\(balls.count == 1 ? "Bola" : "Bolas") \(balls.map(String.init).joined(separator: " · "))"
            }
            predictionAlertLayoutKey = nil
        }
        predictionAlertTitle.contentsScale = window.screen.scale
        predictionAlertDetail.contentsScale = window.screen.scale
        let hidden = text == nil || panelOpen
        if predictionAlert.isHidden != hidden { predictionAlert.isHidden = hidden }
        if !hidden { layoutPredictionAlert() }
    }

    private func layoutPredictionAlert() {
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 100, safe.height > 80 else { return }
        // The centered banner leaves the left power control and right-side
        // controls clear, and stays inside the home-indicator safe area.
        let width = min(390, max(100, safe.width - 104))
        let detail = predictionAlertDetail.string as? String ?? ""
        let title = predictionAlertTitle.string as? String ?? ""
        let key = "\(safe)|\(traitCollection.preferredContentSizeCategory.rawValue)|\(title)|\(detail)"
        guard predictionAlertLayoutKey != key else { return }
        predictionAlertLayoutKey = key
        let titleFont = UIFontMetrics(forTextStyle: .caption1).scaledFont(
            for: .systemFont(ofSize: 12, weight: .bold), maximumPointSize: 18)
        let detailFont = UIFontMetrics(forTextStyle: .headline).scaledFont(
            for: .systemFont(ofSize: 17, weight: .bold), maximumPointSize: 24)
        let textWidth = width - 28
        let measured = (detail as NSString).boundingRect(
            with: CGSize(width: textWidth, height: .greatestFiniteMagnitude),
            options: [.usesLineFragmentOrigin, .usesFontLeading],
            attributes: [.font: detailFont], context: nil)
        let measuredTitle = (title as NSString).boundingRect(
            with: CGSize(width: textWidth, height: .greatestFiniteMagnitude),
            options: [.usesLineFragmentOrigin, .usesFontLeading],
            attributes: [.font: titleFont], context: nil)
        let titleHeight = max(ceil(titleFont.lineHeight), ceil(measuredTitle.height)) + 2
        let detailHeight = max(ceil(detailFont.lineHeight), ceil(measured.height) + 2)
        let height = titleHeight + detailHeight + 16
        predictionAlert.frame = CGRect(x: safe.midX - width / 2, y: safe.maxY - height,
                                       width: width, height: height)
        predictionAlert.shadowPath = UIBezierPath(roundedRect: predictionAlert.bounds, cornerRadius: 12).cgPath
        predictionAlertAccent.frame = CGRect(x: 5, y: 10, width: 3, height: height - 20)
        predictionAlertTitle.font = titleFont
        predictionAlertTitle.fontSize = titleFont.pointSize
        predictionAlertTitle.frame = CGRect(x: 14, y: 7, width: textWidth, height: titleHeight)
        predictionAlertDetail.font = detailFont
        predictionAlertDetail.fontSize = detailFont.pointSize
        predictionAlertDetail.frame = CGRect(x: 14, y: titleHeight + 7, width: textWidth, height: detailHeight)
    }

    private func reportDraw(paths: Int, finalPositions: Int, guidePoints: Int) {
        drawCount += 1
        let predictionVisible = paths > 0 || finalPositions > 0
        if !predictionVisible { emptyDrawCount += 1 }
        if let previous = lastPredictionVisible, previous != predictionVisible { predictionVisibilityChanges += 1 }
        lastPredictionVisible = predictionVisible
        let now = ProcessInfo.processInfo.systemUptime
        if let age = model.captureAgeMilliseconds(at: now) {
            renderAgeCount += 1
            renderAgeTotalMilliseconds += age
            renderAgeMaximumMilliseconds = max(renderAgeMaximumMilliseconds, age)
        }
        guard now - lastDrawReport >= 1 else { return }
        let currentWindow = view.window
        let visibleWindows = (currentWindow?.windowScene?.windows ?? UIApplication.shared.windows)
            .filter { !$0.isHidden && $0.alpha > 0.01 }
        model.recordOverlayEvent("overlay.draw.interval", details: [
            "intervalSeconds": String(format: "%.3f", now - lastDrawReport),
            "draws": String(drawCount),
            "requests": String(drawGate.requests),
            "coalescedRequests": String(drawGate.coalescedRequests),
            "emptyPredictionDraws": String(emptyDrawCount),
            "predictionVisibilityChanges": String(predictionVisibilityChanges),
            "paths": String(paths),
            "finalPositions": String(finalPositions),
            "guidePoints": String(guidePoints),
            "captureToCommitSamples": String(renderAgeCount),
            "captureToCommitMeanMs": renderAgeCount > 0 ? String(format: "%.3f", renderAgeTotalMilliseconds / Double(renderAgeCount)) : "unavailable",
            "captureToCommitMaxMs": renderAgeCount > 0 ? String(format: "%.3f", renderAgeMaximumMilliseconds) : "unavailable",
            "windowHidden": String(currentWindow?.isHidden ?? true),
            "windowAlpha": String(Double(currentWindow?.alpha ?? 0)),
            "highestVisibleWindowLevel": String(Double(visibleWindows.map { $0.windowLevel.rawValue }.max() ?? 0)),
            "panelOpen": String(panelOpen),
            "panelHidden": String(panelContainer.isHidden)
        ])
        lastDrawReport = now
        drawCount = 0
        drawGate.resetIntervalMetrics()
        emptyDrawCount = 0
        predictionVisibilityChanges = 0
        renderAgeCount = 0
        renderAgeTotalMilliseconds = 0
        renderAgeMaximumMilliseconds = 0
    }

    private func styledColor(_ id: Int) -> UIColor {
        let color: UIColor
        switch model.pathColorMode {
        case "mint": color = UIColor(red: 0.28, green: 0.95, blue: 0.82, alpha: 1)
        case "white": color = .white
        default: color = Self.traceColor(id)
        }
        return color.withAlphaComponent(CGFloat(model.pathOpacity))
    }

    private static func traceColor(_ id: Int) -> UIColor {
        switch id {
        case 0: return UIColor(red: 0.28, green: 0.95, blue: 0.82, alpha: 0.96)
        case 1, 9: return .systemYellow
        case 2, 10: return .systemBlue
        case 3, 11: return .systemRed
        case 4, 12: return .systemPurple
        case 5, 13: return .systemOrange
        case 6, 14: return .systemGreen
        case 7, 15: return .systemPink
        default: return .white
        }
    }
}

@MainActor
private struct PLIntegratedPanel: View {
    @ObservedObject var model: IntegratedGameModel
    @ObservedObject var authorization: AppModel
    let close: () -> Void
    let beginLogin: () -> Void
    let shareDiagnostics: () -> Void
    let accessChanged: (Bool) -> Void
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @ScaledMetric(relativeTo: .caption) private var statusLineHeight: CGFloat = 16
    @State private var section = 0
    @State private var showTwoFactor = false
    @State private var confirmForget = false

    var body: some View {
        GeometryReader { geometry in
            let columns = PLOverlayGeometry.usesColumns(width: geometry.size.width,
                                                        accessibility: dynamicTypeSize.isAccessibilitySize)
            VStack(spacing: 0) {
                header(inlineNavigation: columns && authorization.canUseModules)
                if authorization.canUseModules && !columns { navigation.padding(.horizontal, 18).padding(.bottom, 12) }
                ScrollView {
                    Group {
                        if authorization.canUseModules {
                            if section == 0 { visualization(columns: columns) }
                            else if section == 1 { automation(columns: columns) }
                            else { settings(columns: columns) }
                        } else { login.padding(.horizontal, 22) }
                    }
                    .padding(.top, 10)
                    .padding(.bottom, 24)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .font(.subheadline)
        .foregroundColor(.white)
        .tint(PoolTheme.accent)
        .background(PoolTheme.background)
        // Keep the persistent host and disable implicit animation on live data.
        .transaction { $0.animation = nil; $0.disablesAnimations = true }
        .onChange(of: authorization.canUseModules) { allowed in
            model.authorizationChanged()
            accessChanged(allowed)
        }
        .confirmationDialog("Remover a chave salva neste iPhone?", isPresented: $confirmForget, titleVisibility: .visible) {
            Button("Remover chave e sair", role: .destructive) {
                Task { await authorization.forgetLicense() }
            }
            Button("Cancelar", role: .cancel) { }
        } message: {
            Text("Na próxima abertura, será necessário informar a chave novamente.")
        }
    }

    private func header(inlineNavigation: Bool) -> some View {
        HStack(spacing: 10) {
            HStack(spacing: 8) {
                if let logo = PLBrandAssets.mark {
                    Image(uiImage: logo).resizable().scaledToFit()
                        .frame(width: 32, height: 32)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .accessibilityHidden(true)
                }
                Text("SDKPool").font(.headline.weight(.bold)).tracking(0.7)
            }
            .fixedSize(horizontal: true, vertical: false)
            Spacer(minLength: 0)
            if inlineNavigation { navigation.frame(maxWidth: 390) }
            Spacer(minLength: 0)
            if model.autoPlayEnabled || model.singleShotRequested {
                Button { model.setAutoPlay(false) } label: {
                    Label("Parar", systemImage: "stop.fill")
                        .font(.caption.weight(.bold)).padding(.horizontal, 10)
                        .frame(minHeight: 44)
                        .foregroundColor(.white)
                        .background(Color(red: 0.68, green: 0.09, blue: 0.09))
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Parar jogo automático")
            }
            Button(action: close) {
                Image(systemName: "xmark").font(.body.weight(.semibold))
                    .frame(width: 44, height: 44)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .foregroundColor(PoolTheme.secondary)
            .accessibilityLabel("Fechar painel e voltar à partida")
        }
        .padding(.horizontal, 20).padding(.vertical, 12)
    }

    private var navigation: some View {
        HStack(spacing: 0) {
            navigationButton("Visualização", index: 0)
            navigationButton("Automação", index: 1)
            navigationButton("Ajustes", index: 2)
        }
        .padding(3).background(PoolTheme.elevated)
        .clipShape(Capsule())
    }

    private func navigationButton(_ label: String, index: Int) -> some View {
        Button { section = index } label: {
            Text(label).font(.subheadline.weight(section == index ? .semibold : .regular))
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, minHeight: 44)
                .foregroundColor(section == index ? .white : PoolTheme.secondary)
                .background {
                    if section == index { Capsule().fill(PoolTheme.highlight) }
                }
                .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(section == index ? [.isSelected] : [])
    }

    // A single scrolling content plane, with no card stack. The separators
    // follow the tallest column instead of changing with each live status.
    @ViewBuilder
    private func threeColumns<A: View, B: View, C: View>(
        wide: Bool,
        @ViewBuilder first: () -> A,
        @ViewBuilder second: () -> B,
        @ViewBuilder third: () -> C
    ) -> some View {
        if wide {
            HStack(alignment: .top, spacing: 0) {
                first().frame(maxWidth: .infinity, alignment: .topLeading).padding(.horizontal, 22)
                second().frame(maxWidth: .infinity, alignment: .topLeading).padding(.horizontal, 22)
                third().frame(maxWidth: .infinity, alignment: .topLeading).padding(.horizontal, 22)
            }
            .overlay {
                GeometryReader { bounds in
                    Path { path in
                        for fraction in [CGFloat(1) / 3, CGFloat(2) / 3] {
                            let x = bounds.size.width * fraction
                            path.move(to: CGPoint(x: x, y: 0))
                            path.addLine(to: CGPoint(x: x, y: bounds.size.height))
                        }
                    }.stroke(PoolTheme.border, lineWidth: 1)
                }.allowsHitTesting(false).accessibilityHidden(true)
            }
        } else {
            VStack(alignment: .leading, spacing: 22) {
                first()
                Divider().overlay(PoolTheme.border)
                second()
                Divider().overlay(PoolTheme.border)
                third()
            }.padding(.horizontal, 22)
        }
    }

    private func visualization(columns: Bool) -> some View {
        threeColumns(wide: columns) {
            VStack(alignment: .leading, spacing: 8) {
                columnTitle("Previsão")
                valueSlider("Força inicial", value: model.referencePreviewPower,
                            display: "\(Int((model.referencePreviewPower * 100).rounded()))%",
                            range: 0.05...1, step: 0.01, set: model.setReferencePreviewPower)
                controlToggle("Bolas projetadas", value: model.showFinalPositions, set: model.setShowFinalPositions)
                controlToggle("Linhas do percurso", value: model.showTrajectories, set: model.setShowTrajectories)
                controlToggle("Marcas nas caçapas", value: model.showPocketMarkers, set: model.setShowPocketMarkers)
                controlToggle("Percurso de todas as bolas", value: model.showAllPaths, set: model.setShowAllPaths)
                Text(model.previewPowerCaption).font(.caption).foregroundColor(PoolTheme.secondary)
                    .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
                Text("Ao puxar o taco, a prévia acompanha a força do jogo.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        } second: {
            VStack(alignment: .leading, spacing: 8) {
                columnTitle("Alertas")
                controlToggle("Bola na caçapa", value: model.alertPotEnabled, set: model.setAlertPotEnabled)
                controlToggle("Branca na caçapa", value: model.alertScratchEnabled, set: model.setAlertScratchEnabled)
                Text("Os avisos acompanham a previsão válida da tacada.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true).padding(.top, 8)
                Text(model.currentPredictionAlert ?? "Nenhum alerta na prévia atual.")
                    .font(.caption.weight(.medium)).foregroundColor(PoolTheme.warning)
                    .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
                Divider().overlay(PoolTheme.border).padding(.vertical, 10)
                columnTitle("Mesa")
                stateLine(model.hasTable ? "Mesa conectada" : "Aguardando a mesa", active: model.hasTable)
                Text(model.hasTable ? (model.isPlayerTurn ? "Sua vez" : "Vez do adversário") : "Entre em uma partida para iniciar a leitura.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .lineLimit(2).frame(maxWidth: .infinity, minHeight: statusLineHeight * 2, alignment: .topLeading)
                Text(model.status).font(.caption).foregroundColor(PoolTheme.secondary)
                    .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
            }
        } third: {
            styleControls
        }
    }

    private var styleControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            columnTitle("Estilo")
            optionPicker("Bolas", value: model.projectedBallStyle,
                         options: [("Preenchidas", "filled"), ("Contorno", "outline")], set: model.setProjectedBallStyle)
            optionPicker("Linhas", value: model.pathStyle,
                         options: [("Neon", "neon"), ("Sólidas", "solid"), ("Tracejadas", "dashed")], set: model.setPathStyle)
            optionPicker("Cor", value: model.pathColorMode,
                         options: [("Por bola", "balls"), ("Verde", "mint"), ("Branco", "white")], set: model.setPathColorMode)
            valueSlider("Espessura", value: model.pathWidth,
                        display: String(format: "%.2g", model.pathWidth), range: 1...4, step: 0.25, set: model.setPathWidth)
            valueSlider("Opacidade", value: model.pathOpacity,
                        display: "\(Int((model.pathOpacity * 100).rounded()))%", range: 0.3...1, step: 0.05, set: model.setPathOpacity)
            optionPicker("Caçapas", value: model.pocketMarkerStyle,
                         options: [("Seta", "arrow"), ("Anel", "ring")], set: model.setPocketMarkerStyle)
            controlToggle("Números nas bolas", value: model.showFinalNumbers, set: model.setShowFinalNumbers)
        }
    }

    private func automation(columns: Bool) -> some View {
        threeColumns(wide: columns) {
            suggestions
        } second: {
            VStack(alignment: .leading, spacing: 12) {
                columnTitle("Mira automática")
                Button { model.autoAim() } label: {
                    Label("Calcular e aplicar mira", systemImage: "scope")
                }
                .buttonStyle(PLPanelButtonStyle()).disabled(!model.canRequestAutoAim)
                Text("Escolhe uma sugestão e ajusta a direção e a força. A tacada fica por sua conta.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Text(model.aimActionReadiness)
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
                Divider().overlay(PoolTheme.border).padding(.vertical, 4)
                columnTitle("Jogo automático")
                if model.autoPlayEnabled || model.singleShotRequested {
                    Button { model.setAutoPlay(false) } label: {
                        Label("PARAR AUTOMÁTICO", systemImage: "stop.fill")
                    }
                    .buttonStyle(PLStopButtonStyle())
                    .accessibilityHint("Interrompe as próximas ações. Uma tacada já enviada continua no jogo.")
                } else {
                    Button { model.setAutoPlay(true) } label: {
                        Label("Jogar esta partida", systemImage: "play.fill")
                    }
                    .buttonStyle(PoolPrimaryButtonStyle()).disabled(!model.canEnableAutoPlay)
                    Button { model.autoShot() } label: {
                        Label("Executar uma tacada", systemImage: "play.circle")
                    }
                    .buttonStyle(PLPanelButtonStyle()).disabled(!model.canRequestAutoShot)
                }
                stateLine(model.autoPlayEnabled ? "Automático ligado" : "Automático desligado", active: model.autoPlayEnabled)
                Text(model.automationStatus).font(.caption).foregroundColor(PoolTheme.secondary)
                    .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
                Text(model.canEnableAutoPlay || model.autoPlayEnabled
                     ? "Feche o menu para começar. Ao reabrir, o automático pausa."
                     : model.autoShotUnavailableReason)
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
                Text("Válido para esta partida. Entre na próxima sala pelo jogo e ative novamente.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        } third: {
            diagnostics
        }
    }

    private var suggestions: some View {
        VStack(alignment: .leading, spacing: 10) {
            columnTitle("Sugestões de tacada")
            Button { model.recommend() } label: {
                HStack(spacing: 8) {
                    if model.isPlanning { ProgressView().tint(PoolTheme.accent) }
                    Text(model.isPlanning ? "Calculando…" : "Buscar sugestões")
                }
            }
            .buttonStyle(PLPanelButtonStyle())
            .disabled(!model.canRecommend || model.isPlanning || model.autoPlayEnabled || model.singleShotRequested)
            Text(model.suggestionStatus).font(.caption).foregroundColor(PoolTheme.secondary)
                .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
            ForEach(model.suggestions) { suggestion in
                suggestionButton(suggestion)
            }
            Button { model.applySelectedSuggestion() } label: {
                Label("Aplicar mira da prévia", systemImage: "scope")
            }
            .buttonStyle(PLPanelButtonStyle()).disabled(!model.canApplySelectedSuggestion)
            if !model.followGameAim {
                Button { model.setFollowGameAim(true) } label: {
                    Label("Voltar à mira do jogo", systemImage: "arrow.uturn.backward")
                }
                .buttonStyle(PLPanelButtonStyle())
                .accessibilityHint("Descarta a prévia selecionada e volta a acompanhar a mira do jogo.")
            }
            Text("Toque numa opção para ver a prévia. Aplicar ajusta a mira sem disparar.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func suggestionButton(_ suggestion: ShotSuggestion) -> some View {
        let selected = model.selectedSuggestionID == suggestion.id
        let method: String
        switch suggestion.method {
        case .direct: method = "Direta"
        case .bank: method = "Tabela"
        case .breakShot: method = "Saída"
        }
        return Button { model.selectSuggestion(suggestion) } label: {
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 6) {
                    Text(suggestion.method == .breakShot ? "Tacada de saída" : "Bola \(suggestion.targetID)")
                        .font(.subheadline.weight(.semibold))
                    Spacer(minLength: 0)
                    if selected { Image(systemName: "checkmark.circle.fill").foregroundColor(PoolTheme.accent) }
                }
                Text(suggestion.method == .breakShot
                     ? "\(method) · força \(model.powerLabel(for: suggestion))"
                     : "Caçapa \(suggestion.pocketID + 1) · \(method.lowercased()) · \(model.powerLabel(for: suggestion))")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 10).padding(.vertical, 9)
            .frame(maxWidth: .infinity, minHeight: 52, alignment: .leading)
            .background(PoolTheme.elevated)
            .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .stroke(selected ? PoolTheme.accent : PoolTheme.border, lineWidth: selected ? 1.5 : 1)
            }
        }
        .buttonStyle(.plain).disabled(!model.canSelectSuggestions)
        .opacity(model.canSelectSuggestions ? 1 : 0.45)
        .accessibilityHint("Mostra a previsão desta sugestão sem alterar a mira no jogo.")
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }

    private var diagnostics: some View {
        VStack(alignment: .leading, spacing: 12) {
            columnTitle("Diagnóstico")
            Text(model.telemetryStatus).font(.caption).foregroundColor(PoolTheme.secondary)
                .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
            Button(model.telemetryRecording ? "Parar gravação" : "Gravar 30 segundos") { model.toggleTelemetry() }
                .buttonStyle(PLPanelButtonStyle())
                .disabled(!model.hasTable && !model.telemetryRecording)
            Button { shareDiagnostics() } label: {
                Label("Exportar diagnóstico", systemImage: "square.and.arrow.up")
            }
            .buttonStyle(PLPanelButtonStyle()).disabled(model.telemetryFrames == 0)
            Text("Registra a leitura e os bloqueios do cálculo. A chave de acesso não entra no arquivo.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Divider().overlay(PoolTheme.border).padding(.vertical, 4)
            columnTitle("Leitura ao vivo")
            metricRow("Capturas/s", value: String(format: "%.1f", model.captureRate))
            metricRow("Previsão", value: String(format: "%.0f ms", model.predictionMilliseconds))
            metricRow("Sugestões", value: String(format: "%.0f ms", model.planningMilliseconds))
            metricRow("Idade da leitura", value: String(format: "%.1f ms", model.sampleAgeMilliseconds))
            metricRow("Captura", value: String(format: "%.1f ms", model.captureMilliseconds))
            Text(model.liveReadiness).font(.caption).foregroundColor(PoolTheme.secondary)
                .lineLimit(3).frame(maxWidth: .infinity, minHeight: statusLineHeight * 3, alignment: .topLeading)
            controlToggle("Conferir centros das bolas", value: model.showLivePositions, set: model.setShowLivePositions)
            DisclosureGroup("Detalhes da leitura") {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(model.nativeDiagnostics.keys.sorted(), id: \.self) { key in
                        Text("\(key): \(model.nativeDiagnostics[key] ?? "")")
                            .font(.system(.caption, design: .monospaced))
                            .textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
                    }
                }.frame(maxWidth: .infinity, alignment: .leading).padding(.top, 12)
            }.font(.caption.weight(.semibold)).frame(minHeight: 44)
        }
    }

    private func settings(columns: Bool) -> some View {
        threeColumns(wide: columns) {
            account
        } second: {
            VStack(alignment: .leading, spacing: 12) {
                columnTitle("Preferências")
                stateLine("Estilo salvo no iPhone", active: true)
                Text("As alterações em Visualização são salvas automaticamente neste dispositivo.")
                    .font(.subheadline).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Divider().overlay(PoolTheme.border).padding(.vertical, 8)
                metricRow("Força inicial", value: "\(Int((model.referencePreviewPower * 100).rounded()))%")
                metricRow("Espessura", value: String(format: "%.2g", model.pathWidth))
                metricRow("Opacidade", value: "\(Int((model.pathOpacity * 100).rounded()))%")
                Text("O efeito deve estar centralizado para a prévia inicial da tacada.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        } third: {
            VStack(alignment: .leading, spacing: 12) {
                columnTitle("Sobre")
                Text("SDKPool").font(.title3.weight(.semibold))
                Text("SDKPool 1.7 · compilação 9").font(.caption).foregroundColor(PoolTheme.secondary)
                Text("Previsão ao vivo, controle visual e diagnóstico da mesa.")
                    .foregroundColor(PoolTheme.secondary).fixedSize(horizontal: false, vertical: true)
                Divider().overlay(PoolTheme.border).padding(.vertical, 8)
                Text("Para conferir uma falha, grave e exporte o diagnóstico na aba Automação.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Text("As trajetórias são estimativas físicas; o estado da leitura aparece em tempo real.")
                    .font(.caption).foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var account: some View {
        VStack(alignment: .leading, spacing: 12) {
            columnTitle("Seu acesso")
            Label(authorization.statusText, systemImage: "checkmark.circle.fill")
                .font(.subheadline.weight(.medium)).foregroundColor(PoolTheme.success)
                .fixedSize(horizontal: false, vertical: true)
            Text(authorization.hasRememberedLicense
                 ? "A chave está salva neste iPhone. O acesso será validado automaticamente ao abrir o jogo."
                 : "A chave não está salva neste dispositivo.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
            if let notice = authorization.credentialNotice {
                Text(notice).font(.caption).foregroundColor(PoolTheme.warning)
            }
            Button("Encerrar esta sessão") { Task { await authorization.signOut() } }
                .buttonStyle(PLPanelButtonStyle())
            Text("A chave continua salva. Use a opção abaixo para removê-la do dispositivo.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Button("Remover chave salva", role: .destructive) { confirmForget = true }
                .buttonStyle(PLPanelButtonStyle(destructive: true))
                .disabled(!authorization.hasRememberedLicense)
        }
    }

    private var login: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(authorization.hasRememberedLicense ? "Bom ter você de volta" : "Ative seu acesso")
                .font(.title3.bold())
            Text("Depois de validar, a chave fica salva neste iPhone.")
                .font(.callout).foregroundColor(PoolTheme.secondary)
            if let issue = authorization.configurationIssue {
                Text(issue).font(.caption).foregroundColor(PoolTheme.warning)
            }
            if authorization.session != nil {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(authorization.statusText).font(.callout)
                }.frame(minHeight: 44)
                Button("Encerrar esta sessão") { Task { await authorization.signOut() } }
                    .frame(minHeight: 44).buttonStyle(.bordered)
            } else {
                Text("Chave de acesso").font(.subheadline.weight(.semibold))
                SecureField("Cole ou digite sua chave", text: $authorization.licenseKey)
                    .textInputAutocapitalization(.never).disableAutocorrection(true)
                    .poolField()
                if #available(iOS 16.0, *) {
                    PasteButton(payloadType: String.self) { values in
                        if let value = values.first { _ = authorization.pasteLicense(value) }
                    }
                    .labelStyle(.titleAndIcon).frame(minHeight: 44)
                    .accessibilityLabel("Colar chave de acesso")
                } else {
                    Button { authorization.pasteFromClipboard() } label: {
                        Label("Colar chave", systemImage: "doc.on.clipboard")
                            .frame(minHeight: 44)
                    }.buttonStyle(.bordered)
                }
                if let notice = authorization.clipboardNotice {
                    Text(notice).font(.caption).foregroundColor(PoolTheme.secondary)
                }
                DisclosureGroup("Código adicional", isExpanded: $showTwoFactor) {
                    TextField("Código de autenticação", text: $authorization.twoFactorCode)
                        .keyboardType(.numberPad).textContentType(.oneTimeCode)
                        .poolField().padding(.top, 10)
                }.font(.subheadline).frame(minHeight: 44)
                if case .error(let error) = authorization.phase {
                    Text(error).font(.callout).foregroundColor(PoolTheme.warning)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Button {
                    Task { await authorization.activate(); model.authorizationChanged() }
                } label: {
                    HStack(spacing: 10) {
                        if authorization.phase == .authenticating { ProgressView().tint(.white) }
                        Text(authorization.phase == .authenticating ? "Validando acesso…" : "Entrar e salvar chave")
                    }
                }
                .buttonStyle(PoolPrimaryButtonStyle())
                .disabled(authorization.configurationIssue != nil || authorization.phase == .authenticating ||
                          (authorization.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !authorization.hasRememberedLicense))
                if authorization.hasRememberedLicense {
                    Button("Usar outra chave") { confirmForget = true }
                        .frame(minHeight: 44).buttonStyle(.bordered)
                }
            }
            if let notice = authorization.credentialNotice {
                Text(notice).font(.caption).foregroundColor(PoolTheme.warning)
            }
            Text("É necessário ter conexão para validar o acesso.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
        }
        .simultaneousGesture(TapGesture().onEnded { beginLogin() })
    }

    private func columnTitle(_ title: String) -> some View {
        Text(title).font(.headline.weight(.semibold))
            .frame(maxWidth: .infinity, minHeight: 28, alignment: .leading)
            .padding(.bottom, 4)
    }

    private func stateLine(_ title: String, active: Bool) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Image(systemName: active ? "checkmark.circle.fill" : "circle.dashed")
                .foregroundColor(active ? PoolTheme.success : PoolTheme.secondary)
            Text(title).font(.subheadline.weight(.medium))
                .fixedSize(horizontal: false, vertical: true)
        }.frame(maxWidth: .infinity, minHeight: 36, alignment: .leading)
    }

    private func metricRow(_ title: String, value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text(title).font(.caption).foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            Text(value).font(.system(.subheadline, design: .monospaced).weight(.medium))
                .fixedSize(horizontal: true, vertical: false)
        }.frame(minHeight: 32)
    }

    private func controlToggle(_ title: String, value: Bool, set: @escaping (Bool) -> Void) -> some View {
        Toggle(title, isOn: Binding(get: { value }, set: set))
            .toggleStyle(PLCircleToggleStyle())
    }

    private func valueSlider(_ title: String, value: Double, display: String,
                             range: ClosedRange<Double>, step: Double,
                             set: @escaping (Double) -> Void) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text(title).font(.caption)
                Spacer(minLength: 4)
                Text(display).font(.caption.weight(.medium)).monospacedDigit()
                    .foregroundColor(PoolTheme.accent)
            }
            Slider(value: Binding(get: { value }, set: set), in: range, step: step)
                .frame(minHeight: 44)
                .accessibilityLabel(title).accessibilityValue(display)
        }
    }

    private func optionPicker(_ title: String, value: String,
                              options: [(label: String, value: String)],
                              set: @escaping (String) -> Void) -> some View {
        HStack(spacing: 8) {
            Menu {
                Picker(title, selection: Binding(get: { value }, set: set)) {
                    ForEach(options, id: \.value) { item in Text(item.label).tag(item.value) }
                }
            } label: {
                HStack(spacing: 6) {
                    Text(options.first { $0.value == value }?.label ?? value)
                        .font(.caption.weight(.medium)).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.down").font(.system(size: 9, weight: .semibold))
                        .accessibilityHidden(true)
                }
                .foregroundColor(.white).padding(.horizontal, 10)
                .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                .background(PoolTheme.elevated)
                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            }
            .accessibilityLabel(title)
            .accessibilityValue(options.first { $0.value == value }?.label ?? value)
            Text(title).font(.caption).frame(width: 60, alignment: .leading)
        }
    }
}

private struct PLCircleToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        Button { configuration.isOn.toggle() } label: {
            HStack(spacing: 10) {
                ZStack {
                    Circle().fill(PoolTheme.elevated)
                    if configuration.isOn {
                        Circle().fill(PoolTheme.highlight)
                        Image(systemName: "checkmark").font(.system(size: 11, weight: .bold))
                            .foregroundColor(.white)
                    } else {
                        Circle().stroke(Color.white.opacity(0.4), lineWidth: 1.5)
                    }
                }.frame(width: 24, height: 24).accessibilityHidden(true)
                configuration.label.font(.subheadline).foregroundColor(.white)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityValue(configuration.isOn ? "Ativado" : "Desativado")
    }
}

private struct PLPanelButtonStyle: ButtonStyle {
    var destructive = false
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.subheadline.weight(.medium))
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, 10)
            .foregroundColor(destructive ? PoolTheme.accent : .white)
            .background(PoolTheme.elevated)
            .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            .opacity(isEnabled ? (configuration.isPressed ? 0.75 : 1) : 0.45)
    }
}

private struct PLStopButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.subheadline.weight(.bold))
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, minHeight: 48)
            .padding(.horizontal, 10)
            .foregroundColor(.white)
            .background(Color(red: 0.68, green: 0.09, blue: 0.09))
            .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            .opacity(configuration.isPressed ? 0.75 : 1)
    }
}
