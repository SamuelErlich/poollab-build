import Foundation
import UIKit
import Combine
import PoolLabCore

/// CADisplayLink retains its target; this proxy does not retain the model.
@MainActor
private final class PLFrameCaptureTarget: NSObject {
    weak var model: IntegratedGameModel?
    @objc func tick(_ link: CADisplayLink) { model?.captureFrame(at: link.timestamp) }
}

/// Runtime calls remain on the main thread. The two independent workers only
/// receive copied values: following the cue never cancels the shot planner.
@MainActor
final class IntegratedGameModel: ObservableObject {
    let authorization: AppModel
    @Published private(set) var status = "Ative sua licença para ler a mesa da partida."
    @Published private(set) var hasTable = false
    @Published private(set) var isPlayerTurn = false
    @Published private(set) var isMoving = false
    @Published private(set) var angleDegrees = 270.0
    @Published private(set) var power = 0.45
    /// A local visualization input while the real cue is at rest. This is
    /// never sent to the game unless a separate, explicit aim action is used.
    @Published private(set) var referencePreviewPower = 0.45
    @Published private(set) var previewUsesReferencePower = false
    @Published private(set) var aimAvailable = false
    @Published private(set) var isCalibrated = false
    @Published private(set) var hasNativePhysics = false
    @Published private(set) var shotInputSupported = false
    @Published private(set) var shotInputUnavailableReason = "Aguardando a leitura do efeito selecionado."
    @Published private(set) var followGameAim = true
    @Published private(set) var showTrajectories = true
    @Published private(set) var showAllPaths = true
    @Published private(set) var showFinalPositions = true
    @Published private(set) var showFinalNumbers = true
    @Published private(set) var pathWidth = 2.0
    @Published private(set) var pathOpacity = 0.9
    @Published private(set) var pathColorMode = "balls"
    @Published private(set) var pathStyle = "neon"
    @Published private(set) var projectedBallStyle = "filled"
    @Published private(set) var pocketMarkerStyle = "arrow"
    @Published private(set) var showPocketMarkers = true
    @Published private(set) var keepPreview = true
    @Published private(set) var previewPowerLocked = false
    @Published private(set) var alertPotEnabled = true
    @Published private(set) var alertScratchEnabled = true
    @Published private(set) var showOpponentPreview = false
    @Published private(set) var opponentPreviewAvailable = false
    @Published private(set) var opponentPreviewReason = "Aguardando dados da mira do adversário."
    @Published private(set) var isPredicting = false
    @Published private(set) var isPlanning = false
    @Published private(set) var suggestions: [ShotSuggestion] = []
    @Published private(set) var ballCount = 0
    @Published private(set) var previewDuration: Double?
    @Published private(set) var autoPlayEnabled = false
    @Published private(set) var isWaitingForShot = false
    @Published private(set) var autoShotAvailable = false
    @Published private(set) var autoShotUnavailableReason = "Entre em uma partida para conferir os controles."
    @Published private(set) var automationStatus = "Jogo automático desligado."
    @Published private(set) var blockInterstitialAds = false
    @Published private(set) var autoQueueEnabled = false
    @Published private(set) var queueStatus = "Próxima partida automática desligada."
    @Published private(set) var isLuckyShot = false
    @Published private(set) var luckySuggestion: LuckyShotSuggestion?
    @Published private(set) var luckyStatus = "Aguardando o alvo da Lucky Shot."
    @Published private(set) var singleShotRequested = false
    @Published private(set) var showLivePositions = false
    @Published private(set) var captureRate = 0.0
    @Published private(set) var predictionMilliseconds = 0.0
    @Published private(set) var captureMilliseconds = 0.0
    @Published private(set) var liveReadiness = "Aguardando a mesa."
    @Published private(set) var telemetryRecording = false
    @Published private(set) var telemetryFrames = 0
    @Published private(set) var telemetryStatus = "Grave a mira e uma tacada para conferir as leituras."
    @Published private(set) var sampleAgeMilliseconds = 0.0
    @Published private(set) var nativeDiagnostics: [String: String] = [:]

    var onOverlayChange: (() -> Void)?
    private var isForeground = false
    private var captureLink: CADisplayLink?
    private var frameTarget: PLFrameCaptureTarget?
    private var lastFrameAt: TimeInterval = 0
    private var lastQueuePollAt: TimeInterval = 0
    private var rateWindowAt: TimeInterval = 0
    private var capturesInWindow = 0
    private var lastNativeAim: (angle: Double, power: Double)?
    private var previewIsTemporary = false
    private var lastTelemetryAt: TimeInterval = 0
    private var telemetryStartedAt: TimeInterval = 0
    private var telemetry: [[String: Any]] = []
    private var predictionCompletedAt: TimeInterval = 0
    private var lastPredictionMetricsAt: TimeInterval = 0
    private var lastPredictionComputeMilliseconds = 0.0
    private struct PredictionRequest {
        let state: TableState
        let shot: ShotParameters?
        let capturedAt: TimeInterval
        let nativeFrame: UInt64
        let opponentCue: Bool
        let coordinateIdentity: ObjectIdentifier
        let goldenObstacleIDs: Set<Int>?
        var usesReferencePower = false
    }
    private var pendingPrediction: PredictionRequest?
    private var activePrediction: PredictionRequest?
    private var acceptedPrediction: PredictionRequest?
    private var requestedPreviewShot: ShotParameters?
    private var requestedPreviewUsesReferencePower = false
    private var lastMovingPredictionRequestAt: TimeInterval = 0
    private var authorizationObserver: AnyCancellable?
    private var predictionTask: Task<Void, Never>?
    private var plannerTask: Task<Void, Never>?
    private var predictionGeneration: UInt64 = 0
    private var plannerGeneration: UInt64 = 0
    private var planningPurpose: PlanningPurpose?
    private var snapshot: PLGameSnapshot?
    private var tableState: TableState?
    private var traces: [BallTrace] = []
    private var finalBalls: [PoolBall] = []
    private var predictedFrames: [SimulationFrame] = []
    private var predictedPockets: [(ball: Int, pocket: Int)] = []
    private var predictedScratch = false
    private var panelIsOpen = false
    private var lockedPreviewPower: Double?
    private var legalTargets: Set<Int> = []
    private var runtimeCanShoot = false
    private var lastAuthorized = false
    private var stableSince: TimeInterval?
    private var shotSubmittedAt: TimeInterval?
    // Kept after a timeout/error. An uncertain command must never be repeated
    // on an unchanged table merely because the user toggles the switch again.
    private var lastSubmittedState: TableState?
    private var attemptedQueueTokens: Set<String> = []
    private struct QueueTransition {
        let token: String
        let deadline: TimeInterval
        var submitted = false
        var observedNewMatch = false
    }
    private var queueTransition: QueueTransition?
    private let queueTransitionTimeout: TimeInterval = 30
    private let styles = UserDefaults.standard
    private let stylePrefix = "PoolLab.Integrated.Overlay."
    private let minimumStableTime: TimeInterval = 0.65
    private let shotStartTimeout: TimeInterval = 4

    private enum PlanningPurpose { case suggestions, applyAim, singleShot, autoPlay, luckyShot }
    var isAuthorized: Bool { isForeground && authorization.canUseModules }
    var canCalculate: Bool { isAuthorized && hasTable && isPlayerTurn && isCalibrated && hasNativePhysics && shotInputSupported && !isMoving && tableState?.cueBall != nil }
    private var canPreviewAim: Bool {
        isAuthorized && hasTable && isCalibrated && hasNativePhysics && shotInputSupported && !isMoving && tableState?.cueBall != nil
            && (isPlayerTurn || (showOpponentPreview && opponentPreviewAvailable && snapshot?.opponentTurn == true))
    }
    var canApplyAim: Bool { canCalculate && isPlayerTurn && !isWaitingForShot }
    var canRecommend: Bool { canCalculate && !legalTargets.isEmpty && !isWaitingForShot }
    var canRequestAutoAim: Bool { canRecommend && canApplyAim && !isPlanning && !autoPlayEnabled && !singleShotRequested }
    var canRequestAutoShot: Bool {
        canRecommend && isPlayerTurn && runtimeCanShoot && autoShotAvailable
            && !isPlanning && !autoPlayEnabled && !singleShotRequested && tableState != lastSubmittedState
    }
    var canEnableAutoPlay: Bool { isAuthorized && hasTable && autoShotAvailable }
    var canCalculateLuckyShot: Bool {
        canCalculate && isLuckyShot && snapshot?.goldenTargetAvailable == true && !isPlanning && !isWaitingForShot
    }

    init(authorization: AppModel) {
        self.authorization = authorization
        showTrajectories = boolStyle("paths", fallback: true)
        showAllPaths = boolStyle("allPaths", fallback: true)
        showFinalPositions = boolStyle("endpoints", fallback: true)
        showFinalNumbers = boolStyle("numbers", fallback: true)
        pathWidth = numberStyle("width", fallback: 2, range: 1...4)
        pathOpacity = numberStyle("opacity", fallback: 0.9, range: 0.3...1)
        let storedColor = styles.string(forKey: stylePrefix + "color") ?? "balls"
        pathColorMode = ["balls", "mint", "white"].contains(storedColor) ? storedColor : "balls"
        pathStyle = stringStyle("lineStyle", fallback: "neon", allowed: ["neon", "solid", "dashed"])
        projectedBallStyle = stringStyle("ballStyle", fallback: "filled", allowed: ["filled", "outline"])
        pocketMarkerStyle = stringStyle("pocketStyle", fallback: "arrow", allowed: ["arrow", "ring"])
        showPocketMarkers = boolStyle("pockets", fallback: true)
        keepPreview = true
        alertPotEnabled = boolStyle("potAlert", fallback: true)
        alertScratchEnabled = boolStyle("scratchAlert", fallback: true)
        showOpponentPreview = false
        referencePreviewPower = numberStyle("referencePower", fallback: 0.45, range: 0.05...1)
        authorizationObserver = authorization.objectWillChange.sink { [weak self] _ in
            Task { @MainActor [weak self] in self?.authorizationChanged() }
        }
    }

    func becameActive() {
        guard !isForeground else { poll(); return }
        isForeground = true
        startTimer()
        Task { [weak self] in
            guard let self else { return }
            await self.authorization.becameActive()
            guard self.isForeground else { return }
            self.authorizationChanged()
            self.poll()
        }
    }

    func becameInactive() {
        isForeground = false
        captureLink?.invalidate()
        captureLink = nil
        frameTarget = nil
        if telemetryRecording { stopTelemetry() }
        authorization.becameInactive()
        lastAuthorized = false
        clearBoard(message: "Leitura e jogo automático pausados enquanto o aplicativo está inativo.")
    }

    func authorizationChanged() {
        let allowed = isAuthorized
        if !allowed {
            if lastAuthorized || hasTable || predictionTask != nil || plannerTask != nil || autoPlayEnabled || autoQueueEnabled || blockInterstitialAds {
                clearBoard(message: "Acesso pausado. Confirme sua licença para continuar.")
            }
        } else if !lastAuthorized {
            lastAuthorized = true
            poll()
        }
        lastAuthorized = allowed
    }

    func setAutoQueue(_ value: Bool) {
        guard !value || isAuthorized else { return }
        if !value, queueTransition != nil {
            stopAutomation(message: "Retomada automática cancelada junto com a próxima partida.")
        }
        autoQueueEnabled = value
        queueStatus = value ? "Ao terminar, entrar novamente na mesma mesa quando o jogo permitir." : "Próxima partida automática desligada."
        if value { pollQueue() }
    }

    private func pollQueue() {
        guard isAuthorized else { return }
        do {
            // Keep observing the current match even while Auto Queue is off;
            // the bridge requires that evidence before accepting a result.
            let state = try PLQueueBridge.capture()
            if let transition = queueTransition {
                if ProcessInfo.processInfo.systemUptime >= transition.deadline {
                    autoQueueEnabled = false
                    queueStatus = "A próxima mesa não ficou pronta em 30 segundos. Confira a tela do jogo."
                    stopAutomation(message: "Tempo de espera da próxima partida esgotado. Automático desligado.")
                    return
                }
                if transition.submitted, !state.isResultScreen, !state.resultToken.isEmpty,
                   state.resultToken != transition.token {
                    queueTransition?.observedNewMatch = true
                }
            }
            guard autoQueueEnabled else { return }
            if state.isResultScreen, !state.resultToken.isEmpty, autoPlayEnabled, queueTransition == nil {
                // The bridge only issues this token after observing an active
                // match. An arbitrary missing table cannot arm this exception.
                queueTransition = QueueTransition(token: state.resultToken,
                    deadline: ProcessInfo.processInfo.systemUptime + queueTransitionTimeout)
            }
            guard state.isResultScreen else {
                queueStatus = "Aguardando o resultado da partida atual."
                return
            }
            guard state.ready, !state.resultToken.isEmpty else {
                queueStatus = state.unavailableReason
                return
            }
            guard !attemptedQueueTokens.contains(state.resultToken) else {
                queueStatus = "Entrada já solicitada para este resultado. Aguardando a próxima partida."
                return
            }
            attemptedQueueTokens.insert(state.resultToken)
            try PLQueueBridge.startNextMatch(token: state.resultToken)
            if queueTransition?.token == state.resultToken { queueTransition?.submitted = true }
            queueStatus = "Próxima partida solicitada na mesma mesa."
        } catch {
            if queueTransition != nil { stopAutomation(message: "Retomada interrompida: \(error.localizedDescription)") }
            guard autoQueueEnabled else { return }
            autoQueueEnabled = false
            queueStatus = "Próxima partida automática interrompida: \(error.localizedDescription)"
        }
    }

    func setBlockInterstitialAds(_ value: Bool) {
        guard !value || isAuthorized else { return }
        do {
            try PLAdControl.setBlocking(enabled: value)
            blockInterstitialAds = value
        } catch {
            status = "Não foi possível alterar os anúncios: \(error.localizedDescription)"
        }
    }

    func setAngle(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        followGameAim = false
        previewIsTemporary = true
        if previewUsesReferencePower { previewUsesReferencePower = false }
        angleDegrees = min(360, max(0, value))
        requestPrediction()
    }

    func setPower(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        power = min(1, max(0, value))
        if previewUsesReferencePower { previewUsesReferencePower = false }
        if previewPowerLocked { lockedPreviewPower = power }
        else { followGameAim = false; previewIsTemporary = true }
        requestPrediction()
    }

    var previewPowerCaption: String {
        if isMoving { return "Acompanhando o movimento real" }
        if previewUsesReferencePower { return "Prévia com força de referência: \(Int((referencePreviewPower * 100).rounded()))%" }
        return "Força atual do taco: \(Int((power * 100).rounded()))%"
    }

    func setReferencePreviewPower(_ value: Double) {
        guard value.isFinite else { return }
        let clamped = min(1, max(0.05, value))
        guard referencePreviewPower != clamped else { return }
        referencePreviewPower = clamped
        saveStyle(clamped, "referencePower")
        // Re-read the actual cue. A slider edit during a real pull must not
        // replace its power, and changing this setting never invokes apply().
        if isAuthorized { poll() }
    }

    func setPreviewPowerLocked(_ value: Bool) {
        guard isAuthorized else { return }
        previewPowerLocked = value
        lockedPreviewPower = value ? power : nil
        previewIsTemporary = false
        followGameAim = true
        poll()
        requestPrediction()
    }

    func setFollowGameAim(_ value: Bool) {
        guard isAuthorized else { return }
        followGameAim = value
        previewIsTemporary = false
        if value { poll() }
        requestPrediction()
    }

    func setShowTrajectories(_ value: Bool) { showTrajectories = value; saveStyle(value, "paths") }
    func setShowAllPaths(_ value: Bool) { showAllPaths = value; saveStyle(value, "allPaths") }
    func setShowFinalPositions(_ value: Bool) { showFinalPositions = value; saveStyle(value, "endpoints") }
    func setShowFinalNumbers(_ value: Bool) { showFinalNumbers = value; saveStyle(value, "numbers") }
    func setShowLivePositions(_ value: Bool) { showLivePositions = value; onOverlayChange?() }
    func setShowPocketMarkers(_ value: Bool) { showPocketMarkers = value; saveStyle(value, "pockets") }
    func setKeepPreview(_ value: Bool) { keepPreview = value; saveStyle(value, "keepPreview") }
    func setAlertPotEnabled(_ value: Bool) { alertPotEnabled = value; saveStyle(value, "potAlert") }
    func setAlertScratchEnabled(_ value: Bool) { alertScratchEnabled = value; saveStyle(value, "scratchAlert") }
    func setShowOpponentPreview(_ value: Bool) {
        showOpponentPreview = value; saveStyle(value, "opponentPreview")
        cancelPrediction(clearOverlay: true)
        poll()
        requestPrediction()
    }
    func setPathStyle(_ value: String) {
        guard ["neon", "solid", "dashed"].contains(value) else { return }
        pathStyle = value; saveStyle(value, "lineStyle")
    }
    func setProjectedBallStyle(_ value: String) {
        guard ["filled", "outline"].contains(value) else { return }
        projectedBallStyle = value; saveStyle(value, "ballStyle")
    }
    func setPocketMarkerStyle(_ value: String) {
        guard ["arrow", "ring"].contains(value) else { return }
        pocketMarkerStyle = value; saveStyle(value, "pocketStyle")
    }

    func toggleTelemetry() {
        if telemetryRecording { stopTelemetry(); return }
        guard isAuthorized else { return }
        telemetry = []
        telemetryFrames = 0
        telemetryStartedAt = ProcessInfo.processInfo.systemUptime
        lastTelemetryAt = 0
        telemetryRecording = true
        telemetryStatus = "Gravando até 30 segundos. Mova a mira e execute uma tacada."
    }

    private func stopTelemetry() {
        telemetryRecording = false
        telemetryStatus = "\(telemetryFrames) amostras locais prontas para exportar."
    }

    func exportTelemetry() throws -> URL {
        if telemetryRecording { stopTelemetry() }
        let document: [String: Any] = [
            "format": "SDKPool.LiveCapture", "version": 3, "frameworkBuild": 6,
            "createdAt": ISO8601DateFormatter().string(from: Date()),
            "note": "Native positions, velocities, spin, response coefficients, cue and readiness are measured. Predicted paths and endpoints are calculated estimates, not native future state.",
            "captureHzMeasured": captureRate, "readiness": liveReadiness,
            "status": status, "automationStatus": automationStatus,
            "nativeDiagnostics": nativeDiagnostics, "frames": telemetry
        ]
        let data = try JSONSerialization.data(withJSONObject: document, options: [.prettyPrinted, .sortedKeys])
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("SDKPoolDiagnostics", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent("SDKPool-V6-\(UUID().uuidString).json")
        try data.write(to: url, options: .atomic)
        return url
    }

    private func recordCapture(_ captured: PLGameSnapshot, now: TimeInterval, elapsed: TimeInterval) {
        capturesInWindow += 1
        if rateWindowAt == 0 { rateWindowAt = now }
        if now - rateWindowAt >= 1 {
            captureRate = Double(capturesInWindow) / (now - rateWindowAt)
            captureMilliseconds = elapsed * 1_000
            sampleAgeMilliseconds = max(0, now - captured.captureTimestamp) * 1_000
            nativeDiagnostics = captured.diagnostics
            capturesInWindow = 0
            rateWindowAt = now
        }
        guard telemetryRecording, now - lastTelemetryAt >= 0.095 else { return }
        lastTelemetryAt = now
        func value(_ x: Double) -> Any { x.isFinite ? x : NSNull() }
        func point(_ p: CGPoint) -> [Any] { [value(Double(p.x)), value(Double(p.y))] }
        let balls: [[String: Any]] = captured.balls.map { ball in
            ["id": ball.number, "nativePosition": [value(ball.x), value(ball.y)],
             "nativeVelocity": [value(ball.vx), value(ball.vy)],
             "nativeSpin": [value(ball.spinX), value(ball.spinY), value(ball.spinZ)], "radius": value(ball.radius),
             "visualCenter": point(ball.visualCenter)]
        }
        let currentPrediction = predictionIsCurrent
        let estimates: [[String: Any]] = (currentPrediction ? finalBalls : []).map { ball in
            ["id": ball.id, "normalizedPosition": [value(ball.position.x), value(ball.position.y)],
             "pocketed": ball.pocketed]
        }
        let predictionSource: Any
        if let accepted = acceptedPrediction {
            let sourceBalls: [[String: Any]] = accepted.state.balls.map { ball in
                ["id": ball.id, "position": [ball.position.x, ball.position.y],
                 "velocity": [ball.velocity.x, ball.velocity.y], "spin": [ball.spin.x, ball.spin.y, ball.spin.z]]
            }
            let sourceShot: Any = accepted.shot.map { shot -> [String: Any] in
                let spin = shot.initialSpin ?? .zero
                return ["angleRadians": shot.angleRadians, "simulationPower": shot.power,
                        "initialSpin": [spin.x, spin.y, spin.z]]
            } as Any? ?? NSNull()
            let sourceDynamics: Any = accepted.state.table.nativeDynamics.map { profile -> [String: Any] in
                ["slidingDeceleration": profile.slidingDeceleration, "equilibriumTimeFactor": profile.equilibriumTimeFactor,
                 "spinDeceleration": profile.spinDeceleration, "slidingFrictionCoefficient": profile.slidingFrictionCoefficient,
                 "cushionSpinCoupling": profile.cushionSpinCoupling, "logicalFrameTime": profile.logicalFrameTime]
            } as Any? ?? NSNull()
            predictionSource = ["captureTimestamp": accepted.capturedAt, "nativeFrame": accepted.nativeFrame,
                                "kind": accepted.shot == nil ? "movingContinuation" : (accepted.opponentCue ? "opponentCueShot" : "cueShot"),
                                "usesReferencePower": accepted.usesReferencePower,
                                "normalizedMaximumShotSpeed": accepted.state.table.maximumShotSpeed,
                                "normalizedDynamics": sourceDynamics,
                                "normalizedBalls": sourceBalls,
                                "shot": sourceShot]
        } else { predictionSource = NSNull() }
        telemetry.append([
            "elapsed": now - telemetryStartedAt, "captureTimestamp": value(captured.captureTimestamp),
            "nativeFrame": captured.frameNumber, "balls": balls, "captureCostMs": elapsed * 1_000,
            "tableNativeBounds": [value(captured.originX), value(captured.originY), value(captured.width), value(captured.height)],
            "tableViewCorners": [point(captured.tableTopLeft), point(captured.tableTopRight), point(captured.tableBottomLeft)],
            "projectionResidual": value(captured.projectionResidual),
            "aim": ["available": captured.aimAvailable, "radians": value(captured.aimAngle), "power": value(captured.cuePower), "minimumShotPower": value(captured.minimumShotPower),
                    "shotInputSupported": captured.shotInputSupported, "shotInputReason": captured.shotInputUnavailableReason,
                    "english": [value(captured.cueEnglishX), value(captured.cueEnglishY)]],
            "preview": ["usesReferencePower": previewUsesReferencePower, "referencePower": referencePreviewPower,
                        "controlPower": power, "calculating": isPredicting,
                        "lastCalculationCostMs": lastPredictionComputeMilliseconds],
            "opponentAim": ["available": captured.opponentPreviewAvailable, "age": value(captured.opponentAimAge),
                            "maximumShotSpeed": value(captured.opponentMaximumShotSpeed), "reason": captured.opponentPreviewUnavailableReason],
            "readiness": ["playerTurn": captured.playerTurn, "canShoot": captured.canShoot,
                          "reason": captured.shootReadinessReason, "legalTargets": captured.legalTargetNumbers],
            "physics": ["native": captured.physicsCalibrationAvailable, "maximumShotSpeed": value(captured.maximumShotSpeed),
                        "rollingDeceleration": value(captured.rollingDeceleration), "ballRestitution": value(captured.ballRestitution),
                        "slidingDeceleration": value(captured.slidingDeceleration), "equilibriumTimeFactor": value(captured.equilibriumTimeFactor),
                        "spinDeceleration": value(captured.spinDeceleration), "slidingFrictionCoefficient": value(captured.slidingFrictionCoefficient),
                        "cushionSpinCoupling": value(captured.cushionSpinCoupling), "logicalFrameTime": value(captured.logicalFrameTime),
                        "cushionRestitution": value(captured.cushionRestitution)],
            "estimatedFinalPositions": estimates, "predictionSource": predictionSource, "predictionIsCurrent": currentPrediction,
            "estimateAgeMs": acceptedPrediction == nil ? NSNull() : value(max(0, now - predictionCompletedAt) * 1_000),
            "diagnostics": captured.diagnostics
        ])
        telemetryFrames = telemetry.count
        if telemetry.count >= 300 || now - telemetryStartedAt >= 30 { stopTelemetry() }
    }

    /// Manual previews belong to the panel. Returning to the game resumes its
    /// actual cue unless the user explicitly switched live following off.
    func panelClosed() {
        panelIsOpen = false
        if previewIsTemporary {
            previewIsTemporary = false
            followGameAim = true
            poll()
        }
        onOverlayChange?()
    }

    func panelOpened() { panelIsOpen = true; onOverlayChange?() }
    private var overlayVisible: Bool { keepPreview || panelIsOpen }
    private var predictionIsCurrent: Bool {
        acceptedPrediction.map { acceptsPrediction($0, at: ProcessInfo.processInfo.systemUptime) } ?? false
    }
    var currentPredictionAlert: String? {
        guard overlayVisible, predictionIsCurrent else { return nil }
        if alertScratchEnabled && predictedScratch { return "Previsão: branca na caçapa" }
        let balls = Set(predictedPockets.map(\.ball)).subtracting([0]).sorted()
        if alertPotEnabled && !balls.isEmpty { return "Previsão: encaçapa \(balls.map(String.init).joined(separator: ", "))" }
        return nil
    }
    func setPathWidth(_ value: Double) {
        guard value.isFinite else { return }; pathWidth = min(4, max(1, value)); saveStyle(pathWidth, "width")
    }
    func setPathOpacity(_ value: Double) {
        guard value.isFinite else { return }; pathOpacity = min(1, max(0.3, value)); saveStyle(pathOpacity, "opacity")
    }
    func setPathColorMode(_ value: String) {
        guard ["balls", "mint", "white"].contains(value) else { return }
        pathColorMode = value; saveStyle(value, "color")
    }

    func refresh() {
        guard isAuthorized else { return }
        poll()
        requestPrediction()
    }

    func powerLabel(for suggestion: ShotSuggestion) -> String {
        guard let value = try? GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power) else { return "indisponível" }
        return "\(Int((value * 100).rounded()))%"
    }

    func recommend() { startPlanning(.suggestions) }
    func autoAim() { guard canRequestAutoAim else { return }; startPlanning(.applyAim) }

    func calculateLuckyShot() {
        guard canCalculateLuckyShot, let state = tableState, let snapshot else { return }
        let scale = 200 / snapshot.width
        let target = Vector2(x: (snapshot.goldenTargetX - snapshot.originX) * scale,
                             y: (snapshot.originY + snapshot.height - snapshot.goldenTargetY) * scale)
        let ball = snapshot.goldenBallNumber
        let obstacles = Set(state.balls.map(\.id)).subtracting([0, ball])
        cancelPlanner(clearSuggestions: true)
        let operation = plannerGeneration
        planningPurpose = .luckyShot
        isPlanning = true
        luckyStatus = "Procurando uma direção e força para aproximar a bola do alvo…"
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try LuckyShotPlanner.suggestion(for: state, targetBallID: ball, targetCenter: target, obstacleIDs: obstacles)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.plannerGeneration, self.accepts(state), self.isLuckyShot else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.luckySuggestion = found
                guard let found else {
                    self.luckyStatus = "Nenhuma opção encontrada sem contato com os obstáculos. Ajuste a mira manualmente."
                    return
                }
                guard self.setPreview(found.shot) else { return }
                self.followGameAim = false
                self.previewIsTemporary = true
                self.requestPrediction()
                self.luckyStatus = "Sugestão calculada para aproximar a bola do centro. Confira a previsão antes de aplicar."
            } catch {
                guard let self, operation == self.plannerGeneration, self.accepts(state) else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.luckyStatus = "Não foi possível calcular a Lucky Shot: \(error.localizedDescription)"
            }
        }
    }

    func applyLuckyAim() {
        guard isLuckyShot, canApplyAim, let luckySuggestion, setPreview(luckySuggestion.shot) else { return }
        applyAim()
    }

    func autoShot() {
        guard canRequestAutoShot else { return }
        singleShotRequested = true
        automationStatus = "Aguardando a mesa estabilizar para uma tacada."
        advanceAutomation()
    }

    func setAutoPlay(_ enabled: Bool) {
        if !enabled {
            stopAutomation(message: isWaitingForShot ? "Automático desligado. A tacada já enviada continua no jogo." : "Jogo automático desligado.")
            return
        }
        guard canEnableAutoPlay else {
            automationStatus = autoShotUnavailableReason
            return
        }
        cancelPlanner(clearSuggestions: false)
        autoPlayEnabled = true
        singleShotRequested = false
        automationStatus = "Automático ligado. Aguardando sua vez e a mesa parar."
        advanceAutomation()
    }

    func selectSuggestion(_ suggestion: ShotSuggestion) {
        guard canCalculate, !autoPlayEnabled, !isWaitingForShot,
              suggestions.contains(where: { $0.id == suggestion.id }) else { return }
        followGameAim = false
        previewIsTemporary = true
        guard setPreview(suggestion.shot) else { return }
        requestPrediction()
    }

    func applyAim() {
        guard canApplyAim, let state = tableState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            guard current.playerTurn, current.shotInputSupported, normalized.calibrated, normalized.nativePhysics, !normalized.moving, normalized.state == state,
                  current.coordinateView === snapshot?.coordinateView, isAuthorized else {
                throw CaptureError.changedTable
            }
            try PLRuntimeBridge.apply(angle: -angleDegrees * .pi / 180, power: power)
            followGameAim = true
            status = "Direção e força aplicadas. Você pode executar a tacada no jogo."
            poll()
        } catch {
            stopAutomation(message: "Mira não aplicada: \(error.localizedDescription)")
            status = automationStatus
        }
    }

    /// Overlay data is always projected from the current game's view, even when
    /// the menu is closed or the device rotates. Pocketed endpoints are marked
    /// separately; incomplete simulations never claim a final resting position.
    func overlayPaths(in window: UIWindow) -> [(Int, [CGPoint])] {
        guard overlayVisible, showTrajectories, predictionIsCurrent, let projection = projection(in: window) else { return [] }
        if isMoving && ProcessInfo.processInfo.systemUptime - predictionCompletedAt > 0.15 { return [] }
        let paths: [(Int, [Vector2])] = isMoving
            ? movingPaths(at: ProcessInfo.processInfo.systemUptime)
            : traces.filter { showAllPaths || $0.id == 0 }.map { ($0.id, $0.points) }
        return paths.compactMap { id, normalizedPoints in
            var points = normalizedPoints.map(projection.point)
            if isMoving, let snapshot, let ball = snapshot.balls.first(where: { $0.number == id }),
               let center = convertToOverlay(ball.visualCenter, snapshot: snapshot, window: window), !points.isEmpty {
                points[0] = center
            }
            guard points.count > 1, points.allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return nil }
            return (id, points)
        }
    }

    private func movingPaths(at now: TimeInterval) -> [(Int, [Vector2])] {
        guard let acceptedPrediction, let state = tableState else { return [] }
        let elapsed = max(0, now - acceptedPrediction.capturedAt)
        let threshold = state.table.ballRadius * 0.1
        let current = state.balls.filter { !$0.pocketed && (showAllPaths || $0.id == 0) }
        var points = Dictionary(uniqueKeysWithValues: current.map { ($0.id, [$0.position]) })
        // Frames carry time; compressed traces do not. Remove already elapsed
        // prediction segments and anchor each remaining path on its live ball.
        for frame in predictedFrames where frame.time >= elapsed {
            for ball in frame.balls where !ball.pocketed {
                guard let previous = points[ball.id]?.last,
                      previous.distance(to: ball.position) >= threshold else { continue }
                points[ball.id]?.append(ball.position)
            }
        }
        return current.compactMap { ball in
            guard let path = points[ball.id], path.count > 1 else { return nil }
            return (ball.id, path)
        }
    }

    func overlayFinalPositions(in window: UIWindow) -> [(Int, CGPoint, CGFloat, Bool)] {
        guard overlayVisible, showFinalPositions, predictionIsCurrent, let projection = projection(in: window), let state = tableState else { return [] }
        let radius = CGFloat(state.table.ballRadius) * projection.scale
        if isMoving && ProcessInfo.processInfo.systemUptime - predictionCompletedAt > 0.15 { return [] }
        return finalBalls.filter { ball in
            !ball.pocketed && (showAllPaths || ball.id == 0) && (state.balls.first(where: { $0.id == ball.id })
                .map { $0.position.distance(to: ball.position) > state.table.ballRadius * 0.25 } == true)
        }.compactMap { ball in
            let point = projection.point(ball.position)
            guard point.x.isFinite, point.y.isFinite, radius.isFinite else { return nil }
            return (ball.id, point, max(3, radius), ball.pocketed)
        }
    }

    /// This short guide needs no worker: it uses the current cue direction and
    /// copied physical ball centers, ending at the first ball or cushion.
    func overlayLiveGuide(in window: UIWindow) -> [CGPoint] {
        guard overlayVisible, showTrajectories, canPreviewAim, !isWaitingForShot, aimAvailable,
              let state = tableState, let projection = projection(in: window, prediction: false) else { return [] }
        return Self.firstContactGuide(state: state, angle: angleDegrees * .pi / 180).map(projection.point)
    }

    static func firstContactGuide(state: TableState, angle: Double) -> [Vector2] {
        guard angle.isFinite, let cue = state.cueBall else { return [] }
        let direction = Vector2(x: cos(angle), y: sin(angle))
        let r = state.table.ballRadius
        var distance = Double.infinity
        for (origin, delta, low, high) in [(cue.position.x, direction.x, r, state.table.width - r),
                                          (cue.position.y, direction.y, r, state.table.height - r)] {
            if delta > 1e-9 { distance = min(distance, (high - origin) / delta) }
            else if delta < -1e-9 { distance = min(distance, (low - origin) / delta) }
        }
        for ball in state.balls where ball.id != 0 && !ball.pocketed {
            let relative = ball.position - cue.position
            let forward = relative.dot(direction)
            guard forward > 0 else { continue }
            let discriminant = 4 * r * r - (relative.lengthSquared - forward * forward)
            if discriminant >= 0 { distance = min(distance, max(0, forward - sqrt(discriminant))) }
        }
        guard distance.isFinite, distance > 0 else { return [] }
        return [cue.position, cue.position + direction * distance]
    }

    /// Uses independent native sprite centers, not simulated endpoints.
    func overlayLiveBallPositions(in window: UIWindow) -> [(Int, CGPoint, CGFloat)] {
        guard overlayVisible, showLivePositions || isMoving, let snapshot,
              let projection = projection(in: window, prediction: false), let state = tableState else { return [] }
        return snapshot.balls.compactMap { ball in
            guard let point = convertToOverlay(ball.visualCenter, snapshot: snapshot, window: window),
                  point.x.isFinite, point.y.isFinite else { return nil }
            return (ball.number, point, max(3, CGFloat(state.table.ballRadius) * projection.scale))
        }
    }

    func overlayPocketMarkers(in window: UIWindow) -> [(CGPoint, CGPoint)] {
        guard overlayVisible, showPocketMarkers, predictionIsCurrent,
              let state = tableState, let projection = projection(in: window),
              !isMoving || ProcessInfo.processInfo.systemUptime - predictionCompletedAt <= 0.15 else { return [] }
        let center = Vector2(x: state.table.width / 2, y: state.table.height / 2)
        return Set(predictedPockets.map(\.pocket)).sorted().compactMap { id in
            guard let pocket = state.table.pockets.first(where: { $0.id == id }) else { return nil }
            let inner = pocket.center + (center - pocket.center).normalized() * (state.table.ballRadius * 3)
            return (projection.point(inner), projection.point(pocket.center))
        }
    }

    func overlayLuckyTarget(in window: UIWindow) -> CGPoint? {
        guard overlayVisible, isLuckyShot, let snapshot, snapshot.goldenTargetAvailable,
              let projection = projection(in: window, prediction: false) else { return nil }
        let scale = 200 / snapshot.width
        let point = projection.point(Vector2(x: (snapshot.goldenTargetX - snapshot.originX) * scale,
                                             y: (snapshot.originY + snapshot.height - snapshot.goldenTargetY) * scale))
        return point.x.isFinite && point.y.isFinite ? point : nil
    }

    private func projection(in window: UIWindow, prediction: Bool = true) -> (point: (Vector2) -> CGPoint, scale: CGFloat)? {
        guard isAuthorized, hasTable, (!prediction || (isMoving || (canPreviewAim && !(followGameAim && !aimAvailable)))),
              let snapshot, let state = tableState, let sourceWindow = snapshot.coordinateView.window,
              Self.isActive(sourceWindow), sourceWindow.windowScene === window.windowScene else { return nil }
        guard let a = convertToOverlay(snapshot.tableTopLeft, snapshot: snapshot, window: window),
              let b = convertToOverlay(snapshot.tableTopRight, snapshot: snapshot, window: window),
              let c = convertToOverlay(snapshot.tableBottomLeft, snapshot: snapshot, window: window) else { return nil }
        guard [a, b, c].allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return nil }
        let scaleX = hypot(b.x - a.x, b.y - a.y) / CGFloat(state.table.width)
        let scaleY = hypot(c.x - a.x, c.y - a.y) / CGFloat(state.table.height)
        return ({ point in
            let u = CGFloat(point.x / state.table.width), v = CGFloat(point.y / state.table.height)
            return CGPoint(x: a.x + (b.x - a.x) * u + (c.x - a.x) * v,
                           y: a.y + (b.y - a.y) * u + (c.y - a.y) * v)
        }, (scaleX + scaleY) / 2)
    }

    private func convertToOverlay(_ point: CGPoint, snapshot: PLGameSnapshot, window: UIWindow) -> CGPoint? {
        guard let sourceWindow = snapshot.coordinateView.window,
              Self.isActive(sourceWindow), sourceWindow.windowScene === window.windowScene else { return nil }
        let inSourceWindow = snapshot.coordinateView.convert(point, to: sourceWindow)
        // UIView's conversion contract is within one window. Cross the window
        // boundary with UIWindow's overload, then let the renderer use its view.
        return sourceWindow.convert(inSourceWindow, to: window)
    }

    private func startTimer() {
        guard captureLink == nil else { return }
        let target = PLFrameCaptureTarget()
        target.model = self
        let link = CADisplayLink(target: target, selector: #selector(PLFrameCaptureTarget.tick(_:)))
        link.preferredFramesPerSecond = 30
        frameTarget = target
        captureLink = link
        link.add(to: .main, forMode: .common)
    }

    fileprivate func captureFrame(at time: TimeInterval) {
        guard isForeground, time - lastFrameAt >= 1.0 / 31 else { return }
        lastFrameAt = time
        poll(pollQueueNow: false)
        let now = ProcessInfo.processInfo.systemUptime
        if telemetryRecording && now - telemetryStartedAt >= 30 { stopTelemetry() }
        // Failed captures must report zero throughput, not leave an old good
        // number frozen on screen. Successful captures update the same window.
        if rateWindowAt > 0 && now - rateWindowAt >= 1 {
            captureRate = Double(capturesInWindow) / (now - rateWindowAt)
            capturesInWindow = 0
            rateWindowAt = now
        }
    }

    private func poll(pollQueueNow: Bool = true) {
        guard isAuthorized else { authorizationChanged(); return }
        let now = ProcessInfo.processInfo.systemUptime
        if pollQueueNow || now - lastQueuePollAt >= 0.25 {
            lastQueuePollAt = now
            pollQueue()
        }
        if let transition = queueTransition, !transition.observedNewMatch {
            clearBoard(message: "Aguardando a próxima partida confirmada pelo jogo.", preserveQueueIntent: true)
            return
        }
        do {
            let captureStartedAt = ProcessInfo.processInfo.systemUptime
            let captured = try PLRuntimeBridge.capture()
            let captureElapsed = ProcessInfo.processInfo.systemUptime - captureStartedAt
            let normalized = try Self.normalized(captured, useOpponentCue: showOpponentPreview && captured.opponentTurn && captured.opponentPreviewAvailable)
            guard let sourceWindow = captured.coordinateView.window, Self.isActive(sourceWindow) else {
                clearBoard(message: "A mesa da partida ainda não está visível.", preserveQueueIntent: queueTransition != nil)
                return
            }
            if queueTransition?.observedNewMatch == true {
                // A new bridge-issued match token plus a visible, valid table
                // allows resumption. The stable-time gate starts again below.
                queueTransition = nil
                lastSubmittedState = nil
                stableSince = nil
            }
            let allowed = Set(captured.legalTargetNumbers.map { $0.intValue })
            let changed = tableState != normalized.state || isPlayerTurn != captured.playerTurn
                || legalTargets != allowed || snapshot?.coordinateView !== captured.coordinateView
                || snapshot?.isBreakShot != captured.isBreakShot
                || snapshot?.opponentPreviewAvailable != captured.opponentPreviewAvailable
                || snapshot?.shotInputSupported != captured.shotInputSupported
                || snapshot?.goldenShot != captured.goldenShot || snapshot?.goldenTargetAvailable != captured.goldenTargetAvailable
                || snapshot?.goldenTargetX != captured.goldenTargetX || snapshot?.goldenTargetY != captured.goldenTargetY
            let wasMoving = isMoving
            let wasAimAvailable = aimAvailable
            snapshot = captured
            tableState = normalized.state
            if hasTable != (true) { hasTable = true }
            if isCalibrated != (normalized.calibrated) { isCalibrated = normalized.calibrated }
            if hasNativePhysics != (normalized.nativePhysics) { hasNativePhysics = normalized.nativePhysics }
            if shotInputSupported != captured.shotInputSupported { shotInputSupported = captured.shotInputSupported }
            if shotInputUnavailableReason != captured.shotInputUnavailableReason { shotInputUnavailableReason = captured.shotInputUnavailableReason }
            if isMoving != (normalized.moving) { isMoving = normalized.moving }
            if isLuckyShot != (captured.goldenShot) { isLuckyShot = captured.goldenShot }
            if isPlayerTurn != (captured.playerTurn) { isPlayerTurn = captured.playerTurn }
            if opponentPreviewAvailable != captured.opponentPreviewAvailable { opponentPreviewAvailable = captured.opponentPreviewAvailable }
            if opponentPreviewReason != captured.opponentPreviewUnavailableReason { opponentPreviewReason = captured.opponentPreviewUnavailableReason }
            if ballCount != (normalized.state.balls.count) { ballCount = normalized.state.balls.count }
            legalTargets = allowed
            runtimeCanShoot = captured.canShoot
            let shotSupported = captured.autoShotAvailable && normalized.calibrated && normalized.nativePhysics
                && (!captured.playerTurn || captured.shotInputSupported)
            if autoShotAvailable != shotSupported { autoShotAvailable = shotSupported }
            let physicsIssue = captured.diagnostics["physicsBlocker"].flatMap { $0.isEmpty ? nil : $0 }
            let physicsUnavailable = normalized.calibrated && !normalized.nativePhysics
                ? (physicsIssue ?? normalized.calibrationIssue ?? captured.autoShotUnavailableReason)
                : (normalized.calibrationIssue ?? captured.autoShotUnavailableReason)
            let unavailable = normalized.calibrated && normalized.nativePhysics && !captured.shotInputSupported
                ? captured.shotInputUnavailableReason : physicsUnavailable
            if autoShotUnavailableReason != unavailable { autoShotUnavailableReason = unavailable }
            let availableAim = captured.aimAvailable && captured.aimAngle.isFinite
                && captured.cuePower.isFinite && (0...1).contains(captured.cuePower)
            if aimAvailable != availableAim { aimAvailable = availableAim }
            var readiness = !normalized.calibrated || !normalized.nativePhysics || !captured.shotInputSupported
                ? autoShotUnavailableReason
                : (!captured.autoShotAvailable ? captured.autoShotUnavailableReason : captured.shootReadinessReason)
            if readiness.isEmpty { readiness = captured.canShoot ? "Controle nativo pronto para a tacada." : "O jogo ainda não liberou a tacada." }
            if liveReadiness != readiness { liveReadiness = readiness }
            let aimChanged = ingestNativeAim(captured)
            recordCapture(captured, now: ProcessInfo.processInfo.systemUptime, elapsed: captureElapsed)

            // A command is released only after observed movement or a turn
            // transition. A timeout alone never permits resending it.
            if isMoving || !isPlayerTurn {
                lastSubmittedState = nil
                if isWaitingForShot {
                    isWaitingForShot = false
                    shotSubmittedAt = nil
                    automationStatus = autoPlayEnabled ? "Tacada iniciada. Aguardando as bolas pararem." : "Tacada iniciada no jogo."
                }
            }
            if isMoving {
                stableSince = nil
                if !wasMoving {
                    cancelPrediction(clearOverlay: true)
                    cancelPlanner(clearSuggestions: true)
                }
                if singleShotRequested { stopAutomation(message: "A mesa mudou antes da tacada. Solicite novamente quando parar.") }
                let movingStatus = normalized.nativePhysics ? "Posições, velocidades e efeito ao vivo; previsão de parada recalculada." : autoShotUnavailableReason
                if status != movingStatus { status = movingStatus }
                if !normalized.nativePhysics { cancelPrediction(clearOverlay: true) }
                requestPrediction()
                onOverlayChange?()
                return
            }
            if !normalized.calibrated || !normalized.nativePhysics || !captured.shotInputSupported {
                cancelPrediction(clearOverlay: true)
                cancelPlanner(clearSuggestions: true)
                let reason = !captured.shotInputSupported && normalized.calibrated && normalized.nativePhysics
                    ? captured.shotInputUnavailableReason : autoShotUnavailableReason
                if !captured.playerTurn && normalized.calibrated && normalized.nativePhysics {
                    // The opponent's selected English belongs to their preview.
                    // It cannot disarm our already-enabled wait for the next turn.
                    if autoPlayEnabled && automationStatus != "Aguardando sua vez e o efeito centralizado no jogo." {
                        automationStatus = "Aguardando sua vez e o efeito centralizado no jogo."
                    }
                } else { stopAutomation(message: reason) }
                if status != reason { status = reason }
                onOverlayChange?()
                return
            }
            if changed || wasMoving {
                stableSince = ProcessInfo.processInfo.systemUptime
                cancelPrediction(clearOverlay: true)
                cancelPlanner(clearSuggestions: true)
                status = isPlayerTurn ? "Mesa lida. As linhas acompanham a mira do jogo." : "Mesa lida. Aguardando sua vez."
            }
            if stableSince == nil { stableSince = ProcessInfo.processInfo.systemUptime }
            if followGameAim {
                if !aimAvailable {
                    cancelPrediction(clearOverlay: true)
                    if status != "Mira do jogo indisponível nesta etapa. Aguarde o jogo liberar a mira." {
                        status = "Mira do jogo indisponível nesta etapa. Aguarde o jogo liberar a mira."
                    }
                }
            }
            if let issue = normalized.calibrationIssue, status != issue { status = issue }
            if changed || wasMoving || aimChanged || (!wasAimAvailable && aimAvailable) { requestPrediction() }
            onOverlayChange?()
            if isWaitingForShot, let sentAt = shotSubmittedAt,
               ProcessInfo.processInfo.systemUptime - sentAt > shotStartTimeout {
                isWaitingForShot = false
                shotSubmittedAt = nil
                stopAutomation(message: "O jogo não confirmou movimento após a tacada. Automático desligado; confira os controles da partida.")
                return
            }
            if isPlayerTurn && !autoShotAvailable && (autoPlayEnabled || singleShotRequested) {
                stopAutomation(message: autoShotUnavailableReason)
                return
            }
            advanceAutomation()
        } catch {
            let runtimeError = error as NSError
            let expectedTransition = runtimeError.domain == "PoolLab.RuntimeBridge"
                && [4, 5, 20, 21, 24, 32, 33, 35, 37].contains(runtimeError.code)
            clearBoard(message: "Leitura indisponível: \(error.localizedDescription)",
                       preserveQueueIntent: queueTransition != nil && expectedTransition)
        }
    }

    private func ingestNativeAim(_ captured: PLGameSnapshot) -> Bool {
        guard aimAvailable else { return false }
        let angle = Self.degrees(-captured.aimAngle)
        let nativeChanged = lastNativeAim.map {
            Self.angularDistance(angle, $0.angle) > 0.03 || abs(captured.cuePower - $0.power) > 0.0005
        } ?? false
        // Keep a threshold anchor, rather than replacing it on every sample:
        // several small native movements must also release a manual preview.
        if lastNativeAim == nil || nativeChanged { lastNativeAim = (angle, captured.cuePower) }
        // A temporary panel preview must not keep a stale direction after the
        // player touches the real cue. Explicitly paused following is respected.
        if previewIsTemporary && nativeChanged {
            followGameAim = true
            previewIsTemporary = false
        }
        guard followGameAim || (!isPlayerTurn && showOpponentPreview && opponentPreviewAvailable) else { return false }
        // The game's zero cue power means “not pulling yet”, not “hide the
        // preview”. Only our copied-value simulation uses this reference.
        // Any real pull takes precedence, including powers below release limit.
        let usesReference = isPlayerTurn && !isMoving && lockedPreviewPower == nil && captured.cuePower <= 0.000001
        let previewPower = isPlayerTurn
            ? (lockedPreviewPower ?? (usesReference ? referencePreviewPower : captured.cuePower))
            : captured.cuePower
        let referenceModeChanged = previewUsesReferencePower != usesReference
        if referenceModeChanged { previewUsesReferencePower = usesReference }
        if angleDegrees != angle { angleDegrees = angle }
        if power != previewPower { power = previewPower }
        guard let requestedPreviewShot,
              let simulationPower = try? GameShotCalibration.simulationPower(fromControlPower: previewPower) else { return true }
        // Compare with the last queued calculation, not the previous display
        // frame. Use the same angle/simulation-power tolerances as acceptance;
        // otherwise slow input can hide an old result without requesting a new one.
        return requestedPreviewUsesReferencePower != usesReference
            || Self.angularDistance(angle, Self.degrees(requestedPreviewShot.angleRadians)) > 0.03
            || abs(simulationPower - requestedPreviewShot.power) > 0.0005
    }

    private static func angularDistance(_ a: Double, _ b: Double) -> Double {
        let difference = abs(a - b).truncatingRemainder(dividingBy: 360)
        return min(difference, 360 - difference)
    }

    private func startPlanning(_ purpose: PlanningPurpose) {
        guard canRecommend, let state = tableState else { return }
        if purpose != .suggestions && !canApplyAim { return }
        guard let minimumPower = try? Self.minimumPlannerPower(control: snapshot?.minimumShotPower ?? 0) else {
            stopAutomation(message: "O jogo informou um limite de força inválido.")
            return
        }
        cancelPlanner(clearSuggestions: true)
        let operation = plannerGeneration
        let allowed = legalTargets
        let isBreakShot = snapshot?.isBreakShot ?? false
        planningPurpose = purpose
        isPlanning = true
        status = "Comparando tacadas permitidas na mesa atual…"
        if purpose == .singleShot || purpose == .autoPlay { automationStatus = "Procurando uma tacada permitida…" }
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try ShotPlanner.suggestions(for: state, includeBanks: true, limit: 4, allowedTargetIDs: allowed,
                    minimumPower: minimumPower, isBreakShot: isBreakShot)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, self.acceptsPlan(operation, state: state, allowed: allowed) else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.suggestions = found
                guard let best = found.first else {
                    self.status = "Nenhuma tacada permitida encontrada pelo modelo nesta posição."
                    if purpose == .singleShot || purpose == .autoPlay { self.stopAutomation(message: self.status) }
                    return
                }
                switch purpose {
                case .suggestions:
                    self.status = "Escolha uma tacada para ver o percurso."
                case .applyAim:
                    guard self.setPreview(best.shot) else { return }
                    self.applyAim()
                case .singleShot, .autoPlay:
                    self.execute(best, expectedState: state, allowed: allowed)
                case .luckyShot:
                    break // Lucky Shot uses its own bounded target search.
                }
            } catch {
                guard let self, self.acceptsPlan(operation, state: state, allowed: allowed) else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.status = "Não foi possível calcular a tacada: \(error.localizedDescription)"
                if purpose == .singleShot || purpose == .autoPlay { self.stopAutomation(message: self.status) }
            }
        }
    }

    private func advanceAutomation() {
        guard autoPlayEnabled || singleShotRequested, isAuthorized, !isWaitingForShot, !isPlanning else { return }
        guard canCalculate, isPlayerTurn else {
            if automationStatus != "Aguardando sua vez e a mesa parar." { automationStatus = "Aguardando sua vez e a mesa parar." }
            return
        }
        guard autoShotAvailable else { stopAutomation(message: autoShotUnavailableReason); return }
        guard !legalTargets.isEmpty else {
            stopAutomation(message: "O jogo ainda não informou uma bola permitida para esta tacada.")
            return
        }
        guard tableState != lastSubmittedState else {
            stopAutomation(message: "Esta mesa já recebeu uma tentativa. Aguarde movimento ou execute a tacada pelo jogo.")
            return
        }
        guard runtimeCanShoot else {
            if automationStatus != liveReadiness { automationStatus = liveReadiness }
            return
        }
        guard let stableSince, ProcessInfo.processInfo.systemUptime - stableSince >= minimumStableTime else {
            if automationStatus != "Confirmando que a mesa está parada…" { automationStatus = "Confirmando que a mesa está parada…" }
            return
        }
        startPlanning(autoPlayEnabled ? .autoPlay : .singleShot)
    }

    private func execute(_ suggestion: ShotSuggestion, expectedState: TableState, allowed: Set<Int>) {
        guard autoPlayEnabled || singleShotRequested, isAuthorized, !isWaitingForShot,
              expectedState != lastSubmittedState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            let currentAllowed = Set(current.legalTargetNumbers.map { $0.intValue })
            guard current.playerTurn, current.canShoot, current.autoShotAvailable, current.shotInputSupported,
                  current.isBreakShot == (suggestion.method == .breakShot),
                  normalized.calibrated, normalized.nativePhysics, !normalized.moving, normalized.state == expectedState,
                  current.coordinateView === snapshot?.coordinateView,
                  currentAllowed == allowed, allowed.contains(suggestion.targetID),
                  isAuthorized else { throw CaptureError.changedTable }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power)
            // Mark before entering the game: even a partial runtime failure
            // cannot cause a second invocation for this unchanged board.
            lastSubmittedState = expectedState
            shotSubmittedAt = ProcessInfo.processInfo.systemUptime
            isWaitingForShot = true
            singleShotRequested = false
            try PLRuntimeBridge.shoot(angle: -suggestion.shot.angleRadians, power: nativePower,
                                      target: suggestion.targetID, pocket: suggestion.pocketID)
            angleDegrees = Self.degrees(suggestion.shot.angleRadians)
            power = nativePower
            followGameAim = true
            automationStatus = "Tacada enviada. Aguardando movimento no jogo…"
            status = suggestion.method == .breakShot ? "Tacada de saída enviada." : "Bola \(suggestion.targetID), caçapa \(suggestion.pocketID + 1)."
            cancelPrediction(clearOverlay: true)
        } catch {
            shotSubmittedAt = nil
            isWaitingForShot = false
            if (error as NSError).userInfo["shotDispatched"] as? Bool == false {
                // A rejected guard is different from an uncertain release.
                // The bridge explicitly proves that no shot callback ran.
                lastSubmittedState = nil
            }
            stopAutomation(message: "Tacada automática interrompida: \(error.localizedDescription)")
            status = automationStatus
        }
    }

    private func stopAutomation(message: String) {
        queueTransition = nil
        if autoPlayEnabled { autoPlayEnabled = false }
        if singleShotRequested { singleShotRequested = false }
        if planningPurpose == .singleShot || planningPurpose == .autoPlay { cancelPlanner(clearSuggestions: false) }
        if automationStatus != message { automationStatus = message }
    }

    private func requestPrediction() {
        guard isAuthorized, hasTable, hasNativePhysics, isMoving || isCalibrated, var state = tableState, let snapshot,
              isMoving || (canPreviewAim && aimAvailable && !isWaitingForShot) else { return }
        let now = ProcessInfo.processInfo.systemUptime
        guard snapshot.captureTimestamp.isFinite, now - snapshot.captureTimestamp <= 0.25,
              snapshot.captureTimestamp <= now + 0.01 else { return }
        if isMoving {
            guard now - lastMovingPredictionRequestAt >= 0.095 else { return }
            lastMovingPredictionRequestAt = now
            state.table = Self.continuationTable(state.table)
        }
        let shot: ShotParameters?
        if isMoving { shot = nil }
        else {
            guard let simulationPower = try? GameShotCalibration.simulationPower(fromControlPower: power) else { return }
            shot = ShotParameters(angleRadians: angleDegrees * .pi / 180, power: simulationPower)
        }
        let obstacles: Set<Int>? = isLuckyShot ? Set(state.balls.map(\.id)).subtracting([0, snapshot.goldenBallNumber]) : nil
        let request = PredictionRequest(state: state, shot: shot,
            capturedAt: snapshot.captureTimestamp, nativeFrame: snapshot.frameNumber,
            opponentCue: !isPlayerTurn,
            coordinateIdentity: ObjectIdentifier(snapshot.coordinateView), goldenObstacleIDs: obstacles,
            usesReferencePower: shot != nil && previewUsesReferencePower)
        pendingPrediction = request
        requestedPreviewShot = shot
        requestedPreviewUsesReferencePower = request.usesReferencePower
        // Keep the last result until the new one replaces it atomically. All
        // renderers still check acceptsPrediction, so stale directions/endpoints
        // stay hidden, while a refresh of the same shot does not flash blank.
        if predictionTask == nil { startPendingPrediction() }
    }

    private func startPendingPrediction() {
        guard predictionTask == nil, let request = pendingPrediction else { return }
        pendingPrediction = nil
        activePrediction = request
        let operation = predictionGeneration
        if !isPredicting { isPredicting = true }
        predictionTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                let started = ProcessInfo.processInfo.systemUptime
                let result: ShotResult
                if let shot = request.shot {
                    result = try BilliardsEngine.simulate(state: request.state, shot: shot, recordFrames: true)
                } else {
                    result = try BilliardsEngine.simulateContinuation(state: request.state, recordFrames: true)
                }
                return (result, (ProcessInfo.processInfo.systemUptime - started) * 1_000)
            }
            do {
                let (result, computeMilliseconds) = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.predictionGeneration else { return }
                self.predictionTask = nil
                self.activePrediction = nil
                let now = ProcessInfo.processInfo.systemUptime
                self.lastPredictionComputeMilliseconds = computeMilliseconds
                // Metrics do not drive readiness or physics. Publishing them
                // four times a second keeps the panel stable during cue input.
                if self.lastPredictionMetricsAt == 0 || now - self.lastPredictionMetricsAt >= 0.25 {
                    self.predictionMilliseconds = computeMilliseconds
                    self.lastPredictionMetricsAt = now
                }
                if self.acceptsPrediction(request, at: now) {
                    let obstacleContact = request.goldenObstacleIDs.map { obstacles in
                        result.events.contains { event in
                            if case let .ballCollision(first, second) = event {
                                return obstacles.contains(first) || obstacles.contains(second)
                            }
                            return false
                        }
                    } ?? false
                    self.traces = obstacleContact ? [] : result.traces
                    self.finalBalls = !obstacleContact && result.settled ? result.finalState.balls : []
                    self.predictedFrames = obstacleContact ? [] : result.frames
                    if self.previewDuration != result.duration { self.previewDuration = result.duration }
                    self.predictionCompletedAt = request.capturedAt
                    self.acceptedPrediction = request
                    self.predictedPockets = obstacleContact ? [] : result.events.compactMap {
                        if case let .pocket(ball, pocket) = $0 { return (ball, pocket) }
                        return nil
                    }
                    self.predictedScratch = !obstacleContact && result.scratched
                    if obstacleContact { self.luckyStatus = "Percurso cruza um obstáculo. Ajuste a direção." }
                    else if !result.settled { self.status = "Percurso parcial; a simulação ainda não chegou ao repouso." }
                    self.onOverlayChange?()
                }
            } catch {
                guard let self, operation == self.predictionGeneration else { return }
                self.predictionTask = nil
                self.activePrediction = nil
                if self.acceptsPrediction(request, at: ProcessInfo.processInfo.systemUptime) {
                    self.traces = []; self.finalBalls = []; self.previewDuration = nil; self.acceptedPrediction = nil
                    self.status = "Previsão indisponível: \(error.localizedDescription)"
                    self.onOverlayChange?()
                }
            }
            guard let self, operation == self.predictionGeneration else { return }
            // At most one worker and one newest pending request. Continuous
            // aiming cannot starve a 70 ms debounce or queue obsolete frames.
            if self.pendingPrediction != nil { self.startPendingPrediction() }
            else if self.isPredicting { self.isPredicting = false }
        }
    }

    private func acceptsPrediction(_ request: PredictionRequest, at time: TimeInterval) -> Bool {
        guard isAuthorized, hasTable, hasNativePhysics, isMoving || isCalibrated, !Task.isCancelled,
              let snapshot, request.coordinateIdentity == ObjectIdentifier(snapshot.coordinateView),
              let currentTable = tableState?.table,
              (request.shot == nil ? Self.continuationTable(currentTable) : currentTable) == request.state.table else { return false }
        if let shot = request.shot {
            guard canPreviewAim, request.opponentCue == !isPlayerTurn, !isWaitingForShot, tableState == request.state,
                  request.usesReferencePower == previewUsesReferencePower,
                  let currentPower = try? GameShotCalibration.simulationPower(fromControlPower: power) else { return false }
            return Self.angularDistance(Self.degrees(shot.angleRadians), angleDegrees) <= 0.03
                && abs(shot.power - currentPower) <= 0.0005
                && !(followGameAim && !aimAvailable)
        }
        // A moving estimate is short-lived. Current positions continue to be
        // drawn directly from native sprites even if the solver is too slow.
        return isMoving && time - request.capturedAt <= 0.15
            && Set(tableState?.balls.map(\.id) ?? []) == Set(request.state.balls.map(\.id))
    }

    private static func continuationTable(_ source: PoolTable) -> PoolTable {
        var table = source
        // No cue impulse is created by continuation. A missing cue statistic
        // must not block measured moving balls; the stand-in only satisfies
        // the shared geometry validator and is never used as a shot speed.
        if !table.maximumShotSpeed.isFinite || !(1...2_000).contains(table.maximumShotSpeed) {
            table.maximumShotSpeed = 1
        }
        return table
    }

    private static func minimumPlannerPower(control: Double) throws -> Double {
        guard control.isFinite, (0...1).contains(control) else { throw BilliardsError.invalidShot }
        // The native threshold originates as float but is compared as double.
        // Guard the control value before simulation so a q -> p round trip
        // cannot fall one ULP below it. Never clamp an already planned shot.
        return try GameShotCalibration.simulationPower(fromControlPower: min(1, control + 1e-7))
    }

    private func accepts(_ state: TableState) -> Bool {
        isAuthorized && isCalibrated && hasNativePhysics && shotInputSupported && !Task.isCancelled && tableState == state && !isMoving
    }
    private func acceptsPlan(_ operation: UInt64, state: TableState, allowed: Set<Int>) -> Bool {
        operation == plannerGeneration && accepts(state) && legalTargets == allowed
    }
    private func cancelPrediction(clearOverlay: Bool) {
        predictionGeneration &+= 1
        predictionTask?.cancel()
        predictionTask = nil
        pendingPrediction = nil
        activePrediction = nil
        requestedPreviewShot = nil
        if isPredicting { isPredicting = false }
        if clearOverlay {
            traces = []; finalBalls = []; predictedFrames = []; acceptedPrediction = nil
            if previewDuration != nil { previewDuration = nil }
            onOverlayChange?()
        }
    }
    private func cancelPlanner(clearSuggestions: Bool) {
        plannerGeneration &+= 1
        plannerTask?.cancel()
        plannerTask = nil
        planningPurpose = nil
        if isPlanning { isPlanning = false }
        if clearSuggestions {
            if !suggestions.isEmpty { suggestions = [] }
            if luckySuggestion != nil { luckySuggestion = nil }
        }
    }
    private func clearBoard(message: String, preserveQueueIntent: Bool = false) {
        if !isAuthorized && autoQueueEnabled { autoQueueEnabled = false; queueStatus = "Próxima partida automática pausada; ative novamente para continuar." }
        if !isAuthorized && blockInterstitialAds { setBlockInterstitialAds(false) }
        if preserveQueueIntent && queueTransition != nil && autoPlayEnabled && autoQueueEnabled && isAuthorized {
            singleShotRequested = false
            automationStatus = "Automático aguardando a próxima mesa. Você pode desligar a qualquer momento."
        } else { stopAutomation(message: message) }
        cancelPrediction(clearOverlay: true)
        cancelPlanner(clearSuggestions: true)
        snapshot = nil
        lastNativeAim = nil
        if liveReadiness != message { liveReadiness = message }
        tableState = nil
        stableSince = nil
        shotSubmittedAt = nil
        if isWaitingForShot { isWaitingForShot = false }
        if hasTable { hasTable = false }
        if isPlayerTurn { isPlayerTurn = false }
        if isMoving { isMoving = false }
        if aimAvailable { aimAvailable = false }
        if isCalibrated { isCalibrated = false }
        if hasNativePhysics { hasNativePhysics = false }
        if shotInputSupported { shotInputSupported = false }
        if previewUsesReferencePower { previewUsesReferencePower = false }
        if shotInputUnavailableReason != message { shotInputUnavailableReason = message }
        if opponentPreviewAvailable { opponentPreviewAvailable = false }
        if isLuckyShot { isLuckyShot = false }
        if luckyStatus != "Aguardando o alvo da Lucky Shot." { luckyStatus = "Aguardando o alvo da Lucky Shot." }
        runtimeCanShoot = false
        if autoShotAvailable { autoShotAvailable = false }
        if autoShotUnavailableReason != message { autoShotUnavailableReason = message }
        legalTargets = []
        if ballCount != 0 { ballCount = 0 }
        if status != message { status = message }
    }
    private func setPreview(_ shot: ShotParameters) -> Bool {
        guard shot.angleRadians.isFinite,
              let nativePower = try? GameShotCalibration.controlPower(fromSimulationPower: shot.power) else {
            status = "A sugestão contém uma direção ou força inválida."
            return false
        }
        angleDegrees = Self.degrees(shot.angleRadians)
        power = nativePower
        if previewUsesReferencePower { previewUsesReferencePower = false }
        return true
    }
    private static func degrees(_ radians: Double) -> Double {
        let result = (radians * 180 / .pi).truncatingRemainder(dividingBy: 360)
        return result < 0 ? result + 360 : result
    }
    private func boolStyle(_ key: String, fallback: Bool) -> Bool {
        styles.object(forKey: stylePrefix + key) == nil ? fallback : styles.bool(forKey: stylePrefix + key)
    }
    private func stringStyle(_ key: String, fallback: String, allowed: Set<String>) -> String {
        let value = styles.string(forKey: stylePrefix + key) ?? fallback
        return allowed.contains(value) ? value : fallback
    }
    private func numberStyle(_ key: String, fallback: Double, range: ClosedRange<Double>) -> Double {
        guard styles.object(forKey: stylePrefix + key) != nil else { return fallback }
        let value = styles.double(forKey: stylePrefix + key)
        return value.isFinite ? min(range.upperBound, max(range.lowerBound, value)) : fallback
    }
    private func saveStyle(_ value: Any, _ key: String) {
        styles.set(value, forKey: stylePrefix + key)
        onOverlayChange?()
    }

    private static func normalized(_ snapshot: PLGameSnapshot, useOpponentCue: Bool = false) throws -> (state: TableState, moving: Bool, calibrated: Bool, nativePhysics: Bool, calibrationIssue: String?) {
        let values = [snapshot.originX, snapshot.originY, snapshot.width, snapshot.height]
        guard values.allSatisfy(\.isFinite), snapshot.width > 0, snapshot.height > 0,
              !snapshot.balls.isEmpty, snapshot.balls.count <= 16 else { throw CaptureError.invalidGeometry }
        let scale = 200 / snapshot.width
        let radii = snapshot.balls.map { $0.radius * scale }
        guard radii.allSatisfy({ $0.isFinite && $0 > 0 }) else { throw CaptureError.invalidGeometry }
        let radius = radii.reduce(0, +) / Double(radii.count)
        guard radii.allSatisfy({ abs($0 - radius) <= 0.05 * radius }) else { throw CaptureError.invalidGeometry }
        var table = PoolTable()
        table.width = 200
        table.height = snapshot.height * scale
        table.ballRadius = radius
        table.pocketRadius = radius * 2.18
        let maximumSpeed = (useOpponentCue ? snapshot.opponentMaximumShotSpeed : snapshot.maximumShotSpeed) * scale
        let calibratedCue = maximumSpeed.isFinite && (1...2000).contains(maximumSpeed)
        let deceleration = snapshot.rollingDeceleration * scale
        let dynamics = NativeDynamics(
            slidingDeceleration: snapshot.slidingDeceleration * scale,
            equilibriumTimeFactor: snapshot.equilibriumTimeFactor / scale,
            spinDeceleration: snapshot.spinDeceleration,
            slidingFrictionCoefficient: snapshot.slidingFrictionCoefficient,
            cushionSpinCoupling: snapshot.cushionSpinCoupling,
            logicalFrameTime: snapshot.logicalFrameTime)
        let dynamicsValues = [dynamics.slidingDeceleration, dynamics.equilibriumTimeFactor,
                              dynamics.spinDeceleration, dynamics.slidingFrictionCoefficient,
                              dynamics.cushionSpinCoupling, dynamics.logicalFrameTime]
        let validDynamics = dynamicsValues.allSatisfy(\.isFinite)
            && (0.001...2_000).contains(dynamics.slidingDeceleration)
            && (1e-8...100).contains(dynamics.equilibriumTimeFactor)
            && (0...10_000).contains(dynamics.spinDeceleration)
            && (0...1).contains(dynamics.slidingFrictionCoefficient)
            && (0...2).contains(dynamics.cushionSpinCoupling)
            && (0.0005...0.02).contains(dynamics.logicalFrameTime)
        let calibratedTable = snapshot.physicsCalibrationAvailable && deceleration.isFinite
            && (0...100).contains(deceleration) && snapshot.ballRestitution.isFinite
            && (0...1).contains(snapshot.ballRestitution) && snapshot.cushionRestitution.isFinite
            && (0...1).contains(snapshot.cushionRestitution) && validDynamics
        let calibrationIssue: String?
        if !calibratedCue {
            calibrationIssue = "Mesa lida, mas a força do taco atual não pôde ser calibrada. Previsão e tacadas automáticas pausadas."
        } else if !calibratedTable {
            calibrationIssue = "Parâmetros físicos desta mesa indisponíveis ou fora dos limites aceitos. Previsões e tacadas automáticas pausadas."
        } else { calibrationIssue = nil }
        table.maximumShotSpeed = calibratedCue ? maximumSpeed : 0
        if calibratedTable {
            table.rollingDeceleration = deceleration
            table.ballRestitution = snapshot.ballRestitution
            table.cushionRestitution = snapshot.cushionRestitution
            table.nativeDynamics = dynamics
        }
        // Native motion includes angular velocity, even when the center stopped.
        // Keep every copied component: cutting small residuals can authorize a
        // new shot while the game is still resolving sliding or spin.
        let moving = snapshot.balls.contains {
            $0.vx != 0 || $0.vy != 0 || $0.spinX != 0 || $0.spinY != 0 || $0.spinZ != 0
        }
        let balls: [PoolBall] = snapshot.balls.map { ball in
            return PoolBall(id: ball.number,
                            position: Vector2(x: (ball.x - snapshot.originX) * scale,
                                              y: (snapshot.originY + snapshot.height - ball.y) * scale),
                            velocity: Vector2(x: ball.vx * scale, y: -ball.vy * scale),
                            // Angular velocity is a pseudovector. Reflecting Y
                            // negates X and Z, and never scales radians/second.
                            spin: BallSpin(x: -ball.spinX, y: ball.spinY, z: -ball.spinZ))
        }.sorted { $0.id < $1.id }
        let state = TableState(table: table, balls: balls)
        if !moving {
            // Validate geometry independently from missing cue calibration.
            // The stand-in exists only for this validation call; the returned
            // state retains unavailable values and cannot run a simulation.
            var geometryValidation = state
            if !calibratedCue { geometryValidation.table.maximumShotSpeed = 1 }
            try BilliardsEngine.validate(geometryValidation, requireCue: false)
        }
        return (state, moving, calibratedCue, calibratedTable, calibrationIssue)
    }

    private static func isActive(_ window: UIWindow) -> Bool {
        guard !window.isHidden else { return false }
        if let scene = window.windowScene { return scene.activationState == .foregroundActive }
        return UIApplication.shared.applicationState == .active
    }
    private enum CaptureError: LocalizedError {
        case invalidGeometry, changedTable
        var errorDescription: String? {
            switch self {
            case .invalidGeometry: return "A geometria lida da partida não corresponde a uma mesa válida."
            case .changedTable: return "A partida mudou. Aguarde a mesa parar e solicite uma nova tacada."
            }
        }
    }
}
