import Foundation
import UIKit
import Combine
import PoolLabCore

/// Runtime calls remain on the main thread. The two independent workers only
/// receive copied values: following the cue never cancels the shot planner.
@MainActor
final class IntegratedGameModel: ObservableObject {
    let authorization: AppModel
    @Published private(set) var status = "Ative sua licença para ler a mesa da partida."
    @Published private(set) var hasTable = false
    @Published private(set) var isPlayerTurn = false
    @Published private(set) var isMoving = false
    @Published private(set) var angleDegrees = 270.0
    @Published private(set) var power = 0.45
    /// A local visualization input while the real cue is at rest. This is
    /// never sent to the game unless a separate, explicit aim action is used.
    @Published private(set) var referencePreviewPower = 0.45
    @Published private(set) var previewUsesReferencePower = false
    @Published private(set) var aimAvailable = false
    @Published private(set) var isCalibrated = false
    @Published private(set) var hasNativePhysics = false
    @Published private(set) var shotInputSupported = false
    @Published private(set) var shotInputUnavailableReason = "Aguardando a leitura do efeito selecionado."
    @Published private(set) var followGameAim = true
    @Published private(set) var showTrajectories = true
    @Published private(set) var showAllPaths = true
    @Published private(set) var showFinalPositions = true
    @Published private(set) var showFinalNumbers = true
    @Published private(set) var pathWidth = 2.0
    @Published private(set) var pathOpacity = 0.9
    @Published private(set) var pathColorMode = "balls"
    @Published private(set) var pathStyle = "neon"
    @Published private(set) var projectedBallStyle = "filled"
    @Published private(set) var pocketMarkerStyle = "arrow"
    @Published private(set) var showPocketMarkers = true
    @Published private(set) var keepPreview = true
    @Published private(set) var previewPowerLocked = false
    @Published private(set) var alertPotEnabled = true
    @Published private(set) var alertScratchEnabled = true
    @Published private(set) var showOpponentPreview = false
    @Published private(set) var opponentPreviewAvailable = false
    @Published private(set) var opponentPreviewReason = "Aguardando dados da mira do adversário."
    @Published private(set) var isPredicting = false
    @Published private(set) var isPlanning = false
    @Published private(set) var suggestions: [ShotSuggestion] = []
    @Published private(set) var selectedSuggestionID: String?
    @Published private(set) var suggestionStatus = "Calcule uma sugestão quando a mesa estiver pronta."
    @Published private(set) var planningMilliseconds = 0.0
    @Published private(set) var ballCount = 0
    @Published private(set) var previewDuration: Double?
    @Published private(set) var aimEnabled = false
    @Published private(set) var automationPaused = false
    @Published private(set) var autoPlayEnabled = false
    @Published private(set) var autoPlayMode: AutoPlayMode = .normal
    @Published private(set) var automationElapsedSeconds: TimeInterval = 0
    @Published private(set) var isWaitingForShot = false
    @Published private(set) var autoShotAvailable = false
    @Published private(set) var autoShotUnavailableReason = "Entre em uma partida para conferir os controles."
    @Published private(set) var automationStatus = "Jogo automático desligado."
    @Published private(set) var blockInterstitialAds = false
    @Published private(set) var autoQueueEnabled = false
    @Published private(set) var queueStatus = "Próxima partida automática desligada."
    @Published private(set) var isLuckyShot = false
    @Published private(set) var luckySuggestion: LuckyShotSuggestion?
    @Published private(set) var luckyStatus = "Aguardando o alvo da Lucky Shot."
    @Published private(set) var singleShotRequested = false
    @Published private(set) var showLivePositions = false
    @Published private(set) var captureRate = 0.0
    @Published private(set) var predictionMilliseconds = 0.0
    @Published private(set) var captureMilliseconds = 0.0
    @Published private(set) var liveReadiness = "Aguardando a mesa."
    @Published private(set) var telemetryRecording = false
    @Published private(set) var telemetryFrames = 0
    @Published private(set) var telemetryStatus = "Grave a mira e uma tacada para conferir as leituras."
    @Published private(set) var sampleAgeMilliseconds = 0.0
    @Published private(set) var nativeDiagnostics: [String: String] = [:]

    var onOverlayChange: (() -> Void)?
    /// Commits a completed forecast without taking another sample first.
    /// Waiting for the next capture would invalidate it during continuous aim.
    var onPredictionReady: (() -> Void)?
    private var isForeground = false
    private var lastFrameAt: TimeInterval = 0
    private var sessionClock = AutomationSessionClock()
    private var lastQueuePollAt: TimeInterval = 0
    private var rateWindowAt: TimeInterval = 0
    private var capturesInWindow = 0
    private var lastNativeAim: (angle: Double, power: Double)?
    private var previewIsTemporary = false
    private var lastTelemetryAt: TimeInterval = 0
    private var telemetryStartedAt: TimeInterval = 0
    private var telemetry: [[String: Any]] = []
    private var predictionCompletedAt: TimeInterval = 0
    private var predictionRenderDeadline: TimeInterval?
    private var predictionInputStableSince: TimeInterval?
    private var lastPredictionMetricsAt: TimeInterval = 0
    private var lastPredictionComputeMilliseconds = 0.0
    private struct PredictionRequest {
        let state: TableState
        let shot: ShotParameters?
        let capturedAt: TimeInterval
        let nativeFrame: UInt64
        let opponentCue: Bool
        let coordinateIdentity: ObjectIdentifier
        let goldenObstacleIDs: Set<Int>?
        var usesReferencePower = false
    }
    private var pendingPrediction: PredictionRequest?
    private var activePrediction: PredictionRequest?
    private var acceptedPrediction: PredictionRequest?
    private var requestedPreviewShot: ShotParameters?
    private var requestedPreviewUsesReferencePower = false
    private var lastMovingPredictionRequestAt: TimeInterval = 0
    private var authorizationObserver: AnyCancellable?
    private var predictionTask: Task<Void, Never>?
    private var plannerTask: Task<Void, Never>?
    private var predictionGeneration: UInt64 = 0
    private var plannerGeneration: UInt64 = 0
    private var planningPurpose: PlanningPurpose?
    /// Separate from render cadence. A failed basic route search is not proof
    /// that the board has no shot; the bounded planner explores its later phases.
    private var lastPlanningSearch: [String: Any] = [:]
    private var snapshot: PLGameSnapshot?
    private var captureHealthy = false
    private var captureFailureStartedAt: TimeInterval?
    private var predictionInputIssue: String?
    private var unsupportedMotionStartedAt: TimeInterval?
    private let unsupportedMotionTimeout: TimeInterval = 30
    private var suggestionState: TableState?
    private var suggestionAllowed: Set<Int> = []
    private var suggestionCoordinateIdentity: ObjectIdentifier?
    private var suggestionIsBreakShot = false
    private var overlayEvents: [[String: Any]] = []
    private var captureEvents: [[String: Any]] = []
    private var tableState: TableState?
    private var traces: [BallTrace] = []
    private var finalBalls: [PoolBall] = []
    private var predictedFrames: [SimulationFrame] = []
    private var predictedPockets: [(ball: Int, pocket: Int)] = []
    private var predictedScratch = false
    private var panelIsOpen = false
    private var lockedPreviewPower: Double?
    private var legalTargets: Set<Int> = []
    private var runtimeCanShoot = false
    private var lastAuthorized = false
    private var stableSince: TimeInterval?
    private var shotSubmittedAt: TimeInterval?
    // Kept after a timeout/error. An uncertain command must never be repeated
    // on an unchanged table merely because the user toggles the switch again.
    private var lastSubmittedState: TableState?
    /// A solution belongs to one exact stationary board, rules and native view.
    /// It is shared by continuous AIM and Auto Play, never inferred from lines.
    private struct AutomaticContext: Equatable {
        let state: TableState
        let allowed: Set<Int>
        let coordinate: ObjectIdentifier
        let isBreakShot: Bool
    }
    private struct AutomaticPlan {
        let context: AutomaticContext
        let suggestion: ShotSuggestion
        var notBefore: TimeInterval = 0
        var aimApplied = false
        var controlSequence: AutomaticControlSequence?
    }
    /// The existing capture/display loop advances these native control values.
    /// This is visible interpolation, not synthesized touches or a second timer.
    private struct AutomaticControlSequence {
        let startAngle: Double
        let startPower: Double
        let targetAngle: Double
        let targetPower: Double
        let angleDelta: Double
        let profile: AutoPlayControlProfile
        var lastTickAt: TimeInterval
        var elapsed: TimeInterval = 0
        var lastAngle: Double
        var lastPower: Double
        var hasApplied = false
        var phase: String {
            profile.phase(at: elapsed)
        }
    }
    private var automaticPlan: AutomaticPlan?
    private var automaticSearchContext: AutomaticContext?
    private var automaticSearchPass = 0
    private var automaticSearchRetryAt: TimeInterval = 0
    private var automaticAttemptContext: AutomaticContext?
    private var automaticCommandAttempts = 0
    private var automaticControlAttempts = 0
    private var lastAutomaticControlMilliseconds = 0.0
    private var maximumAutomaticControlMilliseconds = 0.0
    private var automaticRetryAfter: TimeInterval = 0
    var automationArmed: Bool { aimEnabled || autoPlayEnabled }
    private var automationIsRunning: Bool { automationArmed && !automationPaused }
    /// Intent survives an app suspension/session refresh. Runtime work still
    /// requires isAuthorized at every read, plan acceptance and native action.
    private var canPreserveAutomationIntent: Bool {
        if authorization.canUseModules { return true }
        switch authorization.phase {
        case .authenticated, .checking, .authenticating:
            return authorization.session != nil
        case .signedOut, .error:
            return false
        }
    }
    private var currentAutomaticContext: AutomaticContext? {
        guard let tableState, let snapshot else { return nil }
        return AutomaticContext(state: tableState, allowed: legalTargets,
            coordinate: ObjectIdentifier(snapshot.coordinateView), isBreakShot: snapshot.isBreakShot)
    }
    private var attemptedQueueTokens: Set<String> = []
    private var lastQueueMatchToken: String?
    private var lastQueueObservation = ""
    private var nextQueueActionAt: TimeInterval = 0
    private struct QueueTransition {
        let token: String
        let deadline: TimeInterval
        var submitted = false
        var observedNewMatch = false
    }
    private var queueTransition: QueueTransition?
    private let queueTransitionTimeout: TimeInterval = 30
    private let styles = UserDefaults.standard
    private let stylePrefix = "PoolLab.Integrated.Overlay."
    private let minimumStableTime: TimeInterval = 0.65
    private let shotStartTimeout: TimeInterval = 4

    private enum PlanningPurpose { case suggestions, applyAim, continuousAim, singleShot, autoPlay, luckyShot }
    var isAuthorized: Bool { isForeground && authorization.canUseModules }
    private var hasFreshCapture: Bool {
        guard captureHealthy, let snapshot else { return false }
        return Self.isFreshSample(snapshot.captureTimestamp, at: ProcessInfo.processInfo.systemUptime)
    }
    private static func isFreshSample(_ timestamp: TimeInterval, at now: TimeInterval) -> Bool {
        timestamp.isFinite && now.isFinite && timestamp <= now + 0.01 && now - timestamp <= 0.25
    }
    var canCalculate: Bool { isAuthorized && hasFreshCapture && predictionInputIssue == nil && hasTable && isPlayerTurn && isCalibrated && hasNativePhysics && shotInputSupported && !isMoving && tableState?.cueBall != nil }
    private var canPreviewAim: Bool {
        isAuthorized && hasFreshCapture && predictionInputIssue == nil && hasTable && isCalibrated && hasNativePhysics && shotInputSupported && !isMoving && tableState?.cueBall != nil
            && (isPlayerTurn || (showOpponentPreview && opponentPreviewAvailable && snapshot?.opponentTurn == true))
    }
    var canApplyAim: Bool { canCalculate && runtimeCanShoot && !isWaitingForShot }
    var canRecommend: Bool { canApplyAim && !legalTargets.isEmpty }
    private var suggestionContextIsCurrent: Bool {
        canCalculate && suggestionState == tableState && suggestionAllowed == legalTargets
            && suggestionCoordinateIdentity == snapshot.map { ObjectIdentifier($0.coordinateView) }
            && suggestionIsBreakShot == snapshot?.isBreakShot && !suggestions.isEmpty
    }
    var canSelectSuggestions: Bool {
        canRecommend && !automationArmed && !singleShotRequested && !isPlanning && suggestionContextIsCurrent
    }
    var canApplySelectedSuggestion: Bool {
        canSelectSuggestions && selectedSuggestionID != nil && !followGameAim && previewIsTemporary
            && suggestions.contains { $0.id == selectedSuggestionID }
    }
    var canRequestAutoAim: Bool { aimEnabled || canEnableAutoAim }
    var canEnableAutoAim: Bool { isAuthorized && hasFreshCapture && hasTable && !isLuckyShot }
    var canRequestAutoShot: Bool {
        canRecommend && isPlayerTurn && runtimeCanShoot && autoShotAvailable
            && !isPlanning && !automationArmed && !singleShotRequested && tableState != lastSubmittedState
    }
    var canEnableAutoPlay: Bool { canEnableAutoAim }
    var aimActionReadiness: String {
        if !isAuthorized { return "Ative sua licença para usar a mira." }
        if !hasTable { return "Entre em uma partida para ler a mesa." }
        if !hasFreshCapture { return "Aguardando uma leitura atual da mesa." }
        if isWaitingForShot { return "Aguardando o jogo confirmar a tacada enviada." }
        if isMoving { return "Aguarde as bolas pararem." }
        if !isPlayerTurn { return "Aguarde sua vez de jogar." }
        if let issue = predictionInputIssue { return issue }
        if !isCalibrated || !hasNativePhysics { return autoShotUnavailableReason }
        if !shotInputSupported { return shotInputUnavailableReason }
        if !runtimeCanShoot { return liveReadiness }
        if legalTargets.isEmpty { return "Aguardando o jogo informar as bolas permitidas." }
        if isPlanning { return "Calculando direção e força…" }
        return "Mesa pronta para calcular uma sugestão."
    }
    var canCalculateLuckyShot: Bool {
        canCalculate && isLuckyShot && snapshot?.goldenTargetAvailable == true && !isPlanning && !isWaitingForShot
    }

    init(authorization: AppModel) {
        self.authorization = authorization
        autoPlayMode = AutoPlayMode(rawValue: styles.string(forKey: stylePrefix + "autoPlayMode") ?? "") ?? .normal
        showTrajectories = boolStyle("paths", fallback: true)
        showAllPaths = boolStyle("allPaths", fallback: true)
        showFinalPositions = boolStyle("endpoints", fallback: true)
        showFinalNumbers = boolStyle("numbers", fallback: true)
        pathWidth = numberStyle("width", fallback: 2, range: 1...4)
        pathOpacity = numberStyle("opacity", fallback: 0.9, range: 0.3...1)
        let storedColor = styles.string(forKey: stylePrefix + "color") ?? "balls"
        pathColorMode = ["balls", "mint", "white"].contains(storedColor) ? storedColor : "balls"
        pathStyle = stringStyle("lineStyle", fallback: "neon", allowed: ["neon", "solid", "dashed"])
        projectedBallStyle = stringStyle("ballStyle", fallback: "filled", allowed: ["filled", "outline"])
        pocketMarkerStyle = stringStyle("pocketStyle", fallback: "arrow", allowed: ["arrow", "ring"])
        showPocketMarkers = boolStyle("pockets", fallback: true)
        keepPreview = true
        alertPotEnabled = boolStyle("potAlert", fallback: true)
        alertScratchEnabled = boolStyle("scratchAlert", fallback: true)
        showOpponentPreview = false
        referencePreviewPower = numberStyle("referencePower", fallback: 0.45, range: 0.05...1)
        authorizationObserver = authorization.objectWillChange.sink { [weak self] _ in
            Task { @MainActor [weak self] in self?.authorizationChanged() }
        }
    }

    func becameActive() {
        guard !isForeground else { poll(); return }
        isForeground = true
        lastFrameAt = 0
        lastMovingPredictionRequestAt = 0
        rateWindowAt = 0
        capturesInWindow = 0
        if captureRate != 0 { captureRate = 0 }
        Task { [weak self] in
            guard let self else { return }
            await self.authorization.becameActive()
            guard self.isForeground else { return }
            self.authorizationChanged()
            self.poll()
        }
    }

    func becameInactive() {
        guard isForeground else { return }
        recordCaptureEvent("applicationInactive", at: ProcessInfo.processInfo.systemUptime)
        isForeground = false
        if telemetryRecording { stopTelemetry() }
        authorization.becameInactive()
        lastAuthorized = false
        clearBoard(message: "Leitura e jogo automático pausados enquanto o aplicativo está inativo.")
    }

    func authorizationChanged() {
        let allowed = isAuthorized
        if allowed != lastAuthorized {
            recordCaptureEvent("authorizationGateChanged", at: ProcessInfo.processInfo.systemUptime,
                               details: ["allowed": String(allowed), "foreground": String(isForeground)])
        }
        if !allowed {
            if lastAuthorized || hasTable || predictionTask != nil || plannerTask != nil || automationArmed || autoQueueEnabled || blockInterstitialAds {
                clearBoard(message: "Acesso pausado. Confirme sua licença para continuar.")
            }
        } else if !lastAuthorized {
            lastAuthorized = true
            poll()
        }
        lastAuthorized = allowed
    }

    func setAutoQueue(_ value: Bool) {
        guard !value || isAuthorized else { return }
        if !value, queueTransition != nil {
            queueTransition = nil
            deferAutomaticActions(message: "Próxima partida desativada. Automático aguardando uma mesa.")
        }
        autoQueueEnabled = value
        queueStatus = value ? "Ao terminar, voltar aos mapas e entrar na mesa em destaque." : "Próxima partida automática desligada."
        if value { pollQueue() }
    }

    private func pollQueue() {
        guard isAuthorized else { return }
        let now = ProcessInfo.processInfo.systemUptime
        do {
            // Observation is read-only and keeps the native match identity
            // current, even while the user's automatic switches are off.
            let state = try PLQueueBridge.captureNavigation()
            let observation = "\(state.sceneName)|\(state.navigationAction)|\(state.actionToken)"
            if observation != lastQueueObservation {
                lastQueueObservation = observation
                recordCaptureEvent("queueNavigationObserved", at: now,
                    details: ["scene": state.sceneName, "action": state.navigationAction,
                              "tier": state.selectedTier, "ready": String(state.ready)])
            }
            if state.isInMatch && !state.resultToken.isEmpty {
                if let previous = lastQueueMatchToken, previous != state.resultToken {
                    // Only a native new-match identity may retire an uncertain
                    // command when the table happens to have identical positions.
                    lastSubmittedState = nil
                    shotSubmittedAt = nil
                    isWaitingForShot = false
                    resetAutomaticPlan()
                    attemptedQueueTokens.removeAll(keepingCapacity: true)
                    recordCaptureEvent("newMatchObserved", at: now)
                }
                lastQueueMatchToken = state.resultToken
                queueTransition = nil
            }
            guard autoQueueEnabled, !automationPaused, !panelIsOpen else { return }
            let dismissesKnownOverlay = state.ready &&
                ["closeNews", "closePopup"].contains(state.navigationAction)
            if state.isInMatch && !dismissesKnownOverlay {
                let message = "Próxima partida ligada. Aguardando o resultado desta mesa."
                if queueStatus != message { queueStatus = message }
                return
            }
            // Timeouts are observable waits, never a change to user intent.
            // Native action tokens and the matchmaking latch prevent re-entry.
            if let transition = queueTransition, now >= transition.deadline {
                queueTransition = nil
                recordCaptureEvent("queueTransitionWaiting", at: now,
                    details: ["reason": "transitionExceeded30Seconds"])
            }
            guard state.ready, state.navigationAction != "wait", !state.actionToken.isEmpty else {
                if queueStatus != state.unavailableReason { queueStatus = state.unavailableReason }
                if autoPlayEnabled && !state.unavailableReason.isEmpty {
                    waitAutomation(message: state.unavailableReason)
                }
                return
            }
            guard now >= nextQueueActionAt, !attemptedQueueTokens.contains(state.actionToken) else { return }
            attemptedQueueTokens.insert(state.actionToken)
            nextQueueActionAt = now + 0.8
            do {
                try PLQueueBridge.performNavigation(token: state.actionToken)
            } catch {
                // A proven pre-dispatch rejection can be retried after a fresh
                // stable observation. An uncertain callback remains consumed.
                if (error as NSError).userInfo["navigationDispatched"] as? Bool == false {
                    attemptedQueueTokens.remove(state.actionToken)
                    nextQueueActionAt = now + 1.5
                }
                throw error
            }
            queueTransition = QueueTransition(token: state.resultToken,
                deadline: now + queueTransitionTimeout, submitted: true)
            recordCaptureEvent("queueNavigationSubmitted", at: now,
                details: ["action": state.navigationAction, "tier": state.selectedTier])
            switch state.navigationAction {
            case "backToMaps", "openMaps": queueStatus = "Voltando à seleção de mapas…"
            case "selectMap": queueStatus = "Mesa em destaque selecionada. Buscando adversário…"
            case "closeNews", "closePopup", "closePromotion": queueStatus = "Fechando a janela para continuar…"
            default: queueStatus = "Aguardando o jogo concluir a navegação…"
            }
        } catch {
            guard autoQueueEnabled else { return }
            let message = "Aguardando a navegação do jogo: \(error.localizedDescription)"
            if queueStatus != message { queueStatus = message }
            if autoPlayEnabled { waitAutomation(message: message) }
        }
    }

    func setBlockInterstitialAds(_ value: Bool) {
        guard !value || isAuthorized else { return }
        do {
            try PLAdControl.setBlocking(enabled: value)
            blockInterstitialAds = value
        } catch {
            status = "Não foi possível alterar os anúncios: \(error.localizedDescription)"
        }
    }

    func setAngle(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        followGameAim = false
        previewIsTemporary = true
        if previewUsesReferencePower { previewUsesReferencePower = false }
        angleDegrees = min(360, max(0, value))
        requestPrediction()
    }

    func setPower(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        power = min(1, max(0, value))
        if previewUsesReferencePower { previewUsesReferencePower = false }
        if previewPowerLocked { lockedPreviewPower = power }
        else { followGameAim = false; previewIsTemporary = true }
        requestPrediction()
    }

    var previewPowerCaption: String {
        if isMoving { return "Acompanhando o movimento real" }
        if previewUsesReferencePower { return "Prévia com força de referência: \(Int((referencePreviewPower * 100).rounded()))%" }
        return "Força atual do taco: \(Int((power * 100).rounded()))%"
    }

    func setReferencePreviewPower(_ value: Double) {
        guard value.isFinite else { return }
        let clamped = min(1, max(0.05, value))
        guard referencePreviewPower != clamped else { return }
        referencePreviewPower = clamped
        saveStyle(clamped, "referencePower")
        // Re-read the actual cue. A slider edit during a real pull must not
        // replace its power, and changing this setting never invokes apply().
        if isAuthorized { poll() }
    }

    func setPreviewPowerLocked(_ value: Bool) {
        guard isAuthorized, !value || !automationArmed else { return }
        previewPowerLocked = value
        lockedPreviewPower = value ? power : nil
        previewIsTemporary = false
        followGameAim = true
        poll()
        requestPrediction()
    }

    func setFollowGameAim(_ value: Bool) {
        guard isAuthorized else { return }
        followGameAim = value
        previewIsTemporary = false
        if value {
            selectedSuggestionID = nil
            poll()
        }
        requestPrediction()
    }

    func setShowTrajectories(_ value: Bool) { showTrajectories = value; saveStyle(value, "paths") }
    func setShowAllPaths(_ value: Bool) { showAllPaths = value; saveStyle(value, "allPaths") }
    func setShowFinalPositions(_ value: Bool) { showFinalPositions = value; saveStyle(value, "endpoints") }
    func setShowFinalNumbers(_ value: Bool) { showFinalNumbers = value; saveStyle(value, "numbers") }
    func setShowLivePositions(_ value: Bool) { showLivePositions = value; onOverlayChange?() }
    func setShowPocketMarkers(_ value: Bool) { showPocketMarkers = value; saveStyle(value, "pockets") }
    func setKeepPreview(_ value: Bool) { keepPreview = value; saveStyle(value, "keepPreview") }
    func setAlertPotEnabled(_ value: Bool) { alertPotEnabled = value; saveStyle(value, "potAlert") }
    func setAlertScratchEnabled(_ value: Bool) { alertScratchEnabled = value; saveStyle(value, "scratchAlert") }
    func setShowOpponentPreview(_ value: Bool) {
        showOpponentPreview = value; saveStyle(value, "opponentPreview")
        cancelPrediction(clearOverlay: true)
        poll()
        requestPrediction()
    }
    func setPathStyle(_ value: String) {
        guard ["neon", "solid", "dashed"].contains(value) else { return }
        pathStyle = value; saveStyle(value, "lineStyle")
    }
    func setProjectedBallStyle(_ value: String) {
        guard ["filled", "outline"].contains(value) else { return }
        projectedBallStyle = value; saveStyle(value, "ballStyle")
    }
    func setPocketMarkerStyle(_ value: String) {
        guard ["arrow", "ring"].contains(value) else { return }
        pocketMarkerStyle = value; saveStyle(value, "pocketStyle")
    }

    func toggleTelemetry() {
        if telemetryRecording { stopTelemetry(); return }
        guard isAuthorized else { return }
        telemetry = []
        telemetryFrames = 0
        telemetryStartedAt = ProcessInfo.processInfo.systemUptime
        lastTelemetryAt = 0
        telemetryRecording = true
        telemetryStatus = "Gravando até 30 segundos. Mova a mira e execute uma tacada."
    }

    private func stopTelemetry() {
        telemetryRecording = false
        telemetryStatus = "\(telemetryFrames) amostras locais prontas para exportar."
    }

    func exportTelemetry() throws -> URL {
        if telemetryRecording { stopTelemetry() }
        let document: [String: Any] = [
            "format": "SDKPool.LiveCapture", "version": 7, "frameworkBuild": 16,
            "createdAt": ISO8601DateFormatter().string(from: Date()),
            "note": "Native positions, velocities, spin, response coefficients, cue and readiness are measured. Predicted paths and endpoints are calculated estimates, not native future state.",
            "captureHzMeasured": captureRate, "readiness": liveReadiness,
            "status": status, "automationStatus": automationStatus,
            "suggestionStatus": suggestionStatus, "planningCostMs": planningMilliseconds,
            "planningSearch": lastPlanningSearch,
            "autoPlayMode": autoPlayMode.rawValue,
            "automationElapsedSeconds": sessionClock.elapsed(at: ProcessInfo.processInfo.systemUptime),
            "queueStatus": queueStatus,
            "captureCadence": "sharedDisplayLinkBeforeDraw", "captureCapHz": 60,
            "movingPredictionMinimumIntervalMs": 1_000.0 / 30,
            "predictionRenderBridgeMaximumMs": 1_000.0 / 60,
            "pocketIndicatorStableInputMs": 80,
            "nativeDiagnostics": nativeDiagnostics, "frames": telemetry,
            "overlayEvents": overlayEvents, "captureEvents": captureEvents,
            "captureHealthy": captureHealthy,
            "recordingStartedAtUptime": telemetryStartedAt,
            "predictionInputIssue": predictionInputIssue as Any? ?? NSNull()
        ]
        let data = try JSONSerialization.data(withJSONObject: document, options: [.prettyPrinted, .sortedKeys])
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("SDKPoolDiagnostics", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent("SDKPool-V15-\(UUID().uuidString).json")
        try data.write(to: url, options: .atomic)
        return url
    }

    /// Visibility events are measured separately from native gameplay samples.
    /// The bounded ring does not publish UI changes or record clipboard/license data.
    func recordOverlayEvent(_ name: String, details: [String: String] = [:]) {
        let now = ProcessInfo.processInfo.systemUptime
        overlayEvents.append(["name": String(name.prefix(80)), "uptime": now,
                              "elapsed": telemetryStartedAt > 0 ? now - telemetryStartedAt : NSNull(),
                              "details": details])
        if overlayEvents.count > 160 { overlayEvents.removeFirst(overlayEvents.count - 160) }
    }

    private func recordCaptureEvent(_ name: String, at now: TimeInterval, details: [String: String] = [:]) {
        captureEvents.append(["name": name, "uptime": now,
                              "elapsed": telemetryStartedAt > 0 ? now - telemetryStartedAt : NSNull(),
                              "details": details])
        if captureEvents.count > 128 { captureEvents.removeFirst(captureEvents.count - 128) }
    }

    private func recordCapture(_ captured: PLGameSnapshot, now: TimeInterval, elapsed: TimeInterval) {
        capturesInWindow += 1
        if rateWindowAt == 0 { rateWindowAt = now }
        if now - rateWindowAt >= 1 {
            captureRate = Double(capturesInWindow) / (now - rateWindowAt)
            captureMilliseconds = elapsed * 1_000
            sampleAgeMilliseconds = max(0, now - captured.captureTimestamp) * 1_000
            nativeDiagnostics = captured.diagnostics
            capturesInWindow = 0
            rateWindowAt = now
        }
        guard telemetryRecording, now - lastTelemetryAt >= 0.095 else { return }
        lastTelemetryAt = now
        func value(_ x: Double) -> Any { x.isFinite ? x : NSNull() }
        func point(_ p: CGPoint) -> [Any] { [value(Double(p.x)), value(Double(p.y))] }
        let balls: [[String: Any]] = captured.balls.map { ball in
            ["id": ball.number, "nativePosition": [value(ball.x), value(ball.y)],
             "nativeVelocity": [value(ball.vx), value(ball.vy)],
             "nativeSpin": [value(ball.spinX), value(ball.spinY), value(ball.spinZ)], "radius": value(ball.radius),
             "visualCenter": point(ball.visualCenter)]
        }
        let currentPrediction = predictionIsCurrent
        let estimates: [[String: Any]] = (currentPrediction ? finalBalls : []).map { ball in
            ["id": ball.id, "normalizedPosition": [value(ball.position.x), value(ball.position.y)],
             "pocketed": ball.pocketed]
        }
        let predictionSource: Any
        if let accepted = acceptedPrediction {
            let sourceBalls: [[String: Any]] = accepted.state.balls.map { ball in
                ["id": ball.id, "position": [ball.position.x, ball.position.y],
                 "velocity": [ball.velocity.x, ball.velocity.y], "spin": [ball.spin.x, ball.spin.y, ball.spin.z]]
            }
            let sourceShot: Any = accepted.shot.map { shot -> [String: Any] in
                let spin = shot.initialSpin ?? .zero
                return ["angleRadians": shot.angleRadians, "simulationPower": shot.power,
                        "initialSpin": [spin.x, spin.y, spin.z]]
            } as Any? ?? NSNull()
            let sourceDynamics: Any = accepted.state.table.nativeDynamics.map { profile -> [String: Any] in
                ["slidingDeceleration": profile.slidingDeceleration, "equilibriumTimeFactor": profile.equilibriumTimeFactor,
                 "spinDeceleration": profile.spinDeceleration, "slidingFrictionCoefficient": profile.slidingFrictionCoefficient,
                 "cushionSpinCoupling": profile.cushionSpinCoupling, "logicalFrameTime": profile.logicalFrameTime]
            } as Any? ?? NSNull()
            predictionSource = ["captureTimestamp": accepted.capturedAt, "nativeFrame": accepted.nativeFrame,
                                "kind": accepted.shot == nil ? "movingContinuation" : (accepted.opponentCue ? "opponentCueShot" : "cueShot"),
                                "usesReferencePower": accepted.usesReferencePower,
                                "normalizedMaximumShotSpeed": accepted.state.table.maximumShotSpeed,
                                "normalizedDynamics": sourceDynamics,
                                "normalizedBalls": sourceBalls,
                                "shot": sourceShot]
        } else { predictionSource = NSNull() }
        telemetry.append([
            "elapsed": now - telemetryStartedAt, "captureTimestamp": value(captured.captureTimestamp),
            "nativeFrame": captured.frameNumber, "balls": balls, "captureCostMs": elapsed * 1_000,
            "tableNativeBounds": [value(captured.originX), value(captured.originY), value(captured.width), value(captured.height)],
            "tableViewCorners": [point(captured.tableTopLeft), point(captured.tableTopRight), point(captured.tableBottomLeft)],
            "projectionResidual": value(captured.projectionResidual),
            "aim": ["available": captured.aimAvailable, "radians": value(captured.aimAngle), "power": value(captured.cuePower), "minimumShotPower": value(captured.minimumShotPower),
                    "shotInputSupported": captured.shotInputSupported, "shotInputReason": captured.shotInputUnavailableReason,
                    "english": [value(captured.cueEnglishX), value(captured.cueEnglishY)]],
            "preview": ["usesReferencePower": previewUsesReferencePower, "referencePower": referencePreviewPower,
                        "controlPower": power, "calculating": isPredicting,
                        "lastCalculationCostMs": lastPredictionComputeMilliseconds],
            "opponentAim": ["available": captured.opponentPreviewAvailable, "age": value(captured.opponentAimAge),
                            "maximumShotSpeed": value(captured.opponentMaximumShotSpeed), "reason": captured.opponentPreviewUnavailableReason],
            "readiness": ["playerTurn": captured.playerTurn, "canShoot": captured.canShoot,
                          "reason": captured.shootReadinessReason, "legalTargets": captured.legalTargetNumbers],
            "physics": ["native": captured.physicsCalibrationAvailable, "maximumShotSpeed": value(captured.maximumShotSpeed),
                        "rollingDeceleration": value(captured.rollingDeceleration), "ballRestitution": value(captured.ballRestitution),
                        "slidingDeceleration": value(captured.slidingDeceleration), "equilibriumTimeFactor": value(captured.equilibriumTimeFactor),
                        "spinDeceleration": value(captured.spinDeceleration), "slidingFrictionCoefficient": value(captured.slidingFrictionCoefficient),
                        "cushionSpinCoupling": value(captured.cushionSpinCoupling), "logicalFrameTime": value(captured.logicalFrameTime),
                        "cushionRestitution": value(captured.cushionRestitution)],
            "nativeGeometry": ["available": captured.nativeGeometryAvailable,
                               "reason": captured.nativeGeometryUnavailableReason,
                               "cushionVertices": captured.nativeCushionVertices.map { point($0.cgPointValue) },
                               "pocketCenters": captured.nativePocketCenters.map { point($0.cgPointValue) },
                               "pocketAimPoints": captured.nativePocketAimPoints.map { point($0.cgPointValue) },
                               "pocketAttractionRadius": value(captured.nativePocketRadius),
                               "pocketAttractionCoefficient": value(captured.nativePocketAttractionCoefficient),
                               "captureRadiusSource": "ballRadius"],
            "estimatedFinalPositions": estimates, "predictionSource": predictionSource, "predictionIsCurrent": currentPrediction,
            "predictionIsRenderable": predictionIsRenderable, "pocketPredictionIsCurrent": pocketPredictionIsCurrent,
            "captureHealthy": captureHealthy, "predictionInputIssue": predictionInputIssue as Any? ?? NSNull(),
            "automation": ["enabled": autoPlayEnabled, "aimEnabled": aimEnabled,
                           "paused": automationPaused, "armed": automationArmed,
                           "mode": autoPlayMode.rawValue,
                           "elapsedSeconds": sessionClock.elapsed(at: now),
                           "commandAttempts": automaticCommandAttempts,
                           "controlAttempts": automaticControlAttempts,
                           "controlPhase": automaticPlan?.controlSequence?.phase ?? "idle",
                           "controlStepCostMs": lastAutomaticControlMilliseconds,
                           "controlSequenceMaxCostMs": maximumAutomaticControlMilliseconds,
                           "singleRequested": singleShotRequested,
                           "waitingForMotion": isWaitingForShot, "planning": isPlanning,
                           "status": automationStatus, "suggestionStatus": suggestionStatus,
                           "lastPlanningCostMs": planningMilliseconds,
                           "search": lastPlanningSearch],
            "estimateAgeMs": acceptedPrediction == nil ? NSNull() : value(max(0, now - predictionCompletedAt) * 1_000),
            "diagnostics": captured.diagnostics
        ])
        telemetryFrames = telemetry.count
        if telemetry.count >= 300 || now - telemetryStartedAt >= 30 { stopTelemetry() }
    }

    /// A selected, still-valid suggestion remains visible after closing the
    /// panel so its full path can be inspected before an explicit Apply action.
    /// Native cue changes and board/turn changes invalidate that selection.
    func panelClosed() {
        let keepSelectedPreview = selectedSuggestionID != nil && suggestionContextIsCurrent
            && !autoPlayEnabled && !singleShotRequested && !followGameAim && previewIsTemporary
        panelIsOpen = false
        if !keepSelectedPreview { selectedSuggestionID = nil }
        if automationArmed || singleShotRequested { stableSince = ProcessInfo.processInfo.systemUptime }
        if previewIsTemporary && !keepSelectedPreview {
            previewIsTemporary = false
            followGameAim = true
            poll()
        }
        onOverlayChange?()
    }

    func panelOpened() {
        panelIsOpen = true
        if planningPurpose == .singleShot || planningPurpose == .autoPlay || planningPurpose == .continuousAim {
            cancelPlanner(clearSuggestions: true)
        }
        automaticPlan = nil
        if (automationArmed && !automationPaused) || singleShotRequested {
            automationStatus = "Feche o menu para continuar o AIM e o automático."
        }
        onOverlayChange?()
    }
    private var overlayVisible: Bool { keepPreview || panelIsOpen }
    private var predictionIsCurrent: Bool {
        acceptedPrediction.map { acceptsPrediction($0, at: ProcessInfo.processInfo.systemUptime) } ?? false
    }
    private var predictionIsRenderable: Bool {
        predictionCanRender(at: ProcessInfo.processInfo.systemUptime)
    }
    private func predictionCanRender(at time: TimeInterval) -> Bool {
        guard let accepted = acceptedPrediction else { return false }
        if acceptsPrediction(accepted, at: time) { return true }
        // This is display continuity only. A changed table, turn, geometry,
        // reference-power mode or capture never qualifies. The deadline starts
        // on the first input change and cannot be extended by more input.
        guard accepted.shot != nil, predictionContextIsCurrent(accepted, at: time),
              let deadline = predictionRenderDeadline, time < deadline,
              predictionTask != nil,
              [activePrediction, pendingPrediction].compactMap({ $0 }).contains(where: {
                  $0.shot != nil && acceptsPrediction($0, at: time)
              }) else { return false }
        return true
    }
    private var pocketPredictionIsCurrent: Bool {
        pocketPredictionIsCurrent(at: ProcessInfo.processInfo.systemUptime)
    }
    private func pocketPredictionIsCurrent(at time: TimeInterval) -> Bool {
        guard let accepted = acceptedPrediction,
              acceptsPrediction(accepted, at: time) else { return false }
        if accepted.shot == nil { return true }
        // While dragging, tiny direction changes can swap the predicted pocket.
        // Lines stay live; an outcome appears only after the input settles.
        guard let stableSince = predictionInputStableSince else { return false }
        return time - stableSince >= 0.08
    }
    var currentPredictionIsScratch: Bool {
        overlayVisible && pocketPredictionIsCurrent && alertScratchEnabled && predictedScratch
    }
    var currentPredictedPocketBalls: [Int] {
        guard overlayVisible, pocketPredictionIsCurrent, alertPotEnabled else { return [] }
        return Set(predictedPockets.map(\.ball)).subtracting([0]).sorted()
    }
    var currentCaptureTimestamp: TimeInterval? { hasFreshCapture ? snapshot?.captureTimestamp : nil }
    var currentNativeFrame: UInt64? { hasFreshCapture ? snapshot?.frameNumber : nil }
    var currentPredictionAlert: String? {
        guard overlayVisible, pocketPredictionIsCurrent else { return nil }
        let reference = previewUsesReferencePower && !isMoving
            ? " (força de referência \(Int((referencePreviewPower * 100).rounded()))%)" : ""
        if alertScratchEnabled && predictedScratch { return "Previsão: branca na caçapa\(reference)" }
        let balls = Set(predictedPockets.map(\.ball)).subtracting([0]).sorted()
        if alertPotEnabled && !balls.isEmpty { return "Previsão: encaçapa \(balls.map(String.init).joined(separator: ", "))\(reference)" }
        return nil
    }
    func setPathWidth(_ value: Double) {
        guard value.isFinite else { return }; pathWidth = min(4, max(1, value)); saveStyle(pathWidth, "width")
    }
    func setPathOpacity(_ value: Double) {
        guard value.isFinite else { return }; pathOpacity = min(1, max(0.3, value)); saveStyle(pathOpacity, "opacity")
    }
    func setPathColorMode(_ value: String) {
        guard ["balls", "mint", "white"].contains(value) else { return }
        pathColorMode = value; saveStyle(value, "color")
    }

    func refresh() {
        guard isAuthorized else { return }
        poll()
        requestPrediction()
    }

    func powerLabel(for suggestion: ShotSuggestion) -> String {
        guard let value = try? GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power) else { return "indisponível" }
        return "\(Int((value * 100).rounded()))%"
    }

    func recommend() {
        guard canRecommend, !isPlanning, !automationArmed, !singleShotRequested else { return }
        startPlanning(.suggestions)
    }
    func autoAim() { setAutoAimEnabled(!aimEnabled) }

    func setAutoAimEnabled(_ enabled: Bool) {
        guard enabled != aimEnabled else { return }
        if !enabled {
            stopAutomation(message: "AIM e jogo automático desligados.")
            onOverlayChange?()
            return
        }
        guard canEnableAutoAim else { return }
        aimEnabled = true
        automationPaused = false
        resetAutomaticPlan()
        automationStatus = "AIM ligado. Aguardando sua vez e a mesa parar."
        recordCaptureEvent("continuousAimEnabled", at: ProcessInfo.processInfo.systemUptime)
        poll()
    }

    func setAutoPlayEnabled(_ enabled: Bool) { setAutoPlay(enabled) }

    func setAutoPlayMode(_ value: AutoPlayMode) {
        guard value != autoPlayMode else { return }
        autoPlayMode = value
        styles.set(value.rawValue, forKey: stylePrefix + "autoPlayMode")
        // A mode change never releases an already prepared or uncertain shot.
        resetAutomaticPlan()
        recordCaptureEvent("autoPlayModeChanged", at: ProcessInfo.processInfo.systemUptime,
                           details: ["mode": value.rawValue])
        onOverlayChange?()
    }

    private func updateAutomationClock(at now: TimeInterval) {
        sessionClock.synchronize(enabled: autoPlayEnabled, paused: automationPaused, at: now)
        let seconds = floor(sessionClock.elapsed(at: now))
        // A display tick must not rebuild the panel dozens of times a second.
        if automationElapsedSeconds != seconds { automationElapsedSeconds = seconds }
    }

    func toggleAutomationPause() {
        guard automationArmed else { return }
        automationPaused.toggle()
        updateAutomationClock(at: ProcessInfo.processInfo.systemUptime)
        resetAutomaticPlan()
        singleShotRequested = false
        recordCaptureEvent(automationPaused ? "automationPaused" : "automationResumed",
                           at: ProcessInfo.processInfo.systemUptime)
        automationStatus = automationPaused ? "AIM e automático pausados." : "Retomando com uma nova leitura da mesa."
        if !automationPaused { poll() }
        onOverlayChange?()
    }

    private func resetAutomaticPlan() {
        // Automatic control and the visible forecast use the same live power.
        // A manually locked preview must not conceal the selected shot force.
        previewPowerLocked = false
        lockedPreviewPower = nil
        followGameAim = true
        previewIsTemporary = false
        cancelPlanner(clearSuggestions: true)
        automaticPlan = nil
        automaticSearchContext = nil
        automaticSearchPass = 0
        automaticSearchRetryAt = 0
        automaticAttemptContext = nil
        automaticCommandAttempts = 0
        automaticControlAttempts = 0
        automaticRetryAfter = 0
        stableSince = nil
    }

    func calculateLuckyShot() {
        guard canCalculateLuckyShot, let state = tableState, let snapshot else { return }
        let scale = 200 / snapshot.width
        let target = Vector2(x: (snapshot.goldenTargetX - snapshot.originX) * scale,
                             y: (snapshot.originY + snapshot.height - snapshot.goldenTargetY) * scale)
        let ball = snapshot.goldenBallNumber
        let obstacles = Set(state.balls.map(\.id)).subtracting([0, ball])
        cancelPlanner(clearSuggestions: true)
        let operation = plannerGeneration
        planningPurpose = .luckyShot
        isPlanning = true
        luckyStatus = "Procurando uma direção e força para aproximar a bola do alvo…"
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try LuckyShotPlanner.suggestion(for: state, targetBallID: ball, targetCenter: target, obstacleIDs: obstacles)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.plannerGeneration, self.accepts(state), self.isLuckyShot else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.luckySuggestion = found
                guard let found else {
                    self.luckyStatus = "Nenhuma opção encontrada sem contato com os obstáculos. Ajuste a mira manualmente."
                    return
                }
                guard self.setPreview(found.shot) else { return }
                self.followGameAim = false
                self.previewIsTemporary = true
                self.requestPrediction()
                self.luckyStatus = "Sugestão calculada para aproximar a bola do centro. Confira a previsão antes de aplicar."
            } catch {
                guard let self, operation == self.plannerGeneration, self.accepts(state) else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.luckyStatus = "Não foi possível calcular a Lucky Shot: \(error.localizedDescription)"
            }
        }
    }

    func applyLuckyAim() {
        guard isLuckyShot, canApplyAim, let luckySuggestion, setPreview(luckySuggestion.shot) else { return }
        applyAim()
    }

    func autoShot() {
        guard canRequestAutoShot else { return }
        singleShotRequested = true
        automationStatus = "Aguardando a mesa estabilizar para uma tacada."
        advanceAutomation()
    }

    func setAutoPlay(_ enabled: Bool) {
        guard enabled != autoPlayEnabled else { return }
        if !enabled {
            autoPlayEnabled = false
            updateAutomationClock(at: ProcessInfo.processInfo.systemUptime)
            setAutoQueue(false)
            singleShotRequested = false
            resetAutomaticPlan()
            automationStatus = automationPaused ? "AIM pausado." : "Auto Play desligado. AIM continua ligado."
            onOverlayChange?()
            return
        }
        guard canEnableAutoPlay else { return }
        aimEnabled = true
        autoPlayEnabled = true
        automationPaused = false
        updateAutomationClock(at: ProcessInfo.processInfo.systemUptime)
        unsupportedMotionStartedAt = nil
        resetAutomaticPlan()
        recordCaptureEvent("autoPlayEnabled", at: ProcessInfo.processInfo.systemUptime)
        singleShotRequested = false
        automationStatus = "AIM e automático ligados. Aguardando sua vez e a mesa parar."
        setAutoQueue(true)
        poll()
    }

    func selectSuggestion(_ suggestion: ShotSuggestion) {
        guard canSelectSuggestions,
              let current = suggestions.first(where: { $0.id == suggestion.id }),
              setPreview(current.shot) else { return }
        selectedSuggestionID = current.id
        followGameAim = false
        previewIsTemporary = true
        suggestionStatus = "Bola \(current.targetID), força \(powerLabel(for: current)). Confira o percurso e aplique a mira."
        requestPrediction()
    }

    func applySelectedSuggestion() {
        guard canApplySelectedSuggestion, let id = selectedSuggestionID,
              let selected = suggestions.first(where: { $0.id == id }), setPreview(selected.shot) else { return }
        applyAim()
    }

    func applyAim() {
        guard canApplyAim, let state = tableState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            guard current.playerTurn, current.canShoot, current.shotInputSupported,
                  Self.isFreshSample(current.captureTimestamp, at: ProcessInfo.processInfo.systemUptime), normalized.calibrated, normalized.nativePhysics, normalized.predictionIssue == nil, !normalized.moving, normalized.state == state,
                  current.coordinateView === snapshot?.coordinateView, isAuthorized else {
                throw CaptureError.changedTable
            }
            try PLRuntimeBridge.apply(angle: -angleDegrees * .pi / 180, power: power)
            followGameAim = true
            previewIsTemporary = false
            selectedSuggestionID = nil
            suggestionStatus = "Mira aplicada. A tacada fica por sua conta."
            recordCaptureEvent("aimApplied", at: ProcessInfo.processInfo.systemUptime)
            status = "Direção e força aplicadas. Você pode executar a tacada no jogo."
            poll()
        } catch {
            deferAutomaticActions(message: "Mira aguardando os controles: \(error.localizedDescription)")
            status = automationStatus
        }
    }

    /// Overlay data is always projected from the current game's view, even when
    /// the menu is closed or the device rotates. Pocketed endpoints are marked
    /// separately; incomplete simulations never claim a final resting position.
    func overlayPaths(in window: UIWindow) -> [(Int, [CGPoint])] {
        guard overlayVisible, showTrajectories, predictionIsRenderable, let projection = projection(in: window) else { return [] }
        if isMoving && ProcessInfo.processInfo.systemUptime - predictionCompletedAt > 0.15 { return [] }
        let paths: [(Int, [Vector2])] = isMoving
            ? movingPaths(at: ProcessInfo.processInfo.systemUptime)
            : traces.filter { showAllPaths || $0.id == 0 }.map { ($0.id, $0.points) }
        return paths.compactMap { id, normalizedPoints in
            var points = normalizedPoints.map(projection.point)
            if isMoving, let snapshot, let ball = snapshot.balls.first(where: { $0.number == id }),
               let center = convertToOverlay(ball.visualCenter, snapshot: snapshot, window: window), !points.isEmpty {
                points[0] = center
            }
            guard points.count > 1, points.allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return nil }
            return (id, points)
        }
    }

    private func movingPaths(at now: TimeInterval) -> [(Int, [Vector2])] {
        guard let acceptedPrediction, let state = tableState else { return [] }
        let elapsed = max(0, now - acceptedPrediction.capturedAt)
        let threshold = state.table.ballRadius * 0.1
        let current = state.balls.filter { !$0.pocketed && (showAllPaths || $0.id == 0) }
        var points = Dictionary(uniqueKeysWithValues: current.map { ($0.id, [$0.position]) })
        // Frames carry time; compressed traces do not. Remove already elapsed
        // prediction segments and anchor each remaining path on its live ball.
        for frame in predictedFrames where frame.time >= elapsed {
            for ball in frame.balls where !ball.pocketed {
                guard let previous = points[ball.id]?.last,
                      previous.distance(to: ball.position) >= threshold else { continue }
                points[ball.id]?.append(ball.position)
            }
        }
        return current.compactMap { ball in
            guard let path = points[ball.id], path.count > 1 else { return nil }
            return (ball.id, path)
        }
    }

    func overlayFinalPositions(in window: UIWindow) -> [(Int, CGPoint, CGFloat, Bool)] {
        guard overlayVisible, showFinalPositions, predictionIsRenderable, let projection = projection(in: window), let state = tableState else { return [] }
        let radius = CGFloat(state.table.ballRadius) * projection.scale
        if isMoving && ProcessInfo.processInfo.systemUptime - predictionCompletedAt > 0.15 { return [] }
        return finalBalls.filter { ball in
            !ball.pocketed && (showAllPaths || ball.id == 0) && (state.balls.first(where: { $0.id == ball.id })
                .map { $0.position.distance(to: ball.position) > state.table.ballRadius * 0.25 } == true)
        }.compactMap { ball in
            let point = projection.point(ball.position)
            guard point.x.isFinite, point.y.isFinite, radius.isFinite else { return nil }
            return (ball.id, point, max(3, radius), ball.pocketed)
        }
    }

    /// This short guide needs no worker: it uses the current cue direction and
    /// copied physical ball centers, ending at the first ball or cushion.
    func overlayLiveGuide(in window: UIWindow) -> [CGPoint] {
        guard overlayVisible, showTrajectories, canPreviewAim, !isWaitingForShot, aimAvailable,
              let state = tableState, let projection = projection(in: window, prediction: false) else { return [] }
        return Self.firstContactGuide(state: state, angle: angleDegrees * .pi / 180).map(projection.point)
    }

    static func firstContactGuide(state: TableState, angle: Double) -> [Vector2] {
        guard angle.isFinite, let cue = state.cueBall else { return [] }
        let direction = Vector2(x: cos(angle), y: sin(angle))
        guard let destination = try? BilliardsEngine.firstContactPoint(state: state, direction: direction) else { return [] }
        return [cue.position, destination]
    }

    /// Uses independent native sprite centers, not simulated endpoints.
    func overlayLiveBallPositions(in window: UIWindow) -> [(Int, CGPoint, CGFloat)] {
        guard overlayVisible, showLivePositions || isMoving, let snapshot,
              let projection = projection(in: window, prediction: false), let state = tableState else { return [] }
        return snapshot.balls.compactMap { ball in
            guard let point = convertToOverlay(ball.visualCenter, snapshot: snapshot, window: window),
                  point.x.isFinite, point.y.isFinite else { return nil }
            return (ball.number, point, max(3, CGFloat(state.table.ballRadius) * projection.scale))
        }
    }

    func overlayPocketMarkers(in window: UIWindow) -> [(CGPoint, CGPoint)] {
        guard overlayVisible, showPocketMarkers, pocketPredictionIsCurrent,
              let state = tableState, let projection = projection(in: window),
              !isMoving || ProcessInfo.processInfo.systemUptime - predictionCompletedAt <= 0.15 else { return [] }
        let center = Vector2(x: state.table.width / 2, y: state.table.height / 2)
        return Set(predictedPockets.map(\.pocket)).sorted().compactMap { id in
            guard let pocket = state.table.pockets.first(where: { $0.id == id }) else { return nil }
            let inner = pocket.center + (center - pocket.center).normalized() * (state.table.ballRadius * 3)
            return (projection.point(inner), projection.point(pocket.center))
        }
    }

    /// Layout exclusions use actual measured table geometry even when markers
    /// are disabled. A small notice must never sit over cloth or a pocket mouth.
    func overlayPredictionBadgeGeometry(in window: UIWindow) -> (table: CGRect, pockets: [CGRect])? {
        guard let state = tableState, state.table.nativeGeometry != nil,
              let projection = projection(in: window, prediction: false) else { return nil }
        let corners = [Vector2(x: 0, y: 0), Vector2(x: state.table.width, y: 0),
                       Vector2(x: 0, y: state.table.height), Vector2(x: state.table.width, y: state.table.height)]
            .map(projection.point)
        guard corners.allSatisfy({ $0.x.isFinite && $0.y.isFinite }),
              let minX = corners.map(\.x).min(), let maxX = corners.map(\.x).max(),
              let minY = corners.map(\.y).min(), let maxY = corners.map(\.y).max() else { return nil }
        let pockets = state.table.pockets.map { pocket -> CGRect in
            let center = projection.point(pocket.center)
            let radius = CGFloat(pocket.attractionRadius + state.table.ballRadius) * projection.scale
            return CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2)
        }
        return (CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY), pockets)
    }

    func overlayLuckyTarget(in window: UIWindow) -> CGPoint? {
        guard overlayVisible, isLuckyShot, let snapshot, snapshot.goldenTargetAvailable,
              let projection = projection(in: window, prediction: false) else { return nil }
        let scale = 200 / snapshot.width
        let point = projection.point(Vector2(x: (snapshot.goldenTargetX - snapshot.originX) * scale,
                                             y: (snapshot.originY + snapshot.height - snapshot.goldenTargetY) * scale))
        return point.x.isFinite && point.y.isFinite ? point : nil
    }

    private func projection(in window: UIWindow, prediction: Bool = true) -> (point: (Vector2) -> CGPoint, scale: CGFloat)? {
        guard isAuthorized, captureHealthy, hasTable, (!prediction || (isMoving || (canPreviewAim && !(followGameAim && !aimAvailable)))),
              let snapshot, let state = tableState, let sourceWindow = snapshot.coordinateView.window,
              Self.isActive(sourceWindow), sourceWindow.windowScene === window.windowScene else { return nil }
        guard let a = convertToOverlay(snapshot.tableTopLeft, snapshot: snapshot, window: window),
              let b = convertToOverlay(snapshot.tableTopRight, snapshot: snapshot, window: window),
              let c = convertToOverlay(snapshot.tableBottomLeft, snapshot: snapshot, window: window) else { return nil }
        guard [a, b, c].allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return nil }
        let scaleX = hypot(b.x - a.x, b.y - a.y) / CGFloat(state.table.width)
        let scaleY = hypot(c.x - a.x, c.y - a.y) / CGFloat(state.table.height)
        return ({ point in
            let u = CGFloat(point.x / state.table.width), v = CGFloat(point.y / state.table.height)
            return CGPoint(x: a.x + (b.x - a.x) * u + (c.x - a.x) * v,
                           y: a.y + (b.y - a.y) * u + (c.y - a.y) * v)
        }, (scaleX + scaleY) / 2)
    }

    private func convertToOverlay(_ point: CGPoint, snapshot: PLGameSnapshot, window: UIWindow) -> CGPoint? {
        guard let sourceWindow = snapshot.coordinateView.window,
              Self.isActive(sourceWindow), sourceWindow.windowScene === window.windowScene else { return nil }
        let inSourceWindow = snapshot.coordinateView.convert(point, to: sourceWindow)
        // UIView's conversion contract is within one window. Cross the window
        // boundary with UIWindow's overload, then let the renderer use its view.
        return sourceWindow.convert(inSourceWindow, to: window)
    }

    /// The persistent overlay calls capture before drawing in one display tick.
    /// This removes the old 30 Hz capture / separate-render scheduling delay.
    func captureFrame(at time: TimeInterval) {
        guard isForeground, time.isFinite,
              lastFrameAt == 0 || time - lastFrameAt >= 1.0 / 61 else { return }
        lastFrameAt = time
        poll(pollQueueNow: false)
        let now = ProcessInfo.processInfo.systemUptime
        if telemetryRecording && now - telemetryStartedAt >= 30 { stopTelemetry() }
        if rateWindowAt > 0 && now - rateWindowAt >= 1 {
            captureRate = Double(capturesInWindow) / (now - rateWindowAt)
            capturesInWindow = 0
            rateWindowAt = now
        }
    }

    /// Diagnostic age only. Drawing still uses measured native centers.
    func captureAgeMilliseconds(at now: TimeInterval) -> Double? {
        guard captureHealthy, let timestamp = snapshot?.captureTimestamp,
              Self.isFreshSample(timestamp, at: now) else { return nil }
        return max(0, now - timestamp) * 1_000
    }

    private func poll(pollQueueNow: Bool = true) {
        updateAutomationClock(at: ProcessInfo.processInfo.systemUptime)
        guard isAuthorized else { authorizationChanged(); return }
        let now = ProcessInfo.processInfo.systemUptime
        if pollQueueNow || now - lastQueuePollAt >= 0.25 {
            lastQueuePollAt = now
            pollQueue()
        }
        do {
            let captureStartedAt = ProcessInfo.processInfo.systemUptime
            let captured = try PLRuntimeBridge.capture()
            let captureElapsed = ProcessInfo.processInfo.systemUptime - captureStartedAt
            guard Self.isFreshSample(captured.captureTimestamp, at: ProcessInfo.processInfo.systemUptime) else {
                throw CaptureError.staleCapture
            }
            let normalized = try Self.normalized(captured, useOpponentCue: showOpponentPreview && captured.opponentTurn && captured.opponentPreviewAvailable)
            guard let sourceWindow = captured.coordinateView.window, Self.isActive(sourceWindow) else {
                clearBoard(message: "A mesa da partida ainda não está visível.", preserveQueueIntent: queueTransition != nil)
                return
            }
            if queueTransition?.observedNewMatch == true {
                // A new bridge-issued match token plus a visible, valid table
                // allows resumption. The stable-time gate starts again below.
                queueTransition = nil
                lastSubmittedState = nil
                stableSince = nil
            }
            let allowed = Set(captured.legalTargetNumbers.map { $0.intValue })
            let changed = tableState != normalized.state || isPlayerTurn != captured.playerTurn
                || legalTargets != allowed || snapshot?.coordinateView !== captured.coordinateView
                || snapshot?.isBreakShot != captured.isBreakShot
                || snapshot?.opponentPreviewAvailable != captured.opponentPreviewAvailable
                || snapshot?.shotInputSupported != captured.shotInputSupported
                || snapshot?.goldenShot != captured.goldenShot || snapshot?.goldenTargetAvailable != captured.goldenTargetAvailable
                || snapshot?.goldenTargetX != captured.goldenTargetX || snapshot?.goldenTargetY != captured.goldenTargetY
            let wasMoving = isMoving
            let wasAimAvailable = aimAvailable
            snapshot = captured
            tableState = normalized.state
            if captureFailureStartedAt != nil {
                recordCaptureEvent("captureRecovered", at: now)
            }
            captureFailureStartedAt = nil
            captureHealthy = true
            if predictionInputIssue != normalized.predictionIssue {
                recordCaptureEvent("predictionInputChanged", at: now,
                                   details: ["reason": normalized.predictionIssue ?? "supported"])
            }
            predictionInputIssue = normalized.predictionIssue
            if hasTable != (true) { hasTable = true }
            if isCalibrated != (normalized.calibrated) { isCalibrated = normalized.calibrated }
            if hasNativePhysics != (normalized.nativePhysics) { hasNativePhysics = normalized.nativePhysics }
            if shotInputSupported != captured.shotInputSupported { shotInputSupported = captured.shotInputSupported }
            if shotInputUnavailableReason != captured.shotInputUnavailableReason { shotInputUnavailableReason = captured.shotInputUnavailableReason }
            if isMoving != (normalized.moving) { isMoving = normalized.moving }
            if isLuckyShot != (captured.goldenShot) { isLuckyShot = captured.goldenShot }
            if isPlayerTurn != (captured.playerTurn) { isPlayerTurn = captured.playerTurn }
            if opponentPreviewAvailable != captured.opponentPreviewAvailable { opponentPreviewAvailable = captured.opponentPreviewAvailable }
            if opponentPreviewReason != captured.opponentPreviewUnavailableReason { opponentPreviewReason = captured.opponentPreviewUnavailableReason }
            if ballCount != (normalized.state.balls.count) { ballCount = normalized.state.balls.count }
            legalTargets = allowed
            runtimeCanShoot = captured.canShoot
            let shotSupported = captured.autoShotAvailable && normalized.calibrated && normalized.nativePhysics
                && (!captured.playerTurn || captured.shotInputSupported)
            if autoShotAvailable != shotSupported { autoShotAvailable = shotSupported }
            let physicsIssue = captured.diagnostics["physicsBlocker"].flatMap { $0.isEmpty ? nil : $0 }
            let physicsUnavailable = normalized.calibrated && !normalized.nativePhysics
                ? (physicsIssue ?? normalized.calibrationIssue ?? captured.autoShotUnavailableReason)
                : (normalized.calibrationIssue ?? captured.autoShotUnavailableReason)
            let unavailable = normalized.calibrated && normalized.nativePhysics && !captured.shotInputSupported
                ? captured.shotInputUnavailableReason : physicsUnavailable
            if autoShotUnavailableReason != unavailable { autoShotUnavailableReason = unavailable }
            let availableAim = captured.aimAvailable && captured.aimAngle.isFinite
                && captured.cuePower.isFinite && (0...1).contains(captured.cuePower)
            if aimAvailable != availableAim { aimAvailable = availableAim }
            var readiness = !normalized.calibrated || !normalized.nativePhysics || !captured.shotInputSupported
                ? autoShotUnavailableReason
                : (!captured.autoShotAvailable ? captured.autoShotUnavailableReason : captured.shootReadinessReason)
            if readiness.isEmpty { readiness = captured.canShoot ? "Controle nativo pronto para a tacada." : "O jogo ainda não liberou a tacada." }
            if liveReadiness != readiness { liveReadiness = readiness }
            let aimChanged = ingestNativeAim(captured)
            recordCapture(captured, now: ProcessInfo.processInfo.systemUptime, elapsed: captureElapsed)

            // Release duplicate-shot protection only on actual measured motion
            // or a turn transition, including motion in the native pocket area.
            acknowledgeShotProgress()

            // The capture can be valid while our rectangular pocket model is
            // not. Preserve measured ball/UI state, but never calculate or act
            // on an unsupported geometry and never clamp native coordinates.
            if let issue = predictionInputIssue {
                if predictionTask != nil || acceptedPrediction != nil || !traces.isEmpty {
                    cancelPrediction(clearOverlay: true)
                }
                if plannerTask != nil || !suggestions.isEmpty { cancelPlanner(clearSuggestions: true) }
                pauseAutomationForUnsupportedMotion(issue: issue, at: now)
                if liveReadiness != issue { liveReadiness = issue }
                if status != issue { status = issue }
                stableSince = nil
                onOverlayChange?()
                return
            }

            unsupportedMotionStartedAt = nil
            if isMoving {
                automaticPlan = nil
                automaticSearchContext = nil
                stableSince = nil
                if !wasMoving {
                    cancelPrediction(clearOverlay: true)
                    cancelPlanner(clearSuggestions: true)
                }
                if singleShotRequested { deferAutomaticActions(message: "A mesa mudou antes da tacada. Aguardando uma nova leitura.") }
                let movingStatus = normalized.nativePhysics ? "Posições, velocidades e efeito ao vivo; previsão de parada recalculada." : autoShotUnavailableReason
                if status != movingStatus { status = movingStatus }
                if !normalized.nativePhysics {
                    cancelPrediction(clearOverlay: true)
                    if automationArmed || singleShotRequested { waitAutomation(message: autoShotUnavailableReason) }
                }
                requestPrediction()
                onOverlayChange?()
                return
            }
            if !normalized.calibrated || !normalized.nativePhysics || !captured.shotInputSupported {
                cancelPrediction(clearOverlay: true)
                cancelPlanner(clearSuggestions: true)
                let reason = !captured.shotInputSupported && normalized.calibrated && normalized.nativePhysics
                    ? captured.shotInputUnavailableReason : autoShotUnavailableReason
                if !captured.playerTurn && normalized.calibrated && normalized.nativePhysics {
                    // The opponent's selected English belongs to their preview.
                    // It cannot disarm our already-enabled wait for the next turn.
                    if automationIsRunning && automationStatus != "Aguardando sua vez e o efeito centralizado no jogo." {
                        automationStatus = "Aguardando sua vez e o efeito centralizado no jogo."
                    }
                } else { waitAutomation(message: reason) }
                stableSince = nil
                if status != reason { status = reason }
                onOverlayChange?()
                return
            }
            if changed || wasMoving {
                automaticPlan = nil
                automaticSearchContext = nil
                stableSince = ProcessInfo.processInfo.systemUptime
                cancelPrediction(clearOverlay: true)
                cancelPlanner(clearSuggestions: true)
                status = isPlayerTurn ? "Mesa lida. As linhas acompanham a mira do jogo." : "Mesa lida. Aguardando sua vez."
            }
            if stableSince == nil { stableSince = ProcessInfo.processInfo.systemUptime }
            if !runtimeCanShoot {
                stableSince = nil
                // A manual pull must not cause continuous AIM to reapply an
                // already aligned shot when the touch ends on this same board.
                if plannerTask != nil { cancelPlanner(clearSuggestions: true) }
                suggestionStatus = liveReadiness
            }
            if followGameAim {
                if !aimAvailable {
                    cancelPrediction(clearOverlay: true)
                    if status != "Mira do jogo indisponível nesta etapa. Aguarde o jogo liberar a mira." {
                        status = "Mira do jogo indisponível nesta etapa. Aguarde o jogo liberar a mira."
                    }
                }
            }
            if let issue = normalized.calibrationIssue, status != issue { status = issue }
            if changed || wasMoving || aimChanged || (!wasAimAvailable && aimAvailable) { requestPrediction() }
            onOverlayChange?()
            if isWaitingForShot, let sentAt = shotSubmittedAt,
               ProcessInfo.processInfo.systemUptime - sentAt > shotStartTimeout {
                isWaitingForShot = false
                shotSubmittedAt = nil
                deferAutomaticActions(message: "Aguardando confirmação da tacada. A mesma posição não será disparada novamente.")
                return
            }
            if isPlayerTurn && !autoShotAvailable && (autoPlayEnabled || singleShotRequested) {
                waitAutomation(message: autoShotUnavailableReason)
                return
            }
            advanceAutomation()
        } catch {
            let runtimeError = error as NSError
            let expectedTransition = runtimeError.domain == "PoolLab.RuntimeBridge"
                && [4, 5, 20, 21, 24, 32, 33, 35, 37].contains(runtimeError.code)
            handleCaptureFailure(error, at: now, transient: expectedTransition)
        }
    }

    private func handleCaptureFailure(_ error: Error, at now: TimeInterval, transient: Bool) {
        let runtime = error as NSError
        let firstFailure = captureFailureStartedAt == nil
        if firstFailure {
            captureFailureStartedAt = now
            recordCaptureEvent("captureUnavailable", at: now,
                               details: ["domain": runtime.domain, "code": String(runtime.code),
                                         "reason": String(error.localizedDescription.prefix(256))])
        }
        captureHealthy = false
        runtimeCanShoot = false
        stableSince = nil
        // No fresh-reading gate can authorize a shot during even one failure.
        if firstFailure {
            automaticPlan = nil
            cancelPrediction(clearOverlay: true)
            cancelPlanner(clearSuggestions: true)
            if queueTransition == nil && (automationArmed || singleShotRequested) {
                waitAutomation(message: "Aguardando uma nova leitura da mesa.")
            }
        }
        // Expected native transitions do not repeatedly reset the panel's
        // entire table state. Hide estimates immediately, then clear a lasting
        // loss after a bounded grace period. Authorization failures never use it.
        let failureAge = max(0, now - (captureFailureStartedAt ?? now))
        if transient && hasTable && failureAge < 3 {
            onOverlayChange?()
            return
        }
        clearBoard(message: "Leitura indisponível: \(error.localizedDescription)",
                   preserveQueueIntent: queueTransition != nil && transient)
    }

    private func ingestNativeAim(_ captured: PLGameSnapshot) -> Bool {
        guard aimAvailable else { return false }
        let angle = Self.degrees(-captured.aimAngle)
        let nativeChanged = lastNativeAim.map {
            Self.angularDistance(angle, $0.angle) > 0.03 || abs(captured.cuePower - $0.power) > 0.0005
        } ?? false
        // Keep a threshold anchor, rather than replacing it on every sample:
        // several small native movements must also release a manual preview.
        if lastNativeAim == nil || nativeChanged { lastNativeAim = (angle, captured.cuePower) }
        // A temporary panel preview must not keep a stale direction after the
        // player touches the real cue. Explicitly paused following is respected.
        if previewIsTemporary && nativeChanged {
            followGameAim = true
            previewIsTemporary = false
            selectedSuggestionID = nil
        }
        guard followGameAim || (!isPlayerTurn && showOpponentPreview && opponentPreviewAvailable) else { return false }
        // The game's zero cue power means “not pulling yet”, not “hide the
        // preview”. Only our copied-value simulation uses this reference.
        // Any real pull takes precedence, including powers below release limit.
        let usesReference = isPlayerTurn && !isMoving && lockedPreviewPower == nil && captured.cuePower <= 0.000001
        let previewPower = isPlayerTurn
            ? (lockedPreviewPower ?? (usesReference ? referencePreviewPower : captured.cuePower))
            : captured.cuePower
        let referenceModeChanged = previewUsesReferencePower != usesReference
        if referenceModeChanged { previewUsesReferencePower = usesReference }
        if angleDegrees != angle { angleDegrees = angle }
        if power != previewPower { power = previewPower }
        guard let requestedPreviewShot,
              let simulationPower = try? GameShotCalibration.simulationPower(fromControlPower: previewPower) else { return true }
        // Compare with the last queued calculation, not the previous display
        // frame. Use the same angle/simulation-power tolerances as acceptance;
        // otherwise slow input can hide an old result without requesting a new one.
        return requestedPreviewUsesReferencePower != usesReference
            || Self.angularDistance(angle, Self.degrees(requestedPreviewShot.angleRadians)) > 0.03
            || abs(simulationPower - requestedPreviewShot.power) > 0.0005
    }

    private static func angularDistance(_ a: Double, _ b: Double) -> Double {
        let difference = abs(a - b).truncatingRemainder(dividingBy: 360)
        return min(difference, 360 - difference)
    }

    private func startPlanning(_ purpose: PlanningPurpose) {
        guard canRecommend, let state = tableState, let snapshot else { return }
        if purpose != .suggestions && !canApplyAim { return }
        guard let minimumPower = try? Self.minimumPlannerPower(control: snapshot.minimumShotPower) else {
            deferAutomaticActions(message: "Aguardando o jogo informar um limite de força válido.")
            return
        }
        cancelPlanner(clearSuggestions: true)
        let operation = plannerGeneration
        let allowed = legalTargets
        let isBreakShot = snapshot.isBreakShot
        let coordinateIdentity = ObjectIdentifier(snapshot.coordinateView)
        let startedAt = ProcessInfo.processInfo.systemUptime
        let context = AutomaticContext(state: state, allowed: allowed,
                                       coordinate: coordinateIdentity, isBreakShot: isBreakShot)
        if automaticSearchContext != context {
            automaticSearchPass = 0
            automaticSearchRetryAt = 0
        }
        automaticSearchContext = context
        let searchBudget = ShotSearchBudget(
            maximumDuration: ShotSearchBudget.automatic.maximumDuration,
            maximumSimulations: ShotSearchBudget.automatic.maximumSimulations,
            explorationPass: automaticSearchPass)
        planningPurpose = purpose
        isPlanning = true
        lastPlanningSearch = ["state": "running", "operation": operation,
                              "maximumDurationMs": searchBudget.maximumDuration * 1_000,
                              "maximumSimulations": searchBudget.maximumSimulations,
                              "explorationPass": searchBudget.explorationPass,
                              "turnRemainingTimeAvailable": false]
        status = "Comparando diretas, tabelas e desvios na mesa atual…"
        suggestionStatus = "Simulando rotas e forças antes de mover o taco…"
        recordCaptureEvent("planningStarted", at: startedAt,
                           details: ["purpose": String(describing: purpose),
                                     "maximumDurationMs": String(searchBudget.maximumDuration * 1_000),
                                     "maximumSimulations": String(searchBudget.maximumSimulations),
                                     "explorationPass": String(searchBudget.explorationPass)])
        if purpose == .singleShot || purpose == .autoPlay || purpose == .continuousAim {
            automationStatus = "Analisando rotas, tabelas e contatos permitidos…"
        }
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try ShotPlanner.search(for: state, includeBanks: true, limit: 4, allowedTargetIDs: allowed,
                    minimumPower: minimumPower, isBreakShot: isBreakShot, budget: searchBudget)
            }
            do {
                let report = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.plannerGeneration else { return }
                let found = report.suggestions
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.planningMilliseconds = max(0, ProcessInfo.processInfo.systemUptime - startedAt) * 1_000
                self.lastPlanningSearch["state"] = "completed"
                self.lastPlanningSearch["termination"] = report.termination.rawValue
                self.lastPlanningSearch["phases"] = report.phases
                self.lastPlanningSearch["candidates"] = report.candidates
                self.lastPlanningSearch["simulations"] = report.simulations
                self.lastPlanningSearch["elapsedMs"] = report.elapsed * 1_000
                self.lastPlanningSearch["solutions"] = found.count
                guard self.acceptsPlan(operation, state: state, allowed: allowed),
                      self.snapshot.map({ ObjectIdentifier($0.coordinateView) }) == coordinateIdentity,
                      self.snapshot?.isBreakShot == isBreakShot else {
                    self.suggestionStatus = "A mesa ou os controles mudaram. Aguarde para calcular novamente."
                    self.lastPlanningSearch["state"] = "discarded"
                    self.recordCaptureEvent("planningDiscarded", at: ProcessInfo.processInfo.systemUptime)
                    return
                }
                self.suggestionState = state
                self.suggestionAllowed = allowed
                self.suggestionCoordinateIdentity = coordinateIdentity
                self.suggestionIsBreakShot = isBreakShot
                self.suggestions = found
                self.recordCaptureEvent("planningCompleted", at: ProcessInfo.processInfo.systemUptime,
                                        details: ["count": String(found.count), "durationMs": String(self.planningMilliseconds),
                                                  "simulations": String(report.simulations), "candidates": String(report.candidates),
                                                  "phases": report.phases.joined(separator: ","),
                                                  "termination": report.termination.rawValue])
                guard let best = found.first else {
                    self.status = "A busca terminou sem encontrar uma rota validada nesta posição."
                    self.suggestionStatus = self.status
                    if purpose == .autoPlay || purpose == .continuousAim {
                        // The next bounded pass explores different samples.
                        // A cooldown prevents a failed search from restarting
                        // on every capture; fresh turn/state gates still apply.
                        self.automaticSearchPass = searchBudget.explorationPass == Int.max ? 0 : searchBudget.explorationPass + 1
                        self.automaticSearchRetryAt = ProcessInfo.processInfo.systemUptime + 0.65
                        self.lastPlanningSearch["nextExplorationPass"] = self.automaticSearchPass
                        self.lastPlanningSearch["retryDelayMs"] = 650
                        self.waitAutomation(message: "Automático ativo. Ampliando a busca por outra rota…")
                    } else if purpose == .singleShot { self.deferAutomaticActions(message: self.status) }
                    return
                }
                switch purpose {
                case .suggestions:
                    self.status = "Escolha uma tacada para ver o percurso."
                    self.suggestionStatus = "\(found.count) opções calculadas. Toque em uma para ver a previsão."
                case .applyAim:
                    guard self.setPreview(best.shot) else { return }
                    self.applyAim()
                case .continuousAim, .autoPlay:
                    guard self.automationIsRunning, !self.panelIsOpen,
                          let context = self.currentAutomaticContext else { return }
                    self.automaticPlan = AutomaticPlan(context: context, suggestion: best,
                        notBefore: startedAt + self.autoPlayMode.minimumAnalysisDuration)
                    self.selectedSuggestionID = best.id
                    self.advanceAutomation()
                case .singleShot:
                    self.execute(best, expectedState: state, allowed: allowed)
                case .luckyShot:
                    break // Lucky Shot uses its own bounded target search.
                }
            } catch {
                guard let self, operation == self.plannerGeneration else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.planningMilliseconds = max(0, ProcessInfo.processInfo.systemUptime - startedAt) * 1_000
                self.lastPlanningSearch["state"] = "failed"
                self.lastPlanningSearch["reason"] = String(error.localizedDescription.prefix(200))
                self.status = "Não foi possível calcular a tacada: \(error.localizedDescription)"
                self.suggestionStatus = self.status
                self.recordCaptureEvent("planningFailed", at: ProcessInfo.processInfo.systemUptime,
                                        details: ["reason": String(error.localizedDescription.prefix(200))])
                if purpose == .autoPlay || purpose == .continuousAim {
                    self.deferAutomaticActions(message: self.status)
                } else if purpose == .singleShot { self.deferAutomaticActions(message: self.status) }
            }
        }
    }

    private func advanceAutomation() {
        guard automationIsRunning || singleShotRequested, isAuthorized, !isWaitingForShot, !isPlanning else { return }
        guard !panelIsOpen else {
            cancelAutomaticControlSequence(reason: "menu", waitForInput: false)
            waitAutomation(message: "Feche o menu para continuar o AIM e o automático.")
            return
        }
        guard canCalculate, isPlayerTurn else {
            cancelAutomaticControlSequence(reason: "unavailable", waitForInput: false)
            waitAutomation(message: aimActionReadiness)
            return
        }
        guard !isLuckyShot else { waitAutomation(message: "AIM contínuo disponível nas partidas de sinuca."); return }
        guard tableState?.balls.contains(where: { $0.id != 0 && !$0.pocketed }) == true else {
            deferAutomaticActions(message: "Mesa concluída. Automático aguardando a próxima partida.")
            return
        }
        guard !legalTargets.isEmpty else {
            cancelAutomaticControlSequence(reason: "legalTargetsUnavailable", waitForInput: false)
            waitAutomation(message: "Aguardando o jogo informar as bolas permitidas.")
            return
        }
        guard runtimeCanShoot else {
            let touched = snapshot.map { Self.hasNativeControlTouch($0) } ?? false
            cancelAutomaticControlSequence(reason: touched ? "manualTouch" : "nativeReadiness", waitForInput: touched)
            waitAutomation(message: liveReadiness)
            return
        }
        if autoPlayEnabled || singleShotRequested {
            guard autoShotAvailable else {
                cancelAutomaticControlSequence(reason: "shotUnavailable", waitForInput: false)
                waitAutomation(message: autoShotUnavailableReason)
                return
            }
            guard tableState != lastSubmittedState else {
                waitAutomation(message: "Aguardando confirmação da tacada anterior. Esta posição não será repetida.")
                return
            }
        }
        let now = ProcessInfo.processInfo.systemUptime
        guard now >= automaticRetryAfter else { return }
        guard let stableSince, now - stableSince >= minimumStableTime else {
            waitAutomation(message: "Confirmando que a mesa está parada…")
            return
        }
        guard let context = currentAutomaticContext else { return }
        if automaticSearchContext != context {
            automaticSearchPass = 0
            automaticSearchRetryAt = 0
        }
        guard now >= automaticSearchRetryAt else { return }
        if let ready = automaticPlan, ready.context == context {
            guard now >= ready.notBefore else {
                waitAutomation(message: "Conferindo a rota calculada…")
                return
            }
            if (autoPlayEnabled || aimEnabled) && !ready.aimApplied {
                advanceAutomaticControlSequence(ready, at: now)
            }
            return
        }
        startPlanning(autoPlayEnabled ? .autoPlay : (aimEnabled ? .continuousAim : .singleShot))
    }

    private static func hasNativeControlTouch(_ current: PLGameSnapshot) -> Bool {
        ["nativeCurrentTouches", "nativeTouchArrayCount", "nativeCueCurrentTouches"].contains {
            (Int(current.diagnostics[$0] ?? "") ?? 0) > 0
        }
    }

    private static func controlAngleDelta(from start: Double, to target: Double) -> Double {
        (target - start).remainder(dividingBy: 2 * .pi)
    }

    private static func smoothControlFraction(_ value: Double) -> Double {
        let t = min(1, max(0, value))
        return t * t * (3 - 2 * t)
    }

    private func cancelAutomaticControlSequence(reason: String, waitForInput: Bool) {
        guard automaticPlan?.controlSequence != nil || (waitForInput && automaticPlan != nil) else { return }
        automaticPlan = nil
        stableSince = nil
        recordCaptureEvent("controlSequenceCancelled", at: ProcessInfo.processInfo.systemUptime,
                           details: ["reason": reason])
        if waitForInput {
            deferAutomaticActions(message: "Aguardando você soltar os controles para continuar o automático.")
        }
        // Leave the cue where it is. Resetting its force here could overwrite
        // the very manual gesture or changed game state that cancelled us.
    }

    private func advanceAutomaticControlSequence(_ plan: AutomaticPlan, at now: TimeInterval) {
        guard automationIsRunning, aimEnabled, !panelIsOpen, canApplyAim,
              currentAutomaticContext == plan.context else { return }
        let controlStartedAt = ProcessInfo.processInfo.systemUptime
        if plan.controlSequence == nil { maximumAutomaticControlMilliseconds = 0 }
        defer {
            lastAutomaticControlMilliseconds = max(0, ProcessInfo.processInfo.systemUptime - controlStartedAt) * 1_000
            maximumAutomaticControlMilliseconds = max(maximumAutomaticControlMilliseconds, lastAutomaticControlMilliseconds)
        }
        do {
            let current = try PLRuntimeBridge.capture()
            if Self.hasNativeControlTouch(current) {
                cancelAutomaticControlSequence(reason: "manualTouch", waitForInput: true)
                return
            }
            let normalized = try Self.normalized(current)
            guard current.playerTurn, current.canShoot, current.shotInputSupported,
                  Self.isFreshSample(current.captureTimestamp, at: ProcessInfo.processInfo.systemUptime),
                  normalized.calibrated, normalized.nativePhysics, normalized.predictionIssue == nil,
                  !normalized.moving, normalized.state == plan.context.state,
                  ObjectIdentifier(current.coordinateView) == plan.context.coordinate,
                  Set(current.legalTargetNumbers.map { $0.intValue }) == plan.context.allowed,
                  current.isBreakShot == plan.context.isBreakShot,
                  plan.context.allowed.contains(plan.suggestion.targetID), current.aimAvailable,
                  current.aimAngle.isFinite, current.cuePower.isFinite, (0...1).contains(current.cuePower),
                  isAuthorized else { throw CaptureError.changedTable }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: plan.suggestion.shot.power)
            var sequence: AutomaticControlSequence
            if let existing = plan.controlSequence {
                sequence = existing
                // Each previous setter already confirmed these exact values.
                // A later external adjustment belongs to the player; never
                // overwrite it or release a shot after it.
                if sequence.hasApplied &&
                    (abs(Self.controlAngleDelta(from: current.aimAngle, to: sequence.lastAngle)) > 0.00001 ||
                     abs(current.cuePower - sequence.lastPower) > 0.00001) {
                    cancelAutomaticControlSequence(reason: "manualControlChange", waitForInput: true)
                    return
                }
                let delta = now - sequence.lastTickAt
                guard delta.isFinite, delta >= 0, delta <= 0.25 else {
                    cancelAutomaticControlSequence(reason: "frameGap", waitForInput: false)
                    return
                }
                // A dropped frame cannot jump the whole pull/release sequence.
                sequence.elapsed += min(delta, 1.0 / 30.0)
                sequence.lastTickAt = now
            } else {
                if automaticAttemptContext != plan.context {
                    automaticAttemptContext = plan.context
                    automaticCommandAttempts = 0
                    automaticControlAttempts = 0
                }
                automaticControlAttempts += 1
                let targetAngle = -plan.suggestion.shot.angleRadians
                let angleDelta = Self.controlAngleDelta(from: current.aimAngle, to: targetAngle)
                sequence = AutomaticControlSequence(startAngle: current.aimAngle, startPower: current.cuePower,
                    targetAngle: targetAngle, targetPower: nativePower, angleDelta: angleDelta,
                    profile: autoPlayMode.controlProfile(angleDelta: angleDelta, power: nativePower), lastTickAt: now,
                    lastAngle: current.aimAngle, lastPower: current.cuePower)
                recordCaptureEvent("controlSequenceStarted", at: now,
                    details: ["target": String(plan.suggestion.targetID), "pocket": String(plan.suggestion.pocketID),
                              "power": String(nativePower), "mode": autoPlayMode.rawValue])
            }
            let phaseBefore = plan.controlSequence?.phase
            let controls = sequence.profile.sample(startAngle: sequence.startAngle,
                startPower: sequence.startPower, targetAngle: sequence.targetAngle,
                targetPower: sequence.targetPower, elapsed: sequence.elapsed)
            let controlAngle = controls.angle
            let controlPower = controls.power
            try PLRuntimeBridge.applyAimProgress(angle: controlAngle, power: controlPower,
                target: plan.suggestion.targetID, pocket: plan.suggestion.pocketID)
            sequence.lastAngle = controlAngle
            sequence.lastPower = controlPower
            sequence.hasApplied = true
            automaticPlan?.controlSequence = sequence
            angleDegrees = Self.degrees(-controlAngle)
            power = controlPower
            followGameAim = true
            previewIsTemporary = false
            if phaseBefore != sequence.phase {
                recordCaptureEvent("controlSequencePhase", at: now, details: ["phase": sequence.phase])
                if sequence.phase == "aligning" { automationStatus = "Alinhando o taco na bola \(plan.suggestion.targetID)…" }
                else if sequence.phase == "correcting" { automationStatus = "Voltando à direção calculada…" }
                else if sequence.phase == "pulling" { automationStatus = "Ajustando a força para \(Int((nativePower * 100).rounded()))%…" }
                else if sequence.phase == "settling" { automationStatus = "Conferindo a direção e a força antes da tacada…" }
            }
            guard sequence.phase == "ready" else { return }
            automaticPlan?.aimApplied = true
            if autoPlayEnabled {
                execute(plan.suggestion, expectedState: plan.context.state, allowed: plan.context.allowed)
            } else {
                automaticPlan?.controlSequence = nil
                automationStatus = "AIM na bola \(plan.suggestion.targetID), força \(Int((nativePower * 100).rounded()))%. Aguardando sua tacada."
                recordCaptureEvent("continuousAimApplied", at: now,
                    details: ["target": String(plan.suggestion.targetID), "pocket": String(plan.suggestion.pocketID)])
            }
        } catch {
            automaticPlan = nil
            recordCaptureEvent("controlSequenceRejected", at: ProcessInfo.processInfo.systemUptime,
                details: ["code": String((error as NSError).code), "domain": (error as NSError).domain,
                          "attempt": String(automaticControlAttempts)])
            if case CaptureError.changedTable = error {
                stableSince = nil
                waitAutomation(message: "A mesa mudou. Aguardando uma leitura estável para o AIM.")
            } else if (error as NSError).domain == "PoolLab.RuntimeBridge" && (error as NSError).code == 58 {
                deferAutomaticActions(message: "Controles interrompidos: \(error.localizedDescription)")
            } else if automaticControlAttempts < 2 {
                automaticRetryAfter = ProcessInfo.processInfo.systemUptime + 0.75
                stableSince = nil
                waitAutomation(message: "Aguardando o jogo liberar o ajuste gradual da mira.")
            } else {
                deferAutomaticActions(message: "AIM aguardando os controles: \(error.localizedDescription)")
            }
        }
    }

    /// Temporary native readiness never clears the user's enabled intent.
    private func waitAutomation(message: String) {
        if (automationIsRunning || singleShotRequested) && automationStatus != message { automationStatus = message }
    }

    /// Wait without changing the user's switches or explicit pause choice.
    /// Rechecks use the normal capture/stability gates and never clear an
    /// uncertain release latch on an unchanged board.
    private func deferAutomaticActions(message: String) {
        singleShotRequested = false
        if plannerTask != nil || !suggestions.isEmpty { cancelPlanner(clearSuggestions: true) }
        automaticPlan = nil
        stableSince = nil
        automaticRetryAfter = ProcessInfo.processInfo.systemUptime + 1
        if !automationPaused && automationStatus != message { automationStatus = message }
    }

    private func execute(_ suggestion: ShotSuggestion, expectedState: TableState, allowed: Set<Int>) {
        guard (autoPlayEnabled && automationIsRunning) || singleShotRequested,
              isAuthorized, !isWaitingForShot, !panelIsOpen,
              expectedState != lastSubmittedState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            let currentAllowed = Set(current.legalTargetNumbers.map { $0.intValue })
            guard current.playerTurn, current.canShoot, current.autoShotAvailable, current.shotInputSupported,
                  Self.isFreshSample(current.captureTimestamp, at: ProcessInfo.processInfo.systemUptime),
                  current.isBreakShot == (suggestion.method == .breakShot),
                  normalized.calibrated, normalized.nativePhysics, normalized.predictionIssue == nil, !normalized.moving, normalized.state == expectedState,
                  current.coordinateView === snapshot?.coordinateView,
                  currentAllowed == allowed, allowed.contains(suggestion.targetID),
                  isAuthorized else { throw CaptureError.changedTable }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power)
            if autoPlayEnabled && !singleShotRequested {
                guard let prepared = automaticPlan, prepared.aimApplied,
                      prepared.suggestion.id == suggestion.id,
                      prepared.context == currentAutomaticContext,
                      prepared.controlSequence?.phase == "ready",
                      abs(Self.controlAngleDelta(from: current.aimAngle, to: -suggestion.shot.angleRadians)) <= 0.00001,
                      abs(current.cuePower - nativePower) <= 0.00001,
                      !Self.hasNativeControlTouch(current) else {
                    cancelAutomaticControlSequence(reason: "finalControlMismatch", waitForInput: true)
                    return
                }
            }
            // Mark before entering the game: even a partial runtime failure
            // cannot cause a second invocation for this unchanged board.
            let context = currentAutomaticContext
            if automaticAttemptContext != context {
                automaticAttemptContext = context
                automaticCommandAttempts = 0
            }
            automaticCommandAttempts += 1
            lastSubmittedState = expectedState
            shotSubmittedAt = ProcessInfo.processInfo.systemUptime
            isWaitingForShot = true
            singleShotRequested = false
            recordCaptureEvent("shotSubmitted", at: ProcessInfo.processInfo.systemUptime,
                               details: ["target": String(suggestion.targetID), "pocket": String(suggestion.pocketID),
                                         "method": suggestion.method.rawValue])
            try PLRuntimeBridge.shoot(angle: -suggestion.shot.angleRadians, power: nativePower,
                                      target: suggestion.targetID, pocket: suggestion.pocketID)
            angleDegrees = Self.degrees(suggestion.shot.angleRadians)
            power = nativePower
            followGameAim = true
            automationStatus = "Tacada enviada. Aguardando movimento no jogo…"
            status = suggestion.method == .breakShot ? "Tacada de saída enviada." : "Bola \(suggestion.targetID), caçapa \(suggestion.pocketID + 1)."
            cancelPrediction(clearOverlay: true)
        } catch {
            recordCaptureEvent("automaticShotRejected", at: ProcessInfo.processInfo.systemUptime,
                details: ["code": String((error as NSError).code), "domain": (error as NSError).domain,
                          "attempt": String(automaticCommandAttempts),
                          "shotDispatched": ((error as NSError).userInfo["shotDispatched"] as? Bool).map(String.init) ?? "unknown"])
            shotSubmittedAt = nil
            isWaitingForShot = false
            if (error as NSError).userInfo["shotDispatched"] as? Bool == false {
                // A rejected guard is different from an uncertain release.
                // The bridge explicitly proves that no shot callback ran.
                lastSubmittedState = nil
            }
            automaticPlan = nil
            if case CaptureError.changedTable = error {
                stableSince = nil
                waitAutomation(message: "A mesa mudou. Aguardando nova leitura para calcular a tacada.")
            } else if (error as NSError).userInfo["shotDispatched"] as? Bool == false,
                      autoPlayEnabled, automaticCommandAttempts < 2 {
                automaticRetryAfter = ProcessInfo.processInfo.systemUptime + 0.75
                stableSince = nil
                waitAutomation(message: "O jogo ainda não liberou a tacada. Conferindo novamente.")
            } else {
                deferAutomaticActions(message: "Automático aguardando confirmação dos controles: \(error.localizedDescription)")
            }
            status = automationStatus
        }
    }

    private func acknowledgeShotProgress() {
        guard isMoving || !isPlayerTurn else { return }
        lastSubmittedState = nil
        automaticPlan = nil
        automaticSearchContext = nil
        automaticAttemptContext = nil
        automaticCommandAttempts = 0
        automaticControlAttempts = 0
        if isWaitingForShot {
            isWaitingForShot = false
            shotSubmittedAt = nil
            automationStatus = autoPlayEnabled ? "Tacada iniciada. Aguardando as bolas pararem." : "Tacada iniciada no jogo."
            recordCaptureEvent("shotMotionObserved", at: ProcessInfo.processInfo.systemUptime)
        }
    }

    private func pauseAutomationForUnsupportedMotion(issue: String, at now: TimeInterval) {
        guard automationArmed || singleShotRequested else { return }
        // A native pocket animation can leave the independent solver's rectangle.
        // Keep only already-armed intent, never a plan or release permission.
        guard automationIsRunning, isAuthorized, hasFreshCapture else {
            waitAutomation(message: issue)
            return
        }
        automaticPlan = nil
        if unsupportedMotionStartedAt == nil {
            unsupportedMotionStartedAt = now
            recordCaptureEvent("autoPlayPausedForNativeMotion", at: now)
        }
        guard let since = unsupportedMotionStartedAt, now - since < unsupportedMotionTimeout else {
            deferAutomaticActions(message: "Automático aguardando a mesa voltar a uma geometria suportada.")
            return
        }
        let message = "Automático aguardando as bolas e a caçapa terminarem o movimento."
        waitAutomation(message: message)
    }

    private func stopAutomation(message: String) {
        if automationArmed || singleShotRequested {
            recordCaptureEvent("automationStopped", at: ProcessInfo.processInfo.systemUptime,
                               details: ["reason": String(message.prefix(256))])
        }
        unsupportedMotionStartedAt = nil
        queueTransition = nil
        if autoPlayEnabled { autoPlayEnabled = false }
        updateAutomationClock(at: ProcessInfo.processInfo.systemUptime)
        if autoQueueEnabled { autoQueueEnabled = false }
        if aimEnabled { aimEnabled = false }
        if automationPaused { automationPaused = false }
        automaticPlan = nil
        automaticSearchContext = nil
        if singleShotRequested { singleShotRequested = false }
        if planningPurpose == .singleShot || planningPurpose == .autoPlay || planningPurpose == .continuousAim {
            cancelPlanner(clearSuggestions: false)
        }
        if automationStatus != message { automationStatus = message }
    }

    private func requestPrediction() {
        guard isAuthorized, captureHealthy, predictionInputIssue == nil, hasTable, hasNativePhysics, isMoving || isCalibrated, var state = tableState, let snapshot,
              isMoving || (canPreviewAim && aimAvailable && !isWaitingForShot) else { return }
        let now = ProcessInfo.processInfo.systemUptime
        guard snapshot.captureTimestamp.isFinite, now - snapshot.captureTimestamp <= 0.25,
              snapshot.captureTimestamp <= now + 0.01 else { return }
        if isMoving {
            guard now - lastMovingPredictionRequestAt >= 1.0 / 30 else { return }
            lastMovingPredictionRequestAt = now
            state.table = Self.continuationTable(state.table)
        }
        let shot: ShotParameters?
        if isMoving { shot = nil }
        else {
            guard let simulationPower = try? GameShotCalibration.simulationPower(fromControlPower: power) else { return }
            shot = ShotParameters(angleRadians: angleDegrees * .pi / 180, power: simulationPower)
        }
        let obstacles: Set<Int>? = isLuckyShot ? Set(state.balls.map(\.id)).subtracting([0, snapshot.goldenBallNumber]) : nil
        let request = PredictionRequest(state: state, shot: shot,
            capturedAt: snapshot.captureTimestamp, nativeFrame: snapshot.frameNumber,
            opponentCue: !isPlayerTurn,
            coordinateIdentity: ObjectIdentifier(snapshot.coordinateView), goldenObstacleIDs: obstacles,
            usesReferencePower: shot != nil && previewUsesReferencePower)
        if let shot {
            let inputChanged = requestedPreviewShot.map {
                Self.angularDistance(Self.degrees($0.angleRadians), Self.degrees(shot.angleRadians)) > 0.03
                    || abs($0.power - shot.power) > 0.0005
            } ?? true
            if inputChanged || requestedPreviewUsesReferencePower != request.usesReferencePower
                || predictionInputStableSince == nil {
                predictionInputStableSince = now
            }
            if let accepted = acceptedPrediction, !acceptsPrediction(accepted, at: now),
               predictionContextIsCurrent(accepted, at: now), predictionRenderDeadline == nil {
                predictionRenderDeadline = now + 1.0 / 60
            }
        } else {
            predictionInputStableSince = nil
            predictionRenderDeadline = nil
        }
        pendingPrediction = request
        requestedPreviewShot = shot
        requestedPreviewUsesReferencePower = request.usesReferencePower
        // One active worker plus the newest pending input. A completed result
        // commits directly; a render-only one-frame bridge avoids clearing the
        // existing layers during the small gap before that commit.
        if predictionTask == nil { startPendingPrediction() }
    }

    private func startPendingPrediction() {
        guard predictionTask == nil, let request = pendingPrediction else { return }
        pendingPrediction = nil
        activePrediction = request
        let operation = predictionGeneration
        if !isPredicting { isPredicting = true }
        predictionTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                let started = ProcessInfo.processInfo.systemUptime
                let result: ShotResult
                if let shot = request.shot {
                    result = try BilliardsEngine.simulate(state: request.state, shot: shot, recordFrames: true)
                } else {
                    result = try BilliardsEngine.simulateContinuation(state: request.state, recordFrames: true)
                }
                return (result, (ProcessInfo.processInfo.systemUptime - started) * 1_000)
            }
            do {
                let (result, computeMilliseconds) = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.predictionGeneration else { return }
                self.predictionTask = nil
                self.activePrediction = nil
                let now = ProcessInfo.processInfo.systemUptime
                self.lastPredictionComputeMilliseconds = computeMilliseconds
                // Metrics do not drive readiness or physics. Publishing them
                // four times a second keeps the panel stable during cue input.
                if self.lastPredictionMetricsAt == 0 || now - self.lastPredictionMetricsAt >= 0.25 {
                    self.predictionMilliseconds = computeMilliseconds
                    self.lastPredictionMetricsAt = now
                }
                if self.acceptsPrediction(request, at: now) {
                    let obstacleContact = request.goldenObstacleIDs.map { obstacles in
                        result.events.contains { event in
                            if case let .ballCollision(first, second) = event {
                                return obstacles.contains(first) || obstacles.contains(second)
                            }
                            return false
                        }
                    } ?? false
                    self.traces = obstacleContact ? [] : result.traces
                    self.finalBalls = !obstacleContact && result.settled ? result.finalState.balls : []
                    self.predictedFrames = obstacleContact ? [] : result.frames
                    if self.previewDuration != result.duration { self.previewDuration = result.duration }
                    self.predictionCompletedAt = request.capturedAt
                    self.acceptedPrediction = request
                    self.predictionRenderDeadline = nil
                    self.predictedPockets = obstacleContact ? [] : result.events.compactMap {
                        if case let .pocket(ball, pocket) = $0 { return (ball, pocket) }
                        return nil
                    }
                    self.predictedScratch = !obstacleContact && result.scratched
                    if obstacleContact { self.luckyStatus = "Percurso cruza um obstáculo. Ajuste a direção." }
                    else if !result.settled { self.status = "Percurso parcial; a simulação ainda não chegou ao repouso." }
                    self.onOverlayChange?()
                    self.onPredictionReady?()
                }
            } catch {
                guard let self, operation == self.predictionGeneration else { return }
                self.predictionTask = nil
                self.activePrediction = nil
                if self.acceptsPrediction(request, at: ProcessInfo.processInfo.systemUptime) {
                    self.traces = []; self.finalBalls = []; self.previewDuration = nil; self.acceptedPrediction = nil
                    self.status = "Previsão indisponível: \(error.localizedDescription)"
                    self.onOverlayChange?()
                }
            }
            guard let self, operation == self.predictionGeneration else { return }
            // At most one worker and one newest pending request. Continuous
            // aiming cannot starve a 70 ms debounce or queue obsolete frames.
            if self.pendingPrediction != nil { self.startPendingPrediction() }
            else if self.isPredicting { self.isPredicting = false }
        }
    }

    private func predictionContextIsCurrent(_ request: PredictionRequest, at time: TimeInterval) -> Bool {
        guard isAuthorized, captureHealthy, predictionInputIssue == nil, hasTable, hasNativePhysics, isMoving || isCalibrated, !Task.isCancelled,
              let snapshot, request.coordinateIdentity == ObjectIdentifier(snapshot.coordinateView),
              Self.isFreshSample(snapshot.captureTimestamp, at: time),
              let currentTable = tableState?.table,
              (request.shot == nil ? Self.continuationTable(currentTable) : currentTable) == request.state.table else { return false }
        if request.shot != nil {
            return canPreviewAim && request.opponentCue == !isPlayerTurn && !isWaitingForShot && tableState == request.state
                && request.usesReferencePower == previewUsesReferencePower
                && !(followGameAim && !aimAvailable)
        }
        // A moving estimate is short-lived. Current positions continue to be
        // drawn directly from native sprites even if the solver is too slow.
        return isMoving && time - request.capturedAt <= 0.15
            && Set(tableState?.balls.map(\.id) ?? []) == Set(request.state.balls.map(\.id))
    }

    private func acceptsPrediction(_ request: PredictionRequest, at time: TimeInterval) -> Bool {
        guard predictionContextIsCurrent(request, at: time) else { return false }
        guard let shot = request.shot else { return true }
        guard let currentPower = try? GameShotCalibration.simulationPower(fromControlPower: power) else { return false }
        return Self.angularDistance(Self.degrees(shot.angleRadians), angleDegrees) <= 0.03
            && abs(shot.power - currentPower) <= 0.0005
    }

    private static func continuationTable(_ source: PoolTable) -> PoolTable {
        var table = source
        // No cue impulse is created by continuation. A missing cue statistic
        // must not block measured moving balls; the stand-in only satisfies
        // the shared geometry validator and is never used as a shot speed.
        if !table.maximumShotSpeed.isFinite || !(1...2_000).contains(table.maximumShotSpeed) {
            table.maximumShotSpeed = 1
        }
        return table
    }

    private static func minimumPlannerPower(control: Double) throws -> Double {
        guard control.isFinite, (0...1).contains(control) else { throw BilliardsError.invalidShot }
        // The native threshold originates as float but is compared as double.
        // Guard the control value before simulation so a q -> p round trip
        // cannot fall one ULP below it. Never clamp an already planned shot.
        return try GameShotCalibration.simulationPower(fromControlPower: min(1, control + 1e-7))
    }

    private func accepts(_ state: TableState) -> Bool {
        isAuthorized && hasFreshCapture && predictionInputIssue == nil && isCalibrated && hasNativePhysics && shotInputSupported && !Task.isCancelled && tableState == state && !isMoving
    }
    private func acceptsPlan(_ operation: UInt64, state: TableState, allowed: Set<Int>) -> Bool {
        operation == plannerGeneration && accepts(state) && canRecommend && legalTargets == allowed
    }
    private func cancelPrediction(clearOverlay: Bool) {
        predictionGeneration &+= 1
        predictionTask?.cancel()
        predictionTask = nil
        pendingPrediction = nil
        activePrediction = nil
        requestedPreviewShot = nil
        predictionRenderDeadline = nil
        predictionInputStableSince = nil
        if isPredicting { isPredicting = false }
        if clearOverlay {
            traces = []; finalBalls = []; predictedFrames = []; acceptedPrediction = nil
            if previewDuration != nil { previewDuration = nil }
            onOverlayChange?()
        }
    }
    private func cancelPlanner(clearSuggestions: Bool) {
        if isPlanning && planningPurpose != .luckyShot && !lastPlanningSearch.isEmpty {
            lastPlanningSearch["state"] = "cancelled"
        }
        plannerGeneration &+= 1
        plannerTask?.cancel()
        plannerTask = nil
        planningPurpose = nil
        if isPlanning { isPlanning = false }
        if clearSuggestions {
            suggestionState = nil
            suggestionAllowed = []
            suggestionCoordinateIdentity = nil
            if selectedSuggestionID != nil {
                selectedSuggestionID = nil
                followGameAim = true
                previewIsTemporary = false
            }
            if !suggestions.isEmpty { suggestions = [] }
            if suggestionStatus != "Calcule uma sugestão quando a mesa estiver pronta." {
                suggestionStatus = "Calcule uma sugestão quando a mesa estiver pronta."
            }
            if luckySuggestion != nil { luckySuggestion = nil }
        }
    }
    private func clearBoard(message: String, preserveQueueIntent: Bool = false) {
        if !canPreserveAutomationIntent && autoQueueEnabled { autoQueueEnabled = false; queueStatus = "Próxima partida automática pausada; ative novamente para continuar." }
        if !isAuthorized && blockInterstitialAds { setBlockInterstitialAds(false) }
        if preserveQueueIntent && queueTransition != nil && autoPlayEnabled && autoQueueEnabled && isAuthorized {
            singleShotRequested = false
            automationStatus = "Automático aguardando a próxima mesa. Você pode desligar a qualquer momento."
        } else if canPreserveAutomationIntent {
            deferAutomaticActions(message: message)
        } else { stopAutomation(message: message) }
        cancelPrediction(clearOverlay: true)
        cancelPlanner(clearSuggestions: true)
        snapshot = nil
        captureHealthy = false
        predictionInputIssue = nil
        unsupportedMotionStartedAt = nil
        lastNativeAim = nil
        if liveReadiness != message { liveReadiness = message }
        tableState = nil
        stableSince = nil
        shotSubmittedAt = nil
        if isWaitingForShot { isWaitingForShot = false }
        if hasTable { hasTable = false }
        if isPlayerTurn { isPlayerTurn = false }
        if isMoving { isMoving = false }
        if aimAvailable { aimAvailable = false }
        if isCalibrated { isCalibrated = false }
        if hasNativePhysics { hasNativePhysics = false }
        if shotInputSupported { shotInputSupported = false }
        if previewUsesReferencePower { previewUsesReferencePower = false }
        if shotInputUnavailableReason != message { shotInputUnavailableReason = message }
        if opponentPreviewAvailable { opponentPreviewAvailable = false }
        if isLuckyShot { isLuckyShot = false }
        if luckyStatus != "Aguardando o alvo da Lucky Shot." { luckyStatus = "Aguardando o alvo da Lucky Shot." }
        runtimeCanShoot = false
        if autoShotAvailable { autoShotAvailable = false }
        if autoShotUnavailableReason != message { autoShotUnavailableReason = message }
        legalTargets = []
        if ballCount != 0 { ballCount = 0 }
        if status != message { status = message }
    }
    private func setPreview(_ shot: ShotParameters) -> Bool {
        guard shot.angleRadians.isFinite,
              let nativePower = try? GameShotCalibration.controlPower(fromSimulationPower: shot.power) else {
            status = "A sugestão contém uma direção ou força inválida."
            return false
        }
        angleDegrees = Self.degrees(shot.angleRadians)
        power = nativePower
        if previewUsesReferencePower { previewUsesReferencePower = false }
        return true
    }
    private static func degrees(_ radians: Double) -> Double {
        let result = (radians * 180 / .pi).truncatingRemainder(dividingBy: 360)
        return result < 0 ? result + 360 : result
    }
    private func boolStyle(_ key: String, fallback: Bool) -> Bool {
        styles.object(forKey: stylePrefix + key) == nil ? fallback : styles.bool(forKey: stylePrefix + key)
    }
    private func stringStyle(_ key: String, fallback: String, allowed: Set<String>) -> String {
        let value = styles.string(forKey: stylePrefix + key) ?? fallback
        return allowed.contains(value) ? value : fallback
    }
    private func numberStyle(_ key: String, fallback: Double, range: ClosedRange<Double>) -> Double {
        guard styles.object(forKey: stylePrefix + key) != nil else { return fallback }
        let value = styles.double(forKey: stylePrefix + key)
        return value.isFinite ? min(range.upperBound, max(range.lowerBound, value)) : fallback
    }
    private func saveStyle(_ value: Any, _ key: String) {
        styles.set(value, forKey: stylePrefix + key)
        onOverlayChange?()
    }

    private static func normalized(_ snapshot: PLGameSnapshot, useOpponentCue: Bool = false) throws -> (state: TableState, moving: Bool, calibrated: Bool, nativePhysics: Bool, calibrationIssue: String?, predictionIssue: String?) {
        let values = [snapshot.originX, snapshot.originY, snapshot.width, snapshot.height]
        guard values.allSatisfy(\.isFinite), snapshot.width > 0, snapshot.height > 0,
              !snapshot.balls.isEmpty, snapshot.balls.count <= 16 else { throw CaptureError.invalidGeometry }
        let scale = 200 / snapshot.width
        let radii = snapshot.balls.map { $0.radius * scale }
        guard radii.allSatisfy({ $0.isFinite && $0 > 0 }) else { throw CaptureError.invalidGeometry }
        guard Set(snapshot.balls.map(\.number)).count == snapshot.balls.count,
              snapshot.balls.allSatisfy({ (0...15).contains($0.number)
                  && [$0.x, $0.y, $0.vx, $0.vy, $0.spinX, $0.spinY, $0.spinZ].allSatisfy(\.isFinite) }) else {
            throw CaptureError.invalidGeometry
        }
        let radius = radii.reduce(0, +) / Double(radii.count)
        guard radii.allSatisfy({ abs($0 - radius) <= 0.05 * radius }) else { throw CaptureError.invalidGeometry }
        var table = PoolTable()
        table.width = 200
        table.height = snapshot.height * scale
        table.ballRadius = radius
        let nativePoints = snapshot.nativeCushionVertices.map(\.cgPointValue)
        let nativePocketCenters = snapshot.nativePocketCenters.map(\.cgPointValue)
        let nativePocketAimPoints = snapshot.nativePocketAimPoints.map(\.cgPointValue)
        let nativeAttractionRadius = snapshot.nativePocketRadius * scale
        let nativeAttraction = snapshot.nativePocketAttractionCoefficient
        let geometryAvailable = snapshot.nativeGeometryAvailable
            && (4...192).contains(nativePoints.count)
            && nativePocketCenters.count == 6 && nativePocketAimPoints.count == 6
            && nativeAttractionRadius.isFinite && (radius...(radius * 6)).contains(nativeAttractionRadius)
            && nativeAttraction.isFinite && (0...10_000).contains(nativeAttraction)
            && (nativePoints + nativePocketCenters + nativePocketAimPoints).allSatisfy { $0.x.isFinite && $0.y.isFinite }
        if geometryAvailable {
            func point(_ value: CGPoint) -> Vector2 {
                Vector2(x: (Double(value.x) - snapshot.originX) * scale,
                        y: (snapshot.originY + snapshot.height - Double(value.y)) * scale)
            }
            // The native numbering follows the opposite Y orientation. These
            // ids match the existing pocket-nomination mapping in the bridge.
            let nativeIndices = [5, 4, 3, 0, 1, 2]
            let pockets = nativeIndices.enumerated().map { id, nativeIndex in
                NativePocketGeometry(id: id, center: point(nativePocketCenters[nativeIndex]),
                    radius: radius, aimPoint: point(nativePocketAimPoints[nativeIndex]),
                    attractionRadius: nativeAttractionRadius)
            }
            table.pocketRadius = radius
            // Native acceleration is (pocketCenter - position) * coefficient;
            // reflecting/scaling the displacement leaves its 1/s² coefficient unchanged.
            table.nativeGeometry = NativeTableGeometry(pockets: pockets, cushionVertices: nativePoints.map(point),
                                                       pocketAttraction: nativeAttraction)
        }
        let maximumSpeed = (useOpponentCue ? snapshot.opponentMaximumShotSpeed : snapshot.maximumShotSpeed) * scale
        let calibratedCue = maximumSpeed.isFinite && (1...2000).contains(maximumSpeed)
        let deceleration = snapshot.rollingDeceleration * scale
        let dynamics = NativeDynamics(
            slidingDeceleration: snapshot.slidingDeceleration * scale,
            equilibriumTimeFactor: snapshot.equilibriumTimeFactor / scale,
            spinDeceleration: snapshot.spinDeceleration,
            slidingFrictionCoefficient: snapshot.slidingFrictionCoefficient,
            cushionSpinCoupling: snapshot.cushionSpinCoupling,
            logicalFrameTime: snapshot.logicalFrameTime)
        let dynamicsValues = [dynamics.slidingDeceleration, dynamics.equilibriumTimeFactor,
                              dynamics.spinDeceleration, dynamics.slidingFrictionCoefficient,
                              dynamics.cushionSpinCoupling, dynamics.logicalFrameTime]
        let validDynamics = dynamicsValues.allSatisfy(\.isFinite)
            && (0.001...2_000).contains(dynamics.slidingDeceleration)
            && (1e-8...100).contains(dynamics.equilibriumTimeFactor)
            && (0...10_000).contains(dynamics.spinDeceleration)
            && (0...1).contains(dynamics.slidingFrictionCoefficient)
            && (0...2).contains(dynamics.cushionSpinCoupling)
            && (0.0005...0.02).contains(dynamics.logicalFrameTime)
        let calibratedTable = geometryAvailable && snapshot.physicsCalibrationAvailable && deceleration.isFinite
            && (0...100).contains(deceleration) && snapshot.ballRestitution.isFinite
            && (0...1).contains(snapshot.ballRestitution) && snapshot.cushionRestitution.isFinite
            && (0...1).contains(snapshot.cushionRestitution) && validDynamics
        let calibrationIssue: String?
        if !calibratedCue {
            calibrationIssue = "Mesa lida, mas a força do taco atual não pôde ser calibrada. Previsão e tacadas automáticas pausadas."
        } else if !geometryAvailable {
            calibrationIssue = snapshot.nativeGeometryUnavailableReason.isEmpty
                ? "Geometria nativa das caçapas indisponível. Linhas e tacadas automáticas pausadas."
                : snapshot.nativeGeometryUnavailableReason
        } else if !calibratedTable {
            calibrationIssue = "Parâmetros físicos desta mesa indisponíveis ou fora dos limites aceitos. Previsões e tacadas automáticas pausadas."
        } else { calibrationIssue = nil }
        table.maximumShotSpeed = calibratedCue ? maximumSpeed : 0
        if calibratedTable {
            table.rollingDeceleration = deceleration
            table.ballRestitution = snapshot.ballRestitution
            table.cushionRestitution = snapshot.cushionRestitution
            table.nativeDynamics = dynamics
        }
        // Native motion includes angular velocity, even when the center stopped.
        // Keep every copied component: cutting small residuals can authorize a
        // new shot while the game is still resolving sliding or spin.
        let moving = snapshot.balls.contains {
            $0.vx != 0 || $0.vy != 0 || $0.spinX != 0 || $0.spinY != 0 || $0.spinZ != 0
        }
        let balls: [PoolBall] = snapshot.balls.map { ball in
            return PoolBall(id: ball.number,
                            position: Vector2(x: (ball.x - snapshot.originX) * scale,
                                              y: (snapshot.originY + snapshot.height - ball.y) * scale),
                            velocity: Vector2(x: ball.vx * scale, y: -ball.vy * scale),
                            // Angular velocity is a pseudovector. Reflecting Y
                            // negates X and Z, and never scales radians/second.
                            spin: BallSpin(x: -ball.spinX, y: ball.spinY, z: -ball.spinZ))
        }.sorted { $0.id < $1.id }
        let state = TableState(table: table, balls: balls)
        // Native sprites near the pocket can legitimately leave the rectangle
        // accepted by the independent solver. That is a prediction limitation,
        // not a reason to erase a valid native capture or flash the panel.
        var predictionIssue: String?
        if calibratedTable {
            var geometryValidation = state
            if !calibratedCue { geometryValidation.table.maximumShotSpeed = 1 }
            do {
                if moving { try BilliardsEngine.validateContinuation(geometryValidation) }
                else { try BilliardsEngine.validate(geometryValidation, requireCue: false) }
            } catch is CancellationError { throw CancellationError() }
            catch {
                predictionIssue = "Leitura ao vivo mantida. Previsão pausada enquanto as bolas estão fora da geometria suportada."
            }
        }
        return (state, moving, calibratedCue, calibratedTable, calibrationIssue, predictionIssue)
    }

    private static func isActive(_ window: UIWindow) -> Bool {
        guard !window.isHidden else { return false }
        if let scene = window.windowScene { return scene.activationState == .foregroundActive }
        return UIApplication.shared.applicationState == .active
    }
    private enum CaptureError: LocalizedError {
        case invalidGeometry, changedTable, staleCapture
        var errorDescription: String? {
            switch self {
            case .invalidGeometry: return "A geometria lida da partida não corresponde a uma mesa válida."
            case .staleCapture: return "A leitura da mesa ficou antiga. Aguarde uma nova leitura."
            case .changedTable: return "A partida mudou. Aguarde a mesa parar e solicite uma nova tacada."
            }
        }
    }
}
