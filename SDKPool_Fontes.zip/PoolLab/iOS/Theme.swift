import SwiftUI

enum PoolTheme {
    // SDKPool keeps the game visible around one opaque, readable control panel.
    static let background = Color(red: 0.024, green: 0.024, blue: 0.035)
    static let surface = Color(red: 0.090, green: 0.086, blue: 0.086)
    static let elevated = Color(red: 0.14, green: 0.13, blue: 0.13)
    static let accent = Color(red: 1.0, green: 0.48, blue: 0.20)
    static let action = Color(red: 0.76, green: 0.12, blue: 0.13)
    // Darker orange/red fills keep white control labels readable.
    static let highlight = LinearGradient(colors: [Color(red: 0.72, green: 0.25, blue: 0.055), action], startPoint: .leading, endPoint: .trailing)
    static let secondary = Color(red: 0.73, green: 0.75, blue: 0.79)
    static let success = Color(red: 0.43, green: 0.86, blue: 0.69)
    static let warning = Color(red: 1.0, green: 0.79, blue: 0.48)
    static let border = Color.white.opacity(0.14)
}

struct PoolCard<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(PoolTheme.surface)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(PoolTheme.border, lineWidth: 1)
            )
    }
}

struct PoolPrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .frame(maxWidth: .infinity, minHeight: 52)
            .foregroundColor(isEnabled ? Color.white : PoolTheme.secondary)
            .background(isEnabled ? PoolTheme.action : PoolTheme.elevated)
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
            .opacity(configuration.isPressed ? 0.8 : 1)
    }
}

struct PoolStatusLabel: View {
    let title: String
    var symbol: String = "circle.fill"
    var color: Color = PoolTheme.accent

    var body: some View {
        Label(title, systemImage: symbol)
            .font(.caption.weight(.semibold))
            .foregroundColor(color)
            .padding(.horizontal, 11)
            .padding(.vertical, 7)
            .background(color.opacity(0.1))
            .clipShape(Capsule())
    }
}

extension View {
    func poolField() -> some View {
        self
            .padding(.horizontal, 15)
            .frame(minHeight: 52)
            .background(PoolTheme.background)
            .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .stroke(PoolTheme.border, lineWidth: 1)
            )
    }
}
