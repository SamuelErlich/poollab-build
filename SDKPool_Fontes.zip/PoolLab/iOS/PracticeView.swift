import SwiftUI
import UniformTypeIdentifiers
import PoolLabCore

@MainActor
struct PracticeView: View {
    @ObservedObject var model: AppModel
    @StateObject private var practice = PracticeModel()
    @Environment(\.scenePhase) private var scenePhase
    @State private var draggedBallID: Int?
    @State private var isImporting = false
    @State private var isExporting = false
    @State private var exportDocument = PoolSceneDocument(data: Data())

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                introduction
                tableCard
                feedback
                if practice.cueNeedsPlacement { cuePlacement }
                playbackControls
                shotControls
                suggestionControls
                ballControls
                sceneControls
                Text("Modelo local aproximado, sem efeito na bola. As sugestões seguem esta simulação; não reproduzem a física do 8 Ball Pool.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: 760)
            .padding(20)
            .frame(maxWidth: .infinity)
        }
        .background(PoolTheme.background.ignoresSafeArea())
        .foregroundColor(.white)
        .navigationTitle("Mesa de treino")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarHidden(false)
        .onAppear { practice.appear(authorization: model) }
        .onDisappear { draggedBallID = nil; practice.disappear() }
        .onChange(of: model.canUseModules) { allowed in
            if !allowed { draggedBallID = nil }
            practice.accessChanged()
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active { practice.accessChanged() }
            else { draggedBallID = nil; practice.suspend() }
        }
        .fileImporter(isPresented: $isImporting, allowedContentTypes: [.json], allowsMultipleSelection: false, onCompletion: importFile)
        .fileExporter(isPresented: $isExporting, document: exportDocument, contentType: .json, defaultFilename: "PoolLab_mesa") { result in
            switch result {
            case .success: practice.report("Mesa exportada em JSON.")
            case .failure(let error): practice.report(error.localizedDescription)
            }
        }
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 9) {
            PoolStatusLabel(title: "TREINO LOCAL", symbol: "circle.grid.cross")
            Text("Monte. Preveja. Jogue.")
                .font(.system(size: 29, weight: .bold, design: .rounded))
            Text("Arraste as bolas, teste uma trajetória e compare opções de tacada.")
                .foregroundColor(PoolTheme.secondary)
            if !model.canUseModules {
                Label("Treino pausado enquanto seu acesso é verificado.", systemImage: "lock.fill")
                    .font(.subheadline)
                    .foregroundColor(PoolTheme.warning)
            }
        }
        .fixedSize(horizontal: false, vertical: true)
    }

    private var tableCard: some View {
        VStack(spacing: 12) {
            tableView
            HStack(spacing: 12) {
                Label("Branca", systemImage: "circle.fill").foregroundColor(.white)
                Label("Trajetórias", systemImage: "line.diagonal").foregroundColor(PoolTheme.accent)
                Spacer(minLength: 0)
                if practice.isPreviewing { ProgressView().tint(PoolTheme.accent).scaleEffect(0.8) }
            }
            .font(.caption2)
            Toggle("Mostrar o caminho de todas as bolas", isOn: Binding(get: { practice.showAllPaths }, set: practice.setShowAllPaths))
                .font(.caption)
                .tint(PoolTheme.accent)
                .disabled(!model.canUseModules)
            if let preview = practice.preview, !preview.settled {
                Text("Previsão interrompida no limite de tempo da simulação.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.warning)
            }
        }
    }

    private var tableView: some View {
        GeometryReader { geometry in
            let scale = geometry.size.width / CGFloat(practice.state.table.width)
            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 7)
                    .fill(LinearGradient(colors: [Color(red: 0.035, green: 0.30, blue: 0.24), Color(red: 0.025, green: 0.18, blue: 0.19)], startPoint: .topLeading, endPoint: .bottomTrailing))
                grid(in: geometry.size)
                trajectories(scale: scale)
                pockets(scale: scale)
                ghostBall(scale: scale)
                ForEach(practice.visibleBalls) { ball in
                    ballView(ball, scale: scale)
                }
            }
            .contentShape(Rectangle())
            .coordinateSpace(name: "poolTable")
            .gesture(tableDrag(scale: scale))
            .overlay(RoundedRectangle(cornerRadius: 7).stroke(Color.white.opacity(0.15), lineWidth: 1).allowsHitTesting(false))
        }
        .aspectRatio(CGFloat(practice.state.table.width / practice.state.table.height), contentMode: .fit)
        .padding(13)
        .background(PoolTheme.elevated)
        .clipShape(RoundedRectangle(cornerRadius: 19))
        .overlay(RoundedRectangle(cornerRadius: 19).stroke(PoolTheme.border, lineWidth: 1))
        .opacity(model.canUseModules ? 1 : 0.45)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Mesa de treino. Seis caçapas e \(practice.visibleBalls.count) bolas.")
    }

    private func grid(in size: CGSize) -> some View {
        Path { path in
            for column in 1..<4 {
                let x = size.width * CGFloat(column) / 4
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
            }
            path.move(to: CGPoint(x: 0, y: size.height / 2))
            path.addLine(to: CGPoint(x: size.width, y: size.height / 2))
        }
        .stroke(Color.white.opacity(0.07), style: StrokeStyle(lineWidth: 1, dash: [3, 7]))
        .allowsHitTesting(false)
    }

    private func trajectories(scale: CGFloat) -> some View {
        let traces = practice.preview?.traces ?? []
        return ForEach(traces) { trace in
            if practice.showAllPaths || trace.id == 0 {
                Path { path in
                    guard let first = trace.points.first else { return }
                    path.move(to: screen(first, scale: scale))
                    for point in trace.points.dropFirst() { path.addLine(to: screen(point, scale: scale)) }
                }
                .stroke(trace.id == 0 ? PoolTheme.accent : PoolBallGlyph.color(for: trace.id).opacity(0.9), style: StrokeStyle(lineWidth: trace.id == 0 ? 1.8 : 1.3, lineCap: .round, lineJoin: .round, dash: trace.id == 0 ? [6, 4] : [3, 3]))
                .allowsHitTesting(false)
            }
        }
    }

    private func pockets(scale: CGFloat) -> some View {
        ForEach(practice.state.table.pockets) { pocket in
            Button {
                practice.setPocket(practice.pocketID == pocket.id ? nil : pocket.id)
            } label: {
                Circle()
                    .fill(Color.black.opacity(0.85))
                    .overlay(Circle().stroke(practice.pocketID == pocket.id ? PoolTheme.warning : Color.white.opacity(0.12), lineWidth: practice.pocketID == pocket.id ? 2.5 : 1))
                    .frame(width: CGFloat(practice.state.table.pocketRadius * 2) * scale, height: CGFloat(practice.state.table.pocketRadius * 2) * scale)
                    .frame(minWidth: 26, minHeight: 26)
                    .contentShape(Circle())
            }
            .buttonStyle(.plain)
            .position(screen(pocket.center, scale: scale))
            .disabled(!practice.canEdit)
            .accessibilityLabel("Caçapa \(pocket.name)")
            .accessibilityValue(practice.pocketID == pocket.id ? "Selecionada" : "Não selecionada")
        }
    }

    @ViewBuilder
    private func ghostBall(scale: CGFloat) -> some View {
        if let suggestion = practice.selectedSuggestion, !practice.isRunning {
            let diameter = CGFloat(practice.state.table.ballRadius * 2) * scale
            Circle()
                .stroke(PoolTheme.warning, style: StrokeStyle(lineWidth: 1.5, dash: [3, 2]))
                .frame(width: diameter, height: diameter)
                .position(screen(suggestion.ghostBall, scale: scale))
                .allowsHitTesting(false)
                .accessibilityHidden(true)
        }
    }

    private func ballView(_ ball: PoolBall, scale: CGFloat) -> some View {
        let diameter = CGFloat(practice.state.table.ballRadius * 2) * scale
        return PoolBallGlyph(id: ball.id, diameter: diameter)
            .overlay(Circle().stroke(ball.id == practice.selectedBallID ? PoolTheme.accent : .clear, lineWidth: 2).padding(-3))
            .frame(width: max(18, diameter), height: max(18, diameter))
            .contentShape(Circle())
            .position(screen(ball.position, scale: scale))
            .onTapGesture { practice.selectBall(ball.id) }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(ball.id == 0 ? "Bola branca" : "Bola \(ball.id)")
            .accessibilityValue(ball.id == practice.selectedBallID ? "Selecionada" : "")
            .accessibilityAction(named: Text("Selecionar")) { practice.selectBall(ball.id) }
            .accessibilityAction(named: Text("Mover à esquerda")) { practice.selectBall(ball.id); practice.nudgeSelected(x: -3, y: 0) }
            .accessibilityAction(named: Text("Mover à direita")) { practice.selectBall(ball.id); practice.nudgeSelected(x: 3, y: 0) }
            .accessibilityAction(named: Text("Mover para cima")) { practice.selectBall(ball.id); practice.nudgeSelected(x: 0, y: -3) }
            .accessibilityAction(named: Text("Mover para baixo")) { practice.selectBall(ball.id); practice.nudgeSelected(x: 0, y: 3) }
    }

    private func tableDrag(scale: CGFloat) -> some Gesture {
        DragGesture(minimumDistance: 3, coordinateSpace: .named("poolTable"))
            .onChanged { value in
                guard practice.canEdit else { return }
                if draggedBallID == nil {
                    let start = Vector2(x: Double(value.startLocation.x / scale), y: Double(value.startLocation.y / scale))
                    let nearest = practice.visibleBalls.min { $0.position.distance(to: start) < $1.position.distance(to: start) }
                    guard let ball = nearest, ball.position.distance(to: start) <= max(practice.state.table.ballRadius * 3, Double(18 / scale)) else { return }
                    draggedBallID = ball.id
                    practice.beginMove(id: ball.id)
                }
                practice.moveSelected(to: Vector2(x: Double(value.location.x / scale), y: Double(value.location.y / scale)))
            }
            .onEnded { _ in
                if draggedBallID != nil { practice.finishMove() }
                draggedBallID = nil
            }
    }

    private var feedback: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: practice.isRunning ? "play.circle.fill" : "info.circle")
                .foregroundColor(PoolTheme.accent)
            Text(practice.message)
                .font(.subheadline)
                .foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .accessibilityElement(children: .combine)
    }

    private var cuePlacement: some View {
        PoolCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("A branca precisa voltar à mesa", systemImage: "circle.dashed")
                    .font(.headline)
                    .foregroundColor(PoolTheme.warning)
                Text("Recoloque a bola, ajuste a posição e escolha a próxima tacada.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.secondary)
                Button("Recolocar branca") {
                    practice.selectBall(0)
                    practice.placeSelectedBall()
                }
                .buttonStyle(PoolPrimaryButtonStyle())
                .disabled(!practice.canEdit)
            }
        }
    }

    private var playbackControls: some View {
        PoolCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text("Tacada e replay").font(.headline)
                    Spacer()
                    if practice.isAutomatic {
                        Text("\(practice.automaticCount)/10")
                            .font(.caption.monospacedDigit())
                            .foregroundColor(PoolTheme.accent)
                    }
                }
                if practice.isRunning {
                    HStack(spacing: 12) {
                        Button { practice.togglePause() } label: {
                            Label(practice.isReplayPaused ? "Continuar" : "Pausar", systemImage: practice.isReplayPaused ? "play.fill" : "pause.fill")
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .disabled(!practice.isReplaying || !model.canUseModules)
                        Button { practice.stop() } label: {
                            Label("Parar", systemImage: "stop.fill")
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                        .tint(PoolTheme.warning)
                    }
                    .buttonStyle(.bordered)
                } else {
                    Button { practice.shoot() } label: {
                        Label("Executar tacada", systemImage: "play.fill")
                    }
                    .buttonStyle(PoolPrimaryButtonStyle())
                    .disabled(!practice.canShoot)
                    HStack(spacing: 12) {
                        Button { practice.undo() } label: {
                            Label("Desfazer", systemImage: "arrow.uturn.backward")
                                .frame(maxWidth: .infinity, minHeight: 40)
                        }
                        .disabled(!practice.canUndo)
                        Button { practice.replayLastShot() } label: {
                            Label("Replay", systemImage: "gobackward")
                                .frame(maxWidth: .infinity, minHeight: 40)
                        }
                        .disabled(!practice.canEdit || !practice.hasReplay)
                    }
                    .buttonStyle(.bordered)
                }
                Picker("Velocidade do replay", selection: Binding(get: { practice.replaySpeed }, set: practice.setReplaySpeed)) {
                    Text("0,5×").tag(0.5)
                    Text("1×").tag(1.0)
                    Text("2×").tag(2.0)
                    Text("4×").tag(4.0)
                }
                .pickerStyle(.segmented)
                .disabled(!model.canUseModules)
            }
            .tint(PoolTheme.accent)
        }
    }

    private var shotControls: some View {
        PoolCard {
            VStack(alignment: .leading, spacing: 18) {
                HStack {
                    Text("Direção").font(.headline)
                    Spacer()
                    Text("\(Int(practice.angleDegrees.rounded()))°")
                        .font(.system(.title3, design: .monospaced).weight(.semibold))
                        .foregroundColor(PoolTheme.accent)
                }
                Slider(value: Binding(get: { practice.angleDegrees }, set: practice.setAngle), in: 0...360, step: 0.5)
                    .accessibilityLabel("Direção da tacada em graus")
                HStack {
                    Text("Força").font(.headline)
                    Spacer()
                    Text("\(Int((practice.power * 100).rounded()))%")
                        .font(.system(.title3, design: .monospaced).weight(.semibold))
                        .foregroundColor(PoolTheme.accent)
                }
                Slider(value: Binding(get: { practice.power }, set: practice.setPower), in: 0.03...1, step: 0.01)
                    .accessibilityLabel("Força da tacada")
                Text("0° aponta para a direita; 90° aponta para baixo. A força usa a escala deste modelo local.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.secondary)
            }
            .tint(PoolTheme.accent)
            .disabled(!practice.canEdit)
        }
    }

    private var suggestionControls: some View {
        PoolCard {
            VStack(alignment: .leading, spacing: 17) {
                Label("Assistente de tacadas", systemImage: "scope").font(.headline)
                VStack(spacing: 7) {
                    Picker("Bola de destino", selection: Binding(get: { practice.targetID ?? -1 }, set: { practice.setTarget($0 < 0 ? nil : $0) })) {
                        Text("Qualquer bola").tag(-1)
                        ForEach(practice.objectBalls) { ball in Text("Bola \(ball.id)").tag(ball.id) }
                    }
                    Picker("Caçapa", selection: Binding(get: { practice.pocketID ?? -1 }, set: { practice.setPocket($0 < 0 ? nil : $0) })) {
                        Text("Qualquer caçapa").tag(-1)
                        ForEach(practice.state.table.pockets) { pocket in Text(pocket.name).tag(pocket.id) }
                    }
                    Toggle("Incluir tabelas", isOn: Binding(get: { practice.includeBanks }, set: practice.setIncludeBanks))
                        .font(.subheadline)
                }
                .disabled(!practice.canEdit)
                Button { practice.findSuggestions() } label: {
                    HStack(spacing: 9) {
                        if practice.isPlanning { ProgressView().tint(PoolTheme.secondary) }
                        Text(practice.isPlanning ? "Procurando opções…" : "Calcular sugestões")
                    }
                }
                .buttonStyle(PoolPrimaryButtonStyle())
                .disabled(!practice.canShoot || practice.objectBalls.isEmpty || practice.isPlanning)
                if !practice.suggestions.isEmpty {
                    VStack(spacing: 9) {
                        ForEach(Array(practice.suggestions.enumerated()), id: \.element.id) { index, suggestion in
                            suggestionRow(suggestion, rank: index + 1)
                        }
                    }
                }
                Divider().overlay(PoolTheme.border)
                Button { practice.startAutomatic() } label: {
                    Label("Executar sequência local", systemImage: "play.rectangle.on.rectangle")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.bordered)
                .disabled(!practice.canShoot || practice.objectBalls.isEmpty || practice.isPlanning)
                Text("Até 10 tacadas nesta mesa. A sequência busca qualquer bola, respeita a caçapa escolhida e para em erro, falta ou ausência de opção.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.secondary)
                Text("As opções são ordenadas pelo custo calculado do percurso. A ordem não é uma porcentagem de acerto.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.secondary)
            }
            .tint(PoolTheme.accent)
        }
    }

    private func suggestionRow(_ suggestion: ShotSuggestion, rank: Int) -> some View {
        let pocketName = practice.state.table.pockets.first { $0.id == suggestion.pocketID }?.name ?? "Caçapa \(suggestion.pocketID + 1)"
        let selected = practice.selectedSuggestion?.id == suggestion.id
        return Button { practice.applySuggestion(suggestion) } label: {
            HStack(spacing: 11) {
                Text("\(rank)")
                    .font(.headline.monospacedDigit())
                    .foregroundColor(PoolTheme.accent)
                    .frame(width: 25)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Bola \(suggestion.targetID) · \(suggestion.method == .bank ? "Tabela" : "Direta")")
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(.white)
                    Text("\(pocketName) · força \(Int((suggestion.shot.power * 100).rounded()))%")
                        .font(.caption)
                        .foregroundColor(PoolTheme.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: selected ? "checkmark.circle.fill" : "arrow.up.right.circle")
                    .foregroundColor(selected ? PoolTheme.accent : PoolTheme.secondary)
            }
            .padding(12)
            .background(selected ? PoolTheme.accent.opacity(0.10) : PoolTheme.background)
            .clipShape(RoundedRectangle(cornerRadius: 13))
        }
        .buttonStyle(.plain)
        .disabled(!practice.canEdit)
        .accessibilityHint("Aplica o ângulo e a força à previsão, sem executar a tacada")
    }

    private var ballControls: some View {
        PoolCard {
            VStack(alignment: .leading, spacing: 15) {
                Label("Monte sua jogada", systemImage: "circle.grid.3x3.fill").font(.headline)
                Picker("Bola selecionada", selection: Binding(get: { practice.selectedBallID }, set: practice.selectBall)) {
                    Text("Branca").tag(0)
                    ForEach(1...15, id: \.self) { id in Text("Bola \(id)").tag(id) }
                }
                .pickerStyle(.menu)
                if let ball = practice.selectedBall {
                    Text("Posição x: \(Int(ball.position.x.rounded())) · y: \(Int(ball.position.y.rounded()))")
                        .font(.caption.monospacedDigit())
                        .foregroundColor(PoolTheme.secondary)
                    HStack(spacing: 12) {
                        nudgeButton("arrow.left", name: "Mover à esquerda", x: -3, y: 0)
                        nudgeButton("arrow.up", name: "Mover para cima", x: 0, y: -3)
                        nudgeButton("arrow.down", name: "Mover para baixo", x: 0, y: 3)
                        nudgeButton("arrow.right", name: "Mover à direita", x: 3, y: 0)
                    }
                    if ball.id != 0 {
                        Button("Retirar esta bola da mesa") { practice.removeSelectedBall() }
                            .font(.subheadline)
                            .tint(PoolTheme.warning)
                            .frame(minHeight: 42)
                    }
                } else {
                    Button(practice.selectedBallID == 0 ? "Recolocar branca" : "Adicionar bola \(practice.selectedBallID)") { practice.placeSelectedBall() }
                        .buttonStyle(PoolPrimaryButtonStyle())
                }
                Text("Arraste diretamente na mesa ou use as setas. Bolas sobrepostas não são aceitas.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.secondary)
            }
            .tint(PoolTheme.accent)
            .disabled(!practice.canEdit)
        }
    }

    private func nudgeButton(_ symbol: String, name: String, x: Double, y: Double) -> some View {
        Button { practice.nudgeSelected(x: x, y: y) } label: {
            Image(systemName: symbol).frame(maxWidth: .infinity, minHeight: 40)
        }
        .buttonStyle(.bordered)
        .accessibilityLabel(name)
    }

    private var sceneControls: some View {
        PoolCard {
            VStack(alignment: .leading, spacing: 15) {
                Label("Mesas e arquivos", systemImage: "square.stack.3d.up").font(.headline)
                Menu {
                    Button("Tacada reta") { practice.reset(to: .straightShot) }
                    Button("Treino com cinco bolas") { practice.reset(to: .practice) }
                    Button("Triângulo completo") { practice.reset(to: .fullRack) }
                } label: {
                    Label("Escolher uma mesa pronta", systemImage: "square.grid.2x2")
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.bordered)
                HStack(spacing: 12) {
                    Button { practice.saveScene() } label: { Label("Salvar", systemImage: "square.and.arrow.down").frame(maxWidth: .infinity, minHeight: 42) }
                    Button { practice.loadScene() } label: { Label("Carregar", systemImage: "arrow.clockwise").frame(maxWidth: .infinity, minHeight: 42) }
                        .disabled(!practice.hasSavedScene)
                }
                .buttonStyle(.bordered)
                HStack(spacing: 12) {
                    Button { if practice.canEdit { isImporting = true } } label: {
                        Label("Importar JSON", systemImage: "doc.badge.plus").frame(maxWidth: .infinity, minHeight: 42)
                    }
                    Button {
                        guard let data = practice.exportScene() else { return }
                        exportDocument = PoolSceneDocument(data: data)
                        isExporting = true
                    } label: {
                        Label("Exportar JSON", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity, minHeight: 42)
                    }
                }
                .font(.caption.weight(.semibold))
                .buttonStyle(.bordered)
                Text("Salvar mantém uma mesa neste aparelho. O JSON compartilha apenas a mesa e as bolas, com limite de 64 KB.")
                    .font(.caption)
                    .foregroundColor(PoolTheme.secondary)
            }
            .tint(PoolTheme.accent)
            .disabled(!practice.canEdit)
        }
    }

    private func screen(_ point: Vector2, scale: CGFloat) -> CGPoint {
        CGPoint(x: CGFloat(point.x) * scale, y: CGFloat(point.y) * scale)
    }

    private func importFile(_ result: Result<[URL], Error>) {
        guard practice.canEdit else { return }
        do {
            guard let url = try result.get().first else { return }
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
            guard values.isRegularFile == true, let size = values.fileSize, size > 0, size <= 65_536 else {
                practice.report("Escolha um arquivo JSON de mesa com até 64 KB.")
                return
            }
            let handle = try FileHandle(forReadingFrom: url)
            defer { try? handle.close() }
            let data = try handle.read(upToCount: 65_537) ?? Data()
            guard !data.isEmpty, data.count <= 65_536 else {
                practice.report("Escolha um arquivo JSON de mesa com até 64 KB.")
                return
            }
            practice.importScene(data)
        } catch { practice.report(error.localizedDescription) }
    }
}

private struct PoolSceneDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data

    init(data: Data) { self.data = data }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents, data.count <= 65_536 else {
            throw CocoaError(.fileReadCorruptFile)
        }
        self.data = data
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

private struct PoolBallGlyph: View {
    let id: Int
    let diameter: CGFloat

    var body: some View {
        ZStack {
            Circle().fill(id > 8 ? .white : Self.color(for: id))
            if id > 8 {
                Rectangle()
                    .fill(Self.color(for: id))
                    .frame(height: diameter * 0.52)
                    .frame(width: diameter, height: diameter)
                    .clipShape(Circle())
            }
            if id > 0 {
                Circle().fill(Color.white.opacity(0.96)).frame(width: diameter * 0.53, height: diameter * 0.53)
                Text("\(id)")
                    .font(.system(size: max(5, diameter * 0.36), weight: .bold, design: .rounded))
                    .foregroundColor(.black)
            }
        }
        .frame(width: diameter, height: diameter)
        .overlay(Circle().stroke(Color.black.opacity(0.22), lineWidth: 0.6))
        .shadow(color: .black.opacity(0.38), radius: 1.5, x: 0, y: 1)
    }

    static func color(for id: Int) -> Color {
        switch id {
        case 0: return .white
        case 1, 9: return Color(red: 1, green: 0.76, blue: 0.15)
        case 2, 10: return Color(red: 0.23, green: 0.55, blue: 1)
        case 3, 11: return Color(red: 0.96, green: 0.28, blue: 0.28)
        case 4, 12: return Color(red: 0.68, green: 0.39, blue: 0.96)
        case 5, 13: return Color(red: 1, green: 0.48, blue: 0.14)
        case 6, 14: return Color(red: 0.22, green: 0.78, blue: 0.42)
        case 7, 15: return Color(red: 0.67, green: 0.16, blue: 0.28)
        default: return Color(white: 0.08)
        }
    }
}
