import Foundation
import Combine
import PoolLabCore
#if canImport(Security)
import Security
#endif
#if canImport(UIKit)
import UIKit
#endif

enum AppPhase: Equatable {
    case signedOut, authenticating, authenticated, checking
    case error(String)
}

@MainActor
final class AppModel: ObservableObject {
    @Published var licenseKey = ""
    @Published var twoFactorCode = ""
    @Published private(set) var phase: AppPhase = .signedOut
    @Published private(set) var session: LicenseSession?
    @Published private(set) var hasRememberedLicense = false
    @Published private(set) var credentialNotice: String?
    @Published private(set) var clipboardNotice: String?
    @Published private var currentDate = Date()

    let configurationIssue: String?
    private let client: (any Licensing)?
    private let credentialStore: any LicenseCredentialStoring
    private let deviceIDProvider: () throws -> String
    private let now: () -> Date
    private let clipboardReader: () -> String?
    private var rememberedKey: String?
    private var pendingCredentialToSave: String?
    private var credentialReadCompleted = false
    private var clipboardAttempted = false
    private var automaticAttemptedThisActivation = false
    private var automaticLoginBlocked = false
    private var signedOutByUser = false
    private var isForeground = true
    private var lastValidatedAt: Date?
    private var generation: UInt64 = 0
    private var heartbeat: Task<Void, Never>?
    private var expiryWatch: Task<Void, Never>?
    private var validating = false
    private var foregroundRefreshPending = false

    var canUseModules: Bool {
        guard isForeground, phase == .authenticated,
              let session, let lastValidatedAt else { return false }
        let elapsed = currentDate.timeIntervalSince(lastValidatedAt)
        return elapsed >= 0 && elapsed < 75 && session.expiresAt > currentDate
    }

    var statusText: String {
        switch phase {
        case .signedOut: return "Entre com sua licença"
        case .authenticating: return "Validando sua licença…"
        case .authenticated: return canUseModules ? "Sessão ativa" : "Acesso pausado"
        case .checking: return "Confirmando sua sessão…"
        case .error(let message): return message
        }
    }

    init(configurationBundle: Bundle = .main) {
        credentialStore = LicenseKeychainStore()
        deviceIDProvider = { try DeviceIdentity.loadOrCreate() }
        now = Date.init
        clipboardReader = Self.readSystemClipboard
        do {
            let config = try Self.readConfiguration(bundle: configurationBundle)
            client = KeyAuthClient(configuration: config)
            configurationIssue = nil
        } catch {
            client = nil
            configurationIssue = error.localizedDescription
        }
        restoreRememberedCredential()
    }

    /// Internal dependency seam for lifecycle tests. Production always uses the
    /// signed KeyAuth client and device-only Keychain implementation above.
    init(client: any Licensing, credentialStore: any LicenseCredentialStoring,
         deviceIDProvider: @escaping () throws -> String, now: @escaping () -> Date = Date.init,
         clipboardReader: @escaping () -> String? = { nil }) {
        self.client = client
        self.credentialStore = credentialStore
        self.deviceIDProvider = deviceIDProvider
        self.now = now
        self.clipboardReader = clipboardReader
        configurationIssue = nil
        currentDate = now()
        restoreRememberedCredential()
    }

    private func restoreRememberedCredential() {
        guard !credentialReadCompleted else { return }
        do {
            rememberedKey = try credentialStore.load()
            hasRememberedLicense = rememberedKey != nil
            credentialReadCompleted = true
            credentialNotice = hasRememberedLicense ? "Chave salva neste iPhone. Entrada automática ativada." : nil
        } catch {
            // A temporarily locked Keychain must not look like an empty device.
            credentialNotice = "Não foi possível ler a chave salva. Desbloqueie o iPhone e tente novamente."
        }
    }

    /// Clipboard text is a suggestion only. Never authenticate arbitrary copied
    /// text, overwrite manual input, or replace an already remembered license.
    @discardableResult
    func pasteLicense(_ text: String) -> Bool {
        guard !hasRememberedLicense, licenseKey.isEmpty,
              phase != .authenticating, phase != .checking else { return false }
        guard let key = LicenseKeyInput.clipboardCandidate(text) else {
            clipboardNotice = "O texto copiado não parece uma chave. Cole ou digite sua licença no campo."
            return false
        }
        licenseKey = key
        clipboardNotice = "Chave preenchida. Toque em Entrar para validar."
        return true
    }

    func pasteFromClipboard() {
        guard !hasRememberedLicense, licenseKey.isEmpty,
              phase != .authenticating, phase != .checking else { return }
        guard let text = clipboardReader() else {
            clipboardNotice = "Nenhuma chave disponível. Use Colar ou digite sua licença."
            return
        }
        _ = pasteLicense(text)
    }

    private static func readSystemClipboard() -> String? {
        #if canImport(UIKit)
        guard UIPasteboard.general.hasStrings else { return nil }
        // On iOS 16+ a first programmatic read can require system approval.
        // The panel also offers the native PasteButton for an explicit paste.
        return UIPasteboard.general.string
        #else
        return nil
        #endif
    }

    func activate() async {
        guard let client, configurationIssue == nil, isForeground,
              phase != .authenticating, phase != .checking else { return }
        let entered = licenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let key = LicenseKeyInput.manualCandidate(entered.isEmpty ? rememberedKey ?? "" : entered) else {
            phase = .error("Confira a licença informada.")
            return
        }
        let code = twoFactorCode.trimmingCharacters(in: .whitespacesAndNewlines)
        signedOutByUser = false
        automaticLoginBlocked = false
        generation &+= 1
        let operation = generation
        stopTimers()
        validating = false
        foregroundRefreshPending = false
        session = nil
        lastValidatedAt = nil
        phase = .authenticating
        // Keep a manually entered key available for correction after a failure;
        // clear it only after a successful signed response. Never keep OTPs.
        twoFactorCode = ""
        do {
            let deviceID = try deviceIDProvider()
            let result = try await client.authenticate(
                key: key, deviceID: deviceID, twoFactorCode: code.isEmpty ? nil : code
            )
            guard operation == generation else { return }
            try Task.checkCancellation()
            currentDate = now()
            guard result.expiresAt > currentDate else {
                automaticLoginBlocked = true
                await invalidate("Sua assinatura não está ativa.")
                return
            }
            // Persist the credential only after KeyAuth has authenticated it.
            // A lifecycle interruption must not erase a valid remembered key.
            persistCredential(key)
            licenseKey = ""
            clipboardNotice = nil
            session = result
            lastValidatedAt = currentDate
            phase = isForeground ? .authenticated : .checking
            if isForeground { startTimers() }
        } catch {
            guard operation == generation else { return }
            automaticLoginBlocked = Self.requiresManualRetry(error)
            await invalidate(Self.message(for: error, key: key))
        }
    }

    private func persistCredential(_ key: String) {
        do {
            try credentialStore.save(key)
            rememberedKey = key
            pendingCredentialToSave = nil
            hasRememberedLicense = true
            credentialReadCompleted = true
            credentialNotice = "Chave salva neste iPhone. Entrada automática ativada."
        } catch {
            // A completed login while the device locks may not access Keychain.
            // Retain in memory and retry storage on the next foreground event.
            pendingCredentialToSave = key
            credentialNotice = "Sessão ativa, mas não foi possível salvar a chave neste iPhone."
        }
    }

    /// Sign out preserves the stored key but prevents automatic re-entry during
    /// this run. Forgetting the device credential is a separate explicit action.
    private func endLocalSession() {
        signedOutByUser = true
        automaticAttemptedThisActivation = true
        foregroundRefreshPending = false
        generation &+= 1
        stopTimers()
        validating = false
        session = nil
        lastValidatedAt = nil
        licenseKey = ""
        twoFactorCode = ""
        phase = .signedOut
    }

    func signOut() async {
        endLocalSession()
        if let client { await client.logout() }
    }

    func forgetLicense() async {
        // Delete before the remote logout await: a later explicit login must
        // never have its newly stored credential removed by this older action.
        endLocalSession()
        pendingCredentialToSave = nil
        do {
            try credentialStore.remove()
            rememberedKey = nil
            hasRememberedLicense = false
            credentialReadCompleted = true
            credentialNotice = "Chave removida deste iPhone."
            clipboardNotice = nil
        } catch {
            credentialNotice = "Não foi possível apagar a chave salva. Desbloqueie o iPhone e tente novamente."
        }
        if let client { await client.logout() }
    }

    func becameInactive() {
        if isForeground { automaticAttemptedThisActivation = false }
        isForeground = false
        foregroundRefreshPending = false
        currentDate = now()
        stopTimers()
        if session != nil { phase = .checking }
    }

    func becameActive() async {
        isForeground = true
        currentDate = now()
        restoreRememberedCredential()
        if let key = pendingCredentialToSave { persistCredential(key) }
        guard configurationIssue == nil, !signedOutByUser else { return }
        if session != nil {
            if validating {
                // An inactive transition can cancel an in-flight heartbeat. If
                // foreground arrives before its callback, let that callback
                // finish, then recover once with a fresh saved-key login.
                foregroundRefreshPending = true
                return
            }
            await revalidate()
            return
        }
        guard phase != .authenticating, phase != .checking,
              !automaticAttemptedThisActivation else { return }
        automaticAttemptedThisActivation = true
        if hasRememberedLicense, licenseKey.isEmpty, !automaticLoginBlocked {
            await activate()
        } else if !clipboardAttempted, credentialReadCompleted,
                  !hasRememberedLicense, licenseKey.isEmpty, phase == .signedOut {
            // Mark before reading: the OS paste prompt can itself interrupt the
            // app and must not cause repeated reads or repeated permission prompts.
            clipboardAttempted = true
            pasteFromClipboard()
        }
    }

    private func revalidate() async {
        guard isForeground, let client, let session, !validating else { return }
        currentDate = now()
        guard session.expiresAt > currentDate else {
            automaticLoginBlocked = true
            await invalidate("Sua assinatura expirou. Ative uma licença válida.")
            return
        }
        validating = true
        // A routine heartbeat must not briefly revoke a still-current session:
        // doing so tears down predictions and automation once every minute.
        // Foreground resume already set .checking while inactive. Expiry and
        // the 75-second freshness cap continue to fail closed during this await.
        if !canUseModules { phase = .checking }
        let operation = generation
        do {
            let refreshed = try await client.checkSession()
            guard operation == generation else { return }
            validating = false
            currentDate = now()
            guard self.session != nil else { return }
            guard refreshed.expiresAt > currentDate else {
                automaticLoginBlocked = true
                await invalidate("Sua assinatura expirou. Ative uma licença válida.")
                return
            }
            self.session = refreshed
            foregroundRefreshPending = false
            guard isForeground else { return }
            lastValidatedAt = currentDate
            phase = .authenticated
            startTimers()
        } catch {
            guard operation == generation else { return }
            validating = false
            let resumeWasWaiting = foregroundRefreshPending && isForeground
            foregroundRefreshPending = false
            automaticLoginBlocked = Self.requiresManualRetry(error)
            await invalidate(Self.message(for: error, key: rememberedKey))
            let failedGeneration = operation &+ 1
            guard resumeWasWaiting, isForeground, generation == failedGeneration,
                  !signedOutByUser, !automaticLoginBlocked, !automaticAttemptedThisActivation,
                  hasRememberedLicense, licenseKey.isEmpty, self.session == nil else { return }
            automaticAttemptedThisActivation = true
            // A canceled heartbeat cannot perform the new request itself.
            // This unstructured task gets one fresh, independently canceled
            // lifetime; generation prevents it from undoing signout/replacement.
            Task { [weak self] in
                guard let self, self.generation == failedGeneration, self.isForeground,
                      !self.signedOutByUser, !self.automaticLoginBlocked,
                      self.hasRememberedLicense, self.licenseKey.isEmpty,
                      self.session == nil else { return }
                await self.activate()
            }
        }
    }

    private static func requiresManualRetry(_ error: Error) -> Bool {
        guard let error = error as? KeyAuthError else { return false }
        switch error {
        case .serviceRejected, .noActiveSubscription, .invalidInput, .invalidConfiguration:
            return true
        default:
            return false
        }
    }

    private static func message(for error: Error, key: String?) -> String {
        var message = error.localizedDescription
        if let key, !key.isEmpty { message = message.replacingOccurrences(of: key, with: "[chave]") }
        return String(message.prefix(512))
    }

    private func invalidate(_ message: String) async {
        generation &+= 1
        stopTimers()
        validating = false
        session = nil
        lastValidatedAt = nil
        phase = .error(message)
        if let client { await client.logout() }
    }

    private func startTimers() {
        stopTimers()
        heartbeat = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 60_000_000_000) }
            catch { return }
            guard !Task.isCancelled else { return }
            await self?.revalidate()
        }
        expiryWatch = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 1_000_000_000) }
                catch { return }
                guard let self, self.isForeground else { return }
                self.currentDate = self.now()
                if let session = self.session, session.expiresAt <= self.currentDate {
                    self.automaticLoginBlocked = true
                    await self.invalidate("Sua assinatura expirou. Ative uma licença válida.")
                    return
                }
            }
        }
    }

    private func stopTimers() {
        heartbeat?.cancel()
        expiryWatch?.cancel()
        heartbeat = nil
        expiryWatch = nil
    }

    private static func readConfiguration(bundle: Bundle) throws -> KeyAuthConfiguration {
        guard let url = bundle.url(forResource: "KeyAuth", withExtension: "plist"),
              let data = try? Data(contentsOf: url),
              let dictionary = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: String],
              let name = dictionary["AppName"], !name.isEmpty, !name.hasPrefix("PREENCHA"),
              let owner = dictionary["OwnerID"], !owner.isEmpty, !owner.hasPrefix("PREENCHA"),
              let version = dictionary["Version"], !version.isEmpty else {
            throw ConfigurationError.missing
        }
        let required = dictionary["RequiredSubscription"].flatMap { $0.isEmpty ? nil : $0 }
        return KeyAuthConfiguration(appName: name, ownerID: owner, version: version, requiredSubscription: required)
    }

    private enum ConfigurationError: LocalizedError {
        case missing
        var errorDescription: String? { "A configuração do serviço de licenças ainda não foi concluída." }
    }
}


/// Input validation is deliberately more conservative for automatic clipboard
/// suggestions than for manually entered KeyAuth license formats.
enum LicenseKeyInput {
    static func manualCandidate(_ raw: String) -> String? {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, key.utf8.count <= 512,
              !key.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else { return nil }
        return key
    }

    static func clipboardCandidate(_ raw: String) -> String? {
        guard raw.utf8.count <= 1024 else { return nil }
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let allowed = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")
        guard (12...512).contains(key.utf8.count),
              key.unicodeScalars.allSatisfy({ allowed.contains($0) }),
              key.unicodeScalars.contains(where: { CharacterSet.letters.contains($0) }),
              key.unicodeScalars.contains(where: { CharacterSet.decimalDigits.contains($0) }) else { return nil }
        return key
    }
}

@MainActor
protocol LicenseCredentialStoring {
    func load() throws -> String?
    func save(_ key: String) throws
    func remove() throws
}

/// The stable host-app identifier intentionally survives the PoolLab → SDKPool
/// display-name change. Credentials never enter preferences, telemetry or files.
@MainActor
struct LicenseKeychainStore: LicenseCredentialStoring {
    private let service: String
    private let account = "license-key"

    init(bundleIdentifier: String? = Bundle.main.bundleIdentifier) {
        service = (bundleIdentifier ?? "com.example.poollab") + ".license"
    }

    private enum StorageError: Error { case unavailable, operation(Int32), invalidData }

    #if canImport(Security)
    private var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: false]
    }
    #endif

    func load() throws -> String? {
        #if canImport(Security)
        var read = query
        read[kSecReturnData as String] = true
        read[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(read as CFDictionary, &item)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess else { throw StorageError.operation(status) }
        guard let data = item as? Data, let raw = String(data: data, encoding: .utf8),
              let key = LicenseKeyInput.manualCandidate(raw) else { throw StorageError.invalidData }
        return key
        #else
        throw StorageError.unavailable
        #endif
    }

    func save(_ key: String) throws {
        #if canImport(Security)
        guard LicenseKeyInput.manualCandidate(key) == key else { throw StorageError.invalidData }
        let attributes: [String: Any] = [
            kSecValueData as String: Data(key.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let updated = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if updated == errSecSuccess { return }
        guard updated == errSecItemNotFound else { throw StorageError.operation(updated) }
        let insert = query.merging(attributes) { _, value in value }
        let added = SecItemAdd(insert as CFDictionary, nil)
        if added == errSecDuplicateItem {
            let retried = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
            guard retried == errSecSuccess else { throw StorageError.operation(retried) }
            return
        }
        guard added == errSecSuccess else { throw StorageError.operation(added) }
        #else
        throw StorageError.unavailable
        #endif
    }

    func remove() throws {
        #if canImport(Security)
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw StorageError.operation(status) }
        #else
        throw StorageError.unavailable
        #endif
    }
}
