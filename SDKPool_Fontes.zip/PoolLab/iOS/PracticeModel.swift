import Foundation
import Combine
import PoolLabCore

/// Owns the editable local table. No state or input is read from another app.
@MainActor
final class PracticeModel: ObservableObject {
    @Published private(set) var state = TableState.practice
    @Published private(set) var angleDegrees = 342.0
    @Published private(set) var power = 0.45
    @Published private(set) var selectedBallID = 0
    @Published private(set) var targetID: Int?
    @Published private(set) var pocketID: Int?
    @Published private(set) var includeBanks = true
    @Published private(set) var showAllPaths = true
    @Published private(set) var preview: ShotResult?
    @Published private(set) var suggestions: [ShotSuggestion] = []
    @Published private(set) var selectedSuggestion: ShotSuggestion?
    @Published private(set) var displayedBalls: [PoolBall]?
    @Published private(set) var isPreviewing = false
    @Published private(set) var isPlanning = false
    @Published private(set) var isReplaying = false
    @Published private(set) var isReplayPaused = false
    @Published private(set) var isAutomatic = false
    @Published private(set) var automaticCount = 0
    @Published private(set) var replaySpeed = 1.0
    @Published private(set) var historyCount = 0
    @Published private(set) var hasReplay = false
    @Published private(set) var message = "Arraste as bolas para montar uma jogada ou escolha uma mesa pronta."

    private weak var authorization: AppModel?
    private var isVisible = false
    private var generation: UInt64 = 0
    private var previewTask: Task<Void, Never>?
    private var plannerTask: Task<Void, Never>?
    private var runTask: Task<Void, Never>?
    private var history: [TableState] = []
    private var dragSnapshot: TableState?
    private var lastResult: ShotResult?
    private let savedSceneKey = "PoolLab.localScene.v1"

    var isAllowed: Bool { isVisible && authorization?.canUseModules == true }
    var isRunning: Bool { isReplaying || isAutomatic }
    var canEdit: Bool { isAllowed && !isRunning }
    var canShoot: Bool { canEdit && state.cueBall != nil }
    var canUndo: Bool { canEdit && !history.isEmpty }
    var visibleBalls: [PoolBall] { (displayedBalls ?? state.balls).filter { !$0.pocketed } }
    var objectBalls: [PoolBall] { state.balls.filter { $0.id > 0 && !$0.pocketed }.sorted { $0.id < $1.id } }
    var selectedBall: PoolBall? { state.balls.first { $0.id == selectedBallID && !$0.pocketed } }
    var cueNeedsPlacement: Bool { state.cueBall == nil }
    var hasSavedScene: Bool { UserDefaults.standard.data(forKey: savedSceneKey) != nil }

    func appear(authorization: AppModel) {
        self.authorization = authorization
        isVisible = true
        accessChanged()
    }

    func disappear() {
        isVisible = false
        cancelOperations()
        rollbackDrag()
    }

    func accessChanged() {
        guard isAllowed else {
            cancelOperations()
            rollbackDrag()
            return
        }
        requestPreview()
    }

    func suspend() {
        cancelOperations()
        rollbackDrag()
    }

    func selectBall(_ id: Int) {
        guard canEdit, (0...15).contains(id) else { return }
        selectedBallID = id
    }

    func setAngle(_ degrees: Double) {
        guard canEdit, degrees.isFinite else { return }
        angleDegrees = min(360, max(0, degrees))
        selectedSuggestion = nil
        changedInputs()
    }

    func setPower(_ value: Double) {
        guard canEdit, value.isFinite else { return }
        power = min(1, max(0.03, value))
        selectedSuggestion = nil
        changedInputs()
    }

    func setTarget(_ id: Int?) {
        guard canEdit, id == nil || objectBalls.contains(where: { $0.id == id }) else { return }
        targetID = id
        changedInputs()
    }

    func setPocket(_ id: Int?) {
        guard canEdit, id == nil || state.table.pockets.contains(where: { $0.id == id }) else { return }
        pocketID = id
        changedInputs()
    }

    func setIncludeBanks(_ value: Bool) {
        guard canEdit else { return }
        includeBanks = value
        changedInputs()
    }

    func setShowAllPaths(_ value: Bool) {
        guard isAllowed else { return }
        showAllPaths = value
    }

    func setReplaySpeed(_ value: Double) {
        guard isAllowed, [0.5, 1, 2, 4].contains(value) else { return }
        replaySpeed = value
    }

    func reset(to preset: TableState = .practice) {
        guard canEdit else { return }
        do {
            try BilliardsEngine.validate(preset, requireCue: false)
            let old = state
            cancelOperations()
            remember(old)
            state = preset
            selectedBallID = 0
            targetID = nil
            pocketID = nil
            angleDegrees = preset == .straightShot ? 270 : 342
            power = 0.45
            clearResults()
            message = "Mesa pronta. Ajuste a tacada ou procure uma sugestão."
            requestPreview()
        } catch { message = error.localizedDescription }
    }

    func beginMove(id: Int) {
        guard canEdit, state.balls.contains(where: { $0.id == id && !$0.pocketed }) else { return }
        cancelOperations()
        selectedBallID = id
        clearResults()
        dragSnapshot = state
    }

    func moveSelected(to point: Vector2) {
        guard canEdit, point.isFinite, let index = state.balls.firstIndex(where: { $0.id == selectedBallID && !$0.pocketed }) else { return }
        if dragSnapshot == nil { beginMove(id: selectedBallID) }
        let radius = state.table.ballRadius
        var candidate = state
        candidate.balls[index].position = Vector2(
            x: min(state.table.width - radius, max(radius, point.x)),
            y: min(state.table.height - radius, max(radius, point.y))
        )
        candidate.balls[index].velocity = .zero
        do {
            try BilliardsEngine.validate(candidate, requireCue: false)
            state = candidate
            message = "Solte a bola para atualizar a previsão."
        } catch { message = error.localizedDescription }
    }

    func finishMove() {
        guard canEdit else { rollbackDrag(); return }
        if let previous = dragSnapshot, previous != state { remember(previous) }
        dragSnapshot = nil
        message = "Posição atualizada."
        requestPreview()
    }

    func nudgeSelected(x: Double, y: Double) {
        guard canEdit, let ball = selectedBall else { return }
        beginMove(id: ball.id)
        moveSelected(to: ball.position + Vector2(x: x, y: y))
        finishMove()
    }

    /// Restores a pocketed ball or adds a missing ball to the first free location.
    func placeSelectedBall() {
        guard canEdit, selectedBall == nil else { return }
        var candidate = state
        candidate.balls.removeAll { $0.id == selectedBallID }
        let radius = candidate.table.ballRadius
        let gap = max(8, radius * 2.5)
        var chosen: TableState?
        for y in stride(from: candidate.table.height / 2, through: candidate.table.height - radius * 3, by: gap) {
            for x in stride(from: radius * 3, through: candidate.table.width - radius * 3, by: gap) {
                var attempt = candidate
                attempt.balls.append(PoolBall(id: selectedBallID, position: Vector2(x: x, y: y)))
                if (try? BilliardsEngine.validate(attempt, requireCue: false)) != nil {
                    chosen = attempt
                    break
                }
            }
            if chosen != nil { break }
        }
        guard let chosen else { message = "Não foi encontrado espaço livre para essa bola."; return }
        replaceState(chosen, message: selectedBallID == 0 ? "Branca recolocada. Arraste para a posição desejada." : "Bola adicionada à mesa.")
    }

    func removeSelectedBall() {
        guard canEdit, selectedBallID > 0, selectedBall != nil else { return }
        var candidate = state
        candidate.balls.removeAll { $0.id == selectedBallID }
        replaceState(candidate, message: "Bola retirada da mesa.")
    }

    func undo() {
        guard canUndo, let previous = history.popLast() else { return }
        cancelOperations()
        state = previous
        historyCount = history.count
        clearResults()
        normalizeSelection()
        message = "Última alteração desfeita."
        requestPreview()
    }

    func findSuggestions() {
        guard canShoot, !objectBalls.isEmpty else { return }
        cancelOperations()
        suggestions = []
        selectedSuggestion = nil
        isPlanning = true
        let operation = generation
        let snapshot = state
        let target = targetID
        let pocket = pocketID
        let banks = includeBanks
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try ShotPlanner.suggestions(for: snapshot, targetID: target, pocketID: pocket, includeBanks: banks, limit: 5)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, self.accepts(operation) else { return }
                self.suggestions = found
                self.isPlanning = false
                self.message = found.isEmpty ? "Nenhuma opção encontrada com estes filtros. Mude as posições, a bola ou a caçapa." : "Toque em uma sugestão para aplicar ângulo e força."
            } catch {
                guard let self, self.accepts(operation) else { return }
                self.isPlanning = false
                self.message = error.localizedDescription
            }
        }
    }

    func applySuggestion(_ suggestion: ShotSuggestion) {
        guard canEdit, suggestions.contains(where: { $0.id == suggestion.id }) else { return }
        cancelOperations()
        angleDegrees = Self.degrees(suggestion.shot.angleRadians)
        power = suggestion.shot.power
        selectedSuggestion = suggestion
        message = "Sugestão aplicada à bola \(suggestion.targetID). A tacada ainda não foi executada."
        requestPreview()
    }

    func shoot() {
        guard canShoot else { return }
        let snapshot = state
        let shot = ShotParameters(angleRadians: angleDegrees * .pi / 180, power: power)
        cancelOperations()
        let operation = generation
        isReplaying = true
        message = "Calculando a tacada…"
        runTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try BilliardsEngine.simulate(state: snapshot, shot: shot, recordFrames: true)
            }
            do {
                let result = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, self.accepts(operation) else { return }
                self.preview = result
                self.message = "Tacada em andamento."
                guard await self.animate(result, operation: operation) else { return }
                self.commit(result, previous: snapshot)
                self.isReplaying = false
                self.isReplayPaused = false
                self.describe(result)
            } catch {
                guard let self, self.accepts(operation) else { return }
                self.isReplaying = false
                self.message = error.localizedDescription
            }
        }
    }

    func replayLastShot() {
        guard canEdit, let result = lastResult else { return }
        cancelOperations()
        let operation = generation
        isReplaying = true
        message = "Repetindo a última tacada."
        runTask = Task { [weak self] in
            guard let self, await self.animate(result, operation: operation) else { return }
            self.displayedBalls = nil
            self.isReplaying = false
            self.isReplayPaused = false
            self.message = "Replay concluído. A mesa continua na posição final."
        }
    }

    func togglePause() {
        guard isAllowed, isReplaying else { return }
        isReplayPaused.toggle()
    }

    /// Bounded simulation inside PoolLab. Stops on miss, scratch or unsettled state.
    func startAutomatic() {
        guard canShoot, !objectBalls.isEmpty else { return }
        cancelOperations()
        isAutomatic = true
        automaticCount = 0
        let operation = generation
        let banks = includeBanks
        let pocket = pocketID
        message = "Procurando a primeira tacada da sequência local…"
        runTask = Task { [weak self] in
            guard let self else { return }
            do {
                for _ in 0..<10 {
                    guard self.accepts(operation) else { return }
                    let snapshot = self.state
                    if snapshot.balls.allSatisfy({ $0.id == 0 || $0.pocketed }) {
                        self.message = "Mesa limpa. Sequência concluída."
                        break
                    }
                    self.isPlanning = true
                    let planner = Task.detached(priority: .userInitiated) {
                        try ShotPlanner.suggestions(for: snapshot, targetID: nil, pocketID: pocket, includeBanks: banks, limit: 1)
                    }
                    let found = try await withTaskCancellationHandler(operation: { try await planner.value }, onCancel: { planner.cancel() })
                    guard self.accepts(operation) else { return }
                    self.isPlanning = false
                    guard let choice = found.first else {
                        self.message = "Sequência parada: nenhuma próxima tacada encontrada."
                        break
                    }
                    self.selectedSuggestion = choice
                    self.angleDegrees = Self.degrees(choice.shot.angleRadians)
                    self.power = choice.shot.power
                    self.preview = choice.result
                    let worker = Task.detached(priority: .userInitiated) {
                        try BilliardsEngine.simulate(state: snapshot, shot: choice.shot, recordFrames: true)
                    }
                    let result = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                    guard self.accepts(operation) else { return }
                    self.preview = result
                    self.isReplaying = true
                    self.message = "Sequência local · tacada \(self.automaticCount + 1) de até 10."
                    guard await self.animate(result, operation: operation) else { return }
                    self.commit(result, previous: snapshot)
                    self.isReplaying = false
                    self.automaticCount += 1
                    if result.scratched {
                        self.message = "Sequência parada: recoloque a branca ou desfaça a tacada."
                        break
                    }
                    if !result.settled || !result.pocketedIDs.contains(where: { $0 > 0 }) {
                        self.message = "Sequência parada: a tacada não terminou com uma bola encaçapada e a mesa parada."
                        break
                    }
                    if self.automaticCount == 10 { self.message = "Limite de 10 tacadas atingido. Você pode iniciar outra sequência." }
                }
                guard self.accepts(operation) else { return }
                self.isAutomatic = false
                self.isReplaying = false
                self.isReplayPaused = false
                self.isPlanning = false
                self.displayedBalls = nil
            } catch {
                guard self.accepts(operation) else { return }
                self.isAutomatic = false
                self.isReplaying = false
                self.isPlanning = false
                self.displayedBalls = nil
                self.message = error.localizedDescription
            }
        }
    }

    func stop() {
        cancelOperations()
        message = "Interrompido. A mesa mantém a última tacada concluída."
        if isAllowed { requestPreview() }
    }

    func saveScene() {
        guard canEdit else { return }
        do {
            UserDefaults.standard.set(try TableStateCodec.encode(state), forKey: savedSceneKey)
            message = "Mesa salva neste aparelho."
        } catch { message = error.localizedDescription }
    }

    func loadScene() {
        guard canEdit else { return }
        guard let data = UserDefaults.standard.data(forKey: savedSceneKey) else {
            message = "Ainda não há uma mesa salva neste aparelho."
            return
        }
        importScene(data)
    }

    func importScene(_ data: Data) {
        guard canEdit else { return }
        do {
            let decoded = try TableStateCodec.decode(data)
            replaceState(decoded, message: "Mesa carregada. A licença e as preferências de acesso não são importadas.")
        } catch { message = error.localizedDescription }
    }

    func exportScene() -> Data? {
        guard canEdit else { return nil }
        do { return try TableStateCodec.encode(state) }
        catch { message = error.localizedDescription; return nil }
    }

    func report(_ text: String) {
        guard isAllowed else { return }
        message = text
    }

    private func changedInputs() {
        cancelOperations()
        suggestions = []
        selectedSuggestion = nil
        requestPreview()
    }

    private func requestPreview() {
        guard canShoot, dragSnapshot == nil else { return }
        previewTask?.cancel()
        let operation = generation
        let snapshot = state
        let shot = ShotParameters(angleRadians: angleDegrees * .pi / 180, power: power)
        isPreviewing = true
        previewTask = Task { [weak self] in
            do {
                try await Task.sleep(nanoseconds: 180_000_000)
                try Task.checkCancellation()
                let worker = Task.detached(priority: .userInitiated) {
                    try BilliardsEngine.simulate(state: snapshot, shot: shot, recordFrames: true)
                }
                let result = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, self.accepts(operation) else { return }
                self.preview = result
                self.isPreviewing = false
            } catch {
                guard let self, self.accepts(operation) else { return }
                self.isPreviewing = false
                if !(error is CancellationError) { self.message = error.localizedDescription }
            }
        }
    }

    private func animate(_ result: ShotResult, operation: UInt64) async -> Bool {
        let frames = result.frames
        for index in frames.indices {
            guard accepts(operation) else { return false }
            do {
                while isReplayPaused {
                    try await Task.sleep(nanoseconds: 50_000_000)
                    guard accepts(operation) else { return false }
                }
                displayedBalls = frames[index].balls
                if index + 1 < frames.count {
                    let delta = max(0.001, min(0.2, frames[index + 1].time - frames[index].time)) / replaySpeed
                    try await Task.sleep(nanoseconds: UInt64(delta * 1_000_000_000))
                }
            } catch { return false }
        }
        return accepts(operation)
    }

    private func commit(_ result: ShotResult, previous: TableState) {
        // A truncated simulation can still contain moving balls. Keep the
        // editable scene valid, and retain the animation only for review.
        guard result.settled else {
            displayedBalls = nil
            lastResult = result
            hasReplay = !result.frames.isEmpty
            preview = nil
            suggestions = []
            selectedSuggestion = nil
            return
        }
        remember(previous)
        state = result.finalState
        displayedBalls = nil
        lastResult = result
        hasReplay = !result.frames.isEmpty
        preview = nil
        suggestions = []
        selectedSuggestion = nil
        normalizeSelection()
    }

    private func describe(_ result: ShotResult) {
        if result.scratched {
            selectedBallID = 0
            message = "A branca caiu. Toque em Recolocar branca e arraste-a, ou desfaça a tacada."
        } else if !result.settled {
            message = "O limite da simulação foi atingido antes da parada completa. Desfaça ou monte outra mesa."
        } else {
            let pocketed = result.pocketedIDs.filter { $0 > 0 }.map(String.init).joined(separator: ", ")
            message = pocketed.isEmpty ? "Tacada concluída. Nenhuma bola encaçapada." : "Bolas encaçapadas: \(pocketed)."
        }
    }

    private func replaceState(_ replacement: TableState, message: String) {
        let previous = state
        cancelOperations()
        remember(previous)
        state = replacement
        clearResults()
        normalizeSelection()
        self.message = message
        requestPreview()
    }

    private func normalizeSelection() {
        if let targetID, !objectBalls.contains(where: { $0.id == targetID }) { self.targetID = nil }
        if let pocketID, !state.table.pockets.contains(where: { $0.id == pocketID }) { self.pocketID = nil }
    }

    private func clearResults() {
        preview = nil
        suggestions = []
        selectedSuggestion = nil
        lastResult = nil
        hasReplay = false
        dragSnapshot = nil
    }

    private func rollbackDrag() {
        if let previous = dragSnapshot { state = previous }
        dragSnapshot = nil
    }

    private func remember(_ snapshot: TableState) {
        if history.last != snapshot { history.append(snapshot) }
        if history.count > 30 { history.removeFirst(history.count - 30) }
        historyCount = history.count
    }

    private func accepts(_ operation: UInt64) -> Bool {
        operation == generation && isAllowed && !Task.isCancelled
    }

    private func cancelOperations() {
        generation &+= 1
        previewTask?.cancel()
        plannerTask?.cancel()
        runTask?.cancel()
        previewTask = nil
        plannerTask = nil
        runTask = nil
        isPreviewing = false
        isPlanning = false
        isReplaying = false
        isReplayPaused = false
        isAutomatic = false
        displayedBalls = nil
        preview = nil
    }

    private static func degrees(_ radians: Double) -> Double {
        let value = (radians * 180 / .pi).truncatingRemainder(dividingBy: 360)
        return value >= 0 ? value : value + 360
    }
}
