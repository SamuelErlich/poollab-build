import Foundation
import Security
import CryptoKit

/// Identidade aleatória desta instalação; não consulta número de série do aparelho.
enum DeviceIdentity {
    enum StorageError: LocalizedError {
        case keychain(OSStatus)
        case invalidData

        var errorDescription: String? {
            "Não foi possível acessar a identificação deste aparelho. Desbloqueie o dispositivo e tente novamente."
        }
    }

    static func loadOrCreate() throws -> String {
        let service = (Bundle.main.bundleIdentifier ?? "com.example.poollab") + ".installation"
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: "installation-uuid",
            kSecAttrSynchronizable as String: false
        ]
        var read = query
        read[kSecReturnData as String] = true
        read[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(read as CFDictionary, &item)
        let identifier: String
        if status == errSecSuccess {
            guard let data = item as? Data,
                  let existing = String(data: data, encoding: .utf8),
                  UUID(uuidString: existing) != nil else { throw StorageError.invalidData }
            identifier = existing
        } else if status == errSecItemNotFound {
            identifier = UUID().uuidString.lowercased()
            var insert = query
            insert[kSecValueData as String] = Data(identifier.utf8)
            insert[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            let result = SecItemAdd(insert as CFDictionary, nil)
            if result == errSecDuplicateItem {
                // Uma criação concorrente ganha; utilize a identidade já registrada.
                var existingItem: CFTypeRef?
                let readStatus = SecItemCopyMatching(read as CFDictionary, &existingItem)
                guard readStatus == errSecSuccess, let data = existingItem as? Data,
                      let existing = String(data: data, encoding: .utf8),
                      UUID(uuidString: existing) != nil else { throw StorageError.keychain(readStatus) }
                return digest(service: service, identifier: existing)
            }
            guard result == errSecSuccess else { throw StorageError.keychain(result) }
        } else {
            throw StorageError.keychain(status)
        }
        return digest(service: service, identifier: identifier)
    }

    private static func digest(service: String, identifier: String) -> String {
        SHA256.hash(data: Data((service + ":" + identifier).utf8))
            .map { String(format: "%02x", $0) }.joined()
    }
}
