import SwiftUI

@main
@MainActor
struct PoolLabApp: App {
    @StateObject private var model = AppModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView(model: model)
                .preferredColorScheme(.dark)
                .tint(PoolTheme.accent)
                .task { await model.becameActive() }
                .onChange(of: scenePhase) { phase in
                    switch phase {
                    case .active:
                        Task { await model.becameActive() }
                    case .inactive, .background:
                        model.becameInactive()
                    @unknown default:
                        model.becameInactive()
                    }
                }
        }
    }
}
