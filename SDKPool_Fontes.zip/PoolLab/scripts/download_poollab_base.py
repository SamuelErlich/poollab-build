#!/usr/bin/env python3
"""Download the exact unsigned V4 base, including Filebin's cookie confirmation.

HTTPS only, bounded transfer and exact size/SHA-256 check before publication.
No supplied game binary or downloaded script is ever executed.
"""
from __future__ import annotations

import argparse
import hashlib
import http.cookiejar
import os
from pathlib import Path
import tempfile
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPCookieProcessor, HTTPSHandler, HTTPRedirectHandler, Request, build_opener

from upgrade_poollab_ipa import BASE_BYTES, BASE_SHA256


class HTTPSRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        if urlsplit(new_url).scheme != "https":
            raise ValueError("Redirecionamento para endereço sem HTTPS recusado.")
        return super().redirect_request(request, fp, code, message, headers, new_url)


def download(url: str, output: Path) -> None:
    parsed = urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Informe um link HTTPS direto para o IPA V4.")
    output = output.expanduser().absolute()
    if output.exists() or output.is_symlink():
        raise ValueError("O arquivo de destino já existe.")
    output.parent.mkdir(parents=True, exist_ok=True)
    cookies = http.cookiejar.CookieJar()
    opener = build_opener(HTTPSHandler(), HTTPSRedirect(), HTTPCookieProcessor(cookies))
    temporary = None
    try:
        # Filebin documents a first HTML response that sets a verification cookie.
        # A second GET with that cookie obtains the download; no challenge is solved.
        for attempt in range(2):
            request = Request(url, headers={"User-Agent": "PoolLabBuild/5", "Accept": "application/octet-stream"})
            with opener.open(request, timeout=30) as response:
                content_type = response.headers.get_content_type()
                if content_type == "text/html":
                    response.read(4096)
                    if attempt == 0 and parsed.hostname == "filebin.net" and len(cookies) > 0:
                        continue
                    raise ValueError("O link retornou uma página, não o IPA. Confira se o link ainda está válido.")
                declared = response.headers.get("Content-Length")
                if declared is not None and int(declared) != BASE_BYTES:
                    raise ValueError("O tamanho informado pelo servidor não corresponde ao IPA V4.")
                digest = hashlib.sha256()
                size = 0
                with tempfile.NamedTemporaryFile(prefix=".poollab-base-", suffix=".tmp",
                                                 dir=output.parent, delete=False) as stream:
                    temporary = Path(stream.name)
                    while True:
                        block = response.read(min(1024 * 1024, BASE_BYTES + 1 - size))
                        if not block:
                            break
                        size += len(block)
                        if size > BASE_BYTES:
                            raise ValueError("O download excedeu o tamanho esperado.")
                        digest.update(block)
                        stream.write(block)
                if size != BASE_BYTES or digest.hexdigest() != BASE_SHA256:
                    raise ValueError("O download não corresponde ao IPA PoolLab V4 verificado. Nenhum pacote foi criado.")
                os.link(temporary, output)
                temporary.unlink()
                temporary = None
                print("IPA V4 baixado e SHA-256 conferido.")
                return
        raise ValueError("Não foi possível obter o arquivo pelo link informado.")
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        download(args.url, args.output)
    except (HTTPError, URLError, OSError, ValueError) as error:
        parser.exit(1, "Download interrompido: " + str(error) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
