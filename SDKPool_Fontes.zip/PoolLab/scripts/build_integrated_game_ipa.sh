#!/bin/bash
# Usage: bash scripts/build_integrated_game_ipa.sh INPUT_IPA OUTPUT_IPA
# KeyAuth settings come from Resources/KeyAuth.plist or KEYAUTH_* environment variables.
# Compiles the framework, creates a new unsigned IPA, and leaves the source IPA intact.
set -euo pipefail

fail() { printf '%s\n' "$*" >&2; exit 1; }
[[ $# -eq 2 ]] || fail 'Usage: bash scripts/build_integrated_game_ipa.sh INPUT_IPA OUTPUT_IPA'
command -v python3 >/dev/null || fail 'Python 3 is required.'

# Resolve before switching to the project directory. The integration tool checks
# these paths again when publishing the result, preventing accidental replacement.
input_ipa="$(python3 - "$1" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1]).expanduser().resolve(strict=True)
if not path.is_file():
    raise SystemExit('INPUT_IPA must be an existing regular file.')
if any(char in str(path) for char in '\r\n'):
    raise SystemExit('Paths containing line breaks are not supported.')
print(path)
PY
)"
output_ipa="$(python3 - "$2" <<'PY'
from pathlib import Path
import sys

requested = Path(sys.argv[1]).expanduser().absolute()
if requested.exists() or requested.is_symlink():
    raise SystemExit('OUTPUT_IPA already exists; choose a new filename.')
path = requested.resolve(strict=False)
if any(char in str(path) for char in '\r\n'):
    raise SystemExit('Paths containing line breaks are not supported.')
if path.suffix.lower() != '.ipa':
    raise SystemExit('OUTPUT_IPA must end in .ipa.')
if not path.parent.is_dir():
    raise SystemExit('Create the destination directory before running this command.')
report = path.with_suffix('.manifest.json')
if report.exists() or report.is_symlink():
    raise SystemExit(f'The output manifest already exists: {report}')
print(path)
PY
)"

[[ "$(uname -s)" == "Darwin" ]] || fail 'This command requires macOS with Xcode and the iOS SDK.'
project_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$project_root"
[[ -f scripts/integrate_game_ipa.py ]] || fail 'scripts/integrate_game_ipa.py is missing.'

build_workspace="$(mktemp -d "${TMPDIR:-/tmp}/poollab-game-ipa.XXXXXX")"
trap 'rm -rf "$build_workspace"' EXIT

bash scripts/build_integration_framework.sh
framework_zip="$project_root/dist/PoolLabIntegration_unsigned.framework.zip"
[[ -f "$framework_zip" ]] || fail 'The framework build did not produce its ZIP.'
/usr/bin/ditto -x -k "$framework_zip" "$build_workspace"
framework_path="$build_workspace/PoolLabIntegration.framework"
[[ -d "$framework_path" ]] || fail 'The framework ZIP did not contain PoolLabIntegration.framework.'

python3 scripts/integrate_game_ipa.py \
  --ipa "$input_ipa" \
  --framework "$framework_path" \
  --output "$output_ipa"

printf 'Created: %s\n' "$output_ipa"
printf '%s\n' 'The original IPA was preserved. Sign the new IPA before installing it on an iPhone.'
