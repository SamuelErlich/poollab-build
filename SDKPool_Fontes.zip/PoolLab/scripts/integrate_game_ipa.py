#!/usr/bin/env python3
"""Integrate a genuinely compiled PoolLabIntegration framework into one audited IPA.

This tool does not compile Swift, sign apps, decrypt executables or enable the
old Fluorite code. It operates on a temporary copy, refuses different source
hashes and publishes a new unsigned IPA without overwriting existing files.
Python 3.9+; standard library only.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import plistlib
import re
import shutil
import stat
import struct
import sys
import tempfile
import unicodedata
import zipfile

SOURCE_IPA_SHA256 = "c90f6ee63966a8d733f30cdce6957392bd571de40356e8fb8346b7214e739230"
SOURCE_POOL_SHA256 = "9dd01a5d7526131036199af3033a188a0c51752870dd4f8a977498c40fc72a6c"
SOURCE_LOADER_SHA256 = "40168cce89c6a5d4ab512f59a5cc4bb3e3234911b8025ac52d59f2a466543032"
APP_PATH = PurePosixPath("Payload/pool.app")
OLD_LOADER = "@executable_path/Frameworks/libloader.framework/libloader"
FRAMEWORK_NAME = "PoolLabIntegration"
NEW_LOADER = f"@executable_path/Frameworks/{FRAMEWORK_NAME}.framework/{FRAMEWORK_NAME}"
NEW_INSTALL_NAME = f"@rpath/{FRAMEWORK_NAME}.framework/{FRAMEWORK_NAME}"
MAX_ARCHIVE_SIZE = 512 * 1024 * 1024
MAX_MEMBER_SIZE = 256 * 1024 * 1024
MAX_EXPANDED_SIZE = 1536 * 1024 * 1024
MAX_ENTRIES = 25000
MAX_FRAMEWORK_SIZE = 256 * 1024 * 1024
MAX_MACHO_SIZE = 128 * 1024 * 1024
PATCHES = (
    (0x10B40, bytes.fromhex("a4dd3e15"), bytes.fromhex("ffc306d1")),
    (0x4CA228, bytes.fromhex("c0f72b15"), bytes.fromhex("ff4301d1")),
    (0x57BB20, bytes.fromhex("6d312915"), bytes.fromhex("ff0301d1")),
    (0xAACD98, bytes.fromhex("f96c1415"), bytes.fromhex("ffc301d1")),
)
STARTUP_IMPORT_OLD = b"sfnSiBIBKssMHzPJrI\0"
STARTUP_IMPORT_NEW = b"_UIApplicationMain\0"
STARTUP_IMPORT_OFFSETS = (0x4B98BB0, 0x4DD721F)
DYLIB_COMMANDS = (0xC, 0x80000018, 0x8000001F, 0x80000023)
ZEROFILL_TYPES = (0x1, 0xC, 0x12)


class IntegrationError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise IntegrationError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def bounded_read(path: Path, maximum: int) -> bytes:
    require(path.is_file() and not path.is_symlink(), f"Arquivo regular necessário: {path}")
    require(path.stat().st_size <= maximum, f"Arquivo maior que o limite: {path}")
    with path.open("rb") as stream:
        data = stream.read(maximum + 1)
    require(len(data) <= maximum, f"Arquivo cresceu além do limite: {path}")
    return data


def read_plist(path: Path) -> dict:
    try:
        value = plistlib.loads(bounded_read(path, 1024 * 1024))
    except (plistlib.InvalidFileException, TypeError, ValueError, OverflowError) as error:
        raise IntegrationError(f"Plist inválido: {path}") from error
    require(isinstance(value, dict), f"Plist não é um dicionário: {path}")
    return value


def command_string(command: bytes) -> str:
    require(len(command) >= 12, "Load command sem campo de nome.")
    offset = struct.unpack_from("<I", command, 8)[0]
    require(12 <= offset < len(command), "Offset de nome inválido no Mach-O.")
    end = command.find(b"\0", offset)
    require(end != -1, "Nome sem terminador no Mach-O.")
    try:
        return command[offset:end].decode("utf-8", "strict")
    except UnicodeDecodeError as error:
        raise IntegrationError("Nome de load command inválido.") from error


@dataclass(frozen=True)
class MachO:
    data: bytes
    filetype: int
    flags: int
    commands: tuple[bytes, ...]
    command_end: int
    first_section: int

    def commands_of_type(self, kind: int) -> list[bytes]:
        return [c for c in self.commands if struct.unpack_from("<I", c)[0] == kind]


def parse_macho(data: bytes, expected_type: int | None = None) -> MachO:
    require(32 <= len(data) <= MAX_MACHO_SIZE, "Tamanho Mach-O inválido.")
    magic, cpu, subtype, filetype, ncmds, sizeofcmds, flags, _ = struct.unpack_from("<8I", data)
    require(magic == 0xFEEDFACF, "É necessário Mach-O thin de 64 bits, não FAT, fonte ou arquivo estático.")
    require(cpu == 0x100000C and (subtype & 0xFFFFFF) == 0, "O binário precisa ser ARM64 de dispositivo, sem ARM64e.")
    if expected_type is not None:
        require(filetype == expected_type, f"Tipo Mach-O {filetype} inesperado; esperado {expected_type}.")
    require(1 <= ncmds <= 4096 and 32 + sizeofcmds <= len(data), "Cabeçalho Mach-O inválido.")
    offset = 32
    sections: list[int] = []
    commands = []
    for _ in range(ncmds):
        require(offset + 8 <= 32 + sizeofcmds, "Load command truncado.")
        kind, size = struct.unpack_from("<2I", data, offset)
        require(size >= 8 and size % 8 == 0 and offset + size <= 32 + sizeofcmds, "Tamanho de load command inválido.")
        command = data[offset:offset + size]
        if kind == 0x19:
            require(size >= 72, "Segmento Mach-O truncado.")
            fileoff, filesize = struct.unpack_from("<2Q", command, 40)
            nsects = struct.unpack_from("<I", command, 64)[0]
            require(size == 72 + nsects * 80, "Tabela de seções inválida.")
            require(fileoff + filesize <= len(data), "Segmento fora do arquivo.")
            for index in range(nsects):
                so = 72 + 80 * index
                section_size, section_offset = struct.unpack_from("<QI", command, so + 40)
                section_flags = struct.unpack_from("<I", command, so + 64)[0]
                if section_size and section_flags & 0xFF not in ZEROFILL_TYPES:
                    require(section_offset >= 32 + sizeofcmds, "Seção sobrepõe os load commands.")
                    require(section_offset + section_size <= len(data), "Seção fora do arquivo.")
                    require(fileoff <= section_offset and section_offset + section_size <= fileoff + filesize,
                            "Seção fora de seu segmento.")
                    sections.append(section_offset)
        elif kind == 0x1D:
            require(size == 16, "LC_CODE_SIGNATURE inválido.")
            sigoff, sigsize = struct.unpack_from("<2I", command, 8)
            require(sigoff + sigsize <= len(data), "Assinatura fora do arquivo.")
        elif kind == 0x2C:
            require(size == 24, "LC_ENCRYPTION_INFO_64 inválido.")
            cryptoff, cryptsize, cryptid = struct.unpack_from("<3I", command, 8)
            require(cryptid == 0, "Binário cifrado: este script não remove nem contorna cifragem.")
            require(cryptoff + cryptsize <= len(data), "Região de cifragem inválida.")
        elif kind in DYLIB_COMMANDS or kind in (0xD, 0x8000001C):
            if kind != 0x8000001C:
                require(size >= 24, "Comando de biblioteca truncado.")
            command_string(command)
        commands.append(command)
        offset += size
    require(offset == 32 + sizeofcmds, "sizeofcmds não corresponde aos comandos.")
    require(bool(sections), "Mach-O não possui seções no arquivo.")
    return MachO(data, filetype, flags, tuple(commands), offset, min(sections))


def rebuild_commands(macho: MachO, commands: list[bytes]) -> bytes:
    encoded = b"".join(commands)
    new_end = 32 + len(encoded)
    require(new_end <= macho.first_section, "Não há espaço no cabeçalho para a nova biblioteca.")
    if new_end > macho.command_end:
        require(not any(macho.data[macho.command_end:new_end]), "O crescimento do cabeçalho sobrescreveria dados.")
    output = bytearray(macho.data)
    struct.pack_into("<2I", output, 16, len(commands), len(encoded))
    output[32:max(macho.command_end, new_end)] = encoded + bytes(max(macho.command_end, new_end) - new_end)
    return bytes(output)


def strip_signature(data: bytes) -> tuple[bytes, int]:
    macho = parse_macho(data)
    commands = [c for c in macho.commands if struct.unpack_from("<I", c)[0] != 0x1D]
    count = len(macho.commands) - len(commands)
    # The obsolete signature blob remains unreferenced in __LINKEDIT. Segment
    # offsets and sizes stay intact. The final signer writes a new signature.
    return (rebuild_commands(macho, commands) if count else data), count


def restore_original_prologues(data: bytes) -> bytes:
    result = bytearray(data)
    for offset, expected, restored in PATCHES:
        require(data[offset:offset + 4] == expected, f"Prólogo inesperado em {offset:#x}; alteração recusada.")
        result[offset:offset + 4] = restored
    return bytes(result)


def restore_startup_import(data: bytes) -> bytes:
    """Restore the UIKit entry import in both lazy-bind and symbol strings.

    The audited main passes argc, argv, nil and the AppDelegate class string
    through this stub. The old weak import instead resolves to zero without
    the previous loader. Its two names have equal lengths, preserving all
    LINKEDIT offsets and bind opcodes; no new runtime code is introduced.
    """
    require(len(STARTUP_IMPORT_OLD) == len(STARTUP_IMPORT_NEW), "Tamanho do import inicial mudou.")
    require(data.count(STARTUP_IMPORT_OLD) == len(STARTUP_IMPORT_OFFSETS),
            "Quantidade inesperada de nomes do import inicial.")
    result = bytearray(data)
    for offset in STARTUP_IMPORT_OFFSETS:
        end = offset + len(STARTUP_IMPORT_OLD)
        require(data[offset:end] == STARTUP_IMPORT_OLD,
                f"Import inicial inesperado em {offset:#x}; alteração recusada.")
        result[offset:end] = STARTUP_IMPORT_NEW
    require(STARTUP_IMPORT_OLD not in result, "O import inicial antigo permaneceu no executável.")
    return bytes(result)


def patch_game_executable(data: bytes) -> tuple[bytes, dict]:
    require(digest(data) == SOURCE_POOL_SHA256, "SHA-256 do executável pool não corresponde à base auditada.")
    macho = parse_macho(data, expected_type=2)
    require(macho.command_end == 0x3770 and macho.first_section == 0x4000, "Layout do cabeçalho mudou.")
    require(not any(data[0x3770:0x4000]), "Padding conhecido do cabeçalho mudou.")
    mains = macho.commands_of_type(0x80000028)
    require(len(mains) == 1 and struct.unpack_from("<Q", mains[0], 8)[0] == 0x3A07C, "LC_MAIN não corresponde à base.")
    found = [i for i, c in enumerate(macho.commands)
             if struct.unpack_from("<I", c)[0] == 0xC and command_string(c) == OLD_LOADER]
    require(len(found) == 1 and found[0] == len(macho.commands) - 1, "Dependência final libloader inesperada.")
    require(len(macho.commands_of_type(0x1D)) == 1, "Assinatura original inesperada.")
    old = macho.commands[found[0]]
    require(len(old) == 88, "Tamanho do comando libloader mudou.")
    path_bytes = NEW_LOADER.encode() + b"\0"
    command_size = (24 + len(path_bytes) + 7) & ~7
    new = bytearray(old[:24])
    struct.pack_into("<I", new, 4, command_size)
    struct.pack_into("<I", new, 8, 24)
    new.extend(path_bytes)
    new.extend(bytes(command_size - len(new)))
    commands = [bytes(new) if i == found[0] else c for i, c in enumerate(macho.commands)
                if struct.unpack_from("<I", c)[0] != 0x1D]
    output = restore_startup_import(restore_original_prologues(rebuild_commands(macho, commands)))
    checked = parse_macho(output, expected_type=2)
    require(not checked.commands_of_type(0x1D), "Falha ao remover referência da assinatura antiga.")
    require(checked.commands_of_type(0x80000028) == mains, "LC_MAIN foi alterado indevidamente.")
    require(checked.commands_of_type(0x19) == macho.commands_of_type(0x19), "Segmentos foram alterados indevidamente.")
    dependencies_before = [c for c in macho.commands if struct.unpack_from("<I", c)[0] in DYLIB_COMMANDS]
    dependencies_after = [c for c in checked.commands if struct.unpack_from("<I", c)[0] in DYLIB_COMMANDS]
    require(dependencies_before[:-1] == dependencies_after[:-1], "Outras dependências foram alteradas.")
    require(len(dependencies_before) == len(dependencies_after) == 105, "Ordem das bibliotecas mudou.")
    report = {
        "before_sha256": digest(data), "after_sha256": digest(output),
        "lc_main_preserved": "0x3a07c", "segment_commands_preserved": True,
        "dependency_ordinal_preserved": 105, "old_dependency": OLD_LOADER, "new_dependency": NEW_LOADER,
        "removed_code_signature_commands": 1, "old_signature_blob": "retained_unreferenced",
        "prologues": [{"offset": hex(o), "before": a.hex(), "after": b.hex()} for o, a, b in PATCHES],
        "startup_import": {
            "before": STARTUP_IMPORT_OLD[:-1].decode(), "after": STARTUP_IMPORT_NEW[:-1].decode(),
            "file_offsets": [hex(o) for o in STARTUP_IMPORT_OFFSETS],
            "library": "/System/Library/Frameworks/UIKit.framework/UIKit", "library_ordinal": 46,
            "stub_address": "0x10314aea0", "pointer_address": "0x104143160",
            "evidence": "main call ABI argc/argv/nil/AppDelegate; crash PC=0, X16=0, LR relative 0x3a468",
            "runtime_verified_after_fix": False,
        },
    }
    return output, report


def safe_zip_entries(archive: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    entries = archive.infolist()
    require(0 < len(entries) <= MAX_ENTRIES, "Quantidade de entradas ZIP fora do limite.")
    seen: dict[str, bool] = {}
    total = 0
    for entry in entries:
        raw = entry.filename
        require(raw and "\0" not in raw and "\\" not in raw and ":" not in raw,
                f"Nome ZIP inválido: {raw!r}")
        require(not any(ord(c) < 32 for c in raw), "Nome ZIP contém caractere de controle.")
        clean = raw[:-1] if raw.endswith("/") else raw
        require(clean and not clean.startswith("/") and all(p not in ("", ".", "..") for p in clean.split("/")),
                f"Caminho ZIP inseguro: {raw!r}")
        # iPhone/Mac filesystems may be case insensitive. Reject aliases before
        # extraction, including file/directory conflicts.
        require(len(clean) <= 4096 and len(clean.split("/")) <= 128, "Nome ZIP excede o limite de tamanho/profundidade.")
        key = unicodedata.normalize("NFC", clean).casefold()
        require(key not in seen, f"Entrada ZIP duplicada ou ambígua: {raw}")
        mode = entry.external_attr >> 16
        kind = stat.S_IFMT(mode)
        require(kind in (0, stat.S_IFREG, stat.S_IFDIR), f"Symlink/arquivo especial não permitido no ZIP: {raw}")
        is_dir = entry.is_dir()
        require(kind != stat.S_IFDIR or is_dir, f"Diretório ZIP inconsistente: {raw}")
        require(kind != stat.S_IFREG or not is_dir, f"Arquivo ZIP inconsistente: {raw}")
        require(not entry.flag_bits & 1, "ZIP protegido por senha não é aceito.")
        require(entry.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), "Método de compressão ZIP não aceito.")
        require(0 <= entry.file_size <= MAX_MEMBER_SIZE, f"Entrada ZIP excede o limite: {raw}")
        require(not is_dir or entry.file_size == 0, f"Diretório ZIP com conteúdo: {raw}")
        total += entry.file_size
        require(total <= MAX_EXPANDED_SIZE, "Tamanho descompactado excede o limite.")
        seen[key] = is_dir
    for key, is_dir in seen.items():
        parts = key.split("/")
        for index in range(1, len(parts)):
            parent = "/".join(parts[:index])
            require(parent not in seen or seen[parent], f"Arquivo ZIP usado como diretório: {parent}")
    return entries


def extract_checked(archive: zipfile.ZipFile, entries: list[zipfile.ZipInfo], destination: Path) -> None:
    total = 0
    for entry in entries:
        target = destination.joinpath(*PurePosixPath(entry.filename).parts)
        if entry.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            target.chmod(0o755)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        size = 0
        with archive.open(entry) as source, target.open("xb") as output:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                size += len(block)
                total += len(block)
                require(size <= entry.file_size and size <= MAX_MEMBER_SIZE and total <= MAX_EXPANDED_SIZE,
                        "Conteúdo ZIP excede o tamanho declarado ou o limite.")
                output.write(block)
        require(size == entry.file_size, f"Entrada ZIP truncada: {entry.filename}")
        mode = entry.external_attr >> 16
        target.chmod(0o755 if mode & 0o111 else 0o644)


def inspect_framework_tree(path: Path) -> dict[str, str]:
    require(path.is_dir() and not path.is_symlink(), "Informe um diretório framework compilado regular.")
    require(path.name == f"{FRAMEWORK_NAME}.framework", f"O bundle deve se chamar {FRAMEWORK_NAME}.framework.")
    hashes: dict[str, str] = {}
    seen: set[str] = set()
    total = 0
    for current, directories, files in os.walk(path, followlinks=False):
        for name in directories + files:
            item = Path(current) / name
            relative = item.relative_to(path).as_posix()
            require(not item.is_symlink(), f"Symlink não aceito no framework iOS: {relative}")
            require(all(part not in (".", "..") for part in item.relative_to(path).parts), "Caminho de framework inválido.")
            require(not any(ord(c) < 32 for c in relative) and "\\" not in relative and ":" not in relative,
                    "Nome inválido no framework.")
            key = unicodedata.normalize("NFC", relative).casefold()
            require(key not in seen, "Nomes ambíguos no framework.")
            seen.add(key)
            require(len(seen) <= MAX_ENTRIES, "Framework excede o limite de entradas.")
            mode = item.stat().st_mode
            require(stat.S_ISREG(mode) or stat.S_ISDIR(mode), "Arquivo especial não aceito no framework.")
            if item.is_file():
                total += item.stat().st_size
                require(total <= MAX_FRAMEWORK_SIZE, "Framework excede o limite de tamanho.")
                hashes[relative] = file_digest(item)
    return hashes


def version_number(value: str) -> tuple[int, int, int]:
    require(isinstance(value, str) and re.fullmatch(r"\d+(?:\.\d+){0,2}", value) is not None,
            "MinimumOSVersion inválida.")
    numbers = tuple(int(x) for x in value.split("."))
    return numbers + (0,) * (3 - len(numbers))


def validate_keyauth(configuration: dict) -> None:
    for key in ("AppName", "OwnerID", "Version"):
        value = configuration.get(key)
        require(isinstance(value, str) and bool(value.strip()), f"Configure {key} em KeyAuth.plist antes de compilar.")
        upper = value.upper()
        placeholder = upper.startswith(("PREENCHA", "CHANGE_ME", "CHANGEME", "YOUR_", "PLACEHOLDER")) or upper in {
            "EXAMPLE", "YOUR APP NAME", "YOUR OWNER ID", "YOUR VERSION"
        }
        require(not placeholder,
                f"{key} ainda contém um exemplo em KeyAuth.plist.")
        require(len(value) <= 256 and not any(ord(c) < 32 for c in value), f"Valor inválido em {key}.")
    require(isinstance(configuration.get("RequiredSubscription", ""), str), "RequiredSubscription deve ser texto.")
    forbidden = {str(k).lower() for k in configuration} & {"secret", "appsecret", "sellerkey", "seller_key", "license", "licensekey"}
    require(not forbidden, "KeyAuth.plist não deve incluir segredos de vendedor, app ou licença.")


def validate_framework(path: Path) -> dict:
    hashes = inspect_framework_tree(path)
    info = read_plist(path / "Info.plist")
    require(info.get("CFBundleExecutable") == FRAMEWORK_NAME and info.get("CFBundlePackageType") == "FMWK",
            "Info.plist não descreve o framework PoolLabIntegration.")
    identifier = info.get("CFBundleIdentifier")
    require(isinstance(identifier, str) and re.fullmatch(r"[A-Za-z0-9.-]+", identifier) is not None,
            "Identificador do framework inválido.")
    minimum = info.get("MinimumOSVersion")
    require(version_number(minimum) == (15, 0, 0), "Framework deve declarar iOS mínimo 15.0.")
    require(info.get("CFBundleSupportedPlatforms") == ["iPhoneOS"], "Info.plist deve declarar iPhoneOS.")
    validate_keyauth(read_plist(path / "KeyAuth.plist"))
    data = bounded_read(path / FRAMEWORK_NAME, MAX_MACHO_SIZE)
    macho = parse_macho(data, expected_type=6)
    ids = macho.commands_of_type(0xD)
    require(len(ids) == 1 and command_string(ids[0]) == NEW_INSTALL_NAME, "LC_ID_DYLIB do framework está incorreto.")
    builds = macho.commands_of_type(0x32)
    require(len(builds) == 1 and len(builds[0]) >= 24, "Framework precisa declarar LC_BUILD_VERSION.")
    platform, minos, sdk = struct.unpack_from("<3I", builds[0], 8)
    require(platform == 2, "Framework foi compilado para simulador ou outra plataforma; é necessário iOS device.")
    require(minos == 0xF0000, "Compile PoolLabIntegration com deployment target iOS 15.0.")
    require(sdk >= minos, "SDK do framework é inválido.")
    require(len(macho.commands_of_type(0x1B)) == 1, "Framework compilado precisa de UUID Mach-O.")
    for command in macho.commands:
        if struct.unpack_from("<I", command)[0] in DYLIB_COMMANDS:
            dependency = command_string(command)
            require(dependency.startswith(("/System/Library/", "/usr/lib/")),
                    f"Framework tem dependência não incorporada: {dependency}")
    text_size = 0
    for command in macho.commands_of_type(0x19):
        count = struct.unpack_from("<I", command, 64)[0]
        for index in range(count):
            so = 72 + 80 * index
            if command[so:so + 16].rstrip(b"\0") == b"__text":
                text_size += struct.unpack_from("<Q", command, so + 40)[0]
    require(text_size > 0, "Framework não contém código compilado.")
    return {"bundle_identifier": identifier, "minimum_ios": minimum,
            "binary_sha256": digest(data), "files_before_signature_removal": hashes,
            "keyauth_configuration": "configured; values omitted from report",
            "architecture": "arm64", "platform": "iOS device", "install_name": NEW_INSTALL_NAME}


def remove_old_signing_metadata(root: Path) -> list[str]:
    removed = []
    # Reverse ordering makes removing a directory safe without traversing stale
    # descendants from the list; all extracted entries were checked for links.
    for path in sorted(root.rglob("*"), key=lambda p: len(p.parts), reverse=True):
        if path.name == "_CodeSignature" and path.is_dir():
            removed.append(path.relative_to(root).as_posix() + "/")
            shutil.rmtree(path)
        elif path.name == "embedded.mobileprovision" and path.is_file():
            removed.append(path.relative_to(root).as_posix())
            path.unlink()
    return sorted(removed)


def normalize_bundle_executable_permissions(root: Path) -> list[dict[str, str]]:
    """Restore executable modes missing from a DOS-origin IPA's ZIP metadata."""
    changed = []
    for info_path in sorted(root.rglob("Info.plist")):
        bundle = info_path.parent
        if bundle.suffix not in (".app", ".appex", ".framework"):
            continue
        executable = read_plist(info_path).get("CFBundleExecutable")
        require(isinstance(executable, str) and bool(executable)
                and executable not in (".", "..")
                and not any(c in executable for c in ("/", "\\", ":", "\0")),
                f"CFBundleExecutable inválido: {info_path.relative_to(root)}")
        binary = bundle / executable
        require(binary.is_file() and not binary.is_symlink(),
                f"Executável do bundle ausente: {binary.relative_to(root)}")
        with binary.open("rb") as stream:
            require(stream.read(4) == b"\xcf\xfa\xed\xfe",
                    f"Executável do bundle não é Mach-O 64 bits: {binary.relative_to(root)}")
        previous = stat.S_IMODE(binary.stat().st_mode)
        if previous != 0o755:
            binary.chmod(0o755)
            changed.append({"path": binary.relative_to(root).as_posix(),
                            "before": f"{previous:04o}", "after": "0755"})
    return changed


def make_archive(root: Path, output: Path) -> None:
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for path in sorted(root.rglob("*")):
            require(not path.is_symlink(), "Symlink inesperado durante o empacotamento.")
            if path.is_file():
                archive.write(path, path.relative_to(root).as_posix())
    with zipfile.ZipFile(output) as archive:
        safe_zip_entries(archive)
        require(archive.testzip() is None, "Falha de integridade no ZIP final.")
        names = set(archive.namelist())
        require(f"{APP_PATH}/Frameworks/{FRAMEWORK_NAME}.framework/{FRAMEWORK_NAME}" in names,
                "Framework ausente no IPA final.")
        require(not any(n.startswith(f"{APP_PATH}/Frameworks/libloader.framework/") for n in names),
                "Loader antigo permaneceu no IPA.")


def exclusive_publish(temporary: Path, target: Path) -> None:
    # Both files are in the same directory/filesystem. link() atomically fails
    # if the target exists, unlike os.replace(), which could overwrite it.
    os.link(temporary, target)
    temporary.unlink()


def integrate(ipa: Path, framework: Path, output: Path, report_path: Path) -> dict:
    ipa = ipa.expanduser().resolve(strict=True)
    framework = framework.expanduser().resolve(strict=True)
    output = output.expanduser().absolute()
    report_path = report_path.expanduser().absolute()
    require(output.suffix.lower() == ".ipa", "A saída deve terminar em .ipa.")
    require(output.resolve() != report_path.resolve(), "IPA e relatório precisam de caminhos diferentes.")
    for target in (output, report_path):
        require(not target.exists() and not target.is_symlink(), f"A saída já existe; escolha outro nome: {target}")
        resolved_target = target.resolve()
        require(resolved_target != ipa and not resolved_target.is_relative_to(framework), "A saída não pode sobrescrever as entradas.")
        target.parent.mkdir(parents=True, exist_ok=True)
    require(ipa.is_file() and ipa.stat().st_size <= MAX_ARCHIVE_SIZE, "IPA ausente ou acima do limite.")
    require(file_digest(ipa) == SOURCE_IPA_SHA256, "SHA-256 do IPA não corresponde à versão 56.31.0 auditada.")
    framework_info = validate_framework(framework)
    temporary_output: Path | None = None
    temporary_report: Path | None = None
    output_published = False
    report_published = False
    try:
        with tempfile.TemporaryDirectory(prefix="poollab-integration-") as temporary:
            staging = Path(temporary)
            source_snapshot = staging / "source.ipa"
            shutil.copyfile(ipa, source_snapshot)
            require(file_digest(source_snapshot) == SOURCE_IPA_SHA256, "O IPA mudou durante a cópia.")
            payload_root = staging / "package"
            payload_root.mkdir()
            with zipfile.ZipFile(source_snapshot) as archive:
                extract_checked(archive, safe_zip_entries(archive), payload_root)
            app = payload_root.joinpath(*APP_PATH.parts)
            info = read_plist(app / "Info.plist")
            expected = {"CFBundleIdentifier": "com.miniclip.8ballpoolmult", "CFBundleExecutable": "pool",
                        "CFBundleShortVersionString": "56.31.0", "CFBundleVersion": "5330", "MinimumOSVersion": "15.0"}
            require(all(info.get(k) == v for k, v in expected.items()), "Identidade/versão do app não corresponde à base.")
            old_framework = app / "Frameworks/libloader.framework"
            require(file_digest(old_framework / "libloader") == SOURCE_LOADER_SHA256, "Hash do loader antigo não corresponde à base.")
            new_framework = app / "Frameworks" / f"{FRAMEWORK_NAME}.framework"
            require(not new_framework.exists(), "A base já contém o framework novo.")
            shutil.copytree(framework, new_framework, copy_function=shutil.copy2)
            staged_framework_info = validate_framework(new_framework)
            require(staged_framework_info == framework_info, "O framework mudou durante a cópia.")
            game = app / "pool"
            new_game, patch_report = patch_game_executable(bounded_read(game, MAX_MACHO_SIZE))
            game.write_bytes(new_game)
            game.chmod(0o755)
            framework_binary = new_framework / FRAMEWORK_NAME
            unsigned_framework, removed_signatures = strip_signature(bounded_read(framework_binary, MAX_MACHO_SIZE))
            framework_binary.write_bytes(unsigned_framework)
            framework_binary.chmod(0o755)
            shutil.rmtree(old_framework)
            removed_metadata = remove_old_signing_metadata(payload_root)
            normalized_modes = normalize_bundle_executable_permissions(payload_root)
            require(file_digest(ipa) == SOURCE_IPA_SHA256, "O IPA original mudou durante a operação.")
            require(inspect_framework_tree(framework) == framework_info["files_before_signature_removal"],
                    "O framework de entrada mudou durante a operação.")
            with tempfile.NamedTemporaryFile(prefix=".poollab-", suffix=".ipa.tmp", dir=output.parent, delete=False) as handle:
                temporary_output = Path(handle.name)
            make_archive(payload_root, temporary_output)
            result = {
                "created_at_utc": datetime.now(timezone.utc).isoformat(),
                "source_ipa_sha256": SOURCE_IPA_SHA256,
                "source_original_preserved_and_rechecked": True,
                "app_identity_preserved": expected,
                "output_ipa_sha256": file_digest(temporary_output),
                "output_ipa_size": temporary_output.stat().st_size,
                "output_filename": output.name,
                "framework": {**framework_info, "binary_after_signature_removal_sha256": digest(unsigned_framework),
                              "removed_code_signature_commands": removed_signatures},
                "game_executable_changes": patch_report,
                "removed_framework": {"path": f"{APP_PATH}/Frameworks/libloader.framework/", "binary_sha256": SOURCE_LOADER_SHA256},
                "removed_signing_metadata": removed_metadata,
                "normalized_bundle_executable_modes": normalized_modes,
                "other_game_resources": "preserved, including fluorite_resources.tar.lz4; no old loader is loaded",
                "signing": "UNSIGNED; requires new valid signing of app and nested bundles",
                "runtime_tested_on_iphone": False,
                "gbox_compatibility_tested": False,
                "old_fluorite_functions_reused": False,
            }
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", prefix=".poollab-", suffix=".json.tmp",
                                             dir=report_path.parent, delete=False) as handle:
                temporary_report = Path(handle.name)
                json.dump(result, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            with temporary_output.open("rb") as handle:
                os.fsync(handle.fileno())
            exclusive_publish(temporary_output, output)
            output_published = True
            exclusive_publish(temporary_report, report_path)
            report_published = True
            return result
    except BaseException:
        # Roll back only paths published by this invocation, never pre-existing
        # files. All build/extraction mutations otherwise live in temp storage.
        if output_published and not report_published:
            output.unlink(missing_ok=True)
        raise
    finally:
        for temporary_path in (temporary_output, temporary_report):
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ipa", type=Path, required=True, help="IPA original exato auditado, preservado sem alterações")
    parser.add_argument("--framework", type=Path, required=True, help="Diretório PoolLabIntegration.framework compilado para iPhone")
    parser.add_argument("--output", type=Path, required=True, help="Novo caminho .ipa; precisa não existir")
    parser.add_argument("--report", type=Path, help="Novo caminho JSON; padrão: nome_do_ipa.manifest.json")
    arguments = parser.parse_args()
    report = arguments.report or arguments.output.with_suffix(".manifest.json")
    try:
        result = integrate(arguments.ipa, arguments.framework, arguments.output, report)
    except (IntegrationError, OSError, zipfile.BadZipFile, RuntimeError, struct.error) as error:
        print(f"Integração interrompida: {error}", file=sys.stderr)
        return 1
    print(json.dumps({"ipa": str(arguments.output.absolute()), "manifest": str(report.absolute()),
                      "sha256": result["output_ipa_sha256"], "signing_required": True,
                      "runtime_tested": False}, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
