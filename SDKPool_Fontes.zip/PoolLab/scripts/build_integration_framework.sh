#!/bin/bash
# Builds the in-process framework. This command does not modify or package a game IPA.
set -euo pipefail

fail() { printf '%s\n' "$*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail 'This build requires macOS with Xcode and the iOS SDK.'
command -v xcodebuild >/dev/null || fail 'Xcode is not installed or selected.'
xcrun --sdk iphoneos --show-sdk-path >/dev/null || fail 'Select a full Xcode installation with an iOS SDK.'

project_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$project_root"

for source_file in \
  Integrated/PLBootstrap.m \
  Integrated/PLAdControl.h \
  Integrated/PLAdControl.m \
  Integrated/PLQueueBridge.h \
  Integrated/PLQueueBridge.m \
  Integrated/PLInteractionRecorder.h \
  Integrated/PLInteractionRecorder.m \
  Integrated/PLRuntimeBridge.h \
  Integrated/PLRuntimeBridge.m \
  Integrated/PoolLabIntegration.h \
  Integrated/PoolLabIntegration.swift \
  Integrated/IntegratedGameModel.swift; do
  [[ -f "$source_file" ]] || fail "Required integration source is missing: $source_file"
done
python3 scripts/configure_keyauth.py

# Build in a fresh directory so a previous build cannot masquerade as this result.
build_workspace="$(mktemp -d "${TMPDIR:-/tmp}/poollab-integration.XXXXXX")"
trap 'rm -rf "$build_workspace"' EXIT

xcodebuild -version
swift test --configuration release --scratch-path "$build_workspace/SwiftTests"
xcodebuild \
  -project PoolLab.xcodeproj \
  -scheme PoolLabIntegration \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$build_workspace/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY= \
  DEVELOPMENT_TEAM= \
  ARCHS=arm64 \
  ONLY_ACTIVE_ARCH=NO \
  build

framework_path="$build_workspace/DerivedData/Build/Products/Release-iphoneos/PoolLabIntegration.framework"
[[ -d "$framework_path" ]] || fail 'Xcode did not produce PoolLabIntegration.framework.'

# Require an actual ARM64 iPhoneOS dynamic library, not a simulator/static artifact.
python3 - "$framework_path" <<'PY'
from pathlib import Path
import plistlib
import struct
import sys

framework = Path(sys.argv[1])
with (framework / 'Info.plist').open('rb') as stream:
    info = plistlib.load(stream)
if info.get('CFBundleExecutable') != 'PoolLabIntegration':
    raise SystemExit('Unexpected framework executable.')
if info.get('CFBundlePackageType') != 'FMWK':
    raise SystemExit('The generated bundle is not a framework.')
if info.get('CFBundleSupportedPlatforms') != ['iPhoneOS']:
    raise SystemExit('The framework must target an iPhone device.')
if info.get('CFBundleVersion') != '17' or info.get('CFBundleShortVersionString') != '1.14':
    raise SystemExit('Expected SDKPool V16 (1.14, build 17). Refusing an older framework.')

binary = (framework / 'PoolLabIntegration').read_bytes()
if len(binary) < 32:
    raise SystemExit('The framework executable is missing or incomplete.')
magic, cpu, subtype, file_type, count, command_bytes, flags, reserved = struct.unpack_from('<8I', binary)
if (magic, cpu, file_type) != (0xFEEDFACF, 0x0100000C, 6):
    raise SystemExit('Expected a thin ARM64 Mach-O dynamic library.')
command_end = 32 + command_bytes
if command_end > len(binary):
    raise SystemExit('Malformed load command table.')

cursor = 32
ios_platform = False
install_name = None
dependencies = []
dylib_commands = {0xC, 0x80000018, 0x8000001F, 0x80000023, 0x20}
for _ in range(count):
    if cursor + 8 > command_end:
        raise SystemExit('Malformed Mach-O command.')
    command, size = struct.unpack_from('<2I', binary, cursor)
    if size < 8 or size % 8 or cursor + size > command_end:
        raise SystemExit('Malformed Mach-O command length.')
    if command == 0x32 and size >= 24:  # LC_BUILD_VERSION: PLATFORM_IOS = 2.
        platform = struct.unpack_from('<I', binary, cursor + 8)[0]
        ios_platform = platform == 2
    if command == 0x25:  # LC_VERSION_MIN_IPHONEOS (older toolchains).
        ios_platform = True
    if command in dylib_commands or command == 0xD:
        if size < 24:
            raise SystemExit('Malformed dylib load command.')
        offset = struct.unpack_from('<I', binary, cursor + 8)[0]
        if not 24 <= offset < size:
            raise SystemExit('Malformed dylib name.')
        encoded = binary[cursor + offset:cursor + size].split(b'\0', 1)[0]
        name = encoded.decode('utf-8')
        if command == 0xD:
            install_name = name
        else:
            dependencies.append(name)
    cursor += size
if cursor != command_end or not ios_platform:
    raise SystemExit('The Mach-O is not a valid iPhoneOS build.')
expected = '@rpath/PoolLabIntegration.framework/PoolLabIntegration'
if install_name != expected:
    raise SystemExit(f'Unexpected framework install name: {install_name!r}')
for name in dependencies:
    if not name.startswith(('/System/Library/', '/usr/lib/')):
        raise SystemExit(f'Unexpected bundled dependency: {name}. Do not package until it is resolved.')
if not (framework / 'KeyAuth.plist').is_file():
    raise SystemExit('The KeyAuth configuration is missing from the framework.')
if not (framework / 'SDKPoolMark.png').is_file():
    raise SystemExit('The SDKPool logo is missing from the framework.')
print('Validated: ARM64 iPhoneOS dynamic framework; system dependencies only.')
PY

xcrun lipo "$framework_path/PoolLabIntegration" -verify_arch arm64
xcrun otool -L "$framework_path/PoolLabIntegration"

COPYFILE_DISABLE=1 /usr/bin/ditto -c -k --keepParent --norsrc --noextattr \
  "$framework_path" "$build_workspace/PoolLabIntegration_unsigned.framework.zip"
/usr/bin/unzip -tq "$build_workspace/PoolLabIntegration_unsigned.framework.zip"

mkdir -p "$project_root/dist"
mv "$build_workspace/PoolLabIntegration_unsigned.framework.zip" \
  "$project_root/dist/PoolLabIntegration_unsigned.framework.zip"
(
  cd "$project_root/dist"
  /usr/bin/shasum -a 256 PoolLabIntegration_unsigned.framework.zip \
    > PoolLabIntegration_unsigned.framework.zip.sha256
)
printf 'Built: %s/dist/PoolLabIntegration_unsigned.framework.zip\n' "$project_root"
printf '%s\n' 'This is an unsigned framework, not an installable IPA. Device integration and signing are separate steps.'
