#!/usr/bin/env python3
"""Apply non-secret KeyAuth application settings supplied through environment."""
import os
from pathlib import Path
import plistlib


def main():
    path = Path(__file__).resolve().parents[1] / "Resources" / "KeyAuth.plist"
    with path.open("rb") as stream:
        settings = plistlib.load(stream)
    fields = {
        "KEYAUTH_APP_NAME": "AppName",
        "KEYAUTH_OWNER_ID": "OwnerID",
        "KEYAUTH_VERSION": "Version",
        "KEYAUTH_SUBSCRIPTION": "RequiredSubscription",
    }
    for variable, field in fields.items():
        if variable in os.environ:
            value = os.environ[variable].strip()
            if len(value) > 256 or any(ord(char) < 32 for char in value):
                raise SystemExit(f"Invalid value for {variable}.")
            settings[field] = value
    for field in ("AppName", "OwnerID", "Version"):
        value = settings.get(field, "")
        if not isinstance(value, str) or not value.strip() or value.startswith("PREENCHA"):
            raise SystemExit(f"Configure {field} in Resources/KeyAuth.plist before building.")
    with path.open("wb") as stream:
        plistlib.dump(settings, stream, sort_keys=False)
    print("KeyAuth application configuration validated. No license or administrative secret is needed.")


if __name__ == "__main__":
    main()
