#!/usr/bin/env python3
"""Replace the framework in the exact verified unsigned PoolLab V4 package.

This does not decrypt an app, alter the game's executable, compile or sign.
Only the SHA-bound V4 package is admitted. The original input is preserved.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import plistlib
import shutil
import tempfile
import zipfile

import integrate_game_ipa as common

BASE_SHA256 = "ae988d071cd947e644cb84cf724c0964653bf60b64c4ddb6d07d924152d674e9"
BASE_BYTES = 164514838
MAIN_SHA256 = "b14d66d27098c2280205980e3f1ef029bb5a2d81e70837cd8e0aaa3c7f05c834"
OLD_FRAMEWORK_SHA256 = "59bdc89819fc087f6355046a99ca3a3d2c71ea7b286e815117e3ed5ab91841c3"
FRAMEWORK_PREFIX = "Payload/pool.app/Frameworks/PoolLabIntegration.framework/"
NEW_VERSION = "1.14"
NEW_BUILD = "17"


def verify_preserved_files(before: Path, after: Path) -> int:
    """Compare actual archive members, including modes, outside our framework."""
    with zipfile.ZipFile(before) as source, zipfile.ZipFile(after) as output:
        a = {x.filename: x for x in source.infolist() if not x.filename.startswith(FRAMEWORK_PREFIX)}
        b = {x.filename: x for x in output.infolist() if not x.filename.startswith(FRAMEWORK_PREFIX)}
        common.require(a.keys() == b.keys(), "A atualização mudou arquivos fora do framework.")
        for name in a:
            common.require(source.read(name) == output.read(name), "Conteúdo do jogo mudou: " + name)
            common.require(a[name].external_attr == b[name].external_attr,
                           "Permissão de arquivo mudou: " + name)
        return len(a)


def upgrade(ipa: Path, framework: Path, output: Path, report_path: Path) -> dict:
    ipa = ipa.expanduser().resolve(strict=True)
    framework = framework.expanduser().resolve(strict=True)
    output = output.expanduser().absolute()
    report_path = report_path.expanduser().absolute()
    common.require(output.suffix.lower() == ".ipa", "A saída deve terminar em .ipa.")
    common.require(output.resolve() != report_path.resolve(), "IPA e relatório precisam de caminhos diferentes.")
    for target in (output, report_path):
        common.require(not target.exists() and not target.is_symlink(), "Saída já existente: " + str(target))
        common.require(target.resolve() != ipa and not target.resolve().is_relative_to(framework),
                       "A saída não pode sobrescrever uma entrada.")
        target.parent.mkdir(parents=True, exist_ok=True)
    common.require(ipa.is_file() and ipa.stat().st_size == BASE_BYTES, "Use o IPA PoolLab V4 exato, sem reassinar.")
    common.require(common.file_digest(ipa) == BASE_SHA256, "O IPA base não corresponde ao PoolLab V4 verificado.")
    framework_info = common.validate_framework(framework)
    info = common.read_plist(framework / "Info.plist")
    common.require(info.get("CFBundleVersion") == NEW_BUILD and
                   info.get("CFBundleShortVersionString") == NEW_VERSION,
                   "A atualização exige o framework SDKPool 1.14, build 17.")
    logo = framework / "SDKPoolMark.png"
    common.require(logo.is_file() and logo.read_bytes().startswith(b"\x89PNG\r\n\x1a\n"),
                   "A logo SDKPool está ausente ou inválida no framework.")
    temporary_output = temporary_report = None
    published = False
    report_published = False
    try:
        with tempfile.TemporaryDirectory(prefix="poollab-upgrade-") as temporary:
            work = Path(temporary)
            snapshot = work / "base.ipa"
            shutil.copyfile(ipa, snapshot)
            common.require(common.file_digest(snapshot) == BASE_SHA256, "A base mudou durante a cópia.")
            package = work / "package"
            package.mkdir()
            with zipfile.ZipFile(snapshot) as archive:
                common.extract_checked(archive, common.safe_zip_entries(archive), package)
            app = package / "Payload/pool.app"
            common.require(common.file_digest(app / "pool") == MAIN_SHA256, "Executável base inesperado.")
            destination = app / "Frameworks/PoolLabIntegration.framework"
            old_info = common.read_plist(destination / "Info.plist")
            common.require(old_info.get("CFBundleVersion") == "4" and
                           old_info.get("CFBundleShortVersionString") == "1.2", "Framework base inesperado.")
            common.require(common.file_digest(destination / "PoolLabIntegration") == OLD_FRAMEWORK_SHA256,
                           "O framework V4 da base foi alterado.")
            shutil.rmtree(destination)
            shutil.copytree(framework, destination, copy_function=shutil.copy2)
            common.require(common.validate_framework(destination) == framework_info,
                           "O framework novo mudou durante a cópia.")
            binary_path = destination / "PoolLabIntegration"
            binary, signature_count = common.strip_signature(common.bounded_read(binary_path, common.MAX_MACHO_SIZE))
            binary_path.write_bytes(binary)
            binary_path.chmod(0o755)
            removed_metadata = common.remove_old_signing_metadata(destination)
            common.require(common.file_digest(app / "pool") == MAIN_SHA256, "O executável do jogo foi alterado.")
            with tempfile.NamedTemporaryFile(prefix=".poollab-upgrade-", suffix=".ipa.tmp",
                                             dir=output.parent, delete=False) as handle:
                temporary_output = Path(handle.name)
            common.make_archive(package, temporary_output)
            preserved_count = verify_preserved_files(snapshot, temporary_output)
            common.require(common.file_digest(ipa) == BASE_SHA256, "O IPA de entrada mudou.")
            common.require(common.inspect_framework_tree(framework) == framework_info["files_before_signature_removal"],
                           "O framework de entrada mudou.")
            result = {
                "created_at_utc": datetime.now(timezone.utc).isoformat(),
                "source_ipa_sha256": BASE_SHA256,
                "source_original_preserved_and_rechecked": True,
                "output_filename": output.name,
                "output_ipa_sha256": common.file_digest(temporary_output),
                "output_ipa_size": temporary_output.stat().st_size,
                "framework_version": NEW_VERSION, "framework_build": NEW_BUILD,
                "framework": {**framework_info,
                              "binary_after_signature_removal_sha256": common.digest(binary),
                              "removed_code_signature_commands": signature_count},
                "removed_framework_signing_metadata": removed_metadata,
                "game_executable_sha256": MAIN_SHA256,
                "non_framework_entries_preserved_byte_for_byte_and_modes": preserved_count,
                "signing": "UNSIGNED; sign app and embedded frameworks before installing",
                "runtime_tested_on_iphone": False,
            }
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", prefix=".poollab-upgrade-",
                                             suffix=".json.tmp", dir=report_path.parent, delete=False) as handle:
                temporary_report = Path(handle.name)
                json.dump(result, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            common.exclusive_publish(temporary_output, output)
            published = True
            common.exclusive_publish(temporary_report, report_path)
            report_published = True
            return result
    except BaseException:
        if published and not report_published:
            output.unlink(missing_ok=True)
        raise
    finally:
        for path in (temporary_output, temporary_report):
            if path is not None:
                path.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ipa", type=Path, required=True)
    parser.add_argument("--framework", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = upgrade(args.ipa, args.framework, args.output, args.output.with_suffix(".manifest.json"))
    except (common.IntegrationError, OSError, zipfile.BadZipFile) as error:
        parser.exit(1, "Atualização interrompida: " + str(error) + "\n")
    print(json.dumps({"ipa": str(args.output), "sha256": result["output_ipa_sha256"],
                      "build": NEW_BUILD, "signing_required": True, "runtime_tested": False}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
