#!/bin/bash
# Builds the independent PoolLab app. Run with: bash scripts/build_unsigned_ipa.sh
set -euo pipefail

fail() { printf '%s\n' "$*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail 'This build requires macOS with Xcode and the iOS SDK.'
command -v xcodebuild >/dev/null || fail 'Xcode is not installed or selected.'
xcrun --sdk iphoneos --show-sdk-path >/dev/null || fail 'Select a full Xcode installation with an iOS SDK.'

project_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$project_root"
python3 scripts/configure_keyauth.py

bundle_id="${POOLLAB_BUNDLE_ID:-com.example.poollab}"
[[ "$bundle_id" =~ ^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$ ]] || fail 'POOLLAB_BUNDLE_ID must be a reverse-DNS bundle identifier.'

# Each run uses a new directory so an old .app cannot be packaged after a failed build.
build_workspace="$(mktemp -d "${TMPDIR:-/tmp}/poollab-build.XXXXXX")"
trap 'rm -rf "$build_workspace"' EXIT

xcodebuild -version
swift test --scratch-path "$build_workspace/SwiftTests"
xcodebuild \
  -project PoolLab.xcodeproj \
  -scheme PoolLab \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$build_workspace/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY= \
  DEVELOPMENT_TEAM= \
  "PRODUCT_BUNDLE_IDENTIFIER=$bundle_id" \
  ARCHS=arm64 \
  ONLY_ACTIVE_ARCH=NO \
  build

app_path="$build_workspace/DerivedData/Build/Products/Release-iphoneos/PoolLab.app"
[[ -d "$app_path" ]] || fail 'Xcode did not produce PoolLab.app.'
executable_name="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$app_path/Info.plist")"
[[ -n "$executable_name" && "$executable_name" != */* ]] || fail 'Invalid bundle executable.'
[[ -x "$app_path/$executable_name" ]] || fail 'The compiled executable is missing.'
platform="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleSupportedPlatforms:0' "$app_path/Info.plist")"
[[ "$platform" == "iPhoneOS" ]] || fail 'Refusing to package a simulator app.'
xcrun lipo "$app_path/$executable_name" -verify_arch arm64

mkdir "$build_workspace/Payload"
/usr/bin/ditto "$app_path" "$build_workspace/Payload/PoolLab.app"
/usr/bin/ditto -c -k --keepParent "$build_workspace/Payload" "$build_workspace/PoolLab_unsigned.ipa"
/usr/bin/unzip -tq "$build_workspace/PoolLab_unsigned.ipa"

mkdir -p "$project_root/dist"
mv "$build_workspace/PoolLab_unsigned.ipa" "$project_root/dist/PoolLab_unsigned.ipa"
(
  cd "$project_root/dist"
  /usr/bin/shasum -a 256 PoolLab_unsigned.ipa > PoolLab_unsigned.ipa.sha256
)
printf 'Built: %s/dist/PoolLab_unsigned.ipa\nRequires your own signing before installation.\n' "$project_root"
