import XCTest
@testable import PoolLabCore

final class LuckyShotPlannerTests: XCTestCase {
    private var scene: TableState {
        TableState(balls: [PoolBall(id: 0, position: Vector2(x: 50, y: 50)),
                           PoolBall(id: 1, position: Vector2(x: 90, y: 50))])
    }

    func testFindsStoppingShotNearTargetWithoutPocketingBalls() throws {
        let result = try XCTUnwrap(LuckyShotPlanner.suggestion(for: scene, targetBallID: 1,
                                                              targetCenter: Vector2(x: 130, y: 50)))
        XCTAssertLessThan(result.finalDistance, 2 * scene.table.ballRadius)
        XCTAssertTrue(result.result.settled)
        XCTAssertFalse(result.result.scratched)
        XCTAssertFalse(result.result.finalState.balls.first(where: { $0.id == 1 })!.pocketed)
        XCTAssertFalse(result.result.traces.isEmpty)
    }

    func testObstacleBlockingTheCueDoesNotProduceAnUnverifiedSuggestion() throws {
        let state = TableState(balls: [PoolBall(id: 0, position: Vector2(x: 40, y: 50)),
                                      PoolBall(id: 1, position: Vector2(x: 130, y: 50)),
                                      PoolBall(id: 2, position: Vector2(x: 85, y: 50))])
        XCTAssertNil(try LuckyShotPlanner.suggestion(for: state, targetBallID: 1,
                                                   targetCenter: Vector2(x: 150, y: 50), obstacleIDs: [2]))
    }

    func testBallAlreadyAtTargetNeedsNoShot() throws {
        XCTAssertNil(try LuckyShotPlanner.suggestion(for: scene, targetBallID: 1,
                                                   targetCenter: Vector2(x: 90, y: 50)))
    }

    func testInvalidTargetAndObstacleInputsAreRejected() {
        XCTAssertThrowsError(try LuckyShotPlanner.suggestion(for: scene, targetBallID: 0,
                                                           targetCenter: Vector2(x: 130, y: 50)))
        XCTAssertThrowsError(try LuckyShotPlanner.suggestion(for: scene, targetBallID: 1,
                                                           targetCenter: Vector2(x: .nan, y: 50)))
        XCTAssertThrowsError(try LuckyShotPlanner.suggestion(for: scene, targetBallID: 1,
                                                           targetCenter: Vector2(x: 130, y: 50), obstacleIDs: [1]))
    }

    func testCancellationIsObservedBeforeTheSearch() async {
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try LuckyShotPlanner.suggestion(for: scene, targetBallID: 1,
                                                  targetCenter: Vector2(x: 130, y: 50))
        }
        do { _ = try await task.value; XCTFail("Expected cancellation") }
        catch { XCTAssertTrue(error is CancellationError) }
    }
}
