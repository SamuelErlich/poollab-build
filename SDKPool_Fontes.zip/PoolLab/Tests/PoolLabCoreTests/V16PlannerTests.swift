import XCTest
@testable import PoolLabCore

final class V16PlannerTests: XCTestCase {
    func testBoundedRetriesReachPreviouslyStarvedFourCushionSeed() throws {
        // Seven legal targets x six pockets allow only 97 complete topologies
        // before the existing 4,096 geometric-attempt cap. In V15 this seed's
        // earliest index across the complete 60-pass ordering cycle was 100,
        // so retries could never generate it for any target/pocket pair.
        let route = ShotPlanner.CushionRoute(objectRails: [],
            cueRails: [.bottom, .top, .bottom, .top])
        let index = try XCTUnwrap(ShotPlanner.automaticCushionRoutes(explorationPass: 7)
            .firstIndex(of: route))
        XCTAssertLessThan(index, 4_096 / (7 * 6))
    }

    func testBoundedRetriesCoverAllFiniteSeedsForSevenLegalTargets() {
        // Tests scheduling coverage, not a promise that every physical shot is
        // enumerated or that a real device has enough elapsed time for this cap.
        let complete = Set(ShotPlanner.automaticCushionRoutes(explorationPass: 0).map(key))
        XCTAssertEqual(complete.count, 864)
        let completeTopologiesPerPass = 4_096 / (7 * 6)
        var visited = Set<String>()
        for pass in 0..<60 {
            let routes = ShotPlanner.automaticCushionRoutes(explorationPass: pass)
            XCTAssertEqual(Set(routes.map(key)), complete)
            visited.formUnion(routes.prefix(completeTopologiesPerPass).map(key))
        }
        // V15 visits only 316 distinct seeds in these same capped prefixes and
        // then repeats forever. Each entry counted here has room for all pairs.
        XCTAssertEqual(visited, complete)
    }

    func testLongRunningExplorationPreservesEverySeedWithoutOverflow() {
        let complete = Set(ShotPlanner.automaticCushionRoutes(explorationPass: 0).map(key))
        for pass in [Int.max - 3, Int.max - 2, Int.max - 1, Int.max] {
            let routes = ShotPlanner.automaticCushionRoutes(explorationPass: pass)
            XCTAssertEqual(routes.count, complete.count)
            XCTAssertEqual(Set(routes.map(key)), complete)
        }
    }

    private func key(_ route: ShotPlanner.CushionRoute) -> String {
        func rail(_ value: ShotPlanner.Rail) -> String {
            switch value {
            case .left: return "L"
            case .right: return "R"
            case .top: return "T"
            case .bottom: return "B"
            }
        }
        return route.objectRails.map(rail).joined() + "/" + route.cueRails.map(rail).joined()
    }
}
