import CryptoKit
import Foundation
import XCTest
@testable import PoolLabCore

final class KeyAuthClientTests: XCTestCase {
    private let fixture = KeyAuthFixture()
    private let configuration = KeyAuthConfiguration(appName: "TestApp", ownerID: "owner-test", version: "1.0")

    private func client(_ transport: any KeyAuthTransport,
                        requiredSubscription: String? = nil) -> KeyAuthClient {
        let instant = fixture.instant
        return KeyAuthClient(configuration: KeyAuthConfiguration(
            appName: configuration.appName, ownerID: configuration.ownerID,
            version: configuration.version, requiredSubscription: requiredSubscription
        ), transport: transport, now: { instant }, signaturePublicKey: fixture.publicKey)
    }

    func testSignedLicenseAcceptsStringAndNumericUnixExpiries() async throws {
        let transport = KeyAuthScriptedTransport([
            try fixture.signed(#"{"success":true,"sessionid":"session-1"}"#),
            try fixture.signed("""
            {"success":true,"info":{"username":"alice","subscriptions":[
            {"subscription":"expired","expiry":"1799999990"},
            {"subscription":"default","expiry":1800003600},
            {"subscription":"pro","expiry":"1800007200"}]}}
            """)
        ])
        let session = try await client(transport, requiredSubscription: "pro")
            .authenticate(key: "test-license", deviceID: "test-device", twoFactorCode: nil)
        XCTAssertEqual(session.username, "alice")
        XCTAssertEqual(session.subscriptions.count, 3)
        XCTAssertEqual(session.expiresAt, Date(timeIntervalSince1970: 1_800_007_200))
        let types = await transport.requestedTypes()
        XCTAssertEqual(types, ["init", "license"])
    }

    func testRemoteRejectionCannotBecomeAuthenticated() async throws {
        let transport = KeyAuthScriptedTransport([
            try fixture.signed(#"{"success":true,"sessionid":"only-initialized"}"#),
            try fixture.signed(#"{"success":false,"message":"Invalid license"}"#)
        ])
        let sut = client(transport)
        do {
            _ = try await sut.authenticate(key: "invalid", deviceID: "device", twoFactorCode: nil)
            XCTFail("Rejected license must not produce a session")
        } catch let error as KeyAuthError {
            XCTAssertEqual(error, .serviceRejected(message: "Invalid license"))
        }
        do { try await sut.checkSession(); XCTFail("Init is not login") }
        catch let error as KeyAuthError { XCTAssertEqual(error, .authenticationRequired) }
        let types = await transport.requestedTypes()
        XCTAssertEqual(types, ["init", "license"], "No check request may authorize an unlicensed init session")
    }

    func testSessionCheckBeforeLoginDoesNotCallNetwork() async throws {
        let transport = KeyAuthScriptedTransport([])
        do { try await client(transport).checkSession(); XCTFail("Login is required") }
        catch let error as KeyAuthError { XCTAssertEqual(error, .authenticationRequired) }
        let types = await transport.requestedTypes()
        XCTAssertTrue(types.isEmpty)
    }

    func testRequiredSubscriptionCannotBeReplacedByDifferentPaidSubscription() async throws {
        let transport = KeyAuthScriptedTransport([
            try fixture.signed(#"{"success":true,"sessionid":"s"}"#),
            try fixture.signed(#"{"success":true,"info":{"username":"alice","subscriptions":[{"subscription":"basic","expiry":"1800003600"}]}}"#)
        ])
        do {
            _ = try await client(transport, requiredSubscription: "pro")
                .authenticate(key: "license", deviceID: "device", twoFactorCode: nil)
            XCTFail("An unrelated subscription must not grant the configured entitlement")
        } catch let error as KeyAuthError { XCTAssertEqual(error, .noActiveSubscription) }
    }

    func testExpiredSubscriptionCannotGrantAccessEvenWhenSuccessIsTrue() async throws {
        let transport = KeyAuthScriptedTransport([
            try fixture.signed(#"{"success":true,"sessionid":"s"}"#),
            try fixture.signed(#"{"success":true,"info":{"username":"alice","subscriptions":[{"subscription":"default","expiry":"1799999999"}]}}"#)
        ])
        do {
            _ = try await client(transport).authenticate(key: "license", deviceID: "device", twoFactorCode: nil)
            XCTFail("Success alone does not prove a current entitlement")
        } catch let error as KeyAuthError { XCTAssertEqual(error, .noActiveSubscription) }
    }

    func testSignedCheckWithoutInfoRetainsPriorExpiryAndFailedCheckRevokes() async throws {
        let transport = KeyAuthScriptedTransport([
            try fixture.signed(#"{"success":true,"sessionid":"s"}"#),
            try fixture.validLicense(),
            try fixture.signed(#"{"success":true,"message":"Session valid"}"#),
            try fixture.signed(#"{"success":false,"message":"Session revoked"}"#)
        ])
        let sut = client(transport)
        _ = try await sut.authenticate(key: "license", deviceID: "device", twoFactorCode: nil)
        let refreshed = try await sut.checkSession()
        XCTAssertEqual(refreshed.expiresAt, Date(timeIntervalSince1970: 1_800_003_600))
        do { try await sut.checkSession(); XCTFail("Revoked sessions fail closed") }
        catch let error as KeyAuthError { XCTAssertEqual(error, .serviceRejected(message: "Session revoked")) }
        do { try await sut.checkSession(); XCTFail("Revoked state must be cleared") }
        catch let error as KeyAuthError { XCTAssertEqual(error, .authenticationRequired) }
        let types = await transport.requestedTypes()
        XCTAssertEqual(types, ["init", "license", "check", "check"])
    }

    func testTamperedResponseIsRejectedBeforeJSONParsing() async throws {
        let signed = try fixture.signed(#"{"success":false}"#)
        let changed = KeyAuthHTTPResponse(statusCode: 200, headers: signed.headers,
                                         body: Data(#"{"success":true,"sessionid":"injected"}"#.utf8))
        let transport = KeyAuthScriptedTransport([changed])
        do {
            _ = try await client(transport).authenticate(key: "license", deviceID: "device", twoFactorCode: nil)
            XCTFail("Modified bytes must invalidate the signature")
        } catch let error as KeyAuthError { XCTAssertEqual(error, .invalidSignature) }
        let types = await transport.requestedTypes()
        XCTAssertEqual(types, ["init"])
    }

    func testCheckReturnsReducedEntitlementExpiryToCaller() async throws {
        let transport = KeyAuthScriptedTransport([
            try fixture.signed(#"{"success":true,"sessionid":"s"}"#),
            try fixture.validLicense(),
            try fixture.signed(#"{"success":true,"info":{"subscriptions":[{"subscription":"default","expiry":1800000060}]}}"#)
        ])
        let sut = client(transport)
        let initial = try await sut.authenticate(key: "license", deviceID: "device", twoFactorCode: nil)
        let updated = try await sut.checkSession()
        XCTAssertEqual(updated.username, initial.username)
        XCTAssertLessThan(updated.expiresAt, initial.expiresAt)
        XCTAssertEqual(updated.expiresAt, Date(timeIntervalSince1970: 1_800_000_060))
    }

    func testOversizedResponseIsRejectedBeforeDecoding() async throws {
        let oversized = KeyAuthHTTPResponse(statusCode: 200, headers: [:], body: Data(repeating: 65, count: 262_145))
        let transport = KeyAuthScriptedTransport([oversized])
        do {
            _ = try await client(transport).authenticate(key: "license", deviceID: "device", twoFactorCode: nil)
            XCTFail("Oversized responses must fail closed")
        } catch let error as KeyAuthError { XCTAssertEqual(error, .responseTooLarge) }
    }

    func testLogoutRejectsLateLicenseSuccessEvenIfTransportIgnoresCancellation() async throws {
        let transport = KeyAuthPausedLicenseTransport(
            initialized: try fixture.signed(#"{"success":true,"sessionid":"s"}"#),
            licensed: try fixture.validLicense(),
            loggedOut: try fixture.signed(#"{"success":true}"#)
        )
        let sut = client(transport)
        let login = Task { try await sut.authenticate(key: "license", deviceID: "device", twoFactorCode: nil) }
        await transport.waitForLicenseRequest()
        // Logout revokes locally immediately. Its task waits for the serialized
        // request, so observing cancellation proves it reached that revocation.
        let logout = Task { await sut.logout() }
        await transport.waitForCancellation()
        await transport.releaseLicenseResponse()
        do { _ = try await login.value; XCTFail("A late success must not resurrect a session") }
        catch is CancellationError { /* In-flight task was canceled. */ }
        catch let error as KeyAuthError { XCTAssertEqual(error, .sessionEnded) }
        await logout.value
        do { try await sut.checkSession(); XCTFail("Logout remains effective") }
        catch let error as KeyAuthError { XCTAssertEqual(error, .authenticationRequired) }
    }

    func testFormEncodingPreservesPlusAndAmpersandInLicense() throws {
        let body = KeyAuthClient.formBody(["type": "license", "key": "a+b&c=d %é"])
        let text = try XCTUnwrap(String(data: body, encoding: .utf8))
        XCTAssertTrue(text.contains("key=a%2Bb%26c%3Dd%20%25%C3%A9"))
        let parsed = KeyAuthFixture.fields(body)
        XCTAssertEqual(parsed["key"], "a+b&c=d %é")
    }
}

final class KeyAuthVerificationTests: XCTestCase {
    private let fixture = KeyAuthFixture()

    func testSignatureWindowRejectsOldAndFutureResponses() throws {
        let instant = fixture.instant
        let verifier = KeyAuthResponseVerifier(publicKeyBytes: fixture.publicKey, now: { instant })
        for offset in [-26.0, 6.0] {
            XCTAssertThrowsError(try verifier.verify(fixture.signed(#"{"success":true}"#, offset: offset))) {
                XCTAssertEqual($0 as? KeyAuthError, .staleResponse)
            }
        }
        for offset in [-25.0, 0.0, 5.0] {
            XCTAssertNoThrow(try verifier.verify(fixture.signed(#"{"success":true}"#, offset: offset)))
        }
    }

    func testMissingSignatureAndDifferentKeyAreRejected() throws {
        let instant = fixture.instant
        let verifier = KeyAuthResponseVerifier(publicKeyBytes: fixture.publicKey, now: { instant })
        let unsigned = KeyAuthHTTPResponse(statusCode: 200, headers: [:], body: Data("{}".utf8))
        XCTAssertThrowsError(try verifier.verify(unsigned)) {
            XCTAssertEqual($0 as? KeyAuthError, .invalidSignature)
        }
        let other = KeyAuthFixture(seed: Data(repeating: 8, count: 32))
        XCTAssertThrowsError(try verifier.verify(other.signed(#"{"success":true}"#))) {
            XCTAssertEqual($0 as? KeyAuthError, .invalidSignature)
        }
    }

    func testRawWhitespaceIsPartOfSignature() throws {
        let instant = fixture.instant
        let verifier = KeyAuthResponseVerifier(publicKeyBytes: fixture.publicKey, now: { instant })
        let signed = try fixture.signed("{ \"success\": true }\n")
        XCTAssertNoThrow(try verifier.verify(signed))
        let reencoded = KeyAuthHTTPResponse(statusCode: 200, headers: signed.headers,
                                           body: Data(#"{"success":true}"#.utf8))
        XCTAssertThrowsError(try verifier.verify(reencoded)) {
            XCTAssertEqual($0 as? KeyAuthError, .invalidSignature)
        }
    }
}

private struct KeyAuthFixture: Sendable {
    let instant = Date(timeIntervalSince1970: 1_800_000_000)
    let seed: Data

    init(seed: Data = Data(repeating: 7, count: 32)) { self.seed = seed }

    var publicKey: Data { try! Curve25519.Signing.PrivateKey(rawRepresentation: seed).publicKey.rawRepresentation }

    func signed(_ text: String, offset: TimeInterval = 0) throws -> KeyAuthHTTPResponse {
        let timestamp = String(Int64(instant.timeIntervalSince1970 + offset))
        let body = Data(text.utf8)
        var message = Data(timestamp.utf8)
        message.append(body)
        let key = try Curve25519.Signing.PrivateKey(rawRepresentation: seed)
        let signature = try key.signature(for: message).map { String(format: "%02x", $0) }.joined()
        return KeyAuthHTTPResponse(statusCode: 200, headers: [
            "x-signature-timestamp": timestamp, "x-signature-ed25519": signature
        ], body: body)
    }

    func validLicense() throws -> KeyAuthHTTPResponse {
        try signed(#"{"success":true,"info":{"username":"alice","subscriptions":[{"subscription":"default","expiry":"1800003600"}]}}"#)
    }

    static func fields(_ data: Data?) -> [String: String] {
        var components = URLComponents()
        components.percentEncodedQuery = String(data: data ?? Data(), encoding: .utf8)
        return Dictionary((components.queryItems ?? []).map { ($0.name, $0.value ?? "") }, uniquingKeysWith: { _, last in last })
    }
}

private actor KeyAuthScriptedTransport: KeyAuthTransport {
    private var responses: [KeyAuthHTTPResponse]
    private var requests: [URLRequest] = []

    init(_ responses: [KeyAuthHTTPResponse]) { self.responses = responses }

    func send(_ request: URLRequest, maximumResponseBytes: Int) async throws -> KeyAuthHTTPResponse {
        requests.append(request)
        guard !responses.isEmpty else { throw KeyAuthError.invalidResponse }
        return responses.removeFirst()
    }

    func requestedTypes() -> [String] { requests.compactMap { KeyAuthFixture.fields($0.httpBody)["type"] } }
}

private actor KeyAuthPausedLicenseTransport: KeyAuthTransport {
    let initialized: KeyAuthHTTPResponse
    let licensed: KeyAuthHTTPResponse
    let loggedOut: KeyAuthHTTPResponse
    private var licenseContinuation: CheckedContinuation<KeyAuthHTTPResponse, Never>?
    private var licenseStarted = false
    private var startWaiter: CheckedContinuation<Void, Never>?
    private var canceled = false
    private var cancellationWaiter: CheckedContinuation<Void, Never>?

    init(initialized: KeyAuthHTTPResponse, licensed: KeyAuthHTTPResponse, loggedOut: KeyAuthHTTPResponse) {
        self.initialized = initialized
        self.licensed = licensed
        self.loggedOut = loggedOut
    }

    func send(_ request: URLRequest, maximumResponseBytes: Int) async throws -> KeyAuthHTTPResponse {
        switch KeyAuthFixture.fields(request.httpBody)["type"] {
        case "init": return initialized
        case "license":
            return await withTaskCancellationHandler(operation: {
                await withCheckedContinuation { continuation in
                    licenseContinuation = continuation
                    licenseStarted = true
                    startWaiter?.resume()
                    startWaiter = nil
                }
            }, onCancel: { Task { await self.recordCancellation() } })
        case "logout": return loggedOut
        default: throw KeyAuthError.invalidResponse
        }
    }

    func waitForLicenseRequest() async {
        if licenseStarted { return }
        await withCheckedContinuation { startWaiter = $0 }
    }

    private func recordCancellation() {
        canceled = true
        cancellationWaiter?.resume()
        cancellationWaiter = nil
    }

    func waitForCancellation() async {
        if canceled { return }
        await withCheckedContinuation { cancellationWaiter = $0 }
    }

    func releaseLicenseResponse() {
        licenseContinuation?.resume(returning: licensed)
        licenseContinuation = nil
    }
}
