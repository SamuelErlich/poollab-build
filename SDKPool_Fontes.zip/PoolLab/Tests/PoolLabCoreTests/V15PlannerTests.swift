import Foundation
import XCTest
@testable import PoolLabCore

final class V15PlannerTests: XCTestCase {
    func testPowerExplorationAlwaysIncludesTrueMaximumAndRespectsNativeQuantization() throws {
        var table = PoolTable()
        table.nativeDynamics = NativeDynamics(slidingDeceleration: 150, equilibriumTimeFactor: 0.002,
            spinDeceleration: 9.8, slidingFrictionCoefficient: 0.2, cushionSpinCoupling: 0.54,
            logicalFrameTime: 0.005)
        for pass in [0, 1, 2, 3, 7, 19, 100] {
            for minimum in [0.0, 0.1, 0.7, 1.0] {
                let powers = ShotPlanner.automaticPowerSamples(estimate: 0.08,
                    minimumPower: minimum, explorationPass: pass)
                XCTAssertTrue(powers.contains(1))
                XCTAssertLessThanOrEqual(powers.count, 8)
                XCTAssertTrue(powers.allSatisfy { $0 >= minimum && $0 <= 1 })
                let full = try ShotPlanner.executableShot(angle: 1.234567, power: 1,
                    minimumPower: minimum, table: table)
                XCTAssertEqual(try GameShotCalibration.controlPower(fromSimulationPower: full.power), 1)
                XCTAssertEqual(full.power, 1)
            }
        }
        let first = ShotPlanner.automaticPowerSamples(estimate: 0.08, minimumPower: 0, explorationPass: 0)
        let retry = ShotPlanner.automaticPowerSamples(estimate: 0.08, minimumPower: 0, explorationPass: 3)
        XCTAssertNotEqual(first, retry)
        XCTAssertEqual(retry.first, 1, "A retry must be able to test full power before another slow weak-power pass")
    }

    func testRailExplorationCoversEveryWallAndMixedCueObjectFourRailRoutes() {
        let routes = ShotPlanner.automaticCushionRoutes(explorationPass: 0)
        for rail in ShotPlanner.Rail.allCases {
            XCTAssertTrue(routes.contains { $0.objectRails == [rail] && $0.cueRails.isEmpty })
            XCTAssertTrue(routes.contains { $0.cueRails == [rail] && $0.objectRails.isEmpty })
        }
        for count in 0...4 {
            XCTAssertTrue(routes.contains { $0.objectRails.count == count && $0.cueRails.count == 4 - count })
        }
        XCTAssertTrue(routes.contains { $0.cueRails == [.left, .right, .left, .bottom] })
        XCTAssertTrue(routes.contains { $0.objectRails == [.top, .right, .bottom, .left] })
        XCTAssertTrue(routes.contains { $0.objectRails == [.top, .bottom] && $0.cueRails == [.left, .right] })
        XCTAssertTrue(routes.allSatisfy { route in
            route.objectRails.count + route.cueRails.count <= 4 &&
                !zip(route.objectRails, route.objectRails.dropFirst()).contains { $0 == $1 } &&
                !zip(route.cueRails, route.cueRails.dropFirst()).contains { $0 == $1 }
        })
        let retry = ShotPlanner.automaticCushionRoutes(explorationPass: 3)
        XCTAssertNotEqual(routes.first, retry.first)
        XCTAssertEqual(retry.first!.cueRails.count + retry.first!.objectRails.count, 4)
        XCTAssertEqual(routes.count, retry.count)
        XCTAssertTrue(routes.allSatisfy { retry.contains($0) })
    }

    func testStrongPowerIsNotPreferredWithoutImprovedSettledPosition() {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 70)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 0), pocketed: true),
            PoolBall(id: 2, position: Vector2(x: 100, y: 35))])
        let result = outcome(state)
        XCTAssertLessThan(ShotPlanner.automaticOutcomeCost(result, power: 0.2, allowed: [1, 2]),
                          ShotPlanner.automaticOutcomeCost(result, power: 1, allowed: [1, 2]))
    }

    func testClusterExitAndUsableCuePositionCanOutweighExtraPower() {
        let clear = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 70)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 0), pocketed: true),
            PoolBall(id: 2, position: Vector2(x: 100, y: 35)),
            PoolBall(id: 9, position: Vector2(x: 150, y: 50)),
            PoolBall(id: 10, position: Vector2(x: 165, y: 75))])
        var clustered = clear
        clustered.balls[3].position = Vector2(x: 105.72, y: 35)
        clustered.balls[4].position = Vector2(x: 94.28, y: 35)
        XCTAssertLessThan(ShotPlanner.automaticOutcomeCost(outcome(clear), power: 0.68, allowed: [1, 2]),
                          ShotPlanner.automaticOutcomeCost(outcome(clustered), power: 0.2, allowed: [1, 2]))
    }

    func testScratchAndUnsettledPositionsCannotWinRanking() {
        var state = TableState.straightShot
        state.balls[0].pocketed = true
        XCTAssertEqual(ShotPlanner.automaticOutcomeCost(outcome(state), power: 1, allowed: [1]), .infinity)
        let unsettled = ShotResult(finalState: .straightShot, frames: [], traces: [], events: [], duration: 30, settled: false)
        XCTAssertEqual(ShotPlanner.automaticOutcomeCost(unsettled, power: 0.2, allowed: [1]), .infinity)
    }

    func testAutomaticSearchReplansScratchProneCenterAndReplaysLegalResult() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 140.3, y: 36.86)),
            PoolBall(id: 1, position: Vector2(x: 143.91, y: 52.72))])
        let report = try ShotPlanner.search(for: state, targetID: 1, pocketID: 4,
            includeBanks: false, allowedTargetIDs: [1], now: { 0 })
        let shot = try XCTUnwrap(report.suggestions.first)
        XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 1, pocketID: 4, allowedTargetIDs: [1]))
        XCTAssertFalse(shot.result.scratched)
        let replay = try BilliardsEngine.simulate(state: state, shot: shot.shot, recordFrames: true)
        XCTAssertEqual(replay.events, shot.result.events)
        XCTAssertEqual(replay.finalState, shot.result.finalState)
        XCTAssertFalse(replay.frames.isEmpty)
    }

    func testExpandedRoutesKeepHardWorkLimitOnRepeatedPasses() throws {
        for pass in [0, 1, 2, 3, 9] {
            let report = try ShotPlanner.search(for: .practice, allowedTargetIDs: [1, 2, 3],
                budget: ShotSearchBudget(maximumDuration: 4, maximumSimulations: 3, explorationPass: pass),
                now: { 0 })
            XCTAssertLessThanOrEqual(report.simulations, 3)
            XCTAssertEqual(report.explorationPass, pass)
            for suggestion in report.suggestions {
                XCTAssertTrue(ShotPlanner.isValidOutcome(suggestion.result, targetID: suggestion.targetID,
                    pocketID: suggestion.pocketID, allowedTargetIDs: [1, 2, 3]))
            }
        }
    }

    func testThreeRailCueKickIsFoundAndExactlyReplayedWithoutScratch() throws {
        // Synthetic practice fixture generated with seed 15001013; this is not
        // a reconstruction of a device recording or a claim of native accuracy.
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 66.6201001379072, y: 39.4578694162354)),
            PoolBall(id: 1, position: Vector2(x: 61.059212611903924, y: 57.8407585940104))])
        let report = try ShotPlanner.search(for: state, targetID: 1, pocketID: 0, allowedTargetIDs: [1],
            budget: ShotSearchBudget(maximumDuration: 4, maximumSimulations: 3_000, explorationPass: 3), now: { 0 })
        let shot = try XCTUnwrap(report.suggestions.first { candidate in
            var cushions = 0
            for event in candidate.result.events {
                if case let .ballCollision(a, b) = event, a == 0 || b == 0 { break }
                if event == .cushion(ball: 0) { cushions += 1 }
            }
            return cushions >= 3
        })
        XCTAssertEqual(shot.method, .multiCushion)
        XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 1, pocketID: 0,
                                                 method: .multiCushion, allowedTargetIDs: [1]))
        let replay = try BilliardsEngine.simulate(state: state, shot: shot.shot, recordFrames: true)
        XCTAssertEqual(replay.events, shot.result.events)
        XCTAssertEqual(replay.finalState, shot.result.finalState)
        XCTAssertFalse(replay.scratched)
        XCTAssertFalse(replay.frames.isEmpty)
    }

    private func outcome(_ state: TableState) -> ShotResult {
        ShotResult(finalState: state, frames: [], traces: [], events: [.pocket(ball: 1, pocket: 1)],
                   duration: 1, settled: true)
    }
}
