import Foundation
import XCTest
@testable import PoolLabCore

final class NativePocketGeometryTests: XCTestCase {
    private struct Recorded: Decodable {
        let index: Int
        let file: String
        let state: TableState
    }

    private func state(_ index: Int) throws -> TableState {
        let fixtures = try JSONDecoder().decode([Recorded].self, from: Data(Self.recordedJSON.utf8))
        var state = try XCTUnwrap(fixtures.first { $0.index == index }).state
        state.table.nativeGeometry = try JSONDecoder().decode(NativeTableGeometry.self, from: Data(Self.geometryJSON.utf8))
        state.table.pocketRadius = state.table.ballRadius
        return state
    }

    func testRecordedBall2HitsJawInsteadOfFalsePocketAndMatchesObservedEndpoint() throws {
        let input = try state(234)
        let result = try BilliardsEngine.simulateContinuation(state: input)
        let ball = try XCTUnwrap(result.finalState.balls.first { $0.id == 2 })
        XCTAssertTrue(result.settled)
        XCTAssertFalse(ball.pocketed)
        XCTAssertTrue(result.events.contains(.cushion(ball: 2)))
        XCTAssertEqual(ball.position.x, 111.07259842519684, accuracy: 0.0001)
        XCTAssertEqual(ball.position.y, 20.38464566929134, accuracy: 0.0001)
        XCTAssertEqual(input, try state(234), "Captured positions, velocity and spin must remain unchanged.")
    }

    func testRecordedBall12ReboundsInsteadOfFalsePocket() throws {
        let result = try BilliardsEngine.simulateContinuation(state: state(184))
        XCTAssertTrue(result.settled)
        XCTAssertFalse(result.pocketedIDs.contains(12))
        XCTAssertTrue(result.events.contains(.cushion(ball: 12)))
        let ball = try XCTUnwrap(result.finalState.balls.first { $0.id == 12 })
        XCTAssertEqual(ball.position.x, 170.94740157480317, accuracy: 0.0001)
        XCTAssertEqual(ball.position.y, 84.61543307086615, accuracy: 0.0001)
    }

    func testRecordedCorrectBall5PocketRemainsPredicted() throws {
        let result = try BilliardsEngine.simulateContinuation(state: state(124))
        XCTAssertTrue(result.settled)
        XCTAssertTrue(result.events.contains(.pocket(ball: 5, pocket: 2)))
    }

    func testRecordedBall2MovingAwayFromJawIsNotRecaptured() throws {
        for index in [253, 254, 255] {
            let result = try BilliardsEngine.simulateContinuation(state: state(index))
            let ball = try XCTUnwrap(result.finalState.balls.first { $0.id == 2 })
            XCTAssertTrue(result.settled)
            XCTAssertFalse(ball.pocketed)
            XCTAssertEqual(ball.position.x, 111.07259842519684, accuracy: 0.0001)
            XCTAssertEqual(ball.position.y, 20.38464566929134, accuracy: 0.0001)
        }
    }

    func testStationaryBallNearMouthIsNotCapturedByTheAttractionCircle() throws {
        var input = try state(234)
        input.balls = [PoolBall(id: 13, position: Vector2(x: 103, y: 3))]
        let result = try BilliardsEngine.simulateContinuation(state: input)
        XCTAssertEqual(result.finalState, input)
        XCTAssertTrue(result.pocketedIDs.isEmpty)
    }

    func testCenteredSidePocketRemainsOpenThroughNativeCushionBoundary() throws {
        var input = try state(234)
        input.balls = [PoolBall(id: 2, position: Vector2(x: 100, y: 20), velocity: Vector2(x: 0, y: -45))]
        let result = try BilliardsEngine.simulateContinuation(state: input)
        XCTAssertTrue(result.settled)
        XCTAssertEqual(result.pocketedIDs, [2])
        XCTAssertFalse(result.events.contains(.cushion(ball: 2)))
    }

    func testGuideAndSimulationUseSameNativeJawContact() throws {
        var input = try state(234)
        let target = try XCTUnwrap(input.balls.first { $0.id == 2 })
        input.balls = [PoolBall(id: 0, position: target.position)]
        let direction = Vector2(x: -0.528533, y: -0.848913)
        let point = try XCTUnwrap(BilliardsEngine.firstContactPoint(state: input, direction: direction))
        let pocket = input.table.pockets[1]
        XCTAssertGreaterThan(point.distance(to: pocket.center), pocket.radius)
        let result = try BilliardsEngine.simulate(state: input,
            shot: ShotParameters(angleRadians: atan2(direction.y, direction.x), power: 0.4))
        XCTAssertEqual(result.events.first, .cushion(ball: 0))
    }

    func testNativeBoundaryRecordingDoesNotAlterPhysics() throws {
        let input = try state(184)
        let recorded = try BilliardsEngine.simulateContinuation(state: input, recordFrames: true)
        let compact = try BilliardsEngine.simulateContinuation(state: input, recordFrames: false)
        XCTAssertEqual(recorded.events, compact.events)
        XCTAssertEqual(recorded.finalState, compact.finalState)
        XCTAssertEqual(recorded.duration, compact.duration)
        XCTAssertTrue(recorded.settled && compact.settled)
    }

    func testNativeGeometryRejectsInvalidRadiiVerticesAndForce() throws {
        var input = try state(234)
        input.table.nativeGeometry!.pocketAttraction = .nan
        XCTAssertThrowsError(try BilliardsEngine.validateContinuation(input))
        input = try state(234)
        input.table.nativeGeometry!.cushionVertices[1] = input.table.nativeGeometry!.cushionVertices[0]
        XCTAssertThrowsError(try BilliardsEngine.validateContinuation(input))
        input = try state(234)
        input.table.nativeGeometry!.pockets[0].attractionRadius = input.table.ballRadius * 0.5
        XCTAssertThrowsError(try BilliardsEngine.validateContinuation(input))
        input = try state(234)
        input.table.nativeGeometry!.cushionVertices[0].x = .infinity
        XCTAssertThrowsError(try BilliardsEngine.validateContinuation(input))
    }

    func testNativeGeometrySurvivesValueCodingRoundTrip() throws {
        let input = try state(234)
        let decoded = try JSONDecoder().decode(TableState.self, from: JSONEncoder().encode(input))
        XCTAssertEqual(decoded, input)
        XCTAssertEqual(try XCTUnwrap(decoded.table.nativeGeometry?.pockets[1].radius), input.table.ballRadius, accuracy: 1e-12)
        XCTAssertEqual(decoded.table.nativeGeometry?.pocketAttraction, 120)
    }

    // The V9 logs did not include table-shape identity. The exact Narrow
    // profile below is inferred by replay: it preserves the observed ball-5
    // pocket and ball-2 jaw rebound. Standard and NarrowTight were also tested
    // and do not reproduce both controls. Runtime uses the live native shape.
    // Source binaries and capture hashes are in V10PredictionAudit.json.
    private static let geometryJSON = #"""
{"cushionVertices":[{"x":0.0,"y":7.874015748031496},{"x":-7.795275590551186,"y":-0.4724409448818853},{"x":-8.818897637795267,"y":-4.488188976377955},{"x":-7.637795275590543,"y":-7.637795275590554},{"x":-4.488188976377944,"y":-8.818897637795278},{"x":-0.4724409448818853,"y":-7.795275590551186},{"x":7.874015748031496,"y":0.0},{"x":93.85826771653544,"y":0.0},{"x":95.1968503937008,"y":-4.0157480314960585},{"x":95.51181102362204,"y":-7.244094488188979},{"x":97.08661417322836,"y":-9.370078740157485},{"x":100.0,"y":-10.393700787401578},{"x":102.91338582677164,"y":-9.370078740157485},{"x":104.48818897637796,"y":-7.244094488188979},{"x":104.80314960629921,"y":-4.0157480314960585},{"x":106.14173228346458,"y":0.0},{"x":192.1259842519685,"y":0.0},{"x":200.4724409448819,"y":-7.795275590551186},{"x":204.48818897637796,"y":-8.818897637795278},{"x":207.63779527559055,"y":-7.637795275590554},{"x":208.8188976377953,"y":-4.488188976377955},{"x":207.79527559055117,"y":-0.4724409448818853},{"x":200.0,"y":7.874015748031496},{"x":200.0,"y":92.1259842519685},{"x":207.79527559055117,"y":100.4724409448819},{"x":208.8188976377953,"y":104.48818897637796},{"x":207.63779527559055,"y":107.63779527559055},{"x":204.48818897637796,"y":108.81889763779527},{"x":200.4724409448819,"y":107.79527559055119},{"x":192.1259842519685,"y":100.0},{"x":106.14173228346458,"y":100.0},{"x":104.80314960629921,"y":104.01574803149606},{"x":104.48818897637796,"y":107.24409448818898},{"x":102.91338582677164,"y":109.3700787401575},{"x":100.0,"y":110.39370078740157},{"x":97.08661417322836,"y":109.3700787401575},{"x":95.51181102362204,"y":107.24409448818898},{"x":95.1968503937008,"y":104.01574803149606},{"x":93.85826771653544,"y":100.0},{"x":7.874015748031496,"y":100.0},{"x":-0.4724409448818853,"y":107.79527559055119},{"x":-4.488188976377944,"y":108.81889763779527},{"x":-7.637795275590543,"y":107.63779527559055},{"x":-8.818897637795267,"y":104.48818897637796},{"x":-7.795275590551186,"y":100.4724409448819},{"x":0.0,"y":92.1259842519685}],"pockets":[{"id":0,"center":{"x":-2.992125984251978,"y":-2.9921259842519663},"aimPoint":{"x":1.4620899602302142,"y":1.4620899602302253},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":1,"center":{"x":100.0,"y":-6.692913385826772},"aimPoint":{"x":100.0,"y":-0.3937007874015748},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":2,"center":{"x":202.992125984252,"y":-2.9921259842519663},"aimPoint":{"x":198.5379100397698,"y":1.4620899602302253},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":3,"center":{"x":-2.992125984251978,"y":102.99212598425198},"aimPoint":{"x":1.4620899602302142,"y":98.53791003976978},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":4,"center":{"x":100.0,"y":106.69291338582678},"aimPoint":{"x":100.0,"y":100.39370078740158},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":5,"center":{"x":202.992125984252,"y":102.99212598425198},"aimPoint":{"x":198.5379100397698,"y":98.53791003976978},"radius":2.9925,"attractionRadius":6.299212598425197}],"pocketAttraction":120.0}
"""#
    private static let recordedJSON = #"""
[{"index":184,"file":"Narrow:SDKPool-V9-D4399EB1-F90C-4093-A99D-37FD9DC2FEA3.json","state":{"table":{"width":200,"height":100.0,"ballRadius":2.9925,"pocketRadius":2.9925,"ballRestitution":1,"cushionRestitution":0.804,"rollingDeceleration":8.565354330708661,"maximumShotSpeed":652.6377760519193,"nativeDynamics":{"cushionSpinCoupling":0.54,"equilibriumTimeFactor":0.0018513119533527696,"logicalFrameTime":0.005,"slidingDeceleration":154.33070866141733,"slidingFrictionCoefficient":0.2,"spinDeceleration":9.8}},"balls":[{"id":0,"position":{"x":188.2751506635707,"y":62.01310240706673},"velocity":{"x":-0.8800339223981664,"y":0.8101141125327246},"spin":{"x":0.27071482457233903,"y":0.29407984040038976,"z":0},"pocketed":false},{"id":4,"position":{"x":7.207637795275591,"y":51.32803149606299},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":7,"position":{"x":179.72090946663155,"y":77.16208619259379},"velocity":{"x":-332.28864722448833,"y":-233.53792793187742},"spin":{"x":2.6869156683728,"y":70.54122863083188,"z":-24.16710980038021},"pocketed":false},{"id":8,"position":{"x":196.42925206714486,"y":88.46925908800416},"velocity":{"x":193.43641866775926,"y":-1.3308412018266524},"spin":{"x":-87.51775247813069,"y":-4.930735715267651,"z":-24.19813340441763},"pocketed":false},{"id":10,"position":{"x":45.42952755905512,"y":54.121968503937005},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":12,"position":{"x":174.76542614805228,"y":70.26973433067967},"velocity":{"x":-205.5479616727277,"y":-110.24326491336278},"spin":{"x":-3.351655460549005,"y":6.24914318971344,"z":0},"pocketed":false},{"id":15,"position":{"x":4.916220472440946,"y":67.72094488188976},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false}]}},{"index":124,"file":"Narrow:SDKPool-V9-9F24C87F-7801-4CAB-A351-841B304FEAB8.json","state":{"table":{"width":200,"height":100.0,"ballRadius":2.9925,"pocketRadius":2.9925,"ballRestitution":1,"cushionRestitution":0.804,"rollingDeceleration":8.565354330708661,"maximumShotSpeed":652.6377760519193,"nativeDynamics":{"cushionSpinCoupling":0.54,"equilibriumTimeFactor":0.0018513119533527696,"logicalFrameTime":0.005,"slidingDeceleration":154.33070866141733,"slidingFrictionCoefficient":0.2,"spinDeceleration":9.8}},"balls":[{"id":0,"position":{"x":37.63999425097004,"y":36.247702796354375},"velocity":{"x":215.68488852371442,"y":2.566906864118615},"spin":{"x":0.03068653373245646,"y":-2.578442443620437,"z":0},"pocketed":false},{"id":1,"position":{"x":40.54133858267716,"y":6.14291338582677},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":2,"position":{"x":144.20015748031497,"y":80.55551181102362},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":3,"position":{"x":155.67637795275593,"y":7.917086614173226},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":4,"position":{"x":168.8511811023622,"y":94.21377952755905},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":5,"position":{"x":126.65834645669293,"y":34.90133858267717},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":7,"position":{"x":153.91622047244095,"y":62.69724409448819},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":8,"position":{"x":196.10874015748033,"y":75.78606299212599},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":9,"position":{"x":30.864566929133854,"y":94.65590551181103},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":10,"position":{"x":149.58905511811022,"y":51.11346456692914},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":11,"position":{"x":190.97425196850395,"y":85.76629921259844},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":12,"position":{"x":40.03842519685039,"y":91.76527559055118},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":14,"position":{"x":182.72173228346458,"y":3.6853543307086607},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":15,"position":{"x":4.916220472440946,"y":67.72094488188976},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false}]}},{"index":234,"file":"Narrow:SDKPool-V9-9F24C87F-7801-4CAB-A351-841B304FEAB8.json","state":{"table":{"width":200,"height":100.0,"ballRadius":2.9924999999999997,"pocketRadius":2.9924999999999997,"ballRestitution":1,"cushionRestitution":0.804,"rollingDeceleration":8.565354330708661,"maximumShotSpeed":652.6377760519193,"nativeDynamics":{"cushionSpinCoupling":0.54,"equilibriumTimeFactor":0.0018513119533527696,"logicalFrameTime":0.005,"slidingDeceleration":154.33070866141733,"slidingFrictionCoefficient":0.2,"spinDeceleration":9.8}},"balls":[{"id":0,"position":{"x":156.48937219664364,"y":91.34628342800364},"velocity":{"x":-89.38063097408731,"y":-55.92483976484124},"spin":{"x":-4.787152331239101,"y":7.650959711899295,"z":0},"pocketed":false},{"id":1,"position":{"x":40.54133858267716,"y":6.14291338582677},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":2,"position":{"x":144.20015748031497,"y":80.55551181102362},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":3,"position":{"x":155.67637795275593,"y":7.917086614173226},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":4,"position":{"x":172.0151968503937,"y":94.84251968503938},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":7,"position":{"x":186.61039370078743,"y":70.65787401574804},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":8,"position":{"x":194.9140157480315,"y":83.31015748031497},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":9,"position":{"x":30.864566929133854,"y":94.65590551181103},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":10,"position":{"x":149.58905511811022,"y":51.11346456692914},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":11,"position":{"x":186.47141732283467,"y":91.81889763779527},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":12,"position":{"x":40.03842519685039,"y":91.76527559055118},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":14,"position":{"x":182.72173228346458,"y":3.6853543307086607},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":15,"position":{"x":4.916220472440946,"y":67.72094488188976},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false}]}},{"index":253,"file":"Narrow:SDKPool-V9-9F24C87F-7801-4CAB-A351-841B304FEAB8.json","state":{"table":{"width":200,"height":100.0,"ballRadius":2.9924999999999997,"pocketRadius":2.9924999999999997,"ballRestitution":1,"cushionRestitution":0.804,"rollingDeceleration":8.565354330708661,"maximumShotSpeed":652.6377760519193,"nativeDynamics":{"cushionSpinCoupling":0.54,"equilibriumTimeFactor":0.0018513119533527696,"logicalFrameTime":0.005,"slidingDeceleration":154.33070866141733,"slidingFrictionCoefficient":0.2,"spinDeceleration":9.8}},"balls":[{"id":0,"position":{"x":86.66096029512113,"y":92.8991474345358},"velocity":{"x":-25.870160609255073,"y":2.655774587777861},"spin":{"x":0.8874768881463195,"y":8.64499936817212,"z":0},"pocketed":false},{"id":1,"position":{"x":40.54133858267716,"y":6.14291338582677},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":2,"position":{"x":96.06215929266473,"y":3.0712139216675265},"velocity":{"x":18.99304207658869,"y":23.786765882565142},"spin":{"x":-3.1455122454697353,"y":1.2992647294052149,"z":-0.514474296731154},"pocketed":false},{"id":3,"position":{"x":155.67637795275593,"y":7.917086614173226},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":4,"position":{"x":172.0151968503937,"y":94.84251968503938},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":7,"position":{"x":186.61039370078743,"y":70.65787401574804},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":8,"position":{"x":194.9140157480315,"y":83.31015748031497},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":9,"position":{"x":30.864566929133854,"y":94.65590551181103},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":10,"position":{"x":149.58905511811022,"y":51.11346456692914},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":11,"position":{"x":186.47141732283467,"y":91.81889763779527},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":12,"position":{"x":40.03842519685039,"y":91.76527559055118},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":14,"position":{"x":182.72173228346458,"y":3.6853543307086607},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":15,"position":{"x":4.916220472440946,"y":67.72094488188976},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false}]}},{"index":254,"file":"Narrow:SDKPool-V9-9F24C87F-7801-4CAB-A351-841B304FEAB8.json","state":{"table":{"width":200,"height":100.0,"ballRadius":2.9924999999999997,"pocketRadius":2.9924999999999997,"ballRestitution":1,"cushionRestitution":0.804,"rollingDeceleration":8.565354330708661,"maximumShotSpeed":652.6377760519193,"nativeDynamics":{"cushionSpinCoupling":0.54,"equilibriumTimeFactor":0.0018513119533527696,"logicalFrameTime":0.005,"slidingDeceleration":154.33070866141733,"slidingFrictionCoefficient":0.2,"spinDeceleration":9.8}},"balls":[{"id":0,"position":{"x":84.11441696263923,"y":93.16057005077813},"velocity":{"x":-25.01810316833714,"y":2.568304218610254},"spin":{"x":0.8582470237628249,"y":8.360268393763455,"z":0},"pocketed":false},{"id":1,"position":{"x":40.54133858267716,"y":6.14291338582677},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":2,"position":{"x":97.56667603638584,"y":4.87750779645401},"velocity":{"x":12.312960306469574,"y":14.137374046109157},"spin":{"x":4.724268687087437,"y":-4.114606618703283,"z":0},"pocketed":false},{"id":3,"position":{"x":155.67637795275593,"y":7.917086614173226},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":4,"position":{"x":172.0151968503937,"y":94.84251968503938},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":7,"position":{"x":186.61039370078743,"y":70.65787401574804},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":8,"position":{"x":194.9140157480315,"y":83.31015748031497},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":9,"position":{"x":30.864566929133854,"y":94.65590551181103},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":10,"position":{"x":149.58905511811022,"y":51.11346456692914},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":11,"position":{"x":186.47141732283467,"y":91.81889763779527},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":12,"position":{"x":40.03842519685039,"y":91.76527559055118},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":14,"position":{"x":182.72173228346458,"y":3.6853543307086607},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":15,"position":{"x":4.916220472440946,"y":67.72094488188976},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false}]}},{"index":255,"file":"Narrow:SDKPool-V9-9F24C87F-7801-4CAB-A351-841B304FEAB8.json","state":{"table":{"width":200,"height":100.0,"ballRadius":2.9924999999999997,"pocketRadius":2.9924999999999997,"ballRestitution":1,"cushionRestitution":0.804,"rollingDeceleration":8.565354330708661,"maximumShotSpeed":652.6377760519193,"nativeDynamics":{"cushionSpinCoupling":0.54,"equilibriumTimeFactor":0.0018513119533527696,"logicalFrameTime":0.005,"slidingDeceleration":154.33070866141733,"slidingFrictionCoefficient":0.2,"spinDeceleration":9.8}},"balls":[{"id":0,"position":{"x":81.65307937424912,"y":93.4132456301037},"velocity":{"x":-24.166045727419238,"y":2.480833849442646},"spin":{"x":0.8290171593793304,"y":8.0755374193548,"z":0},"pocketed":false},{"id":1,"position":{"x":40.54133858267716,"y":6.14291338582677},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":2,"position":{"x":98.77125094977934,"y":6.2605648106356835},"velocity":{"x":11.750410469554502,"y":13.491471089704152},"spin":{"x":4.508428100151763,"y":-3.926620039951379,"z":0},"pocketed":false},{"id":3,"position":{"x":155.67637795275593,"y":7.917086614173226},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":4,"position":{"x":172.0151968503937,"y":94.84251968503938},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":7,"position":{"x":186.61039370078743,"y":70.65787401574804},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":8,"position":{"x":194.9140157480315,"y":83.31015748031497},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":9,"position":{"x":30.864566929133854,"y":94.65590551181103},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":10,"position":{"x":149.58905511811022,"y":51.11346456692914},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":11,"position":{"x":186.47141732283467,"y":91.81889763779527},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":12,"position":{"x":40.03842519685039,"y":91.76527559055118},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":14,"position":{"x":182.72173228346458,"y":3.6853543307086607},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false},{"id":15,"position":{"x":4.916220472440946,"y":67.72094488188976},"velocity":{"x":0,"y":0},"spin":{"x":0,"y":0,"z":0},"pocketed":false}]}}]
"""#
}
