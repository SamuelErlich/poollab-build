import Foundation
import XCTest
@testable import PoolLabCore

final class V13PlannerTests: XCTestCase {
    private var bankOnlyPosition: TableState {
        TableState(balls: [PoolBall(id: 0, position: Vector2(x: 100, y: 70)),
                           PoolBall(id: 1, position: Vector2(x: 70, y: 30))])
    }

    func testExpandedSearchFindsBothRealKickAndDoubleBankWhenDirectRouteFails() throws {
        let state = bankOnlyPosition
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1,
                                                 includeBanks: false, allowedTargetIDs: [1]).isEmpty)
        let shots = try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, limit: 24,
                                               allowedTargetIDs: [1])
        XCTAssertTrue(shots.contains { $0.method == .kick })
        XCTAssertTrue(shots.contains { $0.method == .doubleBank })
        for shot in shots {
            XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 1, pocketID: 1,
                                                     method: shot.method, allowedTargetIDs: [1]))
            let replay = try BilliardsEngine.simulate(state: state, shot: shot.shot, recordFrames: true)
            XCTAssertEqual(replay.finalState, shot.result.finalState)
            XCTAssertEqual(replay.events, shot.result.events)
            XCTAssertFalse(replay.scratched)
            XCTAssertFalse(replay.traces.isEmpty)
        }
        XCTAssertEqual(state, bankOnlyPosition)
    }

    func testExpandedSearchDoesNotBroadenAllowedTargets() throws {
        XCTAssertTrue(try ShotPlanner.suggestions(for: bankOnlyPosition, pocketID: 1,
                                                 allowedTargetIDs: [9]).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: bankOnlyPosition, pocketID: 1,
                                                 allowedTargetIDs: []).isEmpty)
        let first = try ShotPlanner.suggestions(for: bankOnlyPosition, pocketID: 1, limit: 24,
                                               allowedTargetIDs: [1])
        let second = try ShotPlanner.suggestions(for: bankOnlyPosition, pocketID: 1, limit: 24,
                                                allowedTargetIDs: [1])
        XCTAssertEqual(first.map(\.id), second.map(\.id))
        XCTAssertEqual(first.map(\.score), first.map(\.score).sorted())
    }

    func testNativeCommandsAreQuantizedInBridgeDomainAndIdempotent() throws {
        let table = try nativeTable()
        let angles = [-8 * Double.pi, -2 * Double.pi, -0.000049, -0.000051, -0.7,
                      0, 0.000001, 0.000049, 0.000051, 0.7, 2 * Double.pi - 0.000001,
                      2 * Double.pi + 0.000001, 8 * Double.pi + 0.7]
        for angle in angles {
            for power in [0.02, 0.07125, 0.229, 0.5, 0.997, 1.0] {
                let shot = try ShotPlanner.executableShot(angle: angle, power: power,
                                                         minimumPower: 0, table: table)
                var native = (-shot.angleRadians).truncatingRemainder(dividingBy: 2 * .pi)
                if native < 0 { native += 2 * .pi }
                let committed = (native * 10_000).rounded() / 10_000
                XCTAssertEqual(-committed, shot.angleRadians, accuracy: 1e-12)
                let control = try GameShotCalibration.controlPower(fromSimulationPower: shot.power)
                XCTAssertEqual(control * 10_000, (control * 10_000).rounded(), accuracy: 1e-8)
                let repeated = try ShotPlanner.executableShot(angle: shot.angleRadians, power: shot.power,
                                                             minimumPower: 0, table: table)
                XCTAssertEqual(repeated, shot)
                XCTAssertLessThanOrEqual(abs(remainder(shot.angleRadians - angle, 2 * .pi)), 0.000065)
            }
        }
    }

    func testNativeMinimumIsRoundedUpBeforeSimulation() throws {
        var state = TableState.straightShot
        state.table = try nativeTable()
        for control in [0.1, 0.30001, 0.4] {
            let minimum = try GameShotCalibration.simulationPower(fromControlPower: control)
            let shots = try ShotPlanner.suggestions(for: state, pocketID: 1, includeBanks: false,
                                                   allowedTargetIDs: [1], minimumPower: minimum)
            XCTAssertFalse(shots.isEmpty)
            for shot in shots {
                let controlPower = try GameShotCalibration.controlPower(fromSimulationPower: shot.shot.power)
                XCTAssertGreaterThanOrEqual(controlPower + 1e-12, control)
                let committedPower = try GameShotCalibration.simulationPower(
                    fromControlPower: (controlPower * 10_000).rounded() / 10_000)
                let replay = try BilliardsEngine.simulate(state: state,
                    shot: ShotParameters(angleRadians: shot.shot.angleRadians, power: committedPower), recordFrames: false)
                XCTAssertEqual(replay.finalState, shot.result.finalState)
                XCTAssertEqual(replay.events, shot.result.events)
            }
        }
    }

    func testNativeRealGeometryDoubleBankIsVerifiedAndReplaysExactCommand() throws {
        let state = TableState(table: try nativeTable(), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 70)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 35))])
        let shots = try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 2, limit: 24,
                                               allowedTargetIDs: [1])
        let bank = try XCTUnwrap(shots.first { $0.method == .doubleBank })
        XCTAssertTrue(ShotPlanner.isValidOutcome(bank.result, targetID: 1, pocketID: 2,
                                                 method: .doubleBank, allowedTargetIDs: [1]))
        let replay = try BilliardsEngine.simulate(state: state, shot: bank.shot, recordFrames: true)
        XCTAssertEqual(replay.finalState, bank.result.finalState)
        XCTAssertEqual(replay.events, bank.result.events)
        XCTAssertFalse(replay.scratched)
    }

    func testNativeRealGeometryKickIsVerifiedAndReplaysExactCommand() throws {
        let state = TableState(table: try nativeTable(), balls: [
            PoolBall(id: 0, position: Vector2(x: 30, y: 50)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 35))])
        let shots = try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 3, limit: 24,
                                               allowedTargetIDs: [1])
        let kick = try XCTUnwrap(shots.first { $0.method == .kick })
        XCTAssertTrue(ShotPlanner.isValidOutcome(kick.result, targetID: 1, pocketID: 3,
                                                 method: .kick, allowedTargetIDs: [1]))
        let replay = try BilliardsEngine.simulate(state: state, shot: kick.shot, recordFrames: true)
        XCTAssertEqual(replay.finalState, kick.result.finalState)
        XCTAssertEqual(replay.events, kick.result.events)
        XCTAssertFalse(replay.scratched)
    }

    func testMethodRejectsWrongCushionCountsAndWrongFirstContact() {
        let contact = ShotEvent.ballCollision(first: 0, second: 1)
        let pot = ShotEvent.pocket(ball: 1, pocket: 1)
        let kick = outcome([.cushion(ball: 0), contact, pot])
        XCTAssertTrue(ShotPlanner.isValidOutcome(kick, targetID: 1, pocketID: 1, method: .kick))
        XCTAssertFalse(ShotPlanner.isValidOutcome(kick, targetID: 1, pocketID: 1, method: .direct))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome([contact, .cushion(ball: 0), pot]),
                                                 targetID: 1, pocketID: 1, method: .kick))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome([.cushion(ball: 0), .cushion(ball: 0), contact, pot]),
                                                 targetID: 1, pocketID: 1, method: .kick))
        let bank = outcome([contact, .cushion(ball: 1), .cushion(ball: 1), pot])
        XCTAssertTrue(ShotPlanner.isValidOutcome(bank, targetID: 1, pocketID: 1, method: .doubleBank))
        XCTAssertFalse(ShotPlanner.isValidOutcome(bank, targetID: 1, pocketID: 1, method: .bank))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome([contact, .cushion(ball: 1), pot]),
                                                 targetID: 1, pocketID: 1, method: .doubleBank))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome([.cushion(ball: 0), .ballCollision(first: 0, second: 9), contact, pot]),
                                                 targetID: 1, pocketID: 1, method: .kick, allowedTargetIDs: [1]))
    }

    func testNewMethodsCannotAcceptScratchOrEarlyBlack() {
        let events: [ShotEvent] = [.cushion(ball: 0), .ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1)]
        let scratch = outcome(events + [.pocket(ball: 0, pocket: 2)], cuePocketed: true)
        XCTAssertFalse(ShotPlanner.isValidOutcome(scratch, targetID: 1, pocketID: 1, method: .kick, allowedTargetIDs: [1]))
        let black = outcome(events + [.pocket(ball: 8, pocket: 2)], blackPocketed: true)
        XCTAssertFalse(ShotPlanner.isValidOutcome(black, targetID: 1, pocketID: 1, method: .kick, allowedTargetIDs: [1]))
    }

    func testNativeStraightShotUsesVerifiedGentlePower() throws {
        var state = TableState.straightShot
        state.table = try nativeTable()
        let shot = try XCTUnwrap(ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1,
                                                        includeBanks: false, allowedTargetIDs: [1]).first)
        XCTAssertLessThan(shot.shot.power, 0.15)
        XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 1, pocketID: 1,
                                                 method: .direct, allowedTargetIDs: [1]))
        let control = try GameShotCalibration.controlPower(fromSimulationPower: shot.shot.power)
        XCTAssertLessThan(control, 0.3)
    }

    private func outcome(_ events: [ShotEvent], cuePocketed: Bool = false, blackPocketed: Bool = false) -> ShotResult {
        var balls = [PoolBall(id: 0, position: Vector2(x: 100, y: 70), pocketed: cuePocketed),
                     PoolBall(id: 1, position: Vector2(x: 100, y: 0), pocketed: true)]
        if blackPocketed { balls.append(PoolBall(id: 8, position: Vector2(x: 200, y: 0), pocketed: true)) }
        return ShotResult(finalState: TableState(balls: balls), frames: [], traces: [], events: events,
                          duration: 1, settled: true)
    }

    private func nativeTable() throws -> PoolTable {
        // Native coefficients/46-vertex pocket geometry from the unchanged V10
        // recorded fixture, paired with explicit synthetic stationary layouts.
        var table = PoolTable()
        table.ballRadius = 2.9925
        table.pocketRadius = table.ballRadius
        table.ballRestitution = 1
        table.cushionRestitution = 0.804
        table.rollingDeceleration = 8.565354330708661
        table.maximumShotSpeed = 652.6377760519193
        table.nativeDynamics = NativeDynamics(slidingDeceleration: 154.33070866141733,
            equilibriumTimeFactor: 0.0018513119533527696, spinDeceleration: 9.8,
            slidingFrictionCoefficient: 0.2, cushionSpinCoupling: 0.54, logicalFrameTime: 0.005)
        table.nativeGeometry = try JSONDecoder().decode(NativeTableGeometry.self, from: Data(Self.geometryJSON.utf8))
        return table
    }
    private static let geometryJSON = """
{"cushionVertices":[{"x":0.0,"y":7.874015748031496},{"x":-7.795275590551186,"y":-0.4724409448818853},{"x":-8.818897637795267,"y":-4.488188976377955},{"x":-7.637795275590543,"y":-7.637795275590554},{"x":-4.488188976377944,"y":-8.818897637795278},{"x":-0.4724409448818853,"y":-7.795275590551186},{"x":7.874015748031496,"y":0.0},{"x":93.85826771653544,"y":0.0},{"x":95.1968503937008,"y":-4.0157480314960585},{"x":95.51181102362204,"y":-7.244094488188979},{"x":97.08661417322836,"y":-9.370078740157485},{"x":100.0,"y":-10.393700787401578},{"x":102.91338582677164,"y":-9.370078740157485},{"x":104.48818897637796,"y":-7.244094488188979},{"x":104.80314960629921,"y":-4.0157480314960585},{"x":106.14173228346458,"y":0.0},{"x":192.1259842519685,"y":0.0},{"x":200.4724409448819,"y":-7.795275590551186},{"x":204.48818897637796,"y":-8.818897637795278},{"x":207.63779527559055,"y":-7.637795275590554},{"x":208.8188976377953,"y":-4.488188976377955},{"x":207.79527559055117,"y":-0.4724409448818853},{"x":200.0,"y":7.874015748031496},{"x":200.0,"y":92.1259842519685},{"x":207.79527559055117,"y":100.4724409448819},{"x":208.8188976377953,"y":104.48818897637796},{"x":207.63779527559055,"y":107.63779527559055},{"x":204.48818897637796,"y":108.81889763779527},{"x":200.4724409448819,"y":107.79527559055119},{"x":192.1259842519685,"y":100.0},{"x":106.14173228346458,"y":100.0},{"x":104.80314960629921,"y":104.01574803149606},{"x":104.48818897637796,"y":107.24409448818898},{"x":102.91338582677164,"y":109.3700787401575},{"x":100.0,"y":110.39370078740157},{"x":97.08661417322836,"y":109.3700787401575},{"x":95.51181102362204,"y":107.24409448818898},{"x":95.1968503937008,"y":104.01574803149606},{"x":93.85826771653544,"y":100.0},{"x":7.874015748031496,"y":100.0},{"x":-0.4724409448818853,"y":107.79527559055119},{"x":-4.488188976377944,"y":108.81889763779527},{"x":-7.637795275590543,"y":107.63779527559055},{"x":-8.818897637795267,"y":104.48818897637796},{"x":-7.795275590551186,"y":100.4724409448819},{"x":0.0,"y":92.1259842519685}],"pockets":[{"id":0,"center":{"x":-2.992125984251978,"y":-2.9921259842519663},"aimPoint":{"x":1.4620899602302142,"y":1.4620899602302253},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":1,"center":{"x":100.0,"y":-6.692913385826772},"aimPoint":{"x":100.0,"y":-0.3937007874015748},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":2,"center":{"x":202.992125984252,"y":-2.9921259842519663},"aimPoint":{"x":198.5379100397698,"y":1.4620899602302253},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":3,"center":{"x":-2.992125984251978,"y":102.99212598425198},"aimPoint":{"x":1.4620899602302142,"y":98.53791003976978},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":4,"center":{"x":100.0,"y":106.69291338582678},"aimPoint":{"x":100.0,"y":100.39370078740158},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":5,"center":{"x":202.992125984252,"y":102.99212598425198},"aimPoint":{"x":198.5379100397698,"y":98.53791003976978},"radius":2.9925,"attractionRadius":6.299212598425197}],"pocketAttraction":120.0}
"""
}
