import XCTest
@testable import PoolLabCore

final class TableStateCodecTests: XCTestCase {
    func testRoundTripIncludesTunablePhysics() throws {
        var state = TableState.practice
        state.table.cushionRestitution = 0.9
        XCTAssertEqual(try TableStateCodec.decode(TableStateCodec.encode(state)), state)
    }

    func testRoundTripPocketedCueCanBeRepositionedLater() throws {
        var state = TableState.straightShot
        state.balls[0].pocketed = true
        XCTAssertEqual(try TableStateCodec.decode(TableStateCodec.encode(state)), state)
    }

    func testRejectsOversizedBeforeParsing() {
        XCTAssertThrowsError(try TableStateCodec.decode(Data(repeating: 32, count: 65_537))) {
            XCTAssertEqual($0 as? TableStateCodec.CodecError, .oversized)
        }
    }

    func testRejectsUnsupportedSchema() throws {
        let data = try TableStateCodec.encode(.practice)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        object["version"] = 99
        XCTAssertThrowsError(try TableStateCodec.decode(JSONSerialization.data(withJSONObject: object))) {
            XCTAssertEqual($0 as? TableStateCodec.CodecError, .unsupportedFormat)
        }
    }

    func testRejectsDuplicatedBallNumbersOnImport() throws {
        let data = try TableStateCodec.encode(.practice)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        var state = try XCTUnwrap(object["state"] as? [String: Any])
        var balls = try XCTUnwrap(state["balls"] as? [[String: Any]])
        balls[1]["id"] = 0
        state["balls"] = balls
        object["state"] = state
        XCTAssertThrowsError(try TableStateCodec.decode(JSONSerialization.data(withJSONObject: object))) {
            XCTAssertEqual($0 as? BilliardsError, .invalidBalls)
        }
    }

    func testRejectsNonFiniteAndMovingScene() {
        var state = TableState.practice
        state.balls[0].position.x = .infinity
        XCTAssertThrowsError(try TableStateCodec.encode(state))
        state = .practice
        state.balls[0].velocity.x = 10
        XCTAssertThrowsError(try TableStateCodec.encode(state))
    }
}
