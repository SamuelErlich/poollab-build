import XCTest
@testable import PoolLabCore

final class ShotPlannerTests: XCTestCase {
    func testStraightShotFindsVerifiedDirectShotForSelectedPocket() throws {
        let suggestions = try ShotPlanner.suggestions(for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false)
        let shot = try XCTUnwrap(suggestions.first)
        XCTAssertEqual(shot.targetID, 1)
        XCTAssertEqual(shot.pocketID, 1)
        XCTAssertEqual(shot.method, .direct)
        XCTAssertEqual(shot.shot.angleRadians, -.pi / 2, accuracy: 1e-10)
        // Preserve the valid center direction while refining below V12's first
        // coarse accepted power. The exact gentler result is replayed below.
        XCTAssertLessThan(shot.shot.power, 0.2295047641254748)
        XCTAssertGreaterThan(shot.shot.power, 0)
        XCTAssertEqual(shot.ghostBall.x, 100, accuracy: 1e-10)
        XCTAssertEqual(shot.ghostBall.y, 40.7, accuracy: 1e-10)
        XCTAssertTrue(shot.result.settled)
        XCTAssertFalse(shot.result.scratched)
        XCTAssertTrue(shot.result.events.contains(.pocket(ball: 1, pocket: 1)))
        XCTAssertTrue(shot.result.frames.isEmpty)
        XCTAssertTrue(shot.result.traces.isEmpty)
    }

    func testAngularRefinementFindsLegalPotWhereEveryCenterPowerScratches() throws {
        let state = angularNearMiss
        let original = state
        let centerAngle = 1.000782773810062
        // Original coarse power probes for this fixed physical layout, after
        // clamping and deduplication. Every center shot pots the cue ball.
        let centerPowers = [0.45, 0.68, 0.8273651007342051, 0.9, 0.9352822877864928, 1.0]
        for power in centerPowers {
            let center = try BilliardsEngine.simulate(state: state,
                shot: ShotParameters(angleRadians: centerAngle, power: power), recordFrames: false)
            XCTAssertTrue(center.scratched)
            XCTAssertFalse(ShotPlanner.isValidOutcome(center, targetID: 1, pocketID: 4,
                                                      method: .direct, allowedTargetIDs: [1]))
        }

        let suggestion = try XCTUnwrap(ShotPlanner.suggestions(for: state,
            targetID: 1, pocketID: 4, includeBanks: false, allowedTargetIDs: [1]).first)
        XCTAssertEqual(suggestion.shot.angleRadians, centerAngle + 0.0025, accuracy: 1e-12)
        XCTAssertLessThan(suggestion.shot.power, 0.9)
        XCTAssertGreaterThan(suggestion.shot.power, 0)
        XCTAssertTrue(ShotPlanner.isValidOutcome(suggestion.result, targetID: 1, pocketID: 4,
                                               method: .direct, allowedTargetIDs: [1]))
        XCTAssertFalse(suggestion.result.scratched)
        XCTAssertEqual(state, original)

        // Replaying the exact selected angle and power must preserve the
        // validated result when trajectory recording is enabled for the UI.
        let replay = try BilliardsEngine.simulate(state: state, shot: suggestion.shot, recordFrames: true)
        XCTAssertEqual(replay.finalState, suggestion.result.finalState)
        XCTAssertEqual(replay.events, suggestion.result.events)
        XCTAssertEqual(replay.duration, suggestion.result.duration)
        XCTAssertFalse(replay.frames.isEmpty)
    }

    func testRefinedGhostMarkerMatchesReturnedRayAndObjectContactCircle() throws {
        let state = angularNearMiss
        let suggestion = try XCTUnwrap(ShotPlanner.suggestions(for: state,
            targetID: 1, pocketID: 4, includeBanks: false).first)
        let cue = state.balls[0].position
        let object = state.balls[1].position
        let direction = Vector2(x: cos(suggestion.shot.angleRadians), y: sin(suggestion.shot.angleRadians))
        let delta = suggestion.ghostBall - cue
        XCTAssertTrue(suggestion.ghostBall.isFinite)
        XCTAssertEqual(suggestion.ghostBall.distance(to: object), 2 * state.table.ballRadius, accuracy: 1e-10)
        XCTAssertEqual(delta.x * direction.y - delta.y * direction.x, 0, accuracy: 1e-10)
        XCTAssertGreaterThan(delta.dot(direction), 0)
    }

    func testRefinedSearchRemainsDeterministicAndKeepsLegalTargets() throws {
        let first = try ShotPlanner.suggestions(for: angularNearMiss,
            targetID: 1, pocketID: 4, includeBanks: false, allowedTargetIDs: [1])
        let second = try ShotPlanner.suggestions(for: angularNearMiss,
            targetID: 1, pocketID: 4, includeBanks: false, allowedTargetIDs: [1])
        XCTAssertFalse(first.isEmpty)
        XCTAssertEqual(first.map(\.id), second.map(\.id))
        XCTAssertTrue(try ShotPlanner.suggestions(for: angularNearMiss,
            targetID: 1, pocketID: 4, includeBanks: false, allowedTargetIDs: [9]).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: angularNearMiss,
            targetID: 1, pocketID: 4, includeBanks: false, allowedTargetIDs: []).isEmpty)
    }

    func testRefinedSearchVerifiesRuntimeMinimumWithoutChangingReturnedPower() throws {
        let suggestion = try XCTUnwrap(ShotPlanner.suggestions(for: angularNearMiss,
            targetID: 1, pocketID: 4, includeBanks: false, allowedTargetIDs: [1], minimumPower: 0.95).first)
        XCTAssertGreaterThanOrEqual(suggestion.shot.power, 0.95)
        let replay = try BilliardsEngine.simulate(state: angularNearMiss,
            shot: suggestion.shot, recordFrames: false)
        XCTAssertEqual(replay.finalState, suggestion.result.finalState)
        XCTAssertEqual(replay.events, suggestion.result.events)
        XCTAssertTrue(ShotPlanner.isValidOutcome(replay, targetID: 1, pocketID: 4,
                                               method: .direct, allowedTargetIDs: [1]))
    }

    private var angularNearMiss: TableState {
        TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 140.3, y: 36.86)),
            PoolBall(id: 1, position: Vector2(x: 143.91, y: 52.72))
        ])
    }

    func testBlockedCueRouteDoesNotSuggestShootingThroughBlocker() throws {
        var state = TableState.straightShot
        state.balls.append(PoolBall(id: 2, position: Vector2(x: 100, y: 53)))
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testRuntimeMinimumPowerIsAppliedBeforeOutcomeVerification() throws {
        let original = try XCTUnwrap(ShotPlanner.suggestions(
            for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false
        ).first)
        let minimum = original.shot.power + 0.03
        let shots = try ShotPlanner.suggestions(
            for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false,
            minimumPower: minimum
        )
        XCTAssertFalse(shots.isEmpty)
        for shot in shots {
            XCTAssertGreaterThanOrEqual(shot.shot.power, minimum)
            let replay = try BilliardsEngine.simulate(state: .straightShot, shot: shot.shot, recordFrames: false)
            XCTAssertEqual(replay.finalState, shot.result.finalState)
            XCTAssertEqual(replay.events, shot.result.events)
            XCTAssertEqual(replay.duration, shot.result.duration)
            XCTAssertTrue(ShotPlanner.isValidOutcome(replay, targetID: 1, pocketID: 1, method: .direct))
        }
    }

    func testNativeControlMinimumConvertsToExecutablePlannedPower() throws {
        let controlMinimum = 0.4
        let simulationMinimum = try GameShotCalibration.simulationPower(fromControlPower: controlMinimum)
        let shot = try XCTUnwrap(ShotPlanner.suggestions(
            for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false,
            minimumPower: simulationMinimum
        ).first)
        let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: shot.shot.power)
        XCTAssertGreaterThanOrEqual(nativePower, controlMinimum - 1e-12)
        XCTAssertTrue(shot.result.settled)
        XCTAssertFalse(shot.result.scratched)
    }

    func testInvalidMinimumPowerIsRejectedInsteadOfClamped() throws {
        for value in [-0.01, 1.01, .infinity, -.infinity, .nan] {
            XCTAssertThrowsError(try ShotPlanner.suggestions(for: .straightShot, minimumPower: value)) {
                XCTAssertEqual($0 as? BilliardsError, .invalidShot)
            }
        }
    }

    func testConfirmedInitialRackProducesVerifiedBreakWithoutInventedPocket() throws {
        let state = initialRack
        let allowed = Set(1...15).subtracting([8])
        let shot = try XCTUnwrap(ShotPlanner.suggestions(
            for: state, limit: 1, allowedTargetIDs: allowed, minimumPower: 0.2, isBreakShot: true
        ).first)
        XCTAssertEqual(shot.method, .breakShot)
        XCTAssertTrue(allowed.contains(shot.targetID))
        XCTAssertGreaterThanOrEqual(shot.shot.power, 0.2)
        XCTAssertTrue(ShotPlanner.isValidBreakOutcome(shot.result, allowedTargetIDs: allowed))
        let replay = try BilliardsEngine.simulate(state: state, shot: shot.shot, recordFrames: false)
        XCTAssertEqual(replay.finalState, shot.result.finalState)
        XCTAssertEqual(replay.events, shot.result.events)
        XCTAssertFalse(replay.scratched)
        XCTAssertFalse(replay.pocketedIDs.contains(8))
    }

    func testBreakRequiresNativeFlagAndFullUnmovedRack() throws {
        XCTAssertTrue(try ShotPlanner.suggestions(for: initialRack, includeBanks: false)
            .allSatisfy { $0.method != .breakShot })
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, isBreakShot: true).isEmpty)
        var scattered = initialRack
        scattered.balls[7].position = Vector2(x: 75, y: 25)
        XCTAssertTrue(try ShotPlanner.suggestions(for: scattered, isBreakShot: true).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: initialRack, allowedTargetIDs: [], isBreakShot: true).isEmpty)
    }

    func testBreakNeedsFourDistinctObjectCushionsOrObjectPocket() {
        let legal: Set<Int> = [1, 2, 3, 4]
        let contact: [ShotEvent] = [.ballCollision(first: 0, second: 1)]
        let fourRails = contact + [1, 2, 3, 4].map { ShotEvent.cushion(ball: $0) }
        XCTAssertTrue(ShotPlanner.isValidBreakOutcome(outcome(events: fourRails), allowedTargetIDs: legal))
        let repeatedRails = contact + [1, 1, 1, 1, 0].map { ShotEvent.cushion(ball: $0) }
        XCTAssertFalse(ShotPlanner.isValidBreakOutcome(outcome(events: repeatedRails), allowedTargetIDs: legal))
        XCTAssertTrue(ShotPlanner.isValidBreakOutcome(outcome(events: contact + [.pocket(ball: 2, pocket: 0)]), allowedTargetIDs: legal))
        XCTAssertFalse(ShotPlanner.isValidBreakOutcome(outcome(events: fourRails, cuePocketed: true), allowedTargetIDs: legal))
        XCTAssertFalse(ShotPlanner.isValidBreakOutcome(outcome(events: fourRails, blackPocketed: true), allowedTargetIDs: legal))
        XCTAssertFalse(ShotPlanner.isValidBreakOutcome(outcome(events: fourRails, settled: false), allowedTargetIDs: legal))
        XCTAssertFalse(ShotPlanner.isValidBreakOutcome(outcome(events: fourRails), allowedTargetIDs: [9]))
        XCTAssertFalse(ShotPlanner.isValidBreakOutcome(outcome(events: [.ballCollision(first: 0, second: 8), .pocket(ball: 1, pocket: 0)]), allowedTargetIDs: [8, 1]))
    }

    private var initialRack: TableState {
        var balls = [PoolBall(id: 0, position: Vector2(x: 50, y: 50))]
        let radius = PoolTable().ballRadius
        var number = 1
        for row in 0..<5 {
            for column in 0...row {
                balls.append(PoolBall(id: number, position: Vector2(
                    x: 132 + Double(row) * sqrt(3) * radius * 1.002,
                    y: 50 + Double(2 * column - row) * radius * 1.002
                )))
                number += 1
            }
        }
        var table = PoolTable()
        table.maximumShotSpeed = 550
        table.rollingDeceleration = 8.6
        table.ballRestitution = 1
        table.cushionRestitution = 0.804
        return TableState(table: table, balls: balls)
    }

    func testBlockedObjectRouteDoesNotSuggestShootingThroughBlocker() throws {
        var state = TableState.straightShot
        state.balls.append(PoolBall(id: 2, position: Vector2(x: 100, y: 15)))
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testPocketedBlockerDoesNotObstructRoute() throws {
        var state = TableState.straightShot
        state.balls.append(PoolBall(id: 2, position: Vector2(x: 100, y: 53), pocketed: true))
        XCTAssertFalse(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testGhostOutsideTableIsRejected() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 60, y: 85)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 95))
        ])
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testWrongSideCutIsRejected() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 30, y: 35)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 35))
        ])
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testVerifiedOneCushionBankCanBeSuggested() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 20)),
            PoolBall(id: 1, position: Vector2(x: 120, y: 50))
        ])
        let shots = try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: true, limit: 24)
        let bank = try XCTUnwrap(shots.first { $0.method == .bank })
        XCTAssertTrue(bank.result.events.contains(.pocket(ball: 1, pocket: 1)))
        XCTAssertTrue(bank.result.events.contains(.cushion(ball: 1)))
        XCTAssertTrue(bank.result.settled)
        XCTAssertFalse(bank.result.scratched)
    }

    func testShallowBankRequiringAnotherCushionIsNotCalledOneCushion() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 190, y: 50)),
            PoolBall(id: 1, position: Vector2(x: 140, y: 50))
        ])
        let shots = try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: true, limit: 24)
        XCTAssertTrue(shots.allSatisfy { $0.method == .direct })
    }

    func testSearchIsDeterministicAndRespectsLimit() throws {
        let first = try ShotPlanner.suggestions(for: .straightShot, targetID: 1, includeBanks: false, limit: 2)
        let second = try ShotPlanner.suggestions(for: .straightShot, targetID: 1, includeBanks: false, limit: 2)
        XCTAssertFalse(first.isEmpty)
        XCTAssertLessThanOrEqual(first.count, 2)
        XCTAssertEqual(first.map(\.id), second.map(\.id))
        XCTAssertEqual(first.map(\.score), first.map(\.score).sorted())
    }

    func testNoSuchTargetOrPocketReturnsNoSuggestions() throws {
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, targetID: 15).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, pocketID: 99).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, targetID: 0).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, limit: 0).isEmpty)
    }

    func testAllowedTargetsPreserveLegalShotAndRejectExplicitIllegalTarget() throws {
        let unrestricted = try ShotPlanner.suggestions(
            for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false
        )
        let restricted = try ShotPlanner.suggestions(
            for: .straightShot, pocketID: 1, includeBanks: false, allowedTargetIDs: [1]
        )
        XCTAssertFalse(restricted.isEmpty)
        XCTAssertEqual(restricted.map(\.id), unrestricted.map(\.id))
        XCTAssertTrue(restricted.allSatisfy { $0.targetID == 1 })
        XCTAssertTrue(try ShotPlanner.suggestions(
            for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false,
            allowedTargetIDs: [9, 10]
        ).isEmpty)
    }

    func testEmptyAllowedTargetsNeverFallsBackToUnrestrictedSearch() throws {
        XCTAssertFalse(try ShotPlanner.suggestions(
            for: .straightShot, includeBanks: false
        ).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(
            for: .straightShot, includeBanks: false, allowedTargetIDs: []
        ).isEmpty)
    }

    func testBlackBallIsSuggestedOnlyWhenAllowed() throws {
        var state = TableState.straightShot
        state.balls[1].id = 8
        XCTAssertTrue(try ShotPlanner.suggestions(
            for: state, includeBanks: false, allowedTargetIDs: [1, 2, 3]
        ).isEmpty)
        let suggestion = try XCTUnwrap(ShotPlanner.suggestions(
            for: state, pocketID: 1, includeBanks: false, allowedTargetIDs: [8]
        ).first)
        XCTAssertEqual(suggestion.targetID, 8)
        XCTAssertTrue(suggestion.result.events.contains(.pocket(ball: 8, pocket: 1)))
        XCTAssertFalse(suggestion.result.scratched)
    }

    func testInvalidPositionIsReported() {
        var state = TableState.straightShot
        state.balls[0].position.x = -.infinity
        XCTAssertThrowsError(try ShotPlanner.suggestions(for: state)) {
            XCTAssertEqual($0 as? BilliardsError, .invalidBalls)
        }
    }

    func testCancelledSearchThrowsCancellation() async {
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try ShotPlanner.suggestions(for: .straightShot)
        }
        do {
            _ = try await task.value
            XCTFail("A cancelled search should not return suggestions.")
        } catch {
            XCTAssertTrue(error is CancellationError)
        }
    }

    func testCancelledRestrictedSearchThrowsEvenWhenNoTargetsAreAllowed() async {
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try ShotPlanner.suggestions(for: .straightShot, allowedTargetIDs: [])
        }
        do {
            _ = try await task.value
            XCTFail("A cancelled restricted search should not return suggestions.")
        } catch {
            XCTAssertTrue(error is CancellationError)
        }
    }

    func testLegalFirstContactStillRejectsEarlyBlackPocket() {
        let result = outcome(events: [
            .ballCollision(first: 0, second: 1),
            .pocket(ball: 1, pocket: 1),
            .ballCollision(first: 0, second: 8),
            .pocket(ball: 8, pocket: 2)
        ], blackPocketed: true)
        XCTAssertTrue(ShotPlanner.isValidOutcome(result, targetID: 1, pocketID: 1))
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            result, targetID: 1, pocketID: 1, allowedTargetIDs: [1, 2, 3]
        ))
    }

    func testRestrictedOutcomeRequiresSelectedTargetAndFirstContactToBeLegal() {
        let valid = outcome(events: [.ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1)])
        XCTAssertTrue(ShotPlanner.isValidOutcome(
            valid, targetID: 1, pocketID: 1, allowedTargetIDs: [1]
        ))
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            valid, targetID: 1, pocketID: 1, allowedTargetIDs: [9]
        ))
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            valid, targetID: 1, pocketID: 1, allowedTargetIDs: []
        ))
        let illegalFirstContact = outcome(events: [
            .ballCollision(first: 0, second: 9),
            .ballCollision(first: 0, second: 1),
            .pocket(ball: 1, pocket: 1)
        ])
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            illegalFirstContact, targetID: 1, pocketID: 1, allowedTargetIDs: [1]
        ))
    }

    func testPocketSuccessWithCueScratchIsRejected() {
        let result = outcome(events: [.ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1), .pocket(ball: 0, pocket: 4)], cuePocketed: true)
        XCTAssertFalse(ShotPlanner.isValidOutcome(result, targetID: 1, pocketID: 1))
    }

    func testWrongPocketFirstContactAndUnsettledResultsAreRejected() {
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            outcome(events: [.ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 4)]), targetID: 1, pocketID: 1))
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            outcome(events: [.ballCollision(first: 0, second: 2), .ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1)]), targetID: 1, pocketID: 1))
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            outcome(events: [.ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1)], settled: false), targetID: 1, pocketID: 1))
    }

    func testMethodMustMatchActualObjectBallCushionCount() {
        let events: [ShotEvent] = [.ballCollision(first: 0, second: 1), .cushion(ball: 1), .pocket(ball: 1, pocket: 1)]
        let bank = outcome(events: events)
        XCTAssertTrue(ShotPlanner.isValidOutcome(bank, targetID: 1, pocketID: 1, method: .bank))
        XCTAssertFalse(ShotPlanner.isValidOutcome(bank, targetID: 1, pocketID: 1, method: .direct))
        let twoCushions = outcome(events: [.ballCollision(first: 0, second: 1), .cushion(ball: 1), .cushion(ball: 1), .pocket(ball: 1, pocket: 1)])
        XCTAssertFalse(ShotPlanner.isValidOutcome(twoCushions, targetID: 1, pocketID: 1, method: .bank))
    }

    func testRenderedReplayPreservesVerifiedOutcome() throws {
        let suggestion = try XCTUnwrap(ShotPlanner.suggestions(
            for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false
        ).first)
        let replay = try BilliardsEngine.simulate(state: .straightShot, shot: suggestion.shot, recordFrames: true)
        XCTAssertFalse(replay.frames.isEmpty)
        XCTAssertTrue(ShotPlanner.isValidOutcome(replay, targetID: 1, pocketID: 1, method: .direct))
    }

    private func outcome(
        events: [ShotEvent], cuePocketed: Bool = false, settled: Bool = true,
        blackPocketed: Bool = false
    ) -> ShotResult {
        var state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 50), pocketed: cuePocketed),
            PoolBall(id: 1, position: Vector2(x: 100, y: 0), pocketed: true)
        ])
        if blackPocketed {
            state.balls.append(PoolBall(id: 8, position: Vector2(x: 200, y: 0), pocketed: true))
        }
        return ShotResult(finalState: state, frames: [], traces: [], events: events, duration: 1, settled: settled)
    }
}
