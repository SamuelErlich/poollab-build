import Foundation
import XCTest
@testable import PoolLabCore

final class AutoPlayModeTests: XCTestCase {
    func testEveryModeConfirmsBeforeMovingAndHasARealControlSequence() {
        for mode in AutoPlayMode.allCases {
            let profile = mode.controlProfile(angleDelta: 0, power: 0)
            XCTAssertGreaterThan(mode.minimumAnalysisDuration, 0, mode.rawValue)
            XCTAssertGreaterThan(profile.alignmentDuration, 0, mode.rawValue)
            XCTAssertGreaterThan(profile.pullDuration, 0, mode.rawValue)
            XCTAssertGreaterThan(profile.settleDuration, 0, mode.rawValue)
            XCTAssertEqual(profile.phase(at: 0), "aligning")
            XCTAssertEqual(profile.phase(at: profile.duration / 2) == "ready", false)
            XCTAssertEqual(profile.phase(at: profile.duration), "ready")
        }
    }

    func testModesChangeCadenceWithoutChangingTheSelectedShot() {
        // The planner supplies one exact command. Presentation cannot alter
        // its force or angle, even when Hard completes the motion sooner.
        for delta in [-2.5, -0.05, 0, 0.7, 2.8] {
            for power in [0.2, 0.61, 1.0] {
                let profiles = AutoPlayMode.allCases.map { $0.controlProfile(angleDelta: delta, power: power) }
                XCTAssertGreaterThan(profiles[0].duration, profiles[1].duration)
                XCTAssertGreaterThan(profiles[1].duration, profiles[2].duration)
                let target = 0.3 + delta
                let completed = profiles.map {
                    $0.sample(startAngle: 0.3, startPower: 0, targetAngle: target,
                              targetPower: power, elapsed: $0.duration)
                }
                XCTAssertEqual(completed[0], completed[1])
                XCTAssertEqual(completed[1], completed[2])
                XCTAssertEqual(completed[0].angle, target)
                XCTAssertEqual(completed[0].power, power)
                XCTAssertEqual(completed[0].phase, "ready")
            }
        }
    }

    func testFeintAndReturnNeverPullTheCueEvenWhenPreviousPowerWasSet() {
        for mode in [AutoPlayMode.small, .normal] {
            let profile = mode.controlProfile(angleDelta: 0.8, power: 1)
            for startPower in [0.0, 0.4, 1.0] {
                for elapsed in [0, profile.alignmentDuration / 2,
                                profile.alignmentDuration,
                                profile.alignmentDuration + profile.correctionDuration / 2] {
                    let sample = profile.sample(startAngle: 0.1, startPower: startPower,
                        targetAngle: 0.9, targetPower: 1, elapsed: elapsed)
                    XCTAssertEqual(sample.power, 0, "\(mode.rawValue), prior power \(startPower), time \(elapsed)")
                }
            }
        }
    }

    func testSmallAndNormalReturnFromTheirFeintBeforePulling() {
        for mode in [AutoPlayMode.small, .normal] {
            for direction in [-1.0, 1.0] {
                let target = direction * 0.7
                let profile = mode.controlProfile(angleDelta: target, power: 0.7)
                XCTAssertGreaterThan(profile.feintRadians * direction, 0)
                let overshoot = profile.sample(startAngle: 0, startPower: 0,
                    targetAngle: target, targetPower: 0.7, elapsed: profile.alignmentDuration)
                let correction = profile.sample(startAngle: 0, startPower: 0,
                    targetAngle: target, targetPower: 0.7,
                    elapsed: profile.alignmentDuration + profile.correctionDuration / 2)
                let pull = profile.sample(startAngle: 0, startPower: 0,
                    targetAngle: target, targetPower: 0.7,
                    elapsed: profile.alignmentDuration + profile.correctionDuration)
                XCTAssertEqual(overshoot.phase, "correcting")
                XCTAssertGreaterThan(abs(overshoot.angle - target), abs(correction.angle - target))
                XCTAssertEqual(correction.power, 0)
                XCTAssertEqual(pull.phase, "pulling")
                XCTAssertEqual(pull.angle, target)
                XCTAssertEqual(pull.power, 0, accuracy: 1e-12)
            }
        }
    }

    func testHardRemainsGradualWithoutDecorativeFeint() {
        let profile = AutoPlayMode.hard.controlProfile(angleDelta: 1, power: 1)
        let alignment = profile.sample(startAngle: 0, startPower: 0,
            targetAngle: 1, targetPower: 1, elapsed: profile.alignmentDuration / 2)
        let pull = profile.sample(startAngle: 0, startPower: 0,
            targetAngle: 1, targetPower: 1,
            elapsed: profile.alignmentDuration + profile.pullDuration / 2)
        XCTAssertGreaterThan(alignment.angle, 0)
        XCTAssertLessThan(alignment.angle, 1)
        XCTAssertEqual(alignment.power, 0)
        XCTAssertEqual(pull.angle, 1)
        XCTAssertGreaterThan(pull.power, 0)
        XCTAssertLessThan(pull.power, 1)
        XCTAssertEqual(profile.feintRadians, 0)
        XCTAssertEqual(profile.correctionDuration, 0)
    }

    func testPowerIncreasesOnlyOnTheFinalDirectionAndNeverOvershoots() {
        for mode in AutoPlayMode.allCases {
            for targetPower in [0.2, 0.51, 1.0] {
                let profile = mode.controlProfile(angleDelta: -1.2, power: targetPower)
                let pullStarts = profile.alignmentDuration + profile.correctionDuration
                var lastPower = 0.0
                for step in 0...100 {
                    let elapsed = pullStarts + profile.pullDuration * Double(step) / 100
                    let sample = profile.sample(startAngle: 1, startPower: 0,
                        targetAngle: -0.2, targetPower: targetPower, elapsed: elapsed)
                    XCTAssertEqual(sample.angle, -0.2)
                    XCTAssertGreaterThanOrEqual(sample.power, lastPower)
                    XCTAssertLessThanOrEqual(sample.power, targetPower)
                    lastPower = sample.power
                }
                XCTAssertEqual(lastPower, targetPower, accuracy: 1e-12)
            }
        }
    }

    func testSettlingAndLateFramesKeepTheExactPlannedCommand() {
        for mode in AutoPlayMode.allCases {
            let profile = mode.controlProfile(angleDelta: 0.8, power: 0.83)
            let settleStarts = profile.alignmentDuration + profile.correctionDuration + profile.pullDuration
            for elapsed in [settleStarts + profile.settleDuration / 2, profile.duration, profile.duration + 60] {
                let sample = profile.sample(startAngle: -0.1, startPower: 0,
                    targetAngle: 0.7, targetPower: 0.83, elapsed: elapsed)
                XCTAssertEqual(sample.angle, 0.7)
                XCTAssertEqual(sample.power, 0.83)
            }
        }
    }

    func testAlignmentUsesTheShortArcAcrossTheAngleWrap() {
        let start = Double.pi - 0.03
        let target = -Double.pi + 0.04
        for mode in AutoPlayMode.allCases {
            let profile = mode.controlProfile(angleDelta: 0.07, power: 0.5)
            let middle = profile.sample(startAngle: start, startPower: 0,
                targetAngle: target, targetPower: 0.5, elapsed: profile.alignmentDuration / 2)
            XCTAssertGreaterThan(middle.angle, start)
            XCTAssertLessThan(middle.angle - start, 0.1)
            let before = profile.sample(startAngle: start, startPower: 0,
                targetAngle: target, targetPower: 0.5, elapsed: profile.alignmentDuration - 1e-7)
            let after = profile.sample(startAngle: start, startPower: 0,
                targetAngle: target, targetPower: 0.5, elapsed: profile.alignmentDuration)
            let physicalDifference = (after.angle - before.angle).remainder(dividingBy: 2 * .pi)
            XCTAssertEqual(physicalDifference, 0, accuracy: 1e-9)
        }
    }

    func testInvalidElapsedSampleCannotSkipToReady() {
        for mode in AutoPlayMode.allCases {
            let profile = mode.controlProfile(angleDelta: 1, power: 1)
            for elapsed in [-1, Double.nan, .infinity, -.infinity] {
                let sample = profile.sample(startAngle: 0.3, startPower: 0,
                    targetAngle: 1.3, targetPower: 1, elapsed: elapsed)
                XCTAssertEqual(sample.phase, "aligning")
                XCTAssertEqual(sample.angle, 0.3)
                XCTAssertEqual(sample.power, 0)
            }
        }
    }

    func testClockCountsWaitingAndRepeatedUpdatesWithoutRestarting() {
        var clock = AutomationSessionClock()
        XCTAssertEqual(clock.elapsed(at: 100), 0)
        clock.synchronize(enabled: true, paused: false, at: 100)
        for now in [101.0, 120, 180] {
            clock.synchronize(enabled: true, paused: false, at: now)
            XCTAssertEqual(clock.elapsed(at: now), now - 100)
        }
        XCTAssertEqual(clock.elapsed(at: 200), 100)
    }

    func testClockPausesAndResumesWithoutLosingPreviousElapsedTime() {
        var clock = AutomationSessionClock()
        clock.synchronize(enabled: true, paused: false, at: 100)
        clock.synchronize(enabled: true, paused: true, at: 130)
        XCTAssertEqual(clock.elapsed(at: 500), 30)
        clock.synchronize(enabled: true, paused: true, at: 500)
        clock.synchronize(enabled: true, paused: false, at: 600)
        XCTAssertEqual(clock.elapsed(at: 607), 37)
        clock.synchronize(enabled: true, paused: true, at: 610)
        XCTAssertEqual(clock.elapsed(at: 800), 40)
        clock.synchronize(enabled: true, paused: false, at: 900)
        XCTAssertEqual(clock.elapsed(at: 905), 45)
    }

    func testDisablingFreezesTimeAndReactivationStartsANewSession() {
        var clock = AutomationSessionClock()
        clock.synchronize(enabled: true, paused: false, at: 100)
        clock.synchronize(enabled: false, paused: false, at: 140)
        XCTAssertEqual(clock.elapsed(at: 600), 40)
        clock.synchronize(enabled: false, paused: false, at: 600)
        clock.synchronize(enabled: true, paused: false, at: 900)
        XCTAssertEqual(clock.elapsed(at: 900), 0)
        XCTAssertEqual(clock.elapsed(at: 912), 12)
    }

    func testEnablingWhilePausedStartsAZeroSessionUntilResumed() {
        var clock = AutomationSessionClock()
        clock.synchronize(enabled: true, paused: false, at: 100)
        clock.synchronize(enabled: false, paused: true, at: 115)
        clock.synchronize(enabled: true, paused: true, at: 200)
        XCTAssertEqual(clock.elapsed(at: 500), 0)
        clock.synchronize(enabled: true, paused: false, at: 550)
        XCTAssertEqual(clock.elapsed(at: 552.5), 2.5)
    }

    func testClockDiscardsNonFiniteTransitionsWithoutLosingTheSession() {
        var clock = AutomationSessionClock()
        clock.synchronize(enabled: true, paused: false, at: 100)
        clock.synchronize(enabled: true, paused: false, at: 110)
        for invalid in [Double.nan, .infinity, -.infinity] {
            clock.synchronize(enabled: false, paused: true, at: invalid)
            XCTAssertEqual(clock.elapsed(at: invalid), 10)
        }
        XCTAssertEqual(clock.elapsed(at: 120), 20)
        clock.synchronize(enabled: true, paused: true, at: 125)
        XCTAssertEqual(clock.elapsed(at: 500), 25)
    }

    func testClockNeverSubtractsElapsedTimeOnARegressingSynchronization() {
        var clock = AutomationSessionClock()
        clock.synchronize(enabled: true, paused: false, at: 100)
        clock.synchronize(enabled: true, paused: false, at: 110)
        clock.synchronize(enabled: true, paused: true, at: 105)
        XCTAssertEqual(clock.elapsed(at: 103), 10)
        clock.synchronize(enabled: true, paused: false, at: 106)
        XCTAssertEqual(clock.elapsed(at: 115), 15)
        clock.synchronize(enabled: false, paused: false, at: 120)
        XCTAssertEqual(clock.elapsed(at: 119), 20)
    }
}
