import XCTest
@testable import PoolLabCore

final class GameShotCalibrationTests: XCTestCase {
    func testNativeCurveAndEndpoints() throws {
        XCTAssertEqual(try GameShotCalibration.simulationPower(fromControlPower: 0), 0)
        XCTAssertEqual(try GameShotCalibration.simulationPower(fromControlPower: 1), 1)
        XCTAssertEqual(try GameShotCalibration.simulationPower(fromControlPower: 0.75), 0.5, accuracy: 1e-14)
        XCTAssertEqual(try GameShotCalibration.controlPower(fromSimulationPower: 0.5), 0.75, accuracy: 1e-14)
    }

    func testRoundTripAcrossCueRange() throws {
        for index in 0...100 {
            let original = Double(index) / 100
            let simulated = try GameShotCalibration.simulationPower(fromControlPower: original)
            XCTAssertEqual(try GameShotCalibration.controlPower(fromSimulationPower: simulated), original, accuracy: 2e-14)
        }
    }

    func testTinyPowerKeepsPrecision() throws {
        let value = 1e-20
        let simulated = try GameShotCalibration.simulationPower(fromControlPower: value)
        XCTAssertGreaterThan(simulated, 0)
        XCTAssertEqual(simulated / value, 0.5, accuracy: 1e-14)
    }

    func testInvalidControlsAreRejected() {
        for value in [-0.01, 1.01, Double.nan, Double.infinity, -Double.infinity] {
            XCTAssertThrowsError(try GameShotCalibration.simulationPower(fromControlPower: value))
            XCTAssertThrowsError(try GameShotCalibration.controlPower(fromSimulationPower: value))
        }
    }

    func testCurveIsMonotonic() throws {
        var previous = -1.0
        for index in 0...100 {
            let current = try GameShotCalibration.simulationPower(fromControlPower: Double(index) / 100)
            XCTAssertGreaterThan(current, previous)
            previous = current
        }
    }
}
