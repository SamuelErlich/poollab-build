import XCTest
@testable import PoolLabCore

final class PracticeGeometryTests: XCTestCase {
    private let table = TableBounds(width: 200, height: 100)
    private let center = Vector2(x: 100, y: 50)

    func testHorizontalReflectionsAreCollinearAndRespectRadius() throws {
        let path = try PracticeGeometry.trajectory(
            origin: center, angleRadians: 0, table: table,
            ballRadius: 3, maxBounces: 2, maxDistance: 600
        )
        assertPoints(path, [center, .init(x: 197, y: 50),
                            .init(x: 3, y: 50), .init(x: 197, y: 50)])
    }

    func testVerticalDirectionHasNoHorizontalDrift() throws {
        let path = try PracticeGeometry.trajectory(
            origin: center, angleRadians: .pi / 2, table: table,
            ballRadius: 3, maxBounces: 1, maxDistance: 600
        )
        assertPoints(path, [center, .init(x: 100, y: 97), .init(x: 100, y: 3)])
    }

    func testNegativeVerticalDirection() throws {
        let path = try PracticeGeometry.trajectory(
            origin: center, angleRadians: -.pi / 2, table: table,
            ballRadius: 3, maxBounces: 0
        )
        assertPoints(path, [center, .init(x: 100, y: 3)])
    }

    func testCornerReflectsBothAxesWithOneReflection() throws {
        let path = try PracticeGeometry.trajectory(
            origin: .init(x: 150, y: 50), angleRadians: .pi / 4,
            table: table, ballRadius: 3, maxBounces: 1
        )
        assertPoints(path, [.init(x: 150, y: 50), .init(x: 197, y: 97),
                            .init(x: 103, y: 3)])
    }

    func testLimitedDistanceEndsBeforeFirstContact() throws {
        let path = try PracticeGeometry.trajectory(
            origin: center, angleRadians: 0, table: table,
            ballRadius: 3, maxDistance: 20
        )
        assertPoints(path, [center, .init(x: 120, y: 50)])
    }

    func testLimitedDistanceContinuesAfterReflection() throws {
        let path = try PracticeGeometry.trajectory(
            origin: center, angleRadians: 0, table: table,
            ballRadius: 3, maxBounces: 3, maxDistance: 110
        )
        assertPoints(path, [center, .init(x: 197, y: 50), .init(x: 184, y: 50)])
        XCTAssertEqual(length(of: path), 110, accuracy: 1e-10)
    }

    func testDistanceEndingExactlyAtCushionHasNoDuplicate() throws {
        let path = try PracticeGeometry.trajectory(
            origin: center, angleRadians: 0, table: table,
            ballRadius: 3, maxDistance: 97
        )
        assertPoints(path, [center, .init(x: 197, y: 50)])
    }

    func testOutwardEdgeOriginReflectsWithoutDuplicatePoint() throws {
        let origin = Vector2(x: 197, y: 50)
        let path = try PracticeGeometry.trajectory(
            origin: origin, angleRadians: 0, table: table,
            ballRadius: 3, maxBounces: 1, maxDistance: 20
        )
        assertPoints(path, [origin, .init(x: 177, y: 50)])
    }

    func testOutwardEdgeOriginWithNoReflectionStaysAtOrigin() throws {
        let origin = Vector2(x: 197, y: 50)
        let path = try PracticeGeometry.trajectory(
            origin: origin, angleRadians: 0, table: table,
            ballRadius: 3, maxBounces: 0
        )
        XCTAssertEqual(path, [origin])
    }

    func testInwardEdgeOriginDoesNotSpendReflectionImmediately() throws {
        let origin = Vector2(x: 197, y: 50)
        let path = try PracticeGeometry.trajectory(
            origin: origin, angleRadians: .pi, table: table,
            ballRadius: 3, maxBounces: 0
        )
        assertPoints(path, [origin, .init(x: 3, y: 50)])
    }

    func testTangentEdgeRayReachesNextCushion() throws {
        let path = try PracticeGeometry.trajectory(
            origin: .init(x: 3, y: 50), angleRadians: .pi / 2,
            table: table, ballRadius: 3, maxBounces: 0
        )
        assertPoints(path, [.init(x: 3, y: 50), .init(x: 3, y: 97)])
    }

    func testOutwardCornerUsesSingleReflection() throws {
        let path = try PracticeGeometry.trajectory(
            origin: .init(x: 197, y: 97), angleRadians: .pi / 4,
            table: table, ballRadius: 3, maxBounces: 1, maxDistance: 10
        )
        let component = 10 / Double(2).squareRoot()
        assertPoints(path, [.init(x: 197, y: 97),
                            .init(x: 197 - component, y: 97 - component)])
    }

    func testNearZeroComponentIsTreatedAsAxisAligned() throws {
        let path = try PracticeGeometry.trajectory(
            origin: center, angleRadians: 1e-14, table: table,
            ballRadius: 3, maxBounces: 0
        )
        XCTAssertEqual(path, [center, .init(x: 197, y: 50)])
    }

    func testObliquePathIsFiniteBoundedAndDistanceLimited() throws {
        for angle in stride(from: -Double.pi, through: Double.pi, by: Double.pi / 24) {
            let path = try PracticeGeometry.trajectory(
                origin: center, angleRadians: angle, table: table,
                ballRadius: 3, maxBounces: 20, maxDistance: 250
            )
            XCTAssertEqual(length(of: path), 250, accuracy: 1e-8)
            for point in path {
                XCTAssertTrue(point.x.isFinite && point.y.isFinite)
                XCTAssertTrue((3...197).contains(point.x))
                XCTAssertTrue((3...97).contains(point.y))
            }
            for pair in zip(path, path.dropFirst()) { XCTAssertNotEqual(pair.0, pair.1) }
        }
    }

    func testInvalidDimensionsAndRadiusAreRejected() {
        assertError(.invalidTable, table: .init(width: 0, height: 100))
        assertError(.invalidTable, table: .init(width: 200, height: -100))
        assertError(.invalidBallRadius, radius: 0)
        assertError(.invalidBallRadius, radius: -1)
        assertError(.invalidBallRadius, radius: 50)
        assertError(.invalidBallRadius, radius: 51)
    }

    func testOriginOutsideInsetIsRejected() {
        assertError(.originOutsideTable, origin: .init(x: 2.9, y: 50))
        assertError(.originOutsideTable, origin: .init(x: 197.1, y: 50))
        assertError(.originOutsideTable, origin: .init(x: 100, y: 2.9))
        assertError(.originOutsideTable, origin: .init(x: 100, y: 97.1))
    }

    func testInvalidBudgetsAreRejected() {
        assertError(.invalidBounceLimit, bounces: -1)
        assertError(.invalidBounceLimit, bounces: PracticeGeometry.maximumBounceLimit + 1)
        assertError(.invalidBounceLimit, bounces: Int.max)
        assertError(.invalidDistanceLimit, distance: 0)
        assertError(.invalidDistanceLimit, distance: -10)
    }

    func testEveryFloatingPointInputRejectsNonFiniteValues() {
        for value in [Double.nan, Double.infinity, -Double.infinity] {
            assertError(.nonFiniteInput, origin: .init(x: value, y: 50))
            assertError(.nonFiniteInput, origin: .init(x: 100, y: value))
            assertError(.nonFiniteInput, angle: value)
            assertError(.nonFiniteInput, table: .init(width: value, height: 100))
            assertError(.nonFiniteInput, table: .init(width: 200, height: value))
            assertError(.nonFiniteInput, radius: value)
            assertError(.nonFiniteInput, distance: value)
        }
    }

    private func assertError(
        _ expected: PracticeGeometryError,
        origin: Vector2 = .init(x: 100, y: 50),
        angle: Double = 0,
        table: TableBounds = .init(width: 200, height: 100),
        radius: Double = 3,
        bounces: Int = 3,
        distance: Double = 600,
        file: StaticString = #filePath,
        line: UInt = #line
    ) {
        XCTAssertThrowsError(try PracticeGeometry.trajectory(
            origin: origin, angleRadians: angle, table: table,
            ballRadius: radius, maxBounces: bounces, maxDistance: distance
        ), file: file, line: line) { error in
            XCTAssertEqual(error as? PracticeGeometryError, expected, file: file, line: line)
        }
    }

    private func assertPoints(
        _ actual: [Vector2],
        _ expected: [Vector2],
        file: StaticString = #filePath,
        line: UInt = #line
    ) {
        XCTAssertEqual(actual.count, expected.count, file: file, line: line)
        for (point, reference) in zip(actual, expected) {
            XCTAssertEqual(point.x, reference.x, accuracy: 1e-9, file: file, line: line)
            XCTAssertEqual(point.y, reference.y, accuracy: 1e-9, file: file, line: line)
        }
    }

    private func length(of points: [Vector2]) -> Double {
        zip(points, points.dropFirst()).reduce(0) { result, pair in
            let dx = pair.1.x - pair.0.x
            let dy = pair.1.y - pair.0.y
            return result + (dx * dx + dy * dy).squareRoot()
        }
    }
}
