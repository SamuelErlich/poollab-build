import Foundation
import XCTest
@testable import PoolLabCore

final class V14PlannerTests: XCTestCase {
    func testSyntheticRailCaromMissedByLegacyPlannerPotsSameLegalTarget() throws {
        let state = try syntheticRailCarom()
        let original = state
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 3, pocketID: 5,
                                                 allowedTargetIDs: [3]).isEmpty)
        let report = try ShotPlanner.search(for: state, targetID: 3, pocketID: 5, allowedTargetIDs: [3])
        let shot = try XCTUnwrap(report.suggestions.first { $0.method == .carom })
        XCTAssertEqual(report.termination, .solutionFound)
        XCTAssertTrue(shot.result.events.contains(.ballCollision(first: 3, second: 8)))
        XCTAssertTrue(shot.result.events.contains(.cushion(ball: 3)))
        XCTAssertTrue(shot.result.events.contains(.pocket(ball: 3, pocket: 5)))
        XCTAssertFalse(shot.result.finalState.balls.first { $0.id == 8 }!.pocketed)
        XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 3, pocketID: 5,
                                                 method: .carom, allowedTargetIDs: [3]))
        let replay = try BilliardsEngine.simulate(state: state, shot: shot.shot, recordFrames: true)
        XCTAssertEqual(replay.events, shot.result.events)
        XCTAssertEqual(replay.finalState, shot.result.finalState)
        XCTAssertFalse(replay.scratched)
        XCTAssertFalse(replay.frames.isEmpty)
        XCTAssertEqual(state, original)
    }

    func testVideoApproximationIsNotClaimedAsExactFailureReproduction() throws {
        // Centers estimated from the supplied pixels, not recovered memory.
        // V13 already finds a different kick here, so this fixture only checks
        // that new search handles the approximation; it does not reproduce the
        // installed build's observed stop or assert the actual manual command.
        let state = try approximateVideoState()
        XCTAssertFalse(try ShotPlanner.suggestions(for: state, targetID: 3, pocketID: 5,
                                                  allowedTargetIDs: [3, 5]).isEmpty)
        let report = try ShotPlanner.search(for: state, targetID: 3, pocketID: 5, allowedTargetIDs: [3, 5])
        XCTAssertFalse(report.suggestions.isEmpty)
        for shot in report.suggestions {
            XCTAssertEqual(shot.targetID, 3)
            XCTAssertEqual(shot.pocketID, 5)
            XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 3, pocketID: 5,
                                                     method: shot.method, allowedTargetIDs: [3, 5]))
        }
    }

    func testDirectResultKeepsNativeQuantizationMinimumAndGentlePower() throws {
        var state = TableState.straightShot
        state.table = try nativeTable()
        let minimum = try GameShotCalibration.simulationPower(fromControlPower: 0.2)
        let report = try ShotPlanner.search(for: state, targetID: 1, pocketID: 1,
                                            includeBanks: false, allowedTargetIDs: [1], minimumPower: minimum)
        let shot = try XCTUnwrap(report.suggestions.first)
        XCTAssertLessThan(shot.shot.power, 0.15)
        XCTAssertGreaterThanOrEqual(shot.shot.power, minimum)
        let command = try ShotPlanner.executableShot(angle: shot.shot.angleRadians,
            power: shot.shot.power, minimumPower: minimum, table: state.table)
        XCTAssertEqual(command, shot.shot)
        let replay = try BilliardsEngine.simulate(state: state, shot: command, recordFrames: false)
        XCTAssertEqual(replay.events, shot.result.events)
        XCTAssertEqual(replay.finalState, shot.result.finalState)
    }

    func testZeroTimeBudgetDoesNoSimulationAndDoesNotInventSolution() throws {
        let report = try ShotPlanner.search(for: .straightShot, budget: ShotSearchBudget(maximumDuration: 0))
        XCTAssertEqual(report.simulations, 0)
        XCTAssertEqual(report.termination, .timeLimit)
        XCTAssertTrue(report.suggestions.isEmpty)
    }

    func testZeroSimulationBudgetAppliesBeforeEverySearchPhase() throws {
        let report = try ShotPlanner.search(for: .practice,
            budget: ShotSearchBudget(maximumDuration: 1, maximumSimulations: 0))
        XCTAssertEqual(report.simulations, 0)
        XCTAssertEqual(report.termination, .simulationLimit)
        XCTAssertTrue(report.suggestions.isEmpty)
    }

    func testHardSimulationBudgetAlsoCoversRefinementAndPolishing() throws {
        for count in [1, 2, 7, 20] {
            let report = try ShotPlanner.search(for: syntheticRailCarom(), targetID: 3, pocketID: 5,
                allowedTargetIDs: [3], budget: ShotSearchBudget(maximumDuration: 4, maximumSimulations: count))
            XCTAssertLessThanOrEqual(report.simulations, count)
            for shot in report.suggestions {
                XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 3, pocketID: 5, allowedTargetIDs: [3]))
            }
        }
    }

    func testBreakSearchHonorsSameSimulationBudget() throws {
        let report = try ShotPlanner.search(for: .fullRack, allowedTargetIDs: Set(1...15).subtracting([8]),
            isBreakShot: true, budget: ShotSearchBudget(maximumDuration: 4, maximumSimulations: 2))
        XCTAssertEqual(report.simulations, 2)
        XCTAssertEqual(report.termination, .simulationLimit)
        XCTAssertEqual(report.phases, ["break"])
        for shot in report.suggestions { XCTAssertTrue(ShotPlanner.isValidBreakOutcome(shot.result,
            allowedTargetIDs: Set(1...15).subtracting([8]))) }
    }

    func testTinyElapsedBudgetReturnsWithoutUnboundedOldPlannerPass() throws {
        let start = ProcessInfo.processInfo.systemUptime
        let report = try ShotPlanner.search(for: syntheticRailCarom(), targetID: 3, pocketID: 5,
            allowedTargetIDs: [3], budget: ShotSearchBudget(maximumDuration: 0.000001))
        XCTAssertEqual(report.termination, .timeLimit)
        XCTAssertLessThan(report.simulations, 10)
        // Deliberately generous for a shared CI machine; the guarantee is a
        // checkpoint deadline plus one in-flight engine simulation, not realtime.
        XCTAssertLessThan(ProcessInfo.processInfo.systemUptime - start, 0.5)
    }

    func testEmptyLegalSetAndUnavailableTargetProduceNoFabricatedShot() throws {
        for allowed: Set<Int> in [[], [9]] {
            let report = try ShotPlanner.search(for: .straightShot, allowedTargetIDs: allowed)
            XCTAssertTrue(report.suggestions.isEmpty)
            XCTAssertEqual(report.simulations, 0)
            XCTAssertEqual(report.termination, .completed)
        }
    }

    func testSearchRejectsInvalidPowerRatherThanClampingUntestedInput() {
        for minimum in [-0.1, 1.1, .nan, .infinity] {
            XCTAssertThrowsError(try ShotPlanner.search(for: .straightShot, minimumPower: minimum)) {
                XCTAssertEqual($0 as? BilliardsError, .invalidShot)
            }
        }
    }

    func testCaromAcceptanceRequiresSameTargetLegalFirstContactNoScratchOrEarlyEight() {
        let events: [ShotEvent] = [.ballCollision(first: 0, second: 3), .cushion(ball: 3),
                                   .ballCollision(first: 3, second: 8), .pocket(ball: 3, pocket: 5)]
        let good = outcome(events)
        XCTAssertTrue(ShotPlanner.isValidOutcome(good, targetID: 3, pocketID: 5, method: .carom, allowedTargetIDs: [3]))
        XCTAssertFalse(ShotPlanner.isValidOutcome(good, targetID: 3, pocketID: 5, method: .carom, allowedTargetIDs: [9]))
        XCTAssertFalse(ShotPlanner.isValidOutcome(good, targetID: 8, pocketID: 5, method: .carom, allowedTargetIDs: [8]))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome([.ballCollision(first: 0, second: 8)] + events),
            targetID: 3, pocketID: 5, method: .carom, allowedTargetIDs: [3]))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome(events + [.pocket(ball: 8, pocket: 2)], blackPocketed: true),
            targetID: 3, pocketID: 5, method: .carom, allowedTargetIDs: [3]))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome(events + [.pocket(ball: 0, pocket: 2)], cuePocketed: true),
            targetID: 3, pocketID: 5, method: .carom, allowedTargetIDs: [3]))
        XCTAssertFalse(ShotPlanner.isValidOutcome(outcome([.ballCollision(first: 0, second: 3), .pocket(ball: 3, pocket: 5)]),
            targetID: 3, pocketID: 5, method: .carom, allowedTargetIDs: [3]))
    }

    func testMultiCushionAcceptanceAllowsMixedRailsWithoutChangingLegalRules() {
        let result = outcome([.cushion(ball: 0), .ballCollision(first: 0, second: 3),
                              .cushion(ball: 3), .pocket(ball: 3, pocket: 5)])
        XCTAssertTrue(ShotPlanner.isValidOutcome(result, targetID: 3, pocketID: 5,
                                                 method: .multiCushion, allowedTargetIDs: [3]))
        XCTAssertFalse(ShotPlanner.isValidOutcome(result, targetID: 3, pocketID: 5,
                                                  method: .bank, allowedTargetIDs: [3]))
    }

    func testIncludeBanksFalseRejectsHybridCaromWithActualRailEvents() throws {
        let report = try ShotPlanner.search(for: syntheticRailCarom(), targetID: 3, pocketID: 5,
            includeBanks: false, allowedTargetIDs: [3], budget: ShotSearchBudget(maximumDuration: 0.4))
        for shot in report.suggestions {
            var contacted = false
            for event in shot.result.events {
                if event == .pocket(ball: 3, pocket: 5) { break }
                XCTAssertNotEqual(event, .cushion(ball: 3))
                if !contacted { XCTAssertNotEqual(event, .cushion(ball: 0)) }
                if case let .ballCollision(a, b) = event, a == 0 || b == 0 { contacted = true }
            }
        }
    }

    func testSubsequentPassChangesSamplingWhileRetainingVerifiedResults() throws {
        let state = try approximateVideoState()
        let first = try ShotPlanner.search(for: state, targetID: 3, pocketID: 5, allowedTargetIDs: [3, 5])
        let later = try ShotPlanner.search(for: state, targetID: 3, pocketID: 5, allowedTargetIDs: [3, 5],
            budget: ShotSearchBudget(explorationPass: 2))
        let a = try XCTUnwrap(first.suggestions.first)
        let b = try XCTUnwrap(later.suggestions.first)
        XCTAssertNotEqual(a.shot, b.shot)
        XCTAssertEqual(later.explorationPass, 2)
        XCTAssertFalse(later.phases.contains("ordinary"))
        for shot in first.suggestions + later.suggestions {
            XCTAssertTrue(ShotPlanner.isValidOutcome(shot.result, targetID: 3, pocketID: 5, allowedTargetIDs: [3, 5]))
        }
    }

    func testBlockedLegalTargetStillReachesEverySearchPhaseWithinBudget() throws {
        let table = try nativeTable()
        let cue = Vector2(x: 40, y: 50)
        var balls = [PoolBall(id: 0, position: cue),
                     PoolBall(id: 3, position: Vector2(x: 140, y: 30)),
                     PoolBall(id: 8, position: Vector2(x: 180, y: 70))]
        // Six illegal first-contact balls surround the cue with no legal gap.
        // This explicitly unsolved board tests phase reservation, not pot luck.
        for index in 0..<6 {
            let angle = Double(index) * .pi / 3
            balls.append(PoolBall(id: 9 + index, position: cue +
                Vector2(x: cos(angle), y: sin(angle)) * (2 * table.ballRadius + 0.1)))
        }
        let report = try ShotPlanner.search(for: TableState(table: table, balls: balls),
            allowedTargetIDs: [3], budget: ShotSearchBudget(maximumDuration: 0.12))
        XCTAssertTrue(report.suggestions.isEmpty)
        XCTAssertTrue(report.phases.contains("ordinary"))
        XCTAssertTrue(report.phases.contains("deflections_and_cushions"))
        XCTAssertTrue(report.phases.contains("contact_sweep"))
        XCTAssertGreaterThan(report.simulations, 0)
        XCTAssertLessThan(report.elapsed, 0.5)
    }

    func testCancelledAutomaticSearchThrowsEvenForEmptyLegalTargets() async {
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try ShotPlanner.search(for: .straightShot, allowedTargetIDs: [])
        }
        do { _ = try await task.value; XCTFail("Cancellation must propagate") }
        catch { XCTAssertTrue(error is CancellationError) }
    }

    private func syntheticRailCarom() throws -> TableState {
        // Independent synthetic fixture, selected with seed847123. This is not
        // a fitted or exact reconstruction of the supplied video.
        TableState(table: try nativeTable(), balls: [
            PoolBall(id: 0, position: Vector2(x: 85.48714356433919, y: 73.52250410053013)),
            PoolBall(id: 3, position: Vector2(x: 153.05589750734455, y: 6.491466754951172)),
            PoolBall(id: 8, position: Vector2(x: 184.7191062610723, y: 37.42773021860432))])
    }
    private func approximateVideoState() throws -> TableState {
        TableState(table: try nativeTable(), balls: [
            PoolBall(id: 0, position: Vector2(x: 65.13, y: 96.39)),
            PoolBall(id: 3, position: Vector2(x: 141.68, y: 8.42)),
            PoolBall(id: 5, position: Vector2(x: 26.85, y: 51.34)),
            PoolBall(id: 8, position: Vector2(x: 187.78, y: 44.09)),
            PoolBall(id: 9, position: Vector2(x: 28.26, y: 42.93)),
            PoolBall(id: 10, position: Vector2(x: 135.27, y: 25.45)),
            PoolBall(id: 12, position: Vector2(x: 177.47, y: 5.61)),
            PoolBall(id: 13, position: Vector2(x: 190.02, y: 26.73))])
    }
    private func outcome(_ events: [ShotEvent], cuePocketed: Bool = false, blackPocketed: Bool = false) -> ShotResult {
        ShotResult(finalState: TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 80, y: 70), pocketed: cuePocketed),
            PoolBall(id: 3, position: Vector2(x: 200, y: 100), pocketed: true),
            PoolBall(id: 8, position: Vector2(x: 180, y: 50), pocketed: blackPocketed)]),
            frames: [], traces: [], events: events, duration: 1, settled: true)
    }
    private func nativeTable() throws -> PoolTable {
        // Native coefficients/46-vertex pocket geometry from the unchanged V10
        // recorded fixture, paired with explicit synthetic stationary layouts.
        var table = PoolTable()
        table.ballRadius = 2.9925
        table.pocketRadius = table.ballRadius
        table.ballRestitution = 1
        table.cushionRestitution = 0.804
        table.rollingDeceleration = 8.565354330708661
        table.maximumShotSpeed = 652.6377760519193
        table.nativeDynamics = NativeDynamics(slidingDeceleration: 154.33070866141733,
            equilibriumTimeFactor: 0.0018513119533527696, spinDeceleration: 9.8,
            slidingFrictionCoefficient: 0.2, cushionSpinCoupling: 0.54, logicalFrameTime: 0.005)
        table.nativeGeometry = try JSONDecoder().decode(NativeTableGeometry.self, from: Data(Self.geometryJSON.utf8))
        return table
    }
    private static let geometryJSON = """
{"cushionVertices":[{"x":0.0,"y":7.874015748031496},{"x":-7.795275590551186,"y":-0.4724409448818853},{"x":-8.818897637795267,"y":-4.488188976377955},{"x":-7.637795275590543,"y":-7.637795275590554},{"x":-4.488188976377944,"y":-8.818897637795278},{"x":-0.4724409448818853,"y":-7.795275590551186},{"x":7.874015748031496,"y":0.0},{"x":93.85826771653544,"y":0.0},{"x":95.1968503937008,"y":-4.0157480314960585},{"x":95.51181102362204,"y":-7.244094488188979},{"x":97.08661417322836,"y":-9.370078740157485},{"x":100.0,"y":-10.393700787401578},{"x":102.91338582677164,"y":-9.370078740157485},{"x":104.48818897637796,"y":-7.244094488188979},{"x":104.80314960629921,"y":-4.0157480314960585},{"x":106.14173228346458,"y":0.0},{"x":192.1259842519685,"y":0.0},{"x":200.4724409448819,"y":-7.795275590551186},{"x":204.48818897637796,"y":-8.818897637795278},{"x":207.63779527559055,"y":-7.637795275590554},{"x":208.8188976377953,"y":-4.488188976377955},{"x":207.79527559055117,"y":-0.4724409448818853},{"x":200.0,"y":7.874015748031496},{"x":200.0,"y":92.1259842519685},{"x":207.79527559055117,"y":100.4724409448819},{"x":208.8188976377953,"y":104.48818897637796},{"x":207.63779527559055,"y":107.63779527559055},{"x":204.48818897637796,"y":108.81889763779527},{"x":200.4724409448819,"y":107.79527559055119},{"x":192.1259842519685,"y":100.0},{"x":106.14173228346458,"y":100.0},{"x":104.80314960629921,"y":104.01574803149606},{"x":104.48818897637796,"y":107.24409448818898},{"x":102.91338582677164,"y":109.3700787401575},{"x":100.0,"y":110.39370078740157},{"x":97.08661417322836,"y":109.3700787401575},{"x":95.51181102362204,"y":107.24409448818898},{"x":95.1968503937008,"y":104.01574803149606},{"x":93.85826771653544,"y":100.0},{"x":7.874015748031496,"y":100.0},{"x":-0.4724409448818853,"y":107.79527559055119},{"x":-4.488188976377944,"y":108.81889763779527},{"x":-7.637795275590543,"y":107.63779527559055},{"x":-8.818897637795267,"y":104.48818897637796},{"x":-7.795275590551186,"y":100.4724409448819},{"x":0.0,"y":92.1259842519685}],"pockets":[{"id":0,"center":{"x":-2.992125984251978,"y":-2.9921259842519663},"aimPoint":{"x":1.4620899602302142,"y":1.4620899602302253},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":1,"center":{"x":100.0,"y":-6.692913385826772},"aimPoint":{"x":100.0,"y":-0.3937007874015748},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":2,"center":{"x":202.992125984252,"y":-2.9921259842519663},"aimPoint":{"x":198.5379100397698,"y":1.4620899602302253},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":3,"center":{"x":-2.992125984251978,"y":102.99212598425198},"aimPoint":{"x":1.4620899602302142,"y":98.53791003976978},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":4,"center":{"x":100.0,"y":106.69291338582678},"aimPoint":{"x":100.0,"y":100.39370078740158},"radius":2.9925,"attractionRadius":6.299212598425197},{"id":5,"center":{"x":202.992125984252,"y":102.99212598425198},"aimPoint":{"x":198.5379100397698,"y":98.53791003976978},"radius":2.9925,"attractionRadius":6.299212598425197}],"pocketAttraction":120.0}
"""
}
