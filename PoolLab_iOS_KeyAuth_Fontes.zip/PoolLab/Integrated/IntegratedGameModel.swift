import Foundation
import UIKit
import Combine
import PoolLabCore

/// All game-runtime calls stay on the main thread. Only copied scalar table
/// states cross into the cancellable background physics tasks.
@MainActor
final class IntegratedGameModel: ObservableObject {
    let authorization: AppModel
    @Published private(set) var status = "Ative sua licença para ler a mesa da partida."
    @Published private(set) var hasTable = false
    @Published private(set) var isPlayerTurn = false
    @Published private(set) var isMoving = false
    @Published private(set) var angleDegrees = 270.0
    @Published private(set) var power = 0.45
    @Published private(set) var isPredicting = false
    @Published private(set) var isPlanning = false
    @Published private(set) var suggestions: [ShotSuggestion] = []
    @Published private(set) var showAllPaths = true
    @Published private(set) var ballCount = 0
    @Published private(set) var previewDuration: Double?

    var onOverlayChange: (() -> Void)?
    private var isForeground = false
    private var generation: UInt64 = 0
    private var captureTimer: Timer?
    private var authorizationObserver: AnyCancellable?
    private var calculation: Task<Void, Never>?
    private var snapshot: PLGameSnapshot?
    private var tableState: TableState?
    private var traces: [BallTrace] = []
    private var lastAuthorized = false

    var isAuthorized: Bool { isForeground && authorization.canUseModules }
    var canCalculate: Bool { isAuthorized && hasTable && !isMoving && tableState?.cueBall != nil }
    var canApplyAim: Bool { canCalculate && isPlayerTurn }

    init(authorization: AppModel) {
        self.authorization = authorization
        authorizationObserver = authorization.objectWillChange.sink { [weak self] _ in
            // objectWillChange is emitted before the @Published value changes.
            Task { @MainActor [weak self] in self?.authorizationChanged() }
        }
    }

    func becameActive() {
        guard !isForeground else { poll(); return }
        isForeground = true
        startTimer()
        Task { [weak self] in
            guard let self else { return }
            await self.authorization.becameActive()
            guard self.isForeground else { return }
            self.authorizationChanged()
            self.poll()
        }
    }

    func becameInactive() {
        isForeground = false
        captureTimer?.invalidate()
        captureTimer = nil
        authorization.becameInactive()
        lastAuthorized = false
        clearBoard(message: "Leitura pausada enquanto o aplicativo está inativo.")
    }

    func authorizationChanged() {
        let allowed = isAuthorized
        if !allowed {
            if lastAuthorized || hasTable || !traces.isEmpty || calculation != nil {
                clearBoard(message: "Acesso pausado. Confirme sua licença para continuar.")
            }
        } else if !lastAuthorized {
            lastAuthorized = true
            poll()
        }
        lastAuthorized = allowed
    }

    func setAngle(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        angleDegrees = min(360, max(0, value))
        requestPrediction()
    }

    func setPower(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        power = min(1, max(0.03, value))
        requestPrediction()
    }

    func setShowAllPaths(_ value: Bool) {
        guard isAuthorized else { return }
        showAllPaths = value
        onOverlayChange?()
    }

    func refresh() {
        guard isAuthorized else { return }
        poll()
        requestPrediction()
    }

    func recommend() {
        guard canCalculate, let state = tableState else { return }
        cancelCalculation(clearSuggestions: true)
        let operation = generation
        isPlanning = true
        status = "Comparando trajetórias da mesa atual…"
        calculation = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try ShotPlanner.suggestions(for: state, includeBanks: true, limit: 4)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, self.accepts(operation, state: state) else { return }
                self.isPlanning = false
                self.calculation = nil
                self.suggestions = found
                self.status = found.isEmpty ? "Nenhuma opção encontrada pelo modelo nesta posição." : "Escolha uma opção para prever o percurso antes de aplicar a mira."
            } catch {
                guard let self, self.accepts(operation, state: state) else { return }
                self.isPlanning = false
                self.calculation = nil
                self.status = error.localizedDescription
            }
        }
    }

    func selectSuggestion(_ suggestion: ShotSuggestion) {
        guard canCalculate, suggestions.contains(where: { $0.id == suggestion.id }) else { return }
        let value = (suggestion.shot.angleRadians * 180 / .pi).truncatingRemainder(dividingBy: 360)
        angleDegrees = value < 0 ? value + 360 : value
        power = suggestion.shot.power
        requestPrediction()
    }

    func applyAim() {
        guard canApplyAim, let state = tableState else { return }
        do {
            // Re-read immediately before writing to reject an out-of-date plan.
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            guard current.playerTurn, !normalized.moving, normalized.state == state,
                  isAuthorized else {
                clearBoard(message: "A partida mudou. Atualize a leitura e escolha novamente a tacada.")
                return
            }
            // Core y increases downward. The game's physical y increases upward.
            try PLRuntimeBridge.apply(angle: -angleDegrees * .pi / 180, power: power)
            status = "Direção e força aplicadas. Execute a tacada pelos controles do jogo."
        } catch {
            status = "Não foi possível aplicar a mira: \(error.localizedDescription)"
        }
    }

    /// Returns window-space paths only while the captured game view is still in
    /// the same active scene. Affine corner mapping handles scale and rotation.
    func overlayPaths(in window: UIWindow) -> [(Int, [CGPoint])] {
        guard isAuthorized, hasTable, !isMoving,
              let snapshot, let state = tableState,
              let sourceWindow = snapshot.coordinateView.window,
              Self.isActive(sourceWindow), sourceWindow.windowScene === window.windowScene else { return [] }
        let view = snapshot.coordinateView
        let a = view.convert(snapshot.tableTopLeft, to: window)
        let b = view.convert(snapshot.tableTopRight, to: window)
        let c = view.convert(snapshot.tableBottomLeft, to: window)
        guard [a, b, c].allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return [] }
        return traces.filter { showAllPaths || $0.id == 0 }.compactMap { trace in
            let points = trace.points.map { point -> CGPoint in
                let u = CGFloat(point.x / state.table.width)
                let v = CGFloat(point.y / state.table.height)
                return CGPoint(x: a.x + (b.x - a.x) * u + (c.x - a.x) * v,
                               y: a.y + (b.y - a.y) * u + (c.y - a.y) * v)
            }
            guard points.count > 1, points.allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return nil }
            return (trace.id, points)
        }
    }

    private func startTimer() {
        guard captureTimer == nil else { return }
        let timer = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.poll() }
        }
        captureTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    private func poll() {
        guard isAuthorized else { authorizationChanged(); return }
        do {
            let captured = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(captured)
            guard let sourceWindow = captured.coordinateView.window, Self.isActive(sourceWindow) else {
                clearBoard(message: "A mesa da partida ainda não está visível.")
                return
            }
            if normalized.moving {
                clearBoard(message: "Bolas em movimento. Aguardando a mesa parar.")
                isMoving = true
                return
            }
            let changed = tableState != normalized.state || isPlayerTurn != captured.playerTurn
            snapshot = captured
            tableState = normalized.state
            hasTable = true
            isMoving = false
            isPlayerTurn = captured.playerTurn
            ballCount = normalized.state.balls.count
            if changed {
                cancelCalculation(clearSuggestions: true)
                status = captured.playerTurn ? "Mesa lida. Ajuste a previsão ou procure uma sugestão." : "Mesa lida. Aguarde sua vez para aplicar a mira."
                requestPrediction()
            } else {
                // Reproject even when only the game viewport changes.
                onOverlayChange?()
            }
        } catch {
            clearBoard(message: "Leitura indisponível: \(error.localizedDescription)")
        }
    }

    private func requestPrediction() {
        guard canCalculate, let state = tableState else { return }
        cancelCalculation(clearSuggestions: false)
        let operation = generation
        let shot = ShotParameters(angleRadians: angleDegrees * .pi / 180, power: power)
        isPredicting = true
        calculation = Task { [weak self] in
            do {
                try await Task.sleep(nanoseconds: 180_000_000)
                try Task.checkCancellation()
                let worker = Task.detached(priority: .userInitiated) {
                    try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: true)
                }
                let result = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, self.accepts(operation, state: state) else { return }
                self.traces = result.traces
                self.previewDuration = result.duration
                self.isPredicting = false
                self.calculation = nil
                if !result.settled { self.status = "A previsão atingiu o limite de tempo; o percurso mostrado é parcial." }
                self.onOverlayChange?()
            } catch {
                guard let self, self.accepts(operation, state: state) else { return }
                self.isPredicting = false
                self.calculation = nil
                self.status = error.localizedDescription
            }
        }
    }

    private func accepts(_ operation: UInt64, state: TableState) -> Bool {
        operation == generation && isAuthorized && !Task.isCancelled && tableState == state && !isMoving
    }

    private func cancelCalculation(clearSuggestions: Bool) {
        generation &+= 1
        calculation?.cancel()
        calculation = nil
        isPredicting = false
        isPlanning = false
        traces = []
        previewDuration = nil
        if clearSuggestions { suggestions = [] }
        onOverlayChange?()
    }

    private func clearBoard(message: String) {
        cancelCalculation(clearSuggestions: true)
        snapshot = nil
        tableState = nil
        hasTable = false
        isPlayerTurn = false
        isMoving = false
        ballCount = 0
        if status != message { status = message }
    }

    private static func normalized(_ snapshot: PLGameSnapshot) throws -> (state: TableState, moving: Bool) {
        let values = [snapshot.originX, snapshot.originY, snapshot.width, snapshot.height]
        guard values.allSatisfy(\.isFinite), snapshot.width > 0, snapshot.height > 0,
              !snapshot.balls.isEmpty, snapshot.balls.count <= 16 else {
            throw CaptureError.invalidGeometry
        }
        let scale = 200 / snapshot.width
        let radii = snapshot.balls.map { $0.radius * scale }
        guard radii.allSatisfy({ $0.isFinite && $0 > 0 }) else { throw CaptureError.invalidGeometry }
        let radius = radii.reduce(0, +) / Double(radii.count)
        guard radii.allSatisfy({ abs($0 - radius) <= 0.05 * radius }) else { throw CaptureError.invalidGeometry }
        var table = PoolTable()
        table.width = 200
        table.height = snapshot.height * scale
        table.ballRadius = radius
        table.pocketRadius = radius * 2.18
        var moving = false
        let balls: [PoolBall] = snapshot.balls.map { ball in
            if !ball.vx.isFinite || !ball.vy.isFinite || hypot(ball.vx, ball.vy) * scale > 0.002 { moving = true }
            return PoolBall(id: ball.number,
                            position: Vector2(x: (ball.x - snapshot.originX) * scale,
                                              y: (snapshot.originY + snapshot.height - ball.y) * scale))
        }
        let state = TableState(table: table, balls: balls)
        if !moving { try BilliardsEngine.validate(state) }
        return (state, moving)
    }

    private static func isActive(_ window: UIWindow) -> Bool {
        guard !window.isHidden else { return false }
        if let scene = window.windowScene { return scene.activationState == .foregroundActive }
        return UIApplication.shared.applicationState == .active
    }

    private enum CaptureError: LocalizedError {
        case invalidGeometry
        var errorDescription: String? { "A geometria lida da partida não corresponde a uma mesa válida." }
    }
}
