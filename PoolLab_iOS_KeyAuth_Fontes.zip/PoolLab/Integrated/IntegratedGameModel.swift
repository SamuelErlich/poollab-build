import Foundation
import UIKit
import Combine
import PoolLabCore

/// Runtime calls remain on the main thread. The two independent workers only
/// receive copied values: following the cue never cancels the shot planner.
@MainActor
final class IntegratedGameModel: ObservableObject {
    let authorization: AppModel
    @Published private(set) var status = "Ative sua licença para ler a mesa da partida."
    @Published private(set) var hasTable = false
    @Published private(set) var isPlayerTurn = false
    @Published private(set) var isMoving = false
    @Published private(set) var angleDegrees = 270.0
    @Published private(set) var power = 0.45
    @Published private(set) var aimAvailable = false
    @Published private(set) var isCalibrated = false
    @Published private(set) var hasNativePhysics = false
    @Published private(set) var followGameAim = true
    @Published private(set) var showTrajectories = true
    @Published private(set) var showAllPaths = true
    @Published private(set) var showFinalPositions = true
    @Published private(set) var showFinalNumbers = true
    @Published private(set) var pathWidth = 2.0
    @Published private(set) var pathOpacity = 0.9
    @Published private(set) var pathColorMode = "balls"
    @Published private(set) var isPredicting = false
    @Published private(set) var isPlanning = false
    @Published private(set) var suggestions: [ShotSuggestion] = []
    @Published private(set) var ballCount = 0
    @Published private(set) var previewDuration: Double?
    @Published private(set) var autoPlayEnabled = false
    @Published private(set) var isWaitingForShot = false
    @Published private(set) var autoShotAvailable = false
    @Published private(set) var autoShotUnavailableReason = "Entre em uma partida para conferir os controles."
    @Published private(set) var automationStatus = "Jogo automático desligado."
    @Published private(set) var blockInterstitialAds = false
    @Published private(set) var autoQueueEnabled = false
    @Published private(set) var queueStatus = "Próxima partida automática desligada."
    @Published private(set) var isLuckyShot = false
    @Published private(set) var luckySuggestion: LuckyShotSuggestion?
    @Published private(set) var luckyStatus = "Aguardando o alvo da Lucky Shot."
    @Published private(set) var singleShotRequested = false

    var onOverlayChange: (() -> Void)?
    private var isForeground = false
    private var captureTimer: Timer?
    private var authorizationObserver: AnyCancellable?
    private var predictionTask: Task<Void, Never>?
    private var plannerTask: Task<Void, Never>?
    private var predictionGeneration: UInt64 = 0
    private var plannerGeneration: UInt64 = 0
    private var planningPurpose: PlanningPurpose?
    private var snapshot: PLGameSnapshot?
    private var tableState: TableState?
    private var traces: [BallTrace] = []
    private var finalBalls: [PoolBall] = []
    private var legalTargets: Set<Int> = []
    private var runtimeCanShoot = false
    private var lastAuthorized = false
    private var stableSince: TimeInterval?
    private var shotSubmittedAt: TimeInterval?
    // Kept after a timeout/error. An uncertain command must never be repeated
    // on an unchanged table merely because the user toggles the switch again.
    private var lastSubmittedState: TableState?
    private var attemptedQueueTokens: Set<String> = []
    private struct QueueTransition {
        let token: String
        let deadline: TimeInterval
        var submitted = false
        var observedNewMatch = false
    }
    private var queueTransition: QueueTransition?
    private let queueTransitionTimeout: TimeInterval = 30
    private let styles = UserDefaults.standard
    private let stylePrefix = "PoolLab.Integrated.Overlay."
    private let minimumStableTime: TimeInterval = 0.65
    private let shotStartTimeout: TimeInterval = 4

    private enum PlanningPurpose { case suggestions, applyAim, singleShot, autoPlay, luckyShot }
    var isAuthorized: Bool { isForeground && authorization.canUseModules }
    var canCalculate: Bool { isAuthorized && hasTable && isCalibrated && !isMoving && tableState?.cueBall != nil }
    var canApplyAim: Bool { canCalculate && isPlayerTurn && !isWaitingForShot }
    var canRecommend: Bool { canCalculate && !legalTargets.isEmpty && !isWaitingForShot }
    var canRequestAutoAim: Bool { canRecommend && canApplyAim && !isPlanning && !autoPlayEnabled && !singleShotRequested }
    var canRequestAutoShot: Bool {
        canRecommend && isPlayerTurn && runtimeCanShoot && autoShotAvailable
            && !isPlanning && !autoPlayEnabled && !singleShotRequested && tableState != lastSubmittedState
    }
    var canEnableAutoPlay: Bool { isAuthorized && hasTable && autoShotAvailable }
    var canCalculateLuckyShot: Bool {
        canCalculate && isLuckyShot && snapshot?.goldenTargetAvailable == true && !isPlanning && !isWaitingForShot
    }

    init(authorization: AppModel) {
        self.authorization = authorization
        showTrajectories = boolStyle("paths", fallback: true)
        showAllPaths = boolStyle("allPaths", fallback: true)
        showFinalPositions = boolStyle("endpoints", fallback: true)
        showFinalNumbers = boolStyle("numbers", fallback: true)
        pathWidth = numberStyle("width", fallback: 2, range: 1...4)
        pathOpacity = numberStyle("opacity", fallback: 0.9, range: 0.3...1)
        let storedColor = styles.string(forKey: stylePrefix + "color") ?? "balls"
        pathColorMode = ["balls", "mint", "white"].contains(storedColor) ? storedColor : "balls"
        authorizationObserver = authorization.objectWillChange.sink { [weak self] _ in
            Task { @MainActor [weak self] in self?.authorizationChanged() }
        }
    }

    func becameActive() {
        guard !isForeground else { poll(); return }
        isForeground = true
        startTimer()
        Task { [weak self] in
            guard let self else { return }
            await self.authorization.becameActive()
            guard self.isForeground else { return }
            self.authorizationChanged()
            self.poll()
        }
    }

    func becameInactive() {
        isForeground = false
        captureTimer?.invalidate()
        captureTimer = nil
        authorization.becameInactive()
        lastAuthorized = false
        clearBoard(message: "Leitura e jogo automático pausados enquanto o aplicativo está inativo.")
    }

    func authorizationChanged() {
        let allowed = isAuthorized
        if !allowed {
            if lastAuthorized || hasTable || predictionTask != nil || plannerTask != nil || autoPlayEnabled || autoQueueEnabled || blockInterstitialAds {
                clearBoard(message: "Acesso pausado. Confirme sua licença para continuar.")
            }
        } else if !lastAuthorized {
            lastAuthorized = true
            poll()
        }
        lastAuthorized = allowed
    }

    func setAutoQueue(_ value: Bool) {
        guard !value || isAuthorized else { return }
        if !value, queueTransition != nil {
            stopAutomation(message: "Retomada automática cancelada junto com a próxima partida.")
        }
        autoQueueEnabled = value
        queueStatus = value ? "Ao terminar, entrar novamente na mesma mesa quando o jogo permitir." : "Próxima partida automática desligada."
        if value { pollQueue() }
    }

    private func pollQueue() {
        guard isAuthorized else { return }
        do {
            // Keep observing the current match even while Auto Queue is off;
            // the bridge requires that evidence before accepting a result.
            let state = try PLQueueBridge.capture()
            if let transition = queueTransition {
                if ProcessInfo.processInfo.systemUptime >= transition.deadline {
                    autoQueueEnabled = false
                    queueStatus = "A próxima mesa não ficou pronta em 30 segundos. Confira a tela do jogo."
                    stopAutomation(message: "Tempo de espera da próxima partida esgotado. Automático desligado.")
                    return
                }
                if transition.submitted, !state.isResultScreen, !state.resultToken.isEmpty,
                   state.resultToken != transition.token {
                    queueTransition?.observedNewMatch = true
                }
            }
            guard autoQueueEnabled else { return }
            if state.isResultScreen, !state.resultToken.isEmpty, autoPlayEnabled, queueTransition == nil {
                // The bridge only issues this token after observing an active
                // match. An arbitrary missing table cannot arm this exception.
                queueTransition = QueueTransition(token: state.resultToken,
                    deadline: ProcessInfo.processInfo.systemUptime + queueTransitionTimeout)
            }
            guard state.isResultScreen else {
                queueStatus = "Aguardando o resultado da partida atual."
                return
            }
            guard state.ready, !state.resultToken.isEmpty else {
                queueStatus = state.unavailableReason
                return
            }
            guard !attemptedQueueTokens.contains(state.resultToken) else {
                queueStatus = "Entrada já solicitada para este resultado. Aguardando a próxima partida."
                return
            }
            attemptedQueueTokens.insert(state.resultToken)
            try PLQueueBridge.startNextMatch(token: state.resultToken)
            if queueTransition?.token == state.resultToken { queueTransition?.submitted = true }
            queueStatus = "Próxima partida solicitada na mesma mesa."
        } catch {
            if queueTransition != nil { stopAutomation(message: "Retomada interrompida: \(error.localizedDescription)") }
            guard autoQueueEnabled else { return }
            autoQueueEnabled = false
            queueStatus = "Próxima partida automática interrompida: \(error.localizedDescription)"
        }
    }

    func setBlockInterstitialAds(_ value: Bool) {
        guard !value || isAuthorized else { return }
        do {
            try PLAdControl.setBlocking(enabled: value)
            blockInterstitialAds = value
        } catch {
            status = "Não foi possível alterar os anúncios: \(error.localizedDescription)"
        }
    }

    func setAngle(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        followGameAim = false
        angleDegrees = min(360, max(0, value))
        requestPrediction()
    }

    func setPower(_ value: Double) {
        guard isAuthorized, value.isFinite else { return }
        followGameAim = false
        power = min(1, max(0, value))
        requestPrediction()
    }

    func setFollowGameAim(_ value: Bool) {
        guard isAuthorized else { return }
        followGameAim = value
        if value { poll() }
        requestPrediction()
    }

    func setShowTrajectories(_ value: Bool) { showTrajectories = value; saveStyle(value, "paths") }
    func setShowAllPaths(_ value: Bool) { showAllPaths = value; saveStyle(value, "allPaths") }
    func setShowFinalPositions(_ value: Bool) { showFinalPositions = value; saveStyle(value, "endpoints") }
    func setShowFinalNumbers(_ value: Bool) { showFinalNumbers = value; saveStyle(value, "numbers") }
    func setPathWidth(_ value: Double) {
        guard value.isFinite else { return }; pathWidth = min(4, max(1, value)); saveStyle(pathWidth, "width")
    }
    func setPathOpacity(_ value: Double) {
        guard value.isFinite else { return }; pathOpacity = min(1, max(0.3, value)); saveStyle(pathOpacity, "opacity")
    }
    func setPathColorMode(_ value: String) {
        guard ["balls", "mint", "white"].contains(value) else { return }
        pathColorMode = value; saveStyle(value, "color")
    }

    func refresh() {
        guard isAuthorized else { return }
        poll()
        requestPrediction()
    }

    func powerLabel(for suggestion: ShotSuggestion) -> String {
        guard let value = try? GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power) else { return "indisponível" }
        return "\(Int((value * 100).rounded()))%"
    }

    func recommend() { startPlanning(.suggestions) }
    func autoAim() { guard canRequestAutoAim else { return }; startPlanning(.applyAim) }

    func calculateLuckyShot() {
        guard canCalculateLuckyShot, let state = tableState, let snapshot else { return }
        let scale = 200 / snapshot.width
        let target = Vector2(x: (snapshot.goldenTargetX - snapshot.originX) * scale,
                             y: (snapshot.originY + snapshot.height - snapshot.goldenTargetY) * scale)
        let ball = snapshot.goldenBallNumber
        let obstacles = Set(state.balls.map(\.id)).subtracting([0, ball])
        cancelPlanner(clearSuggestions: true)
        let operation = plannerGeneration
        planningPurpose = .luckyShot
        isPlanning = true
        luckyStatus = "Procurando uma direção e força para aproximar a bola do alvo…"
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try LuckyShotPlanner.suggestion(for: state, targetBallID: ball, targetCenter: target, obstacleIDs: obstacles)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.plannerGeneration, self.accepts(state), self.isLuckyShot else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.luckySuggestion = found
                guard let found else {
                    self.luckyStatus = "Nenhuma opção encontrada sem contato com os obstáculos. Ajuste a mira manualmente."
                    return
                }
                guard self.setPreview(found.shot) else { return }
                self.followGameAim = false
                self.requestPrediction()
                self.luckyStatus = "Sugestão calculada para aproximar a bola do centro. Confira a previsão antes de aplicar."
            } catch {
                guard let self, operation == self.plannerGeneration, self.accepts(state) else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.luckyStatus = "Não foi possível calcular a Lucky Shot: \(error.localizedDescription)"
            }
        }
    }

    func applyLuckyAim() {
        guard isLuckyShot, canApplyAim, let luckySuggestion, setPreview(luckySuggestion.shot) else { return }
        applyAim()
    }

    func autoShot() {
        guard canRequestAutoShot else { return }
        singleShotRequested = true
        automationStatus = "Aguardando a mesa estabilizar para uma tacada."
        advanceAutomation()
    }

    func setAutoPlay(_ enabled: Bool) {
        if !enabled {
            stopAutomation(message: isWaitingForShot ? "Automático desligado. A tacada já enviada continua no jogo." : "Jogo automático desligado.")
            return
        }
        guard canEnableAutoPlay else {
            automationStatus = autoShotUnavailableReason
            return
        }
        cancelPlanner(clearSuggestions: false)
        autoPlayEnabled = true
        singleShotRequested = false
        automationStatus = "Automático ligado. Aguardando sua vez e a mesa parar."
        advanceAutomation()
    }

    func selectSuggestion(_ suggestion: ShotSuggestion) {
        guard canCalculate, !autoPlayEnabled, !isWaitingForShot,
              suggestions.contains(where: { $0.id == suggestion.id }) else { return }
        followGameAim = false
        guard setPreview(suggestion.shot) else { return }
        requestPrediction()
    }

    func applyAim() {
        guard canApplyAim, let state = tableState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            guard current.playerTurn, normalized.calibrated, !normalized.moving, normalized.state == state,
                  current.coordinateView === snapshot?.coordinateView, isAuthorized else {
                throw CaptureError.changedTable
            }
            try PLRuntimeBridge.apply(angle: -angleDegrees * .pi / 180, power: power)
            followGameAim = true
            status = "Direção e força aplicadas. Você pode executar a tacada no jogo."
            poll()
        } catch {
            stopAutomation(message: "Mira não aplicada: \(error.localizedDescription)")
            status = automationStatus
        }
    }

    /// Overlay data is always projected from the current game's view, even when
    /// the menu is closed or the device rotates. Pocketed endpoints are marked
    /// separately; incomplete simulations never claim a final resting position.
    func overlayPaths(in window: UIWindow) -> [(Int, [CGPoint])] {
        guard showTrajectories, let projection = projection(in: window) else { return [] }
        return traces.filter { showAllPaths || $0.id == 0 }.compactMap { trace in
            let points = trace.points.map(projection.point)
            guard points.count > 1, points.allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return nil }
            return (trace.id, points)
        }
    }

    func overlayFinalPositions(in window: UIWindow) -> [(Int, CGPoint, CGFloat, Bool)] {
        guard showFinalPositions, let projection = projection(in: window), let state = tableState else { return [] }
        let radius = CGFloat(state.table.ballRadius) * projection.scale
        return finalBalls.filter { showAllPaths || $0.id == 0 }.compactMap { ball in
            let point = projection.point(ball.position)
            guard point.x.isFinite, point.y.isFinite, radius.isFinite else { return nil }
            return (ball.id, point, max(3, radius), ball.pocketed)
        }
    }

    func overlayLuckyTarget(in window: UIWindow) -> CGPoint? {
        guard isLuckyShot, let snapshot, snapshot.goldenTargetAvailable,
              let projection = projection(in: window, prediction: false) else { return nil }
        let scale = 200 / snapshot.width
        let point = projection.point(Vector2(x: (snapshot.goldenTargetX - snapshot.originX) * scale,
                                             y: (snapshot.originY + snapshot.height - snapshot.goldenTargetY) * scale))
        return point.x.isFinite && point.y.isFinite ? point : nil
    }

    private func projection(in window: UIWindow, prediction: Bool = true) -> (point: (Vector2) -> CGPoint, scale: CGFloat)? {
        guard isAuthorized, hasTable, (!prediction || (!isMoving && !(followGameAim && !aimAvailable))),
              let snapshot, let state = tableState, let sourceWindow = snapshot.coordinateView.window,
              Self.isActive(sourceWindow), sourceWindow.windowScene === window.windowScene else { return nil }
        let source = snapshot.coordinateView
        let a = source.convert(snapshot.tableTopLeft, to: window)
        let b = source.convert(snapshot.tableTopRight, to: window)
        let c = source.convert(snapshot.tableBottomLeft, to: window)
        guard [a, b, c].allSatisfy({ $0.x.isFinite && $0.y.isFinite }) else { return nil }
        let scaleX = hypot(b.x - a.x, b.y - a.y) / CGFloat(state.table.width)
        let scaleY = hypot(c.x - a.x, c.y - a.y) / CGFloat(state.table.height)
        return ({ point in
            let u = CGFloat(point.x / state.table.width), v = CGFloat(point.y / state.table.height)
            return CGPoint(x: a.x + (b.x - a.x) * u + (c.x - a.x) * v,
                           y: a.y + (b.y - a.y) * u + (c.y - a.y) * v)
        }, (scaleX + scaleY) / 2)
    }

    private func startTimer() {
        guard captureTimer == nil else { return }
        let timer = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.poll() }
        }
        captureTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    private func poll() {
        guard isAuthorized else { authorizationChanged(); return }
        pollQueue()
        if let transition = queueTransition, !transition.observedNewMatch {
            clearBoard(message: "Aguardando a próxima partida confirmada pelo jogo.", preserveQueueIntent: true)
            return
        }
        do {
            let captured = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(captured)
            guard let sourceWindow = captured.coordinateView.window, Self.isActive(sourceWindow) else {
                clearBoard(message: "A mesa da partida ainda não está visível.", preserveQueueIntent: queueTransition != nil)
                return
            }
            if queueTransition?.observedNewMatch == true {
                // A new bridge-issued match token plus a visible, valid table
                // allows resumption. The stable-time gate starts again below.
                queueTransition = nil
                lastSubmittedState = nil
                stableSince = nil
            }
            let allowed = Set(captured.legalTargetNumbers.map { $0.intValue })
            let changed = tableState != normalized.state || isPlayerTurn != captured.playerTurn
                || legalTargets != allowed || snapshot?.coordinateView !== captured.coordinateView
                || snapshot?.goldenShot != captured.goldenShot || snapshot?.goldenTargetAvailable != captured.goldenTargetAvailable
                || snapshot?.goldenTargetX != captured.goldenTargetX || snapshot?.goldenTargetY != captured.goldenTargetY
            let wasMoving = isMoving
            let wasAimAvailable = aimAvailable
            snapshot = captured
            tableState = normalized.state
            hasTable = true
            isCalibrated = normalized.calibrated
            hasNativePhysics = normalized.nativePhysics
            isMoving = normalized.moving
            isLuckyShot = captured.goldenShot
            isPlayerTurn = captured.playerTurn
            ballCount = normalized.state.balls.count
            legalTargets = allowed
            runtimeCanShoot = captured.canShoot
            autoShotAvailable = captured.autoShotAvailable && normalized.calibrated && normalized.nativePhysics
            autoShotUnavailableReason = normalized.calibrationIssue ?? captured.autoShotUnavailableReason
            aimAvailable = captured.aimAvailable && captured.aimAngle.isFinite
                && captured.cuePower.isFinite && (0...1).contains(captured.cuePower)

            // A command is released only after observed movement or a turn
            // transition. A timeout alone never permits resending it.
            if isMoving || !isPlayerTurn {
                lastSubmittedState = nil
                if isWaitingForShot {
                    isWaitingForShot = false
                    shotSubmittedAt = nil
                    automationStatus = autoPlayEnabled ? "Tacada iniciada. Aguardando as bolas pararem." : "Tacada iniciada no jogo."
                }
            }
            if isMoving {
                stableSince = nil
                cancelPrediction(clearOverlay: true)
                cancelPlanner(clearSuggestions: true)
                if singleShotRequested { stopAutomation(message: "A mesa mudou antes da tacada. Solicite novamente quando parar.") }
                status = "Bolas em movimento. Aguardando a mesa parar."
                return
            }
            if !normalized.calibrated {
                cancelPrediction(clearOverlay: true)
                cancelPlanner(clearSuggestions: true)
                let reason = normalized.calibrationIssue ?? "Calibração da partida indisponível."
                stopAutomation(message: reason)
                status = reason
                onOverlayChange?()
                return
            }
            if changed || wasMoving {
                stableSince = ProcessInfo.processInfo.systemUptime
                cancelPrediction(clearOverlay: true)
                cancelPlanner(clearSuggestions: true)
                status = isPlayerTurn ? "Mesa lida. As linhas acompanham a mira do jogo." : "Mesa lida. Aguardando sua vez."
            }
            if stableSince == nil { stableSince = ProcessInfo.processInfo.systemUptime }
            var aimChanged = false
            if followGameAim {
                if aimAvailable {
                    let angle = Self.degrees(-captured.aimAngle)
                    aimChanged = abs(angle - angleDegrees) > 0.03 || abs(captured.cuePower - power) > 0.0005
                    angleDegrees = angle
                    power = captured.cuePower
                } else {
                    cancelPrediction(clearOverlay: true)
                    status = "Mira do jogo indisponível nesta etapa. Use a previsão manual ou aguarde sua vez."
                }
            }
            if let issue = normalized.calibrationIssue { status = issue }
            if changed || wasMoving || aimChanged || (!wasAimAvailable && aimAvailable) { requestPrediction() }
            else { onOverlayChange?() }
            if isWaitingForShot, let sentAt = shotSubmittedAt,
               ProcessInfo.processInfo.systemUptime - sentAt > shotStartTimeout {
                isWaitingForShot = false
                shotSubmittedAt = nil
                stopAutomation(message: "O jogo não confirmou movimento após a tacada. Automático desligado; confira os controles da partida.")
                return
            }
            if isPlayerTurn && !autoShotAvailable && (autoPlayEnabled || singleShotRequested) {
                stopAutomation(message: autoShotUnavailableReason)
                return
            }
            advanceAutomation()
        } catch {
            let runtimeError = error as NSError
            let expectedTransition = runtimeError.domain == "PoolLab.RuntimeBridge"
                && [4, 5, 20, 21, 24, 32, 33, 35, 37].contains(runtimeError.code)
            clearBoard(message: "Leitura indisponível: \(error.localizedDescription)",
                       preserveQueueIntent: queueTransition != nil && expectedTransition)
        }
    }

    private func startPlanning(_ purpose: PlanningPurpose) {
        guard canRecommend, let state = tableState else { return }
        if purpose != .suggestions && !canApplyAim { return }
        cancelPlanner(clearSuggestions: true)
        let operation = plannerGeneration
        let allowed = legalTargets
        planningPurpose = purpose
        isPlanning = true
        status = "Comparando tacadas permitidas na mesa atual…"
        if purpose == .singleShot || purpose == .autoPlay { automationStatus = "Procurando uma tacada permitida…" }
        plannerTask = Task { [weak self] in
            let worker = Task.detached(priority: .userInitiated) {
                try ShotPlanner.suggestions(for: state, includeBanks: true, limit: 4, allowedTargetIDs: allowed)
            }
            do {
                let found = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, self.acceptsPlan(operation, state: state, allowed: allowed) else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.suggestions = found
                guard let best = found.first else {
                    self.status = "Nenhuma tacada permitida encontrada pelo modelo nesta posição."
                    if purpose == .singleShot || purpose == .autoPlay { self.stopAutomation(message: self.status) }
                    return
                }
                switch purpose {
                case .suggestions:
                    self.status = "Escolha uma tacada para ver o percurso."
                case .applyAim:
                    guard self.setPreview(best.shot) else { return }
                    self.applyAim()
                case .singleShot, .autoPlay:
                    self.execute(best, expectedState: state, allowed: allowed)
                case .luckyShot:
                    break // Lucky Shot uses its own bounded target search.
                }
            } catch {
                guard let self, self.acceptsPlan(operation, state: state, allowed: allowed) else { return }
                self.plannerTask = nil
                self.planningPurpose = nil
                self.isPlanning = false
                self.status = "Não foi possível calcular a tacada: \(error.localizedDescription)"
                if purpose == .singleShot || purpose == .autoPlay { self.stopAutomation(message: self.status) }
            }
        }
    }

    private func advanceAutomation() {
        guard autoPlayEnabled || singleShotRequested, isAuthorized, !isWaitingForShot, !isPlanning else { return }
        guard canCalculate, isPlayerTurn else {
            automationStatus = "Aguardando sua vez e a mesa parar."
            return
        }
        guard autoShotAvailable else { stopAutomation(message: autoShotUnavailableReason); return }
        guard !legalTargets.isEmpty else {
            stopAutomation(message: "O jogo ainda não informou uma bola permitida para esta tacada.")
            return
        }
        guard tableState != lastSubmittedState else {
            stopAutomation(message: "Esta mesa já recebeu uma tentativa. Aguarde movimento ou execute a tacada pelo jogo.")
            return
        }
        guard runtimeCanShoot, let stableSince,
              ProcessInfo.processInfo.systemUptime - stableSince >= minimumStableTime else {
            automationStatus = "Aguardando a mesa estabilizar e o controle de tacada ficar disponível."
            return
        }
        startPlanning(autoPlayEnabled ? .autoPlay : .singleShot)
    }

    private func execute(_ suggestion: ShotSuggestion, expectedState: TableState, allowed: Set<Int>) {
        guard autoPlayEnabled || singleShotRequested, isAuthorized, !isWaitingForShot,
              expectedState != lastSubmittedState else { return }
        do {
            let current = try PLRuntimeBridge.capture()
            let normalized = try Self.normalized(current)
            let currentAllowed = Set(current.legalTargetNumbers.map { $0.intValue })
            guard current.playerTurn, current.canShoot, current.autoShotAvailable,
                  normalized.calibrated, normalized.nativePhysics, !normalized.moving, normalized.state == expectedState,
                  current.coordinateView === snapshot?.coordinateView,
                  currentAllowed == allowed, allowed.contains(suggestion.targetID),
                  isAuthorized else { throw CaptureError.changedTable }
            let nativePower = try GameShotCalibration.controlPower(fromSimulationPower: suggestion.shot.power)
            // Mark before entering the game: even a partial runtime failure
            // cannot cause a second invocation for this unchanged board.
            lastSubmittedState = expectedState
            shotSubmittedAt = ProcessInfo.processInfo.systemUptime
            isWaitingForShot = true
            singleShotRequested = false
            try PLRuntimeBridge.shoot(angle: -suggestion.shot.angleRadians, power: nativePower,
                                      target: suggestion.targetID, pocket: suggestion.pocketID)
            angleDegrees = Self.degrees(suggestion.shot.angleRadians)
            power = nativePower
            followGameAim = true
            automationStatus = "Tacada enviada. Aguardando movimento no jogo…"
            status = "Bola \(suggestion.targetID), caçapa \(suggestion.pocketID + 1)."
            cancelPrediction(clearOverlay: true)
        } catch {
            shotSubmittedAt = nil
            isWaitingForShot = false
            stopAutomation(message: "Tacada automática interrompida: \(error.localizedDescription)")
            status = automationStatus
        }
    }

    private func stopAutomation(message: String) {
        queueTransition = nil
        autoPlayEnabled = false
        singleShotRequested = false
        if planningPurpose == .singleShot || planningPurpose == .autoPlay { cancelPlanner(clearSuggestions: false) }
        automationStatus = message
    }

    private func requestPrediction() {
        guard canCalculate, !(followGameAim && !aimAvailable), !isWaitingForShot, let state = tableState else { return }
        cancelPrediction(clearOverlay: false)
        let operation = predictionGeneration
        guard let simulationPower = try? GameShotCalibration.simulationPower(fromControlPower: power) else {
            status = "A força lida está fora do intervalo aceito."
            return
        }
        let shot = ShotParameters(angleRadians: angleDegrees * .pi / 180, power: simulationPower)
        isPredicting = true
        predictionTask = Task { [weak self] in
            do {
                try await Task.sleep(nanoseconds: 70_000_000)
                try Task.checkCancellation()
                let worker = Task.detached(priority: .userInitiated) {
                    try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: true)
                }
                let result = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
                guard let self, operation == self.predictionGeneration, self.accepts(state) else { return }
                if self.isLuckyShot, let snapshot = self.snapshot {
                    let obstacles = Set(state.balls.map(\.id)).subtracting([0, snapshot.goldenBallNumber])
                    let touchesObstacle = result.events.contains { event in
                        if case let .ballCollision(first, second) = event {
                            return obstacles.contains(first) || obstacles.contains(second)
                        }
                        return false
                    }
                    if touchesObstacle {
                        self.traces = []; self.finalBalls = []; self.previewDuration = nil
                        self.isPredicting = false; self.predictionTask = nil
                        self.luckyStatus = "Previsão limitada pelos obstáculos. Ajuste a direção ou calcule outra opção."
                        self.onOverlayChange?()
                        return
                    }
                }
                self.traces = result.traces
                self.finalBalls = result.settled ? result.finalState.balls : []
                self.previewDuration = result.duration
                self.isPredicting = false
                self.predictionTask = nil
                if !result.settled { self.status = "Percurso parcial: a simulação não chegou ao repouso; posições finais ocultas." }
                self.onOverlayChange?()
            } catch {
                guard let self, operation == self.predictionGeneration, self.accepts(state) else { return }
                self.isPredicting = false
                self.predictionTask = nil
                self.traces = []
                self.finalBalls = []
                self.status = "Previsão indisponível: \(error.localizedDescription)"
                self.onOverlayChange?()
            }
        }
    }

    private func accepts(_ state: TableState) -> Bool {
        isAuthorized && isCalibrated && !Task.isCancelled && tableState == state && !isMoving
    }
    private func acceptsPlan(_ operation: UInt64, state: TableState, allowed: Set<Int>) -> Bool {
        operation == plannerGeneration && accepts(state) && legalTargets == allowed
    }
    private func cancelPrediction(clearOverlay: Bool) {
        predictionGeneration &+= 1
        predictionTask?.cancel()
        predictionTask = nil
        isPredicting = false
        if clearOverlay { traces = []; finalBalls = []; previewDuration = nil; onOverlayChange?() }
    }
    private func cancelPlanner(clearSuggestions: Bool) {
        plannerGeneration &+= 1
        plannerTask?.cancel()
        plannerTask = nil
        planningPurpose = nil
        isPlanning = false
        if clearSuggestions { suggestions = []; luckySuggestion = nil }
    }
    private func clearBoard(message: String, preserveQueueIntent: Bool = false) {
        if !isAuthorized && autoQueueEnabled { autoQueueEnabled = false; queueStatus = "Próxima partida automática pausada; ative novamente para continuar." }
        if !isAuthorized && blockInterstitialAds { setBlockInterstitialAds(false) }
        if preserveQueueIntent && queueTransition != nil && autoPlayEnabled && autoQueueEnabled && isAuthorized {
            singleShotRequested = false
            automationStatus = "Automático aguardando a próxima mesa. Você pode desligar a qualquer momento."
        } else { stopAutomation(message: message) }
        cancelPrediction(clearOverlay: true)
        cancelPlanner(clearSuggestions: true)
        snapshot = nil
        tableState = nil
        stableSince = nil
        shotSubmittedAt = nil
        isWaitingForShot = false
        hasTable = false
        isPlayerTurn = false
        isMoving = false
        aimAvailable = false
        isCalibrated = false
        hasNativePhysics = false
        isLuckyShot = false
        luckyStatus = "Aguardando o alvo da Lucky Shot."
        runtimeCanShoot = false
        autoShotAvailable = false
        autoShotUnavailableReason = message
        legalTargets = []
        ballCount = 0
        if status != message { status = message }
    }
    private func setPreview(_ shot: ShotParameters) -> Bool {
        guard shot.angleRadians.isFinite,
              let nativePower = try? GameShotCalibration.controlPower(fromSimulationPower: shot.power) else {
            status = "A sugestão contém uma direção ou força inválida."
            return false
        }
        angleDegrees = Self.degrees(shot.angleRadians)
        power = nativePower
        return true
    }
    private static func degrees(_ radians: Double) -> Double {
        let result = (radians * 180 / .pi).truncatingRemainder(dividingBy: 360)
        return result < 0 ? result + 360 : result
    }
    private func boolStyle(_ key: String, fallback: Bool) -> Bool {
        styles.object(forKey: stylePrefix + key) == nil ? fallback : styles.bool(forKey: stylePrefix + key)
    }
    private func numberStyle(_ key: String, fallback: Double, range: ClosedRange<Double>) -> Double {
        guard styles.object(forKey: stylePrefix + key) != nil else { return fallback }
        let value = styles.double(forKey: stylePrefix + key)
        return value.isFinite ? min(range.upperBound, max(range.lowerBound, value)) : fallback
    }
    private func saveStyle(_ value: Any, _ key: String) {
        styles.set(value, forKey: stylePrefix + key)
        onOverlayChange?()
    }

    private static func normalized(_ snapshot: PLGameSnapshot) throws -> (state: TableState, moving: Bool, calibrated: Bool, nativePhysics: Bool, calibrationIssue: String?) {
        let values = [snapshot.originX, snapshot.originY, snapshot.width, snapshot.height]
        guard values.allSatisfy(\.isFinite), snapshot.width > 0, snapshot.height > 0,
              !snapshot.balls.isEmpty, snapshot.balls.count <= 16 else { throw CaptureError.invalidGeometry }
        let scale = 200 / snapshot.width
        let radii = snapshot.balls.map { $0.radius * scale }
        guard radii.allSatisfy({ $0.isFinite && $0 > 0 }) else { throw CaptureError.invalidGeometry }
        let radius = radii.reduce(0, +) / Double(radii.count)
        guard radii.allSatisfy({ abs($0 - radius) <= 0.05 * radius }) else { throw CaptureError.invalidGeometry }
        var table = PoolTable()
        table.width = 200
        table.height = snapshot.height * scale
        table.ballRadius = radius
        table.pocketRadius = radius * 2.18
        let maximumSpeed = snapshot.maximumShotSpeed * scale
        let calibratedCue = maximumSpeed.isFinite && (1...2000).contains(maximumSpeed)
        let deceleration = snapshot.rollingDeceleration * scale
        let calibratedTable = snapshot.physicsCalibrationAvailable && deceleration.isFinite
            && (0...100).contains(deceleration) && snapshot.ballRestitution.isFinite
            && (0...1).contains(snapshot.ballRestitution) && snapshot.cushionRestitution.isFinite
            && (0...1).contains(snapshot.cushionRestitution)
        let calibrationIssue: String?
        if !calibratedCue {
            calibrationIssue = "Mesa lida, mas a força do taco atual não pôde ser calibrada. Previsão e tacadas automáticas pausadas."
        } else if !calibratedTable {
            calibrationIssue = "Previsão aproximada; os parâmetros especiais desta mesa não foram calibrados. Tacadas automáticas pausadas."
        } else { calibrationIssue = nil }
        table.maximumShotSpeed = calibratedCue ? maximumSpeed : 0
        if calibratedTable {
            table.rollingDeceleration = deceleration
            table.ballRestitution = snapshot.ballRestitution
            table.cushionRestitution = snapshot.cushionRestitution
        }
        // Without verified special-table coefficients, the manual preview uses
        // PoolTable's explicitly approximate defaults. Automatic firing remains
        // blocked; a missing cue-speed calibration blocks the preview as well.
        var moving = false
        let balls: [PoolBall] = snapshot.balls.map { ball in
            if !ball.vx.isFinite || !ball.vy.isFinite || hypot(ball.vx, ball.vy) * scale > 0.002 { moving = true }
            return PoolBall(id: ball.number,
                            position: Vector2(x: (ball.x - snapshot.originX) * scale,
                                              y: (snapshot.originY + snapshot.height - ball.y) * scale))
        }.sorted { $0.id < $1.id }
        let state = TableState(table: table, balls: balls)
        if !moving {
            // Validate geometry independently from missing cue calibration.
            // The stand-in exists only for this validation call; the returned
            // state retains unavailable values and cannot run a simulation.
            var geometryValidation = state
            if !calibratedCue { geometryValidation.table.maximumShotSpeed = 1 }
            try BilliardsEngine.validate(geometryValidation)
        }
        return (state, moving, calibratedCue, calibratedTable, calibrationIssue)
    }

    private static func isActive(_ window: UIWindow) -> Bool {
        guard !window.isHidden else { return false }
        if let scene = window.windowScene { return scene.activationState == .foregroundActive }
        return UIApplication.shared.applicationState == .active
    }
    private enum CaptureError: LocalizedError {
        case invalidGeometry, changedTable
        var errorDescription: String? {
            switch self {
            case .invalidGeometry: return "A geometria lida da partida não corresponde a uma mesa válida."
            case .changedTable: return "A partida mudou. Aguarde a mesa parar e solicite uma nova tacada."
            }
        }
    }
}
