#import "PLQueueBridge.h"
#import <UIKit/UIKit.h>
#import <objc/message.h>
#import <objc/runtime.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach/mach.h>
#import <mach/mach_vm.h>
#import <string.h>

// Static evidence for this exact build is in QueueRuntimeEvidence.json.
// All state and game calls stay on the game's main/rendering thread.
@interface PLQueueSnapshot ()
@property(nonatomic, readwrite) BOOL ready;
@property(nonatomic, readwrite) BOOL isResultScreen;
@property(nonatomic, copy, readwrite) NSString *resultToken;
@property(nonatomic, copy, readwrite) NSString *unavailableReason;
@end
@implementation PLQueueSnapshot
@end

static NSString *PLQObservedMatchID;
static NSString *PLQObservedTier;
static NSString *PLQResultToken;
static int PLQObservedMode;
static BOOL PLQConsumed;
static id PLQResultInfo;

static BOOL PLQFail(NSError **error, NSInteger code, NSString *message) {
    if (error) *error = [NSError errorWithDomain:@"PoolLab.QueueBridge" code:code
                                      userInfo:@{NSLocalizedDescriptionKey: message}];
    return NO;
}
static BOOL PLQMethod(id object, NSString *name, const char *encoding, NSError **error) {
    Method method = object ? class_getInstanceMethod(object_getClass(object), NSSelectorFromString(name)) : NULL;
    const char *actual = method ? method_getTypeEncoding(method) : NULL;
    return (actual && strcmp(actual, encoding) == 0) ||
        PLQFail(error, 10, [NSString stringWithFormat:@"Controle de próxima partida incompatível: %@.", name]);
}
static id PLQObject(id object, NSString *name) {
    return ((id (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static BOOL PLQBool(id object, NSString *name) {
    return ((BOOL (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static int PLQInt(id object, NSString *name) {
    return ((int (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static BOOL PLQCopy(uintptr_t address, void *destination, size_t length) {
    if (!address || !length || address > UINTPTR_MAX - length) return NO;
    mach_vm_size_t copied = 0;
    return mach_vm_read_overwrite(mach_task_self(), address, length,
        (mach_vm_address_t)(uintptr_t)destination, &copied) == KERN_SUCCESS && copied == length;
}
static Ivar PLQIvar(id object, NSString *className, const char *name,
                    const char *encoding, size_t size, NSError **error) {
    Class expected = NSClassFromString(className);
    Ivar ivar = expected ? class_getInstanceVariable(expected, name) : NULL;
    const char *actual = ivar ? ivar_getTypeEncoding(ivar) : NULL;
    if (!object || !expected || ![object isKindOfClass:expected] || !actual || strcmp(actual, encoding)) {
        PLQFail(error, 11, [NSString stringWithFormat:@"Campo de próxima partida incompatível: %@.%s.", className, name]);
        return NULL;
    }
    ptrdiff_t offset = ivar_getOffset(ivar);
    size_t total = class_getInstanceSize(object_getClass(object));
    if (offset < 0 || (size_t)offset > total || size > total - (size_t)offset) {
        PLQFail(error, 12, @"O tamanho do controle de próxima partida mudou."); return NULL;
    }
    return ivar;
}
static BOOL PLQRead(id object, NSString *className, const char *name, const char *encoding,
                    void *destination, size_t size, NSError **error) {
    Ivar ivar = PLQIvar(object, className, name, encoding, size, error);
    if (!ivar) return NO;
    if (PLQCopy((uintptr_t)(__bridge const void *)object + ivar_getOffset(ivar), destination, size)) return YES;
    return PLQFail(error, 13, @"O controle de próxima partida deixou de estar disponível.");
}
static BOOL PLQExecutable(NSError **error) {
    const struct mach_header *header = _dyld_get_image_header(0);
    if (!header || header->magic != MH_MAGIC_64 || header->cputype != CPU_TYPE_ARM64 ||
        header->ncmds > 4096 || header->sizeofcmds > 1024 * 1024)
        return PLQFail(error, 2, @"Executável incompatível com a próxima partida automática.");
    const uint8_t uuid[16] = {0xc2,0x35,0xdc,0xcd,0x99,0x7e,0x3d,0x31,0xa9,0x8f,0xea,0xa8,0xbd,0xdd,0x2b,0xfb};
    const uint8_t *cursor = (const uint8_t *)header + sizeof(struct mach_header_64);
    size_t remaining = header->sizeofcmds;
    for (uint32_t i = 0; i < header->ncmds; i++) {
        if (remaining < sizeof(struct load_command)) break;
        const struct load_command *command = (const struct load_command *)cursor;
        if (command->cmdsize < sizeof(*command) || command->cmdsize > remaining) break;
        if (command->cmd == LC_UUID && command->cmdsize >= sizeof(struct uuid_command))
            return !memcmp(((const struct uuid_command *)command)->uuid, uuid, sizeof(uuid)) ||
                PLQFail(error, 3, @"O executável não corresponde ao build verificado.");
        cursor += command->cmdsize; remaining -= command->cmdsize;
    }
    return PLQFail(error, 3, @"O executável não corresponde ao build verificado.");
}
static id PLQSingleton(NSString *name, NSString *initialized, NSString *shared, NSError **error) {
    Class cls = NSClassFromString(name);
    if (!PLQMethod(cls, initialized, "B16@0:8", error) || !PLQMethod(cls, shared, "@16@0:8", error)) return nil;
    if (!PLQBool(cls, initialized)) return nil;
    id value = PLQObject(cls, shared);
    return [value isKindOfClass:cls] ? value : nil;
}
static BOOL PLQEnvironment(id __strong *main, id __strong *menu, id __strong *game, NSError **error) {
    if (![NSThread isMainThread] || UIApplication.sharedApplication.applicationState != UIApplicationStateActive)
        return PLQFail(error, 1, @"A próxima partida está pausada enquanto o jogo está inativo.");
    NSBundle *bundle = NSBundle.mainBundle;
    if (![bundle.bundleIdentifier isEqual:@"com.miniclip.8ballpoolmult"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"] isEqual:@"56.31.0"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleVersion"] isEqual:@"5330"] || !PLQExecutable(error)) {
        if (!error || !*error) PLQFail(error, 4, @"Próxima partida disponível somente no build 56.31.0 (5330).");
        return NO;
    }
    Class directorClass = NSClassFromString(@"CCDirector");
    if (!PLQMethod(directorClass, @"sharedDirector", "@16@0:8", error)) return NO;
    id director = PLQObject(directorClass, @"sharedDirector");
    if (!PLQMethod(director, @"runningThread", "@16@0:8", error) ||
        PLQObject(director, @"runningThread") != NSThread.currentThread)
        return PLQFail(error, 5, @"O jogo está atualizando a partida em outra thread.");
    *main = PLQSingleton(@"MainManager", @"isMainManagerInitialized", @"sharedMainManager", error);
    *menu = PLQSingleton(@"MenuManager", @"isMenuManagerInitialized", @"sharedMenuManager", error);
    *game = PLQSingleton(@"GameManager", @"isGameManagerInitialized", @"sharedGameManager", error);
    return *main && *menu && *game;
}

// The inspected libc++ string uses a 24-byte alternate layout. Never construct,
// mutate, or return this C++ type by value through an Objective-C function cast.
static const char *const PLQStringType =
    "{basic_string<char, std::char_traits<char>, std::allocator<char>>=\"\"{?=\"__rep_\"(__rep=\"__s\"{__short=\"__data_\"[23c]\"__size_\"b7\"__is_long_\"b1}\"__l\"{__long=\"__data_\"*\"__size_\"Q\"__cap_\"b63\"__is_long_\"b1})}}";
static NSString *PLQTierAtAddress(uintptr_t address) {
    uint8_t value[24] = {0}, text[129] = {0};
    if (!PLQCopy(address, value, sizeof(value))) return nil;
    uint64_t length = value[23];
    uintptr_t textAddress = address;
    if (value[23] & 0x80) { memcpy(&textAddress, value, 8); memcpy(&length, value + 8, 8); }
    else if (length > 22) return nil;
    if (!length || length > 128 || !PLQCopy(textAddress, text, (size_t)length + 1) || text[length]) return nil;
    NSString *tier = [[NSString alloc] initWithBytes:text length:(NSUInteger)length encoding:NSUTF8StringEncoding];
    if (!tier || [tier rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location != NSNotFound) return nil;
    return tier;
}
static PLQueueSnapshot *PLQSnapshot(BOOL result, NSString *reason) {
    PLQueueSnapshot *snapshot = [PLQueueSnapshot new];
    snapshot.isResultScreen = result;
    snapshot.resultToken = PLQResultToken ?: @"";
    snapshot.unavailableReason = reason;
    return snapshot;
}

static PLQueueSnapshot *PLQCapture(id __strong *menuOut, id __strong *infoOut,
                                   const void **tierOut, NSError **error) {
    id main = nil, menu = nil, game = nil;
    if (!PLQEnvironment(&main, &menu, &game, error)) {
        if (error && *error) return nil;
        return PLQSnapshot(NO, @"Entre em uma partida para preparar a próxima mesa.");
    }
    if (!PLQMethod(main, @"isInGame", "B16@0:8", error) || !PLQMethod(main, @"isInMenu", "B16@0:8", error)) return nil;
    if (PLQBool(main, @"isInGame")) {
        if (!PLQMethod(game, @"matchId", "@16@0:8", error) ||
            !PLQMethod(game, @"tierCode", "r^v16@0:8", error) ||
            !PLQMethod(game, @"gameMode", "i16@0:8", error) ||
            !PLQMethod(game, @"isOnPlayerMatch", "B16@0:8", error) ||
            !PLQMethod(game, @"isOnAllInOrAdvantageGameMode", "B16@0:8", error) ||
            !PLQMethod(game, @"isInSpectatorMode", "B16@0:8", error)) return nil;
        id matchID = PLQObject(game, @"matchId");
        if (![matchID isKindOfClass:NSString.class] || ![matchID length] || [matchID length] > 256)
            return PLQSnapshot(NO, @"Aguardando a identificação da partida.");
        if (![PLQObservedMatchID isEqualToString:matchID]) {
            PLQObservedTier = nil; PLQResultInfo = nil; PLQResultToken = nil; PLQConsumed = NO;
            if (PLQBool(game, @"isOnPlayerMatch") && !PLQBool(game, @"isOnAllInOrAdvantageGameMode") &&
                !PLQBool(game, @"isInSpectatorMode")) {
                const void *tier = ((const void *(*)(id, SEL))objc_msgSend)(game, NSSelectorFromString(@"tierCode"));
                PLQObservedTier = PLQTierAtAddress((uintptr_t)tier);
                PLQObservedMode = PLQInt(game, @"gameMode");
                if (PLQObservedTier) {
                    PLQObservedMatchID = [matchID copy];
                    PLQResultToken = NSUUID.UUID.UUIDString;
                }
            }
        }
        return PLQSnapshot(NO, PLQObservedTier ? @"A próxima partida aguarda o resultado desta mesa." :
                            @"Próxima partida indisponível neste modo.");
    }
    if (!PLQBool(main, @"isInMenu")) return PLQSnapshot(NO, @"Aguardando o fim da transição.");
    if (!PLQMethod(menu, @"getCurrentMenuState", "@16@0:8", error)) return nil;
    id screen = PLQObject(menu, @"getCurrentMenuState");
    Class resultClass = NSClassFromString(@"MenuPlayerMatch");
    if (!resultClass || ![screen isKindOfClass:resultClass]) return PLQSnapshot(NO, @"Aguardando a tela de resultado.");
    int state = -1;
    BOOL ending = NO, animations = YES, requested = YES, opponentRequested = YES, pendingProposal = YES;
    BOOL challenge = YES, betSelection = YES;
    if (!PLQRead(screen, @"MenuPlayerMatch", "mState", "i", &state, sizeof(state), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_isMatchEnding", "B", &ending, sizeof(ending), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_hasPendingProgressionAnimations", "B", &animations, sizeof(animations), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "mPlayerWantsRematch", "B", &requested, sizeof(requested), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "mOpponentWantsRematch", "B", &opponentRequested, sizeof(opponentRequested), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_pendingRematchProposalFromOpponent", "B", &pendingProposal, sizeof(pendingProposal), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_isChallenge", "B", &challenge, sizeof(challenge), error) ||
        !PLQRead(screen, @"MenuPlayerMatch", "_isBetSelectionGame", "B", &betSelection, sizeof(betSelection), error)) return nil;
    if (!ending || state != 2) return PLQSnapshot(NO, @"Aguardando o resultado completo da partida.");
    PLQueueSnapshot *snapshot = PLQSnapshot(YES, @"Aguardando o fim das animações do resultado.");
    if (!PLQObservedTier || !PLQResultToken) {
        snapshot.unavailableReason = @"Ative durante uma partida normal; a próxima mesa será a mesma."; return snapshot;
    }
    if (PLQConsumed) { snapshot.unavailableReason = @"Próxima partida já solicitada. Aguardando uma nova partida."; return snapshot; }
    if (challenge || betSelection || requested || opponentRequested || pendingProposal) {
        snapshot.unavailableReason = @"Próxima partida pausada para desafio, revanche ou aposta variável."; return snapshot;
    }
    if (animations) return snapshot;
    if (!PLQMethod(screen, @"matchInfo", "@16@0:8", error)) return nil;
    id info = PLQObject(screen, @"matchInfo");
    if (![info isKindOfClass:NSClassFromString(@"MatchInfo")]) return snapshot;
    if (!PLQMethod(info, @"wasChallenge", "B16@0:8", error) ||
        !PLQMethod(info, @"isAllInOrAdvantageMode", "B16@0:8", error) ||
        !PLQMethod(info, @"userPlayedOnMatch", "B16@0:8", error) ||
        !PLQMethod(info, @"gameMode", "i16@0:8", error) || !PLQMethod(info, @"betId", "i16@0:8", error)) return nil;
    if (PLQBool(info, @"wasChallenge") || PLQBool(info, @"isAllInOrAdvantageMode") ||
        !PLQBool(info, @"userPlayedOnMatch") || PLQInt(info, @"gameMode") != PLQObservedMode || PLQInt(info, @"betId") != -1) {
        snapshot.unavailableReason = @"Resultado incompatível com a próxima partida na mesma mesa."; return snapshot;
    }
    Ivar tierIvar = PLQIvar(info, @"MatchInfo", "_tierCode", PLQStringType, 24, error);
    if (!tierIvar) return nil;
    const void *tier = (const uint8_t *)(__bridge const void *)info + ivar_getOffset(tierIvar);
    if (![PLQObservedTier isEqualToString:PLQTierAtAddress((uintptr_t)tier)] || (PLQResultInfo && PLQResultInfo != info)) {
        snapshot.unavailableReason = @"A mesa do resultado mudou. Escolha a próxima partida no jogo."; return snapshot;
    }
    Ivar backIvar = PLQIvar(screen, @"MenuPlayerMatch", "mBackButton", "@\"MCMenuItemNodeRGBA\"", sizeof(id), error);
    if (!backIvar) return nil;
    id back = object_getIvar(screen, backIvar);
    if (!back) return snapshot;
    if (!PLQMethod(back, @"visible", "B16@0:8", error) || !PLQMethod(back, @"isEnabled", "B16@0:8", error)) return nil;
    if (!PLQBool(back, @"visible") || !PLQBool(back, @"isEnabled")) return snapshot;
    if (!PLQMethod(menu, @"startSingleMatch:", "v24@0:8r^v16", error) ||
        !PLQMethod(menu, @"enterLondonOnAuthentication", "B16@0:8", error)) return nil;
    // checkStartNanoMatch: can redirect an underfunded authentication flow to a
    // different tier. Do not enter that flow from this same-tier feature.
    if (PLQBool(menu, @"enterLondonOnAuthentication")) {
        snapshot.unavailableReason = @"Aguarde o jogo terminar de conectar antes da próxima partida."; return snapshot;
    }
    PLQResultInfo = info;
    snapshot.ready = YES;
    snapshot.unavailableReason = @"Pronta para procurar outro adversário na mesma mesa.";
    if (menuOut) *menuOut = menu;
    if (infoOut) *infoOut = info;
    if (tierOut) *tierOut = tier;
    return snapshot;
}

@implementation PLQueueBridge
+ (PLQueueSnapshot *)captureWithError:(NSError **)error {
    @try { return PLQCapture(NULL, NULL, NULL, error); }
    @catch (NSException *exception) {
        PLQFail(error, 30, @"O jogo mudou a tela de resultado. Próxima partida pausada."); return nil;
    }
}
+ (BOOL)startNextMatchForToken:(NSString *)token error:(NSError **)error {
    @try {
        id menu = nil, info = nil;
        const void *tier = NULL;
        PLQueueSnapshot *snapshot = PLQCapture(&menu, &info, &tier, error);
        if (!snapshot) return NO;
        if (!snapshot.ready || !token.length || ![token isEqualToString:snapshot.resultToken] || !tier || !info)
            return PLQFail(error, 31, snapshot.unavailableReason);
        // Consume before the native call. An exception, timeout, or popup cannot
        // be retried by disabling and enabling the feature or by signing in again.
        PLQConsumed = YES;
        ((void (*)(id, SEL, const void *))objc_msgSend)(menu, NSSelectorFromString(@"startSingleMatch:"), tier);
        return YES;
    } @catch (NSException *exception) {
        PLQFail(error, 32, @"Não foi possível iniciar a próxima partida. Confira a mensagem do jogo."); return NO;
    }
}
@end
