#import "PLRuntimeBridge.h"
#import <objc/message.h>
#import <objc/runtime.h>
#import <math.h>
#import <string.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>

/* Contract source: Validation/RuntimeContract.json.
 * Only the supplied 56.31.0 (5330), arm64, executable was inspected.
 * ObjC ivar offsets are resolved at runtime, with exact encoding and size checks.
 * MCNumber aggregates deliberately use memcpy: their C++ getter return ABI uses
 * x8, even for one double, and is incompatible with a CGFloat/CGPoint cast.
 */

static NSString *const PLErrorDomain = @"PoolLab.RuntimeBridge";

@interface PLBallSnapshot ()
@property(nonatomic, readwrite) NSInteger number;
@property(nonatomic, readwrite) double x;
@property(nonatomic, readwrite) double y;
@property(nonatomic, readwrite) double vx;
@property(nonatomic, readwrite) double vy;
@property(nonatomic, readwrite) double radius;
@end
@implementation PLBallSnapshot
@end

@interface PLGameSnapshot ()
@property(nonatomic, copy, readwrite) NSArray<PLBallSnapshot *> *balls;
@property(nonatomic, readwrite) double originX;
@property(nonatomic, readwrite) double originY;
@property(nonatomic, readwrite) double width;
@property(nonatomic, readwrite) double height;
@property(nonatomic, readwrite) BOOL playerTurn;
@property(nonatomic, readwrite) CGPoint tableTopLeft;
@property(nonatomic, readwrite) CGPoint tableTopRight;
@property(nonatomic, readwrite) CGPoint tableBottomLeft;
@property(nonatomic, strong, readwrite) UIView *coordinateView;
@end
@implementation PLGameSnapshot
@end

static BOOL PLFail(NSError **error, NSInteger code, NSString *description) {
    if (error) *error = [NSError errorWithDomain:PLErrorDomain code:code
                                      userInfo:@{NSLocalizedDescriptionKey: description}];
    return NO;
}

static BOOL PLCheckMethod(id object, NSString *name, const char *encoding, NSError **error) {
    Method method = class_getInstanceMethod(object_getClass(object), NSSelectorFromString(name));
    const char *actual = method ? method_getTypeEncoding(method) : NULL;
    if (!actual || strcmp(actual, encoding) != 0) {
        return PLFail(error, 10, [NSString stringWithFormat:@"Método incompatível: %@.%@.",
                                 NSStringFromClass(object_getClass(object)), name]);
    }
    return YES;
}

static Ivar PLCheckIvar(id object, NSString *className, const char *name,
                        const char *encoding, size_t length, NSError **error) {
    Class expected = NSClassFromString(className);
    if (!expected || !object || ![object isKindOfClass:expected]) {
        PLFail(error, 11, [NSString stringWithFormat:@"Objeto %@ indisponível.", className]);
        return NULL;
    }
    Ivar ivar = class_getInstanceVariable(expected, name);
    const char *actual = ivar ? ivar_getTypeEncoding(ivar) : NULL;
    if (!actual || strcmp(actual, encoding) != 0) {
        PLFail(error, 12, [NSString stringWithFormat:@"Campo incompatível: %@.%s.", className, name]);
        return NULL;
    }
    NSUInteger encodedSize = 0, alignment = 0;
    NSGetSizeAndAlignment(actual, &encodedSize, &alignment);
    ptrdiff_t offset = ivar_getOffset(ivar);
    size_t instanceSize = class_getInstanceSize(object_getClass(object));
    if (encodedSize != length || alignment == 0 || offset < 0 ||
        (size_t)offset > instanceSize || length > instanceSize - (size_t)offset) {
        PLFail(error, 13, [NSString stringWithFormat:@"Tamanho incompatível: %@.%s.", className, name]);
        return NULL;
    }
    return ivar;
}

static BOOL PLRead(id object, NSString *className, const char *name,
                   const char *encoding, void *destination, size_t length, NSError **error) {
    Ivar ivar = PLCheckIvar(object, className, name, encoding, length, error);
    if (!ivar) return NO;
    memcpy(destination, (const uint8_t *)(__bridge const void *)object + ivar_getOffset(ivar), length);
    return YES;
}

static id PLReadObject(id object, NSString *className, const char *name,
                       const char *encoding, NSError **error) {
    Ivar ivar = PLCheckIvar(object, className, name, encoding, sizeof(id), error);
    return ivar ? object_getIvar(object, ivar) : nil;
}

static id PLObject(id object, NSString *name) {
    return ((id (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static BOOL PLBool(id object, NSString *name) {
    return ((BOOL (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static CGPoint PLPoint(id object, NSString *name) {
    return ((CGPoint (*)(id, SEL))objc_msgSend)(object, NSSelectorFromString(name));
}
static CGPoint PLTransform(id object, CGPoint point) {
    return ((CGPoint (*)(id, SEL, CGPoint))objc_msgSend)(object,
                                        NSSelectorFromString(@"convertToWindowSpace:"), point);
}
static BOOL PLFinitePoint(CGPoint point) { return isfinite(point.x) && isfinite(point.y); }

static BOOL PLExpectedExecutable(NSError **error) {
    const struct mach_header *header = _dyld_get_image_header(0);
    if (!header || header->magic != MH_MAGIC_64 || header->cputype != CPU_TYPE_ARM64 ||
        header->ncmds > 4096 || header->sizeofcmds > 1024*1024)
        return PLFail(error, 8, @"Executável incompatível com esta integração.");
    const uint8_t expectedUUID[16] = {
        0xc2, 0x35, 0xdc, 0xcd, 0x99, 0x7e, 0x3d, 0x31,
        0xa9, 0x8f, 0xea, 0xa8, 0xbd, 0xdd, 0x2b, 0xfb
    };
    const uint8_t *cursor = (const uint8_t *)header + sizeof(struct mach_header_64);
    size_t remaining = header->sizeofcmds;
    for (uint32_t i = 0; i < header->ncmds; ++i) {
        if (remaining < sizeof(struct load_command)) break;
        const struct load_command *command = (const struct load_command *)cursor;
        if (command->cmdsize < sizeof(*command) || command->cmdsize > remaining) break;
        if (command->cmd == LC_UUID && command->cmdsize >= sizeof(struct uuid_command)) {
            const struct uuid_command *uuid = (const struct uuid_command *)command;
            if (memcmp(uuid->uuid, expectedUUID, sizeof(expectedUUID)) == 0) return YES;
            break;
        }
        remaining -= command->cmdsize;
        cursor += command->cmdsize;
    }
    return PLFail(error, 9, @"O executável não corresponde ao build verificado.");
}

static BOOL PLEnvironment(id __strong *manager, id __strong *director, NSError **error) {
#if !defined(__arm64__)
    return PLFail(error, 1, @"A integração exige o executável arm64 do iPhone.");
#else
    if (![NSThread isMainThread]) return PLFail(error, 2, @"A captura precisa acontecer na thread principal.");
    NSBundle *bundle = NSBundle.mainBundle;
    if (![bundle.bundleIdentifier isEqualToString:@"com.miniclip.8ballpoolmult"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"] isEqual:@"56.31.0"] ||
        ![[bundle objectForInfoDictionaryKey:@"CFBundleVersion"] isEqual:@"5330"]) {
        return PLFail(error, 3, @"Esta integração foi preparada para 8 Ball Pool 56.31.0, build 5330.");
    }
    if (!PLExpectedExecutable(error)) return NO;
    Class managerClass = NSClassFromString(@"GameManager");
    Class directorClass = NSClassFromString(@"CCDirector");
    if (!managerClass || !directorClass)
        return PLFail(error, 7, @"As classes desta versão do jogo não foram encontradas.");
    if (!PLCheckMethod(managerClass, @"isGameManagerInitialized", "B16@0:8", error) ||
        !PLCheckMethod(managerClass, @"sharedGameManager", "@16@0:8", error) ||
        !PLCheckMethod(directorClass, @"sharedDirector", "@16@0:8", error)) return NO;
    // sharedGameManager creates an instance if absent; do not initialize game state.
    if (!PLBool(managerClass, @"isGameManagerInitialized"))
        return PLFail(error, 4, @"Abra uma mesa para conectar o menu ao jogo.");
    id game = PLObject(managerClass, @"sharedGameManager");
    id render = PLObject(directorClass, @"sharedDirector");
    if (!game || !render || ![game isKindOfClass:managerClass] || ![render isKindOfClass:directorClass])
        return PLFail(error, 5, @"Objetos do jogo ainda não estão disponíveis.");
    if (!PLCheckMethod(render, @"runningThread", "@16@0:8", error) ||
        !PLCheckMethod(render, @"view", "@16@0:8", error)) return NO;
    NSThread *renderThread = PLObject(render, @"runningThread");
    if (![renderThread isKindOfClass:NSThread.class] || renderThread != NSThread.currentThread)
        return PLFail(error, 6, @"A mesa está sendo atualizada em outra thread. Captura pausada.");
    *manager = game;
    *director = render;
    return YES;
#endif
}

static const char *const PLPhysicsType =
    "{BallPhysicsProperties=\"position\"{?=\"x\"{MCNumber=\"mValue\"d}\"y\"{MCNumber=\"mValue\"d}}"
    "\"velocity\"{?=\"x\"{MCNumber=\"mValue\"d}\"y\"{MCNumber=\"mValue\"d}}"
    "\"radius\"{MCNumber=\"mValue\"d}\"spin\"{?=\"x\"{MCNumber=\"mValue\"d}"
    "\"y\"{MCNumber=\"mValue\"d}\"z\"{MCNumber=\"mValue\"d}}"
    "\"mass\"{MCNumber=\"mValue\"d}\"volume\"{MCNumber=\"mValue\"d}}";
static const char *const PLBoundsType =
    "{MCRect=\"origin\"{?=\"x\"{MCNumber=\"mValue\"d}\"y\"{MCNumber=\"mValue\"d}}"
    "\"size\"{?=\"width\"{MCNumber=\"mValue\"d}\"height\"{MCNumber=\"mValue\"d}}}";
static const char *const PLPointType = "{CGPoint=\"x\"d\"y\"d}";

static PLGameSnapshot *PLCapture(NSError **error) {
    id manager = nil, director = nil;
    if (!PLEnvironment(&manager, &director, error)) return nil;
    if (!PLCheckMethod(manager, @"isPlayerTurn", "B16@0:8", error)) return nil;
    id table = PLReadObject(manager, @"GameManager", "mTable", "@\"Table\"", error);
    if (!table) { if (!error || !*error) PLFail(error, 20, @"Nenhuma mesa disponível."); return nil; }
    id source = PLReadObject(table, @"Table", "mBalls", "@\"NSArray\"", error);
    if (!source || ![source isKindOfClass:NSArray.class]) {
        if (!error || !*error) PLFail(error, 21, @"A lista de bolas não está disponível.");
        return nil;
    }
    NSArray *sourceBalls = [source copy];
    if (sourceBalls.count == 0 || sourceBalls.count > 32) {
        PLFail(error, 22, @"Quantidade de bolas incompatível."); return nil;
    }
    double bounds[4] = {0};
    if (!PLRead(table, @"Table", "mTableCollisionBounds", PLBoundsType, bounds, sizeof(bounds), error)) return nil;
    if (!isfinite(bounds[0]) || !isfinite(bounds[1]) || !isfinite(bounds[2]) || !isfinite(bounds[3]) ||
        bounds[2] <= 0 || bounds[3] <= 0 || bounds[2] > 100000 || bounds[3] > 100000) {
        PLFail(error, 23, @"Dimensões da mesa inválidas."); return nil;
    }
    UIView *view = PLObject(director, @"view");
    if (![view isKindOfClass:UIView.class] || !view.window ||
        view.bounds.size.width <= 0 || view.bounds.size.height <= 0) {
        PLFail(error, 24, @"A imagem da mesa ainda não está visível."); return nil;
    }
    NSMutableArray<PLBallSnapshot *> *values = [NSMutableArray array];
    NSMutableArray<NSValue *> *visualPositions = [NSMutableArray array];
    NSMutableIndexSet *numbers = [NSMutableIndexSet indexSet];
    id parent = nil;
    CGPoint commonOrigin = CGPointZero;
    double numerator = 0, denominator = 0;
    for (id ball in sourceBalls) {
        Class ballClass = NSClassFromString(@"Ball");
        if (!ballClass || ![ball isKindOfClass:ballClass] ||
            !PLCheckMethod(ball, @"onTable", "B16@0:8", error)) {
            if (!error || !*error) PLFail(error, 25, @"Objeto de bola incompatível.");
            return nil;
        }
        uint32_t number = 0;
        if (!PLRead(ball, @"Ball", "number", "I", &number, sizeof(number), error)) return nil;
        if (number > 31 || [numbers containsIndex:number]) {
            PLFail(error, 26, @"Numeração de bolas incompatível."); return nil;
        }
        [numbers addIndex:number];
        if (!PLBool(ball, @"onTable")) continue;
        double physics[10] = {0};
        if (!PLRead(ball, @"Ball", "_physicsProperties", PLPhysicsType, physics, sizeof(physics), error)) return nil;
        for (NSUInteger i = 0; i < 10; ++i) {
            if (!isfinite(physics[i])) { PLFail(error, 27, @"A mesa contém valores físicos inválidos."); return nil; }
        }
        double radius = physics[4];
        if (radius <= 0 || radius * 2 >= fmin(bounds[2], bounds[3]) ||
            physics[0] < bounds[0] - radius * 5 || physics[0] > bounds[0] + bounds[2] + radius * 5 ||
            physics[1] < bounds[1] - radius * 5 || physics[1] > bounds[1] + bounds[3] + radius * 5) {
            PLFail(error, 28, @"Bola fora dos limites esperados. Aguarde a mesa parar."); return nil;
        }
        id visual = PLReadObject(ball, @"Ball", "visualBall", "@\"ProjectedSphere\"", error);
        Class sphereClass = NSClassFromString(@"ProjectedSphere");
        if (!visual || !sphereClass || ![visual isKindOfClass:sphereClass] ||
            !PLCheckMethod(visual, @"position", "{CGPoint=dd}16@0:8", error) ||
            !PLCheckMethod(visual, @"parent", "@16@0:8", error)) {
            if (!error || !*error) PLFail(error, 29, @"Posição visual da bola indisponível.");
            return nil;
        }
        id candidateParent = PLObject(visual, @"parent");
        if (!candidateParent || !PLCheckMethod(candidateParent, @"convertToWindowSpace:", "{CGPoint=dd}32@0:8{CGPoint=dd}16", error)) {
            if (!error || !*error) PLFail(error, 30, @"Transformação da mesa indisponível.");
            return nil;
        }
        CGPoint origin;
        if (!PLRead(ball, @"Ball", "mVisualTableOrigin", PLPointType, &origin, sizeof(origin), error)) return nil;
        CGPoint position = PLPoint(visual, @"position");
        if (!PLFinitePoint(origin) || !PLFinitePoint(position)) {
            PLFail(error, 31, @"Coordenadas visuais inválidas."); return nil;
        }
        if (parent && (parent != candidateParent || hypot(origin.x-commonOrigin.x, origin.y-commonOrigin.y) > 0.01)) {
            PLFail(error, 32, @"A mesa está em transição. Aguarde um instante."); return nil;
        }
        parent = candidateParent;
        commonOrigin = origin;
        numerator += physics[0] * (position.x-origin.x) + physics[1] * (position.y-origin.y);
        denominator += physics[0]*physics[0] + physics[1]*physics[1];
        PLBallSnapshot *value = [PLBallSnapshot new];
        value.number = number; value.x = physics[0]; value.y = physics[1];
        value.vx = physics[2]; value.vy = physics[3]; value.radius = radius;
        [values addObject:value];
        [visualPositions addObject:[NSValue valueWithCGPoint:position]];
    }
    if (values.count == 0 || !parent || denominator < 1e-8) {
        PLFail(error, 33, @"Ainda não há uma mesa pronta para leitura."); return nil;
    }
    double scale = numerator / denominator;
    if (!isfinite(scale) || scale <= 0 || scale > 1000) {
        PLFail(error, 34, @"Escala visual da mesa inválida."); return nil;
    }
    for (NSUInteger i = 0; i < values.count; ++i) {
        PLBallSnapshot *ball = values[i];
        CGPoint measured = visualPositions[i].CGPointValue;
        double residual = hypot(measured.x-commonOrigin.x-ball.x*scale,
                                measured.y-commonOrigin.y-ball.y*scale);
        if (!isfinite(residual) || residual > 1.0) {
            PLFail(error, 35, @"A imagem e a física estão atualizando. Aguarde um instante."); return nil;
        }
    }
    CGPoint topLeft = PLTransform(parent, CGPointMake(commonOrigin.x+bounds[0]*scale,
                                           commonOrigin.y+(bounds[1]+bounds[3])*scale));
    CGPoint topRight = PLTransform(parent, CGPointMake(commonOrigin.x+(bounds[0]+bounds[2])*scale,
                                            commonOrigin.y+(bounds[1]+bounds[3])*scale));
    CGPoint bottomLeft = PLTransform(parent, CGPointMake(commonOrigin.x+bounds[0]*scale,
                                              commonOrigin.y+bounds[1]*scale));
    if (!PLFinitePoint(topLeft) || !PLFinitePoint(topRight) || !PLFinitePoint(bottomLeft)) {
        PLFail(error, 36, @"Não foi possível posicionar a sobreposição."); return nil;
    }
    double ax = topRight.x-topLeft.x, ay = topRight.y-topLeft.y;
    double bx = bottomLeft.x-topLeft.x, by = bottomLeft.y-topLeft.y;
    CGPoint bottomRight = CGPointMake(topRight.x+bx, topRight.y+by);
    CGRect visible = CGRectInset(view.bounds, -2, -2);
    if (hypot(ax, ay) < 20 || hypot(bx, by) < 20 || fabs(ax*by-ay*bx) < 400 ||
        !CGRectContainsPoint(visible, topLeft) || !CGRectContainsPoint(visible, topRight) ||
        !CGRectContainsPoint(visible, bottomLeft) || !CGRectContainsPoint(visible, bottomRight)) {
        PLFail(error, 37, @"A mesa não cabe na área visível. Aguarde a animação terminar."); return nil;
    }
    PLGameSnapshot *result = [PLGameSnapshot new];
    result.balls = values; result.originX = bounds[0]; result.originY = bounds[1];
    result.width = bounds[2]; result.height = bounds[3];
    result.playerTurn = PLBool(manager, @"isPlayerTurn");
    result.tableTopLeft = topLeft; result.tableTopRight = topRight; result.tableBottomLeft = bottomLeft;
    result.coordinateView = view;
    return result;
}

@implementation PLRuntimeBridge
+ (PLGameSnapshot *)captureWithError:(NSError **)error {
    if (error) *error = nil;
    @try { return PLCapture(error); }
    @catch (NSException *exception) {
        PLFail(error, 90, @"A estrutura da mesa não corresponde à versão esperada. Leitura pausada.");
        return nil;
    }
}

+ (BOOL)applyAngle:(double)angle power:(double)power error:(NSError **)error {
    if (error) *error = nil;
    if (!isfinite(angle) || !isfinite(power) || power < 0 || power > 1)
        return PLFail(error, 40, @"Use um ângulo válido e força entre 0 e 1.");
#if !defined(__arm64__)
    return PLFail(error, 1, @"O ajuste exige o executável arm64 do iPhone.");
#else
    @try {
        PLGameSnapshot *snapshot = PLCapture(error);
        if (!snapshot) return NO;
        if (!snapshot.playerTurn) return PLFail(error, 41, @"O ajuste fica disponível na sua vez.");
        BOOL hasCueBall = NO;
        for (PLBallSnapshot *ball in snapshot.balls) {
            if (ball.number == 0) hasCueBall = YES;
            if (hypot(ball.vx, ball.vy) > 0.001)
                return PLFail(error, 42, @"Aguarde todas as bolas pararem antes de ajustar a mira.");
        }
        if (!hasCueBall) return PLFail(error, 43, @"Reposicione a bola branca antes de ajustar a mira.");
        id manager = nil, director = nil;
        if (!PLEnvironment(&manager, &director, error)) return NO;
        id cue = PLReadObject(manager, @"GameManager", "mVisualCue", "@\"VisualCue\"", error);
        if (!cue || ![cue isKindOfClass:NSClassFromString(@"VisualCue")]) {
            if (!error || !*error) PLFail(error, 44, @"Controle do taco indisponível.");
            return NO;
        }
        if (!PLCheckMethod(cue, @"enabled", "B16@0:8", error) ||
            !PLCheckMethod(cue, @"setAimAngle:", "v24@0:8{MCNumber=d}16", error) ||
            !PLCheckMethod(cue, @"setPower:", "v24@0:8{MCNumber=d}16", error)) return NO;
        if (!PLBool(cue, @"enabled")) return PLFail(error, 45, @"O jogo ainda não liberou o taco.");
        void *guide = NULL;
        double currentPower = 0;
        if (!PLRead(cue, @"VisualCue", "mVisualGuide", "^v", &guide, sizeof(guide), error) ||
            !PLRead(cue, @"VisualCue", "mPower", "{MCNumber=\"mValue\"d}",
                    &currentPower, sizeof(currentPower), error)) return NO;
        if (!guide || !isfinite(currentPower)) return PLFail(error, 46, @"A mira ainda não está pronta.");
        double normalizedAngle = fmod(angle, 2.0*M_PI);
        if (normalizedAngle < 0) normalizedAngle += 2.0*M_PI;
        /* ARM64 machine ABI, intentionally NOT a C double parameter:
         * setAimAngle: 0x1001d1500 and setPower: 0x1001d1548 load [x2].
         * The game's nontrivial MCNumber value is passed indirectly in x2.
         * Both return void. All method type encodings are checked above.
         * setPower clamps [0,1], proven by initializer 0x1001d502c..503c.
         * We call the original setters so each updates its visual state.
         */
        typedef void (*PLIndirectNumberSetter)(id, SEL, const double *);
        ((PLIndirectNumberSetter)objc_msgSend)(cue, NSSelectorFromString(@"setAimAngle:"), &normalizedAngle);
        ((PLIndirectNumberSetter)objc_msgSend)(cue, NSSelectorFromString(@"setPower:"), &power);
        double appliedPower = 0;
        if (!PLRead(cue, @"VisualCue", "mPower", "{MCNumber=\"mValue\"d}",
                    &appliedPower, sizeof(appliedPower), error)) return NO;
        if (!isfinite(appliedPower) || fabs(appliedPower-power) > 1e-8)
            return PLFail(error, 47, @"O jogo não confirmou a força solicitada.");
        // No playerShotAction, network call, touch injection or shot dispatch.
        return YES;
    } @catch (NSException *exception) {
        return PLFail(error, 91, @"O jogo recusou o ajuste dos controles.");
    }
#endif
}
@end
