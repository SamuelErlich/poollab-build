#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Value snapshot copied from the game on its rendering thread.
@interface PLBallSnapshot : NSObject
@property(nonatomic, readonly) NSInteger number;
@property(nonatomic, readonly) double x;
@property(nonatomic, readonly) double y;
@property(nonatomic, readonly) double vx;
@property(nonatomic, readonly) double vy;
@property(nonatomic, readonly) double radius;
@end

@interface PLGameSnapshot : NSObject
@property(nonatomic, copy, readonly) NSArray<PLBallSnapshot *> *balls;
@property(nonatomic, readonly) double originX;
@property(nonatomic, readonly) double originY;
@property(nonatomic, readonly) double width;
@property(nonatomic, readonly) double height;
@property(nonatomic, readonly) BOOL playerTurn;
/// Corners in coordinateView's UIKit coordinate system. Physical Y increases upward.
/// topLeft maps (originX, originY + height).
/// topRight maps (originX + width, originY + height).
/// bottomLeft maps (originX, originY).
/// For a Y-down engine: localY = originY + height - physicalY; negate aim angle.
@property(nonatomic, readonly) CGPoint tableTopLeft;
@property(nonatomic, readonly) CGPoint tableTopRight;
@property(nonatomic, readonly) CGPoint tableBottomLeft;
@property(nonatomic, strong, readonly) UIView *coordinateView;
@end

@interface PLRuntimeBridge : NSObject
/// Swift: try PLRuntimeBridge.capture()
+ (nullable PLGameSnapshot *)captureWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(capture());
/// Swift: try PLRuntimeBridge.apply(angle: radiansYUp, power: valueInZeroToOne)
/// Updates the cue controls only; never triggers a shot.
+ (BOOL)applyAngle:(double)angle power:(double)power
             error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(apply(angle:power:));
@end

NS_ASSUME_NONNULL_END
