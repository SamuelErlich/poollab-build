#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Value snapshot copied from the game on its rendering thread.
@interface PLBallSnapshot : NSObject
@property(nonatomic, readonly) NSInteger number;
@property(nonatomic, readonly) double x;
@property(nonatomic, readonly) double y;
@property(nonatomic, readonly) double vx;
@property(nonatomic, readonly) double vy;
@property(nonatomic, readonly) double radius;
@end

@interface PLGameSnapshot : NSObject
@property(nonatomic, copy, readonly) NSArray<PLBallSnapshot *> *balls;
@property(nonatomic, readonly) double originX;
@property(nonatomic, readonly) double originY;
@property(nonatomic, readonly) double width;
@property(nonatomic, readonly) double height;
@property(nonatomic, readonly) BOOL playerTurn;
/// Current native cue direction in physical, Y-up radians.
@property(nonatomic, readonly) BOOL aimAvailable;
@property(nonatomic, readonly) double aimAngle;
@property(nonatomic, readonly) double cuePower;
/// Live native maximum shot speed, in the game's physical units; zero if unavailable.
@property(nonatomic, readonly) double maximumShotSpeed;
/// True only for the validated normal-rule physics parameter path.
@property(nonatomic, readonly) BOOL physicsCalibrationAvailable;
@property(nonatomic, readonly) double rollingDeceleration;
@property(nonatomic, readonly) double ballRestitution;
@property(nonatomic, readonly) double cushionRestitution;
@property(nonatomic, readonly) BOOL goldenShot;
@property(nonatomic, readonly) BOOL goldenTargetAvailable;
@property(nonatomic, readonly) double goldenTargetX;
@property(nonatomic, readonly) double goldenTargetY;
/// Zero means the scoring ring radius has not been established.
@property(nonatomic, readonly) double goldenTargetRadius;
@property(nonatomic, readonly) NSInteger goldenBallNumber;
/// Readiness for planning/nomination now. The final shot validates the cue again.
@property(nonatomic, readonly) BOOL canShoot;
@property(nonatomic, copy, readonly) NSArray<NSNumber *> *legalTargetNumbers;
/// Structural support for these rules/callbacks, independent of the current turn.
@property(nonatomic, readonly) BOOL autoShotAvailable;
@property(nonatomic, copy, readonly) NSString *autoShotUnavailableReason;
/// Corners in coordinateView's UIKit coordinate system. Physical Y increases upward.
/// topLeft maps (originX, originY + height).
/// topRight maps (originX + width, originY + height).
/// bottomLeft maps (originX, originY).
/// For a Y-down engine: localY = originY + height - physicalY; negate aim angle.
@property(nonatomic, readonly) CGPoint tableTopLeft;
@property(nonatomic, readonly) CGPoint tableTopRight;
@property(nonatomic, readonly) CGPoint tableBottomLeft;
@property(nonatomic, strong, readonly) UIView *coordinateView;
@end

@interface PLRuntimeBridge : NSObject
/// Swift: try PLRuntimeBridge.capture()
+ (nullable PLGameSnapshot *)captureWithError:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(capture());
/// Swift: try PLRuntimeBridge.apply(angle: radiansYUp, power: valueInZeroToOne)
/// Updates the cue controls only; never triggers a shot.
+ (BOOL)applyAngle:(double)angle power:(double)power
             error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(apply(angle:power:));
/// Uses the game's normal shot-release callback after freshly validating its state.
/// Pocket IDs follow the planner's order: top-left, top-middle, top-right,
/// bottom-left, bottom-middle, bottom-right. Nothing is dispatched on validation failure.
+ (BOOL)shootAngle:(double)angle power:(double)power target:(NSInteger)target
            pocket:(NSInteger)pocket error:(NSError * _Nullable * _Nullable)error
    NS_SWIFT_NAME(shoot(angle:power:target:pocket:));
@end

NS_ASSUME_NONNULL_END
