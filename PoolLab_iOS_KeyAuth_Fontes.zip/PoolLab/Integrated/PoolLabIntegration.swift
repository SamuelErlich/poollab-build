import UIKit
import SwiftUI
import PoolLabCore

@objc(PLIntegrationBootstrap)
@MainActor
public final class PLIntegrationBootstrap: NSObject {
    private static var retainedCoordinator: PLIntegrationCoordinator?

    @objc public static func start() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { start() }
            return
        }
        if retainedCoordinator == nil { retainedCoordinator = PLIntegrationCoordinator() }
        retainedCoordinator?.installIfNeeded()
    }
}

@MainActor
private final class PLIntegrationCoordinator {
    private let authorization: AppModel
    private let game: IntegratedGameModel
    private var window: PLPassthroughWindow?
    private var observers: [NSObjectProtocol] = []

    init() {
        authorization = AppModel(configurationBundle: Bundle(for: PLIntegrationBootstrap.self))
        game = IntegratedGameModel(authorization: authorization)
        observe(UIApplication.didBecomeActiveNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIApplication.willResignActiveNotification) { [weak self] _ in self?.suspend() }
        observe(UIApplication.didEnterBackgroundNotification) { [weak self] _ in self?.suspend() }
        observe(UIScene.didActivateNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIScene.willDeactivateNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.suspend()
        }
        observe(UIScene.didDisconnectNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.removeWindow()
            self.installIfNeeded()
        }
    }

    func installIfNeeded() {
        guard UIApplication.shared.applicationState == .active else { return }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .filter { $0.activationState == .foregroundActive }
        let scene = scenes.first { candidate in
            candidate.windows.contains { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
        } ?? scenes.first { candidate in
            candidate.windows.contains { !$0.isHidden && !($0 is PLPassthroughWindow) }
        }
        // The target also supports the pre-UIScene AppDelegate lifecycle.
        // UIApplication.windows is intentionally used only for that fallback.
        let candidates = scene?.windows ?? UIApplication.shared.windows
        let host = candidates.first { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
            ?? candidates.first { !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
        guard let host else { return }
        let frame = scene?.coordinateSpace.bounds ?? host.frame
        if let window, window.windowScene === scene {
            window.frame = frame
            window.isHidden = false
            game.becameActive()
            return
        }
        removeWindow()
        let controller = PLOverlayController(model: game, hostWindow: host)
        let overlay: PLPassthroughWindow
        if let scene { overlay = PLPassthroughWindow(windowScene: scene) }
        else { overlay = PLPassthroughWindow(frame: frame) }
        overlay.frame = frame
        overlay.windowLevel = UIWindow.Level(rawValue: UIWindow.Level.normal.rawValue + 1)
        overlay.backgroundColor = .clear
        overlay.overrideUserInterfaceStyle = .dark
        overlay.rootViewController = controller
        overlay.isHidden = false
        // The closed overlay never takes focus. Login borrows it only after a tap.
        window = overlay
        game.becameActive()
    }

    private func suspend() {
        game.becameInactive()
        window?.returnKeyboardFocus()
        window?.isHidden = true
    }

    private func removeWindow() {
        game.becameInactive()
        window?.returnKeyboardFocus()
        window?.isHidden = true
        window?.rootViewController = nil
        window = nil
    }

    private func observe(_ name: Notification.Name, action: @escaping @MainActor (Notification) -> Void) {
        let token = NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { note in
            Task { @MainActor in action(note) }
        }
        observers.append(token)
    }
}

private final class PLPassthroughWindow: UIWindow {
    private weak var previousKeyWindow: UIWindow?

    func borrowKeyboardFocus() {
        guard !isKeyWindow else { return }
        let candidates = windowScene?.windows ?? UIApplication.shared.windows
        previousKeyWindow = candidates.first { $0.isKeyWindow && $0 !== self }
        makeKey()
    }

    func returnKeyboardFocus() {
        endEditing(true)
        if isKeyWindow {
            let candidates = windowScene?.windows ?? UIApplication.shared.windows
            let candidate = previousKeyWindow ?? candidates.first { $0 !== self && !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
            candidate?.makeKey()
        }
        previousKeyWindow = nil
    }

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let target = super.hitTest(point, with: event)
        if target === self || target === rootViewController?.view { return nil }
        return target
    }
}

private final class PLPassthroughView: UIView {
    weak var floatingButton: UIView?
    weak var panel: UIView?

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard !isHidden, alpha > 0.01, isUserInteractionEnabled else { return nil }
        for candidate in [floatingButton, panel].compactMap({ $0 }) {
            guard !candidate.isHidden, candidate.alpha > 0.01, candidate.isUserInteractionEnabled else { continue }
            let converted = convert(point, to: candidate)
            if candidate.point(inside: converted, with: event) {
                return candidate.hitTest(converted, with: event)
            }
        }
        return nil
    }
}

@MainActor
private final class PLOverlayController: UIViewController {
    private let model: IntegratedGameModel
    private weak var hostWindow: UIWindow?
    private let floatingButton = UIButton(type: .system)
    private let panelContainer = UIView()
    private var panelHost: UIHostingController<PLIntegratedPanel>?
    private let trajectories = CALayer()
    private var paths: [Int: CAShapeLayer] = [:]
    private var panelOpen = false
    private var buttonAnchor = CGPoint(x: 1, y: 0.18)

    init(model: IntegratedGameModel, hostWindow: UIWindow) {
        self.model = model
        self.hostWindow = hostWindow
        super.init(nibName: nil, bundle: nil)
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        hostWindow?.rootViewController?.supportedInterfaceOrientations ?? .allButUpsideDown
    }

    override var shouldAutorotate: Bool {
        hostWindow?.rootViewController?.shouldAutorotate ?? true
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func loadView() {
        let root = PLPassthroughView()
        root.backgroundColor = .clear
        root.floatingButton = floatingButton
        root.panel = panelContainer
        view = root
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        trajectories.masksToBounds = true
        view.layer.addSublayer(trajectories)
        floatingButton.setTitle("PL", for: .normal)
        floatingButton.setTitleColor(UIColor(red: 0.025, green: 0.09, blue: 0.08, alpha: 1), for: .normal)
        floatingButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .heavy)
        floatingButton.backgroundColor = UIColor(red: 0.28, green: 0.90, blue: 0.76, alpha: 1)
        floatingButton.layer.cornerRadius = 24
        floatingButton.layer.shadowColor = UIColor.black.cgColor
        floatingButton.layer.shadowOpacity = 0.35
        floatingButton.layer.shadowRadius = 6
        floatingButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        floatingButton.accessibilityLabel = "Abrir ou fechar PoolLab"
        floatingButton.accessibilityHint = "Arraste o botão para mudar sua posição"
        floatingButton.addTarget(self, action: #selector(togglePanel), for: .touchUpInside)
        floatingButton.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(moveButton(_:))))
        view.addSubview(floatingButton)

        panelContainer.backgroundColor = UIColor(red: 0.035, green: 0.055, blue: 0.075, alpha: 0.97)
        panelContainer.layer.cornerRadius = 20
        panelContainer.layer.borderWidth = 1
        panelContainer.layer.borderColor = UIColor.white.withAlphaComponent(0.12).cgColor
        panelContainer.clipsToBounds = true
        view.addSubview(panelContainer)
        let host = UIHostingController(rootView: PLIntegratedPanel(
            model: model, authorization: model.authorization,
            close: { [weak self] in self?.closePanel() },
            beginLogin: { [weak self] in self?.focusLogin() },
            accessChanged: { [weak self] allowed in
                if allowed { (self?.view.window as? PLPassthroughWindow)?.returnKeyboardFocus() }
            }
        ))
        host.view.backgroundColor = .clear
        addChild(host)
        panelContainer.addSubview(host.view)
        host.didMove(toParent: self)
        panelHost = host
        model.onOverlayChange = { [weak self] in self?.drawTrajectories() }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 60, safe.height > 60 else { return }
        let center = CGPoint(x: safe.minX + 24 + (safe.width - 48) * buttonAnchor.x,
                             y: safe.minY + 24 + (safe.height - 48) * buttonAnchor.y)
        floatingButton.frame = CGRect(x: center.x - 24, y: center.y - 24, width: 48, height: 48)
        let width = min(370, safe.width)
        let height = min(650, max(160, safe.height - 58))
        let panelX = min(safe.maxX - width, max(safe.minX, center.x - width + 24))
        let preferredY = center.y + 34
        let panelY = min(safe.maxY - height, max(safe.minY, preferredY))
        panelContainer.frame = CGRect(x: panelX, y: panelY, width: width, height: height)
        panelHost?.view.frame = panelContainer.bounds
        panelContainer.isHidden = !panelOpen
        trajectories.frame = view.bounds
        // Keep the draggable button reachable above the bounded panel.
        view.bringSubviewToFront(floatingButton)
        drawTrajectories()
    }

    @objc private func togglePanel() {
        panelOpen.toggle()
        panelContainer.isHidden = !panelOpen
        if panelOpen { focusLogin() }
        else { (view.window as? PLPassthroughWindow)?.returnKeyboardFocus() }
    }

    private func closePanel() {
        panelOpen = false
        (view.window as? PLPassthroughWindow)?.returnKeyboardFocus()
        panelContainer.isHidden = true
    }

    private func focusLogin() {
        guard panelOpen, !model.authorization.canUseModules else { return }
        (view.window as? PLPassthroughWindow)?.borrowKeyboardFocus()
    }

    @objc private func moveButton(_ gesture: UIPanGestureRecognizer) {
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 48, safe.height > 48 else { return }
        let delta = gesture.translation(in: view)
        let position = CGPoint(x: min(safe.maxX - 24, max(safe.minX + 24, floatingButton.center.x + delta.x)),
                               y: min(safe.maxY - 24, max(safe.minY + 24, floatingButton.center.y + delta.y)))
        buttonAnchor = CGPoint(x: (position.x - safe.minX - 24) / (safe.width - 48),
                               y: (position.y - safe.minY - 24) / (safe.height - 48))
        gesture.setTranslation(.zero, in: view)
        view.setNeedsLayout()
    }

    private func drawTrajectories() {
        guard isViewLoaded, let window = view.window else { return }
        let current = model.overlayPaths(in: window)
        let visible = Set(current.map { $0.0 })
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        for (id, layer) in paths where !visible.contains(id) { layer.path = nil }
        for (id, points) in current {
            let layer: CAShapeLayer
            if let previous = paths[id] { layer = previous }
            else {
                layer = CAShapeLayer()
                layer.fillColor = nil
                layer.lineCap = .round
                layer.lineJoin = .round
                layer.lineWidth = id == 0 ? 2.1 : 1.6
                layer.lineDashPattern = id == 0 ? [7, 4] : [4, 3]
                layer.strokeColor = Self.traceColor(id).cgColor
                trajectories.addSublayer(layer)
                paths[id] = layer
            }
            let path = UIBezierPath()
            if let first = points.first {
                path.move(to: view.convert(first, from: window))
                for point in points.dropFirst() { path.addLine(to: view.convert(point, from: window)) }
            }
            layer.path = path.cgPath
        }
        CATransaction.commit()
    }

    private static func traceColor(_ id: Int) -> UIColor {
        switch id {
        case 0: return UIColor(red: 0.28, green: 0.95, blue: 0.82, alpha: 0.96)
        case 1, 9: return .systemYellow
        case 2, 10: return .systemBlue
        case 3, 11: return .systemRed
        case 4, 12: return .systemPurple
        case 5, 13: return .systemOrange
        case 6, 14: return .systemGreen
        case 7, 15: return .systemPink
        default: return .white
        }
    }
}

@MainActor
private struct PLIntegratedPanel: View {
    @ObservedObject var model: IntegratedGameModel
    @ObservedObject var authorization: AppModel
    let close: () -> Void
    let beginLogin: () -> Void
    let accessChanged: (Bool) -> Void

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("PoolLab").font(.headline)
                    Text("NA PARTIDA").font(.system(size: 9, weight: .bold)).tracking(1.7).foregroundColor(PoolTheme.accent)
                }
                Spacer()
                Button(action: close) { Image(systemName: "xmark").frame(width: 36, height: 36) }
                    .accessibilityLabel("Fechar painel; manter linhas na partida")
            }
            .padding(.horizontal, 17)
            .padding(.vertical, 11)
            Divider().overlay(PoolTheme.border)
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if authorization.canUseModules { controls }
                    else { login }
                }
                .padding(17)
            }
        }
        .foregroundColor(.white)
        .tint(PoolTheme.accent)
        .background(PoolTheme.background.opacity(0.98))
        .onChange(of: authorization.canUseModules) { allowed in
            model.authorizationChanged()
            accessChanged(allowed)
        }
    }

    private var login: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Ative seu acesso").font(.title3.bold())
            Text("A licença libera a leitura e os controles do painel integrado.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
            if let issue = authorization.configurationIssue {
                Text(issue).font(.caption).foregroundColor(PoolTheme.warning)
            }
            if authorization.session != nil {
                HStack {
                    ProgressView()
                    Text(authorization.statusText).font(.caption)
                }
                Button("Sair desta sessão") { Task { await authorization.signOut() } }
                    .frame(minHeight: 40)
            } else {
                SecureField("Chave de acesso", text: $authorization.licenseKey)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .poolField()
                TextField("Código de autenticação, se houver", text: $authorization.twoFactorCode)
                    .keyboardType(.numberPad)
                    .textContentType(.oneTimeCode)
                    .poolField()
                if case .error(let error) = authorization.phase {
                    Text(error).font(.caption).foregroundColor(PoolTheme.warning)
                }
                Button {
                    Task { await authorization.activate(); model.authorizationChanged() }
                } label: {
                    if authorization.phase == .authenticating { ProgressView() }
                    else { Text("Ativar licença") }
                }
                .buttonStyle(PoolPrimaryButtonStyle())
                .disabled(authorization.configurationIssue != nil || authorization.phase == .authenticating || authorization.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            Text("Conexão necessária para validar a licença.")
                .font(.caption2).foregroundColor(PoolTheme.secondary)
        }
        .simultaneousGesture(TapGesture().onEnded { beginLogin() })
    }

    private var controls: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                PoolStatusLabel(title: model.hasTable ? "\(model.ballCount) bolas" : "Sem mesa", symbol: model.hasTable ? "checkmark.circle" : "circle.dashed", color: model.hasTable ? PoolTheme.accent : PoolTheme.warning)
                Spacer()
                if model.hasTable {
                    Text(model.isPlayerTurn ? "Sua vez" : "Aguardando sua vez")
                        .font(.caption2).foregroundColor(model.isPlayerTurn ? PoolTheme.accent : PoolTheme.secondary)
                }
            }
            Text(model.status).font(.caption).foregroundColor(PoolTheme.secondary).fixedSize(horizontal: false, vertical: true)
            directionControls
            Toggle("Trajetória de todas as bolas", isOn: Binding(get: { model.showAllPaths }, set: model.setShowAllPaths))
                .font(.caption)
            HStack(spacing: 10) {
                Button { model.refresh() } label: {
                    Label("Prever", systemImage: "line.diagonal").frame(maxWidth: .infinity, minHeight: 40)
                }
                .disabled(!model.canCalculate)
                Button { model.recommend() } label: {
                    HStack(spacing: 5) {
                        if model.isPlanning { ProgressView().scaleEffect(0.7) }
                        Text("Sugerir")
                    }.frame(maxWidth: .infinity, minHeight: 40)
                }
                .disabled(!model.canCalculate || model.isPlanning)
            }
            .buttonStyle(.bordered)
            .font(.subheadline.weight(.semibold))
            if model.isPredicting {
                HStack(spacing: 8) { ProgressView().scaleEffect(0.75); Text("Calculando percurso…").font(.caption) }
            }
            if !model.suggestions.isEmpty { suggestionRows }
            Button { model.applyAim() } label: {
                Label("Aplicar direção e força", systemImage: "scope")
            }
            .buttonStyle(PoolPrimaryButtonStyle())
            .disabled(!model.canApplyAim)
            Text("O botão ajusta a mira da partida. A tacada continua sendo executada por você no jogo.")
                .font(.caption2).foregroundColor(PoolTheme.secondary)
            Divider().overlay(PoolTheme.border)
            Text("Trajetórias aproximadas, calculadas com as posições lidas da partida. A física deste modelo pode diferir da física do jogo; efeito na bola não é reproduzido.")
                .font(.caption2).foregroundColor(PoolTheme.warning)
                .fixedSize(horizontal: false, vertical: true)
            Button("Sair da licença") { Task { await authorization.signOut() } }
                .font(.caption).frame(minHeight: 36)
        }
    }

    private var directionControls: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Ângulo da previsão")
                Spacer()
                Text("\(Int(model.angleDegrees.rounded()))°").monospacedDigit().foregroundColor(PoolTheme.accent)
            }
            .font(.subheadline)
            Slider(value: Binding(get: { model.angleDegrees }, set: model.setAngle), in: 0...360, step: 0.5)
                .accessibilityLabel("Ângulo da previsão")
            HStack {
                Text("Força")
                Spacer()
                Text("\(Int((model.power * 100).rounded()))%")
                    .monospacedDigit().foregroundColor(PoolTheme.accent)
            }
            .font(.subheadline)
            Slider(value: Binding(get: { model.power }, set: model.setPower), in: 0.03...1, step: 0.01)
                .accessibilityLabel("Força da tacada")
        }
        .disabled(!model.canCalculate)
    }

    private var suggestionRows: some View {
        VStack(spacing: 7) {
            ForEach(Array(model.suggestions.enumerated()), id: \.element.id) { index, suggestion in
                Button { model.selectSuggestion(suggestion) } label: {
                    HStack(alignment: .top, spacing: 9) {
                        Text("\(index + 1)").font(.headline).foregroundColor(PoolTheme.accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Bola \(suggestion.targetID) · \(suggestion.method == .bank ? "Tabela" : "Direta")")
                                .font(.caption.weight(.semibold)).foregroundColor(.white)
                            Text("Caçapa \(suggestion.pocketID + 1) · força \(Int((suggestion.shot.power * 100).rounded()))%")
                                .font(.caption2).foregroundColor(PoolTheme.secondary)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "arrow.up.right.circle").foregroundColor(PoolTheme.accent)
                    }
                    .padding(10)
                    .background(PoolTheme.surface)
                    .clipShape(RoundedRectangle(cornerRadius: 11))
                }
                .buttonStyle(.plain)
                .disabled(!model.canCalculate)
            }
            Text("Escolher uma opção atualiza a previsão. A ordem reflete o custo calculado, não a chance real de acerto.")
                .font(.caption2).foregroundColor(PoolTheme.secondary)
        }
    }
}
