import UIKit
import SwiftUI
import PoolLabCore

@objc(PLIntegrationBootstrap)
@MainActor
public final class PLIntegrationBootstrap: NSObject {
    private static var retainedCoordinator: PLIntegrationCoordinator?

    @objc public static func start() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { start() }
            return
        }
        if retainedCoordinator == nil { retainedCoordinator = PLIntegrationCoordinator() }
        retainedCoordinator?.installIfNeeded()
    }
}

@MainActor
private final class PLIntegrationCoordinator {
    private let authorization: AppModel
    private let game: IntegratedGameModel
    private var window: PLPassthroughWindow?
    private var observers: [NSObjectProtocol] = []

    init() {
        authorization = AppModel(configurationBundle: Bundle(for: PLIntegrationBootstrap.self))
        game = IntegratedGameModel(authorization: authorization)
        observe(UIApplication.didBecomeActiveNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIApplication.willResignActiveNotification) { [weak self] _ in self?.suspend() }
        observe(UIApplication.didEnterBackgroundNotification) { [weak self] _ in self?.suspend() }
        observe(UIScene.didActivateNotification) { [weak self] _ in self?.installIfNeeded() }
        observe(UIScene.willDeactivateNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.suspend()
        }
        observe(UIScene.didDisconnectNotification) { [weak self] note in
            guard let self, let scene = note.object as? UIWindowScene, self.window?.windowScene === scene else { return }
            self.removeWindow()
            self.installIfNeeded()
        }
    }

    func installIfNeeded() {
        guard UIApplication.shared.applicationState == .active else { return }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .filter { $0.activationState == .foregroundActive }
        let scene = scenes.first { candidate in
            candidate.windows.contains { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
        } ?? scenes.first { candidate in
            candidate.windows.contains { !$0.isHidden && !($0 is PLPassthroughWindow) }
        }
        // The target also supports the pre-UIScene AppDelegate lifecycle.
        // UIApplication.windows is intentionally used only for that fallback.
        let candidates = scene?.windows ?? UIApplication.shared.windows
        let host = candidates.first { $0.isKeyWindow && !($0 is PLPassthroughWindow) }
            ?? candidates.first { !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
        guard let host else { return }
        let frame = scene?.coordinateSpace.bounds ?? host.frame
        if let window, window.windowScene === scene {
            window.frame = frame
            window.isHidden = false
            game.becameActive()
            return
        }
        removeWindow()
        let controller = PLOverlayController(model: game, hostWindow: host)
        let overlay: PLPassthroughWindow
        if let scene { overlay = PLPassthroughWindow(windowScene: scene) }
        else { overlay = PLPassthroughWindow(frame: frame) }
        overlay.frame = frame
        overlay.windowLevel = UIWindow.Level(rawValue: UIWindow.Level.normal.rawValue + 1)
        overlay.backgroundColor = .clear
        overlay.overrideUserInterfaceStyle = .dark
        overlay.rootViewController = controller
        overlay.isHidden = false
        // The closed overlay never takes focus. Login borrows it only after a tap.
        window = overlay
        game.becameActive()
    }

    private func suspend() {
        game.becameInactive()
        window?.returnKeyboardFocus()
        window?.isHidden = true
    }

    private func removeWindow() {
        game.becameInactive()
        window?.returnKeyboardFocus()
        window?.isHidden = true
        window?.rootViewController = nil
        window = nil
    }

    private func observe(_ name: Notification.Name, action: @escaping @MainActor (Notification) -> Void) {
        let token = NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { note in
            Task { @MainActor in action(note) }
        }
        observers.append(token)
    }
}

private final class PLPassthroughWindow: UIWindow {
    private weak var previousKeyWindow: UIWindow?

    func borrowKeyboardFocus() {
        guard !isKeyWindow else { return }
        let candidates = windowScene?.windows ?? UIApplication.shared.windows
        previousKeyWindow = candidates.first { $0.isKeyWindow && $0 !== self }
        makeKey()
    }

    func returnKeyboardFocus() {
        endEditing(true)
        if isKeyWindow {
            let candidates = windowScene?.windows ?? UIApplication.shared.windows
            let candidate = previousKeyWindow ?? candidates.first { $0 !== self && !$0.isHidden && $0.windowLevel == .normal && !($0 is PLPassthroughWindow) }
            candidate?.makeKey()
        }
        previousKeyWindow = nil
    }

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let target = super.hitTest(point, with: event)
        if target === self || target === rootViewController?.view { return nil }
        return target
    }
}

private final class PLPassthroughView: UIView {
    weak var floatingButton: UIView?
    weak var panel: UIView?

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard !isHidden, alpha > 0.01, isUserInteractionEnabled else { return nil }
        for candidate in [floatingButton, panel].compactMap({ $0 }) {
            guard !candidate.isHidden, candidate.alpha > 0.01, candidate.isUserInteractionEnabled else { continue }
            let converted = convert(point, to: candidate)
            if candidate.point(inside: converted, with: event) {
                return candidate.hitTest(converted, with: event)
            }
        }
        return nil
    }
}

@MainActor
private final class PLOverlayController: UIViewController {
    private let model: IntegratedGameModel
    private weak var hostWindow: UIWindow?
    private let floatingButton = UIButton(type: .system)
    private let panelContainer = UIView()
    private var panelHost: UIHostingController<PLIntegratedPanel>?
    private let trajectories = CALayer()
    private let luckyTarget = CAShapeLayer()
    private var paths: [Int: CAShapeLayer] = [:]
    private var endpoints: [Int: CAShapeLayer] = [:]
    private var endpointLabels: [Int: CATextLayer] = [:]
    private var panelOpen = false
    private var buttonAnchor = CGPoint(x: 1, y: 0.18)

    init(model: IntegratedGameModel, hostWindow: UIWindow) {
        self.model = model
        self.hostWindow = hostWindow
        super.init(nibName: nil, bundle: nil)
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        hostWindow?.rootViewController?.supportedInterfaceOrientations ?? .allButUpsideDown
    }

    override var shouldAutorotate: Bool {
        hostWindow?.rootViewController?.shouldAutorotate ?? true
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func loadView() {
        let root = PLPassthroughView()
        root.backgroundColor = .clear
        root.floatingButton = floatingButton
        root.panel = panelContainer
        view = root
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        trajectories.masksToBounds = true
        view.layer.addSublayer(trajectories)
        luckyTarget.fillColor = nil
        luckyTarget.strokeColor = UIColor.systemYellow.cgColor
        luckyTarget.lineWidth = 2
        trajectories.addSublayer(luckyTarget)
        floatingButton.setTitle("PL", for: .normal)
        floatingButton.setTitleColor(UIColor(red: 0.025, green: 0.09, blue: 0.08, alpha: 1), for: .normal)
        floatingButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .heavy)
        floatingButton.backgroundColor = UIColor(red: 0.28, green: 0.90, blue: 0.76, alpha: 1)
        floatingButton.layer.cornerRadius = 24
        floatingButton.layer.shadowColor = UIColor.black.cgColor
        floatingButton.layer.shadowOpacity = 0.35
        floatingButton.layer.shadowRadius = 6
        floatingButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        floatingButton.accessibilityLabel = "Abrir ou fechar PoolLab"
        floatingButton.accessibilityHint = "Arraste o botão para mudar sua posição"
        floatingButton.addTarget(self, action: #selector(togglePanel), for: .touchUpInside)
        floatingButton.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(moveButton(_:))))
        view.addSubview(floatingButton)

        panelContainer.backgroundColor = UIColor(red: 0.035, green: 0.055, blue: 0.075, alpha: 0.97)
        panelContainer.layer.cornerRadius = 20
        panelContainer.layer.borderWidth = 1
        panelContainer.layer.borderColor = UIColor.white.withAlphaComponent(0.12).cgColor
        panelContainer.clipsToBounds = true
        view.addSubview(panelContainer)
        let host = UIHostingController(rootView: PLIntegratedPanel(
            model: model, authorization: model.authorization,
            close: { [weak self] in self?.closePanel() },
            beginLogin: { [weak self] in self?.focusLogin() },
            accessChanged: { [weak self] allowed in
                if allowed { (self?.view.window as? PLPassthroughWindow)?.returnKeyboardFocus() }
            }
        ))
        host.view.backgroundColor = .clear
        addChild(host)
        panelContainer.addSubview(host.view)
        host.didMove(toParent: self)
        panelHost = host
        model.onOverlayChange = { [weak self] in self?.drawTrajectories() }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 60, safe.height > 60 else { return }
        let center = CGPoint(x: safe.minX + 24 + (safe.width - 48) * buttonAnchor.x,
                             y: safe.minY + 24 + (safe.height - 48) * buttonAnchor.y)
        floatingButton.frame = CGRect(x: center.x - 24, y: center.y - 24, width: 48, height: 48)
        let isLandscape = safe.width > safe.height
        let width = min(isLandscape ? 290 : 340, safe.width)
        let height = min(650, max(160, safe.height - 58))
        let panelX = min(safe.maxX - width, max(safe.minX, center.x - width + 24))
        let preferredY = center.y + 34
        let panelY = min(safe.maxY - height, max(safe.minY, preferredY))
        panelContainer.frame = CGRect(x: panelX, y: panelY, width: width, height: height)
        panelHost?.view.frame = panelContainer.bounds
        panelContainer.isHidden = !panelOpen
        trajectories.frame = view.bounds
        // Keep the draggable button reachable above the bounded panel.
        view.bringSubviewToFront(floatingButton)
        drawTrajectories()
    }

    @objc private func togglePanel() {
        panelOpen.toggle()
        panelContainer.isHidden = !panelOpen
        if panelOpen { focusLogin() }
        else { (view.window as? PLPassthroughWindow)?.returnKeyboardFocus() }
    }

    private func closePanel() {
        panelOpen = false
        (view.window as? PLPassthroughWindow)?.returnKeyboardFocus()
        panelContainer.isHidden = true
    }

    private func focusLogin() {
        guard panelOpen, !model.authorization.canUseModules else { return }
        (view.window as? PLPassthroughWindow)?.borrowKeyboardFocus()
    }

    @objc private func moveButton(_ gesture: UIPanGestureRecognizer) {
        let safe = view.bounds.inset(by: view.safeAreaInsets).insetBy(dx: 10, dy: 10)
        guard safe.width > 48, safe.height > 48 else { return }
        let delta = gesture.translation(in: view)
        let position = CGPoint(x: min(safe.maxX - 24, max(safe.minX + 24, floatingButton.center.x + delta.x)),
                               y: min(safe.maxY - 24, max(safe.minY + 24, floatingButton.center.y + delta.y)))
        buttonAnchor = CGPoint(x: (position.x - safe.minX - 24) / (safe.width - 48),
                               y: (position.y - safe.minY - 24) / (safe.height - 48))
        gesture.setTranslation(.zero, in: view)
        view.setNeedsLayout()
    }

    private func drawTrajectories() {
        guard isViewLoaded, let window = view.window else { return }
        let current = model.overlayPaths(in: window)
        let visible = Set(current.map { $0.0 })
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        for (id, layer) in paths where !visible.contains(id) { layer.path = nil }
        for (id, points) in current {
            let layer: CAShapeLayer
            if let previous = paths[id] { layer = previous }
            else {
                layer = CAShapeLayer()
                layer.fillColor = nil
                layer.lineCap = .round
                layer.lineJoin = .round
                layer.lineDashPattern = id == 0 ? [7, 4] : [4, 3]
                trajectories.addSublayer(layer)
                paths[id] = layer
            }
            let path = UIBezierPath()
            if let first = points.first {
                path.move(to: view.convert(first, from: window))
                for point in points.dropFirst() { path.addLine(to: view.convert(point, from: window)) }
            }
            layer.path = path.cgPath
            layer.lineWidth = CGFloat(model.pathWidth) * (id == 0 ? 1.15 : 1)
            layer.strokeColor = styledColor(id).cgColor
        }
        let finalPositions = model.overlayFinalPositions(in: window)
        let visibleFinal = Set(finalPositions.map { $0.0 })
        for (id, layer) in endpoints where !visibleFinal.contains(id) { layer.isHidden = true }
        for (id, layer) in endpointLabels where !visibleFinal.contains(id) { layer.isHidden = true }
        for (id, center, radius, pocketed) in finalPositions {
            let circle: CAShapeLayer
            let label: CATextLayer
            if let existing = endpoints[id], let existingLabel = endpointLabels[id] {
                circle = existing; label = existingLabel
            } else {
                circle = CAShapeLayer()
                circle.fillColor = UIColor.black.withAlphaComponent(0.48).cgColor
                trajectories.addSublayer(circle)
                endpoints[id] = circle
                label = CATextLayer()
                label.alignmentMode = .center
                label.foregroundColor = UIColor.white.cgColor
                label.font = UIFont.systemFont(ofSize: 10, weight: .bold)
                trajectories.addSublayer(label)
                endpointLabels[id] = label
            }
            let local = view.convert(center, from: window)
            let size = max(7, radius)
            circle.isHidden = false
            circle.path = UIBezierPath(ovalIn: CGRect(x: local.x - size, y: local.y - size,
                                                     width: size * 2, height: size * 2)).cgPath
            circle.lineWidth = CGFloat(model.pathWidth)
            circle.strokeColor = styledColor(id).cgColor
            circle.lineDashPattern = pocketed ? [2, 2] : nil
            label.isHidden = !model.showFinalNumbers
            label.contentsScale = window.screen.scale
            label.fontSize = min(12, max(9, size))
            label.string = id == 0 ? "●" : "\(id)"
            label.frame = CGRect(x: local.x - size, y: local.y - label.fontSize * 0.65,
                                 width: size * 2, height: label.fontSize * 1.5)
            label.opacity = Float(model.pathOpacity)
        }
        if let center = model.overlayLuckyTarget(in: window) {
            let point = view.convert(center, from: window)
            let marker = UIBezierPath()
            marker.move(to: CGPoint(x: point.x - 8, y: point.y)); marker.addLine(to: CGPoint(x: point.x + 8, y: point.y))
            marker.move(to: CGPoint(x: point.x, y: point.y - 8)); marker.addLine(to: CGPoint(x: point.x, y: point.y + 8))
            luckyTarget.path = marker.cgPath
        } else { luckyTarget.path = nil }
        CATransaction.commit()
    }

    private func styledColor(_ id: Int) -> UIColor {
        let color: UIColor
        switch model.pathColorMode {
        case "mint": color = UIColor(red: 0.28, green: 0.95, blue: 0.82, alpha: 1)
        case "white": color = .white
        default: color = Self.traceColor(id)
        }
        return color.withAlphaComponent(CGFloat(model.pathOpacity))
    }

    private static func traceColor(_ id: Int) -> UIColor {
        switch id {
        case 0: return UIColor(red: 0.28, green: 0.95, blue: 0.82, alpha: 0.96)
        case 1, 9: return .systemYellow
        case 2, 10: return .systemBlue
        case 3, 11: return .systemRed
        case 4, 12: return .systemPurple
        case 5, 13: return .systemOrange
        case 6, 14: return .systemGreen
        case 7, 15: return .systemPink
        default: return .white
        }
    }
}

@MainActor
private struct PLIntegratedPanel: View {
    @ObservedObject var model: IntegratedGameModel
    @ObservedObject var authorization: AppModel
    let close: () -> Void
    let beginLogin: () -> Void
    let accessChanged: (Bool) -> Void

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("PoolLab").font(.headline)
                    Text("NA PARTIDA").font(.system(size: 9, weight: .bold)).tracking(1.7).foregroundColor(PoolTheme.accent)
                }
                Spacer()
                Button(action: close) { Image(systemName: "xmark").frame(width: 36, height: 36) }
                    .accessibilityLabel("Fechar painel; manter linhas na partida")
            }
            .padding(.horizontal, 17)
            .padding(.vertical, 11)
            Divider().overlay(PoolTheme.border)
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    if authorization.canUseModules { controls }
                    else { login }
                }
                .padding(17)
            }
        }
        .foregroundColor(.white)
        .tint(PoolTheme.accent)
        .background(PoolTheme.background.opacity(0.98))
        .onChange(of: authorization.canUseModules) { allowed in
            model.authorizationChanged()
            accessChanged(allowed)
        }
    }

    private var login: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Ative seu acesso").font(.title3.bold())
            Text("A licença libera a leitura e os controles do painel integrado.")
                .font(.caption).foregroundColor(PoolTheme.secondary)
            if let issue = authorization.configurationIssue {
                Text(issue).font(.caption).foregroundColor(PoolTheme.warning)
            }
            if authorization.session != nil {
                HStack {
                    ProgressView()
                    Text(authorization.statusText).font(.caption)
                }
                Button("Sair desta sessão") { Task { await authorization.signOut() } }
                    .frame(minHeight: 40)
            } else {
                SecureField("Chave de acesso", text: $authorization.licenseKey)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .poolField()
                TextField("Código de autenticação, se houver", text: $authorization.twoFactorCode)
                    .keyboardType(.numberPad)
                    .textContentType(.oneTimeCode)
                    .poolField()
                if case .error(let error) = authorization.phase {
                    Text(error).font(.caption).foregroundColor(PoolTheme.warning)
                }
                Button {
                    Task { await authorization.activate(); model.authorizationChanged() }
                } label: {
                    if authorization.phase == .authenticating { ProgressView() }
                    else { Text("Ativar licença") }
                }
                .buttonStyle(PoolPrimaryButtonStyle())
                .disabled(authorization.configurationIssue != nil || authorization.phase == .authenticating || authorization.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            Text("Conexão necessária para validar a licença.")
                .font(.caption2).foregroundColor(PoolTheme.secondary)
        }
        .simultaneousGesture(TapGesture().onEnded { beginLogin() })
    }

    private var controls: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                PoolStatusLabel(title: model.hasTable ? "\(model.ballCount) bolas" : "Sem mesa", symbol: model.hasTable ? "checkmark.circle" : "circle.dashed", color: model.hasTable ? PoolTheme.accent : PoolTheme.warning)
                Spacer()
                if model.hasTable {
                    Text(model.isPlayerTurn ? "Sua vez" : "Aguardando")
                        .font(.caption2).foregroundColor(model.isPlayerTurn ? PoolTheme.accent : PoolTheme.secondary)
                }
            }
            Text(model.status).font(.caption2).foregroundColor(PoolTheme.secondary).fixedSize(horizontal: false, vertical: true)
            VStack(spacing: 8) {
                Toggle("Linhas de previsão", isOn: Binding(get: { model.showTrajectories }, set: model.setShowTrajectories))
                Toggle("Posições finais", isOn: Binding(get: { model.showFinalPositions }, set: model.setShowFinalPositions))
                Toggle("Seguir a mira do jogo", isOn: Binding(get: { model.followGameAim }, set: model.setFollowGameAim))
            }
            .font(.caption)
            if model.followGameAim && model.hasTable && !model.aimAvailable {
                Text("A mira só aparece quando o jogo disponibiliza os controles.")
                    .font(.caption2).foregroundColor(PoolTheme.warning)
            }
            if model.isPredicting {
                HStack(spacing: 7) { ProgressView().scaleEffect(0.65); Text("Atualizando percurso…").font(.caption2) }
            }
            if model.isLuckyShot { luckyControls }
            else { automationControls }
            DisclosureGroup("Mira, força e sugestões") {
                VStack(spacing: 12) {
                    directionControls
                    HStack(spacing: 8) {
                        Button("Prever") { model.refresh() }
                            .disabled(!model.canCalculate)
                        Spacer()
                        Button { model.recommend() } label: {
                            HStack(spacing: 4) {
                                if model.isPlanning { ProgressView().scaleEffect(0.65) }
                                Text("Sugerir")
                            }
                        }
                        .disabled(!model.canRecommend || model.isPlanning || model.autoPlayEnabled)
                    }
                    .buttonStyle(.bordered).font(.caption)
                    if !model.suggestions.isEmpty { suggestionRows }
                    Button { model.applyAim() } label: {
                        Label("Aplicar direção e força", systemImage: "scope")
                    }
                    .buttonStyle(PoolPrimaryButtonStyle())
                    .disabled(!model.canApplyAim || model.autoPlayEnabled)
                }.padding(.top, 10)
            }
            .font(.caption.weight(.semibold))
            DisclosureGroup("Estilo das linhas") { styleControls.padding(.top, 10) }
                .font(.caption.weight(.semibold))
            DisclosureGroup("Próxima partida") {
                VStack(alignment: .leading, spacing: 8) {
                    Toggle("Entrar automaticamente", isOn: Binding(get: { model.autoQueueEnabled }, set: model.setAutoQueue))
                    Text(model.queueStatus).foregroundColor(PoolTheme.secondary)
                    Text("Repete a mesma mesa, com o custo de entrada dela. Não compra fichas nem aceita desafios.")
                        .foregroundColor(PoolTheme.warning)
                }.font(.caption2).padding(.top, 8)
            }.font(.caption.weight(.semibold))
            Toggle("Bloquear anúncios entre partidas", isOn: Binding(get: { model.blockInterstitialAds }, set: model.setBlockInterstitialAds))
                .font(.caption)
            Text("Previsão aproximada, sem reproduzir o efeito da bola. Círculos indicam onde o modelo prevê a parada; círculos pontilhados indicam caçapas.")
                .font(.caption2).foregroundColor(PoolTheme.warning)
                .fixedSize(horizontal: false, vertical: true)
            Button("Sair da licença") { Task { await authorization.signOut() } }
                .font(.caption2).frame(minHeight: 30)
        }
    }

    private var luckyControls: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("Lucky Shot").font(.subheadline.bold()).foregroundColor(.yellow)
            Text(model.luckyStatus).font(.caption2).foregroundColor(PoolTheme.secondary)
            Button { model.calculateLuckyShot() } label: {
                HStack(spacing: 6) {
                    if model.isPlanning { ProgressView().scaleEffect(0.7) }
                    Text("Calcular Lucky Shot")
                }.frame(maxWidth: .infinity, minHeight: 36)
            }
            .buttonStyle(.bordered).disabled(!model.canCalculateLuckyShot)
            if model.luckySuggestion != nil {
                Button("Aplicar mira da Lucky Shot") { model.applyLuckyAim() }
                    .buttonStyle(PoolPrimaryButtonStyle()).disabled(!model.canApplyAim)
            }
            Text("A cruz marca o centro real do alvo. O cálculo evita contato com obstáculos e não garante prêmio. A tacada é executada por você.")
                .font(.caption2).foregroundColor(PoolTheme.warning)
        }
    }

    private var automationControls: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Button { model.autoAim() } label: {
                    Text("Mira automática").frame(maxWidth: .infinity, minHeight: 34)
                }
                .disabled(!model.canRequestAutoAim)
                Button { model.autoShot() } label: {
                    Text("Uma tacada").frame(maxWidth: .infinity, minHeight: 34)
                }
                .disabled(!model.canRequestAutoShot)
            }
            .buttonStyle(.bordered).font(.caption.weight(.semibold))
            if model.singleShotRequested {
                Button("Cancelar tacada em preparação") { model.setAutoPlay(false) }
                    .font(.caption).foregroundColor(PoolTheme.warning)
            }
            Toggle("Jogar automaticamente", isOn: Binding(get: { model.autoPlayEnabled }, set: model.setAutoPlay))
                .font(.caption.weight(.semibold))
                .disabled(!model.autoPlayEnabled && !model.canEnableAutoPlay)
            Text(model.automationStatus)
                .font(.caption2).foregroundColor(model.autoPlayEnabled ? PoolTheme.accent : PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
            if !model.autoShotAvailable {
                Text(model.autoShotUnavailableReason).font(.caption2).foregroundColor(PoolTheme.warning)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Text("Mira automática só ajusta o taco. Uma tacada executa uma vez. O modo contínuo aguarda sua vez e para se a leitura falhar.")
                .font(.caption2).foregroundColor(PoolTheme.secondary)
        }
    }

    private var styleControls: some View {
        VStack(spacing: 10) {
            Toggle("Todas as bolas", isOn: Binding(get: { model.showAllPaths }, set: model.setShowAllPaths))
            Toggle("Números nas posições finais", isOn: Binding(get: { model.showFinalNumbers }, set: model.setShowFinalNumbers))
            Picker("Cor", selection: Binding(get: { model.pathColorMode }, set: model.setPathColorMode)) {
                Text("Bolas").tag("balls")
                Text("Verde").tag("mint")
                Text("Branco").tag("white")
            }
            .pickerStyle(.segmented)
            HStack {
                Text("Espessura")
                Slider(value: Binding(get: { model.pathWidth }, set: model.setPathWidth), in: 1...4, step: 0.25)
            }
            HStack {
                Text("Opacidade")
                Slider(value: Binding(get: { model.pathOpacity }, set: model.setPathOpacity), in: 0.3...1, step: 0.05)
            }
        }
        .font(.caption)
    }

    private var directionControls: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Ângulo da previsão")
                Spacer()
                Text("\(Int(model.angleDegrees.rounded()))°").monospacedDigit().foregroundColor(PoolTheme.accent)
            }
            .font(.subheadline)
            Slider(value: Binding(get: { model.angleDegrees }, set: model.setAngle), in: 0...360, step: 0.5)
                .accessibilityLabel("Ângulo da previsão")
            HStack {
                Text("Força")
                Spacer()
                Text("\(Int((model.power * 100).rounded()))%")
                    .monospacedDigit().foregroundColor(PoolTheme.accent)
            }
            .font(.subheadline)
            Slider(value: Binding(get: { model.power }, set: model.setPower), in: 0...1, step: 0.01)
                .accessibilityLabel("Força da tacada")
        }
        .disabled(!model.canCalculate || model.autoPlayEnabled || model.isWaitingForShot)
    }

    private var suggestionRows: some View {
        VStack(spacing: 7) {
            ForEach(Array(model.suggestions.enumerated()), id: \.element.id) { index, suggestion in
                Button { model.selectSuggestion(suggestion) } label: {
                    HStack(alignment: .top, spacing: 9) {
                        Text("\(index + 1)").font(.headline).foregroundColor(PoolTheme.accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Bola \(suggestion.targetID) · \(suggestion.method == .bank ? "Tabela" : "Direta")")
                                .font(.caption.weight(.semibold)).foregroundColor(.white)
                            Text("Caçapa \(suggestion.pocketID + 1) · força \(model.powerLabel(for: suggestion))")
                                .font(.caption2).foregroundColor(PoolTheme.secondary)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "arrow.up.right.circle").foregroundColor(PoolTheme.accent)
                    }
                    .padding(10)
                    .background(PoolTheme.surface)
                    .clipShape(RoundedRectangle(cornerRadius: 11))
                }
                .buttonStyle(.plain)
                .disabled(!model.canCalculate || model.autoPlayEnabled || model.isWaitingForShot)
            }
            Text("Escolher uma opção atualiza a previsão. A ordem reflete o custo calculado, não a chance real de acerto.")
                .font(.caption2).foregroundColor(PoolTheme.secondary)
        }
    }
}
