import Foundation

/// Deterministic, independent practice model. Equal masses, circular balls and
/// pockets, normal restitution and constant rolling drag; no spin or game hooks.
public enum BilliardsEngine {
    public static let maximumDuration: Double = 30
    public static let maximumSteps = 60_000
    public static let maximumEvents = 4_096
    public static let maximumFrames = 902
    private static let stopSpeed: Double = 0.025
    private static let timeTolerance: Double = 1e-10
    private static let contactTolerance: Double = 1e-7

    public static func validate(_ state: TableState, requireCue: Bool = true) throws {
        try Task.checkCancellation()
        let t = state.table
        let values = [t.width, t.height, t.ballRadius, t.pocketRadius,
                      t.ballRestitution, t.cushionRestitution,
                      t.rollingDeceleration, t.maximumShotSpeed]
        guard values.allSatisfy({ $0.isFinite }),
              (60...1_000).contains(t.width), (40...1_000).contains(t.height),
              (1...10).contains(t.ballRadius),
              t.ballRadius <= min(t.width, t.height) / 12,
              t.pocketRadius >= t.ballRadius * 1.1,
              t.pocketRadius <= min(t.ballRadius * 3.5, min(t.width, t.height) / 6),
              (0...1).contains(t.ballRestitution),
              (0...1).contains(t.cushionRestitution),
              (0...100).contains(t.rollingDeceleration),
              (1...400).contains(t.maximumShotSpeed) else { throw BilliardsError.invalidTable }
        guard state.balls.count <= 16,
              Set(state.balls.map(\.id)).count == state.balls.count else {
            throw BilliardsError.invalidBalls
        }
        let r = t.ballRadius
        for ball in state.balls {
            guard (0...15).contains(ball.id), ball.position.isFinite,
                  ball.velocity.isFinite else { throw BilliardsError.invalidBalls }
            if ball.pocketed { continue }
            guard ball.position.x >= r - contactTolerance,
                  ball.position.x <= t.width - r + contactTolerance,
                  ball.position.y >= r - contactTolerance,
                  ball.position.y <= t.height - r + contactTolerance else {
                throw BilliardsError.invalidBalls
            }
            guard ball.velocity == .zero else { throw BilliardsError.movingBalls }
        }
        for a in state.balls.indices where !state.balls[a].pocketed {
            for b in state.balls.indices where b > a && !state.balls[b].pocketed {
                if state.balls[a].position.distance(to: state.balls[b].position) < 2 * r - contactTolerance {
                    throw BilliardsError.overlappingBalls
                }
            }
        }
        if requireCue && state.cueBall == nil { throw BilliardsError.missingCueBall }
    }

    public static func simulate(
        state: TableState, shot: ShotParameters, recordFrames: Bool = true
    ) throws -> ShotResult {
        try validate(state)
        guard shot.angleRadians.isFinite, shot.power.isFinite, (0...1).contains(shot.power) else {
            throw BilliardsError.invalidShot
        }
        let table = state.table
        // Sorting makes collision tie breaking independent of caller array order.
        var balls = state.balls.sorted { $0.id < $1.id }
        let cueIndex = balls.firstIndex { $0.id == 0 && !$0.pocketed }!
        let angle = shot.angleRadians.truncatingRemainder(dividingBy: 2 * .pi)
        balls[cueIndex].velocity = Vector2(x: cos(angle), y: sin(angle)) * (shot.power * table.maximumShotSpeed)
        for index in balls.indices where balls[index].pocketed { balls[index].velocity = .zero }
        var events: [ShotEvent] = []
        var frames: [SimulationFrame] = []
        var tracePoints = [[Vector2]](repeating: [], count: balls.count)
        if recordFrames {
            frames.reserveCapacity(512)
            for index in balls.indices where !balls[index].pocketed {
                tracePoints[index] = [balls[index].position]
            }
        }
        events.reserveCapacity(64)
        let pockets = table.pockets
        // A manually positioned ball in a pocket opening is captured immediately.
        captureInsidePockets(&balls, pockets: pockets, radius: table.pocketRadius, events: &events)
        stopSlowBalls(&balls)
        var time: Double = 0
        var nextFrame: Double = 1.0 / 30
        var steps = 0
        var wasTruncated = false
        if recordFrames { frames.append(SimulationFrame(time: 0, balls: balls)) }

        while balls.contains(where: { !$0.pocketed && $0.velocity != .zero }) {
            if steps % 32 == 0 { try Task.checkCancellation() }
            guard time < maximumDuration - timeTolerance, steps < maximumSteps,
                  events.count < maximumEvents else { wasTruncated = true; break }
            let fastest = balls.filter { !$0.pocketed }.map { $0.velocity.length }.max() ?? 0
            // Continuous collision detection prevents tunneling. The displacement
            // bound also limits drag integration error and dense-rack work.
            var dt = min(1.0 / 180, table.ballRadius / max(2 * fastest, 1))
            dt = min(dt, maximumDuration - time)
            // Keep step boundaries identical for prediction and replay. Recording
            // changes storage only, never drag integration or collision timing.
            dt = min(dt, max(timeTolerance, nextFrame - time))
            var remaining = dt
            var contacts = 0
            while remaining > timeTolerance {
                if contacts % 16 == 0 { try Task.checkCancellation() }
                guard contacts < 64, events.count < maximumEvents else {
                    wasTruncated = true
                    break
                }
                guard let contact = firstContact(balls: balls, table: table, pockets: pockets, within: remaining) else {
                    advance(&balls, by: remaining)
                    remaining = 0
                    break
                }
                let elapsed = max(0, min(remaining, contact.time))
                advance(&balls, by: elapsed)
                remaining -= elapsed
                resolve(contact.kind, balls: &balls, table: table, events: &events)
                contacts += 1
            }
            let elapsed = dt - remaining
            applyDrag(&balls, deceleration: table.rollingDeceleration, elapsed: elapsed)
            stopSlowBalls(&balls)
            time += elapsed
            steps += 1
            if time + timeTolerance >= nextFrame {
                if recordFrames {
                    recordFrame(time: time, balls: balls, frames: &frames,
                                traces: &tracePoints, minimumDistance: table.ballRadius * 0.15)
                }
                nextFrame += 1.0 / 30
            }
            if wasTruncated { break }
        }
        if recordFrames {
            recordFrame(time: time, balls: balls, frames: &frames,
                        traces: &tracePoints, minimumDistance: 0)
        }
        let settled = !wasTruncated && balls.allSatisfy { $0.pocketed || $0.velocity == .zero }
        return ShotResult(
            finalState: TableState(table: table, balls: balls), frames: frames,
            traces: recordFrames ? balls.indices.compactMap { index in
                tracePoints[index].isEmpty ? nil : BallTrace(id: balls[index].id, points: tracePoints[index])
            } : [], events: events, duration: time, settled: settled
        )
    }

    private enum ContactKind {
        case pocket(Int, Int)
        case ball(Int, Int)
        case cushion(Int, Int) // 0 left, 1 right, 2 top, 3 bottom
    }
    private struct Contact { let time: Double; let kind: ContactKind }

    private static func firstContact(
        balls: [PoolBall], table: PoolTable, pockets: [PoolPocket], within limit: Double
    ) -> Contact? {
        var best: Contact?
        func consider(_ time: Double?, _ kind: ContactKind) {
            guard let t = time, t >= -timeTolerance, t <= limit + timeTolerance else { return }
            let bounded = max(0, min(limit, t))
            // Keep the first exact tie: pockets take precedence over collisions,
            // then ball IDs and wall order define a reproducible result.
            if best == nil || bounded < best!.time - timeTolerance {
                best = Contact(time: bounded, kind: kind)
            }
        }
        for a in balls.indices where !balls[a].pocketed {
            for pocket in pockets {
                consider(circleEntry(position: balls[a].position - pocket.center,
                                     velocity: balls[a].velocity, radius: table.pocketRadius,
                                     captureWhenInside: true), .pocket(a, pocket.id))
            }
        }
        for a in balls.indices where !balls[a].pocketed {
            for b in balls.indices where b > a && !balls[b].pocketed {
                consider(circleEntry(position: balls[b].position - balls[a].position,
                                     velocity: balls[b].velocity - balls[a].velocity,
                                     radius: 2 * table.ballRadius,
                                     captureWhenInside: false), .ball(a, b))
            }
        }
        let r = table.ballRadius
        for a in balls.indices where !balls[a].pocketed {
            let p = balls[a].position, v = balls[a].velocity
            if v.x < -1e-10 { consider(max(0, (r - p.x) / v.x), .cushion(a, 0)) }
            if v.x > 1e-10 { consider(max(0, (table.width - r - p.x) / v.x), .cushion(a, 1)) }
            if v.y < -1e-10 { consider(max(0, (r - p.y) / v.y), .cushion(a, 2)) }
            if v.y > 1e-10 { consider(max(0, (table.height - r - p.y) / v.y), .cushion(a, 3)) }
        }
        return best
    }

    /// First entry of a moving point into a circle. Using the stable quadratic
    /// root avoids subtracting nearly equal values for near-touching balls.
    private static func circleEntry(
        position: Vector2, velocity: Vector2, radius: Double, captureWhenInside: Bool
    ) -> Double? {
        let separation = position.lengthSquared - radius * radius
        let approach = position.dot(velocity)
        if separation <= 1e-8 {
            return captureWhenInside || approach < -1e-9 ? 0 : nil
        }
        let speedSquared = velocity.lengthSquared
        guard speedSquared > 1e-16, approach < 0 else { return nil }
        let discriminant = approach * approach - speedSquared * separation
        guard discriminant >= 0 else { return nil }
        let denominator = -approach + sqrt(discriminant)
        guard denominator > 0 else { return nil }
        return separation / denominator
    }

    private static func resolve(
        _ kind: ContactKind, balls: inout [PoolBall], table: PoolTable, events: inout [ShotEvent]
    ) {
        switch kind {
        case let .pocket(index, pocket):
            balls[index].pocketed = true
            balls[index].velocity = .zero
            events.append(.pocket(ball: balls[index].id, pocket: pocket))
        case let .cushion(index, wall):
            let e = table.cushionRestitution, r = table.ballRadius
            switch wall {
            case 0: balls[index].position.x = r; balls[index].velocity.x = abs(balls[index].velocity.x) * e
            case 1: balls[index].position.x = table.width - r; balls[index].velocity.x = -abs(balls[index].velocity.x) * e
            case 2: balls[index].position.y = r; balls[index].velocity.y = abs(balls[index].velocity.y) * e
            default: balls[index].position.y = table.height - r; balls[index].velocity.y = -abs(balls[index].velocity.y) * e
            }
            events.append(.cushion(ball: balls[index].id))
        case let .ball(a, b):
            let delta = balls[b].position - balls[a].position
            let distance = delta.length
            let normal = distance > 1e-12 ? delta / distance : Vector2(x: 1, y: 0)
            let penetration = 2 * table.ballRadius - distance
            if penetration > 0 {
                let correction = normal * (penetration / 2)
                balls[a].position = balls[a].position - correction
                balls[b].position = balls[b].position + correction
            }
            let relativeNormal = (balls[b].velocity - balls[a].velocity).dot(normal)
            if relativeNormal < 0 {
                let impulse = normal * (-(1 + table.ballRestitution) * relativeNormal / 2)
                balls[a].velocity = balls[a].velocity - impulse
                balls[b].velocity = balls[b].velocity + impulse
                events.append(.ballCollision(first: balls[a].id, second: balls[b].id))
            }
        }
    }

    private static func advance(_ balls: inout [PoolBall], by time: Double) {
        for index in balls.indices where !balls[index].pocketed {
            balls[index].position = balls[index].position + balls[index].velocity * time
        }
    }

    private static func applyDrag(_ balls: inout [PoolBall], deceleration: Double, elapsed: Double) {
        guard deceleration > 0, elapsed > 0 else { return }
        for index in balls.indices where !balls[index].pocketed {
            let speed = balls[index].velocity.length
            if speed > 0 {
                balls[index].velocity = balls[index].velocity * (max(0, speed - deceleration * elapsed) / speed)
            }
        }
    }

    private static func stopSlowBalls(_ balls: inout [PoolBall]) {
        for index in balls.indices where balls[index].velocity.length < stopSpeed {
            balls[index].velocity = .zero
        }
    }

    private static func captureInsidePockets(
        _ balls: inout [PoolBall], pockets: [PoolPocket], radius: Double, events: inout [ShotEvent]
    ) {
        for index in balls.indices where !balls[index].pocketed {
            if let pocket = pockets.first(where: { balls[index].position.distance(to: $0.center) <= radius }) {
                balls[index].pocketed = true
                balls[index].velocity = .zero
                events.append(.pocket(ball: balls[index].id, pocket: pocket.id))
            }
        }
    }

    private static func recordFrame(
        time: Double, balls: [PoolBall], frames: inout [SimulationFrame],
        traces: inout [[Vector2]], minimumDistance: Double
    ) {
        let frame = SimulationFrame(time: time, balls: balls)
        if let last = frames.last, abs(last.time - time) < timeTolerance {
            frames[frames.count - 1] = frame
        } else if frames.count < maximumFrames {
            frames.append(frame)
        } else {
            frames[frames.count - 1] = frame
        }
        for index in balls.indices where !traces[index].isEmpty {
            if traces[index].last! != balls[index].position,
               traces[index].last!.distance(to: balls[index].position) >= minimumDistance {
                if traces[index].count < maximumFrames { traces[index].append(balls[index].position) }
                else { traces[index][traces[index].count - 1] = balls[index].position }
            }
        }
    }
}
