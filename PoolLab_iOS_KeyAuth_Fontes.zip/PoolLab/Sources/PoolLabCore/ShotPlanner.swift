import Foundation

/// Shot selection for this project's local physics model only.
///
/// A suggestion is returned only after a simulation pockets the selected object
/// ball in the requested pocket, first contacts that ball with the cue ball,
/// settles, and leaves the cue ball on the table. The search is deliberately
/// bounded and incomplete: an empty result does not prove a position impossible.
public enum ShotPlanner {
    public static let maximumCandidates = 24
    public static let maximumPowerSamples = 8
    public static let maximumSimulations = maximumCandidates * maximumPowerSamples

    /// `score` is a relative cost, with lower values preferred, not a probability.
    /// `ghostBall` is the cue ball's desired center at impact; `aimPoint` is the
    /// object ball's pocket center or its first cushion contact for a bank.
    public static func suggestions(
        for state: TableState,
        targetID: Int? = nil,
        pocketID: Int? = nil,
        includeBanks: Bool = true,
        limit: Int = 5
    ) throws -> [ShotSuggestion] {
        try Task.checkCancellation()
        try BilliardsEngine.validate(state)
        guard limit > 0, let cue = state.cueBall else { return [] }

        let targets = state.balls.filter {
            !$0.pocketed && $0.id != 0 && (targetID == nil || $0.id == targetID)
        }.sorted { $0.id < $1.id }
        let pockets = state.table.pockets.filter { pocketID == nil || $0.id == pocketID }
        var candidates: [Candidate] = []
        candidates.reserveCapacity(min(targets.count * pockets.count * 5, 450))

        for target in targets {
            try Task.checkCancellation()
            for pocket in pockets {
                if let direct = candidate(
                    state: state, cue: cue, target: target, pocket: pocket,
                    cushion: nil
                ) {
                    candidates.append(direct)
                }
                if includeBanks {
                    for rail in Rail.allCases {
                        if let contact = bankContact(
                            from: target.position, to: pocket.center,
                            rail: rail, table: state.table
                        ), let bank = candidate(
                            state: state, cue: cue, target: target, pocket: pocket,
                            cushion: contact
                        ) {
                            candidates.append(bank)
                        }
                    }
                }
            }
        }

        candidates.sort(by: candidatePrecedes)
        var suggestions: [ShotSuggestion] = []
        for candidate in candidates.prefix(maximumCandidates) {
            try Task.checkCancellation()
            for power in powerSamples(for: candidate, table: state.table) {
                try Task.checkCancellation()
                let shot = ShotParameters(angleRadians: candidate.angle, power: power)
                let result = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false)
                guard isValidOutcome(result, targetID: candidate.targetID, pocketID: candidate.pocketID,
                                     method: candidate.method) else {
                    continue
                }
                // Ascending probes and a monotonically increasing power cost
                // let us keep just the first verified power for this route.
                suggestions.append(ShotSuggestion(
                    targetID: candidate.targetID,
                    pocketID: candidate.pocketID,
                    method: candidate.method,
                    shot: shot,
                    ghostBall: candidate.ghost,
                    aimPoint: candidate.aim,
                    score: candidate.geometryCost + 4 * power,
                    result: result
                ))
                break
            }
        }

        suggestions.sort {
            if $0.score != $1.score { return $0.score < $1.score }
            if $0.targetID != $1.targetID { return $0.targetID < $1.targetID }
            if $0.pocketID != $1.pocketID { return $0.pocketID < $1.pocketID }
            if $0.method != $1.method { return $0.method == .direct }
            if $0.shot.angleRadians != $1.shot.angleRadians { return $0.shot.angleRadians < $1.shot.angleRadians }
            return $0.shot.power < $1.shot.power
        }
        return Array(suggestions.prefix(min(limit, maximumCandidates)))
    }

    // Kept internal so the acceptance contract can be tested independently of
    // the candidate search and the numerical integration implementation.
    static func isValidOutcome(_ result: ShotResult, targetID: Int, pocketID: Int, method: ShotMethod? = nil) -> Bool {
        guard result.settled, !result.scratched,
              result.finalState.balls.contains(where: { $0.id == targetID && $0.pocketed }),
              result.events.contains(.pocket(ball: targetID, pocket: pocketID)) else { return false }

        if let method {
            var cushions = 0
            for event in result.events {
                if event == .pocket(ball: targetID, pocket: pocketID) { break }
                if event == .cushion(ball: targetID) { cushions += 1 }
            }
            guard cushions == (method == .bank ? 1 : 0) else { return false }
        }
        for event in result.events {
            if case let .ballCollision(first, second) = event {
                if first == 0 { return second == targetID }
                if second == 0 { return first == targetID }
            }
        }
        return false
    }

    private struct Candidate {
        let targetID: Int
        let pocketID: Int
        let method: ShotMethod
        let ghost: Vector2
        let aim: Vector2
        let angle: Double
        let cutCosine: Double
        let cueDistance: Double
        let objectFirstDistance: Double
        let objectLastDistance: Double
        let cushionSpeedSquared: Double
        let geometryCost: Double
    }

    private enum Rail: CaseIterable { case left, right, top, bottom }

    private static func candidate(
        state: TableState, cue: PoolBall, target: PoolBall,
        pocket: PoolPocket, cushion: Vector2?
    ) -> Candidate? {
        let table = state.table
        let aim = cushion ?? pocket.center
        // Reaching a pocket center on paper is insufficient at a shallow angle:
        // the ball center may strike the adjoining cushion before entering its
        // capture circle. Exclude that extra-bounce route before simulation.
        guard canEnterPocket(from: cushion ?? target.position, pocket: pocket.center, table: table) else {
            return nil
        }
        let objectVector = aim - target.position
        guard objectVector.length > table.ballRadius else { return nil }
        let direction = objectVector.normalized()
        let ghost = target.position - direction * (2 * table.ballRadius)
        guard isInside(ghost, table: table),
              !table.pockets.contains(where: { ghost.distance(to: $0.center) <= table.pocketRadius }) else {
            return nil
        }
        let cueVector = ghost - cue.position
        guard cueVector.length > 1e-8 else { return nil }
        let cutCosine = cueVector.normalized().dot(direction)
        // Extremely thin cuts are deliberately outside this coarse search.
        guard cutCosine >= 0.22 else { return nil }
        let stationaryObstacles = state.balls.filter { !$0.pocketed && $0.id != 0 && $0.id != target.id }
        guard clearRoute(from: cue.position, to: ghost, obstacles: stationaryObstacles, radius: table.ballRadius),
              clearRoute(from: target.position, to: aim, obstacles: stationaryObstacles, radius: table.ballRadius) else {
            return nil
        }

        var finalDistance = 0.0
        var cushionSpeedSquared = 1.0
        if let cushion {
            guard clearRoute(from: cushion, to: pocket.center, obstacles: stationaryObstacles, radius: table.ballRadius) else {
                return nil
            }
            // The cue ball moves away from its initial center after impact;
            // its actual interaction with the bank route is checked by the engine.
            finalDistance = cushion.distance(to: pocket.center)
            let hitsVertical = abs(cushion.x - table.ballRadius) < 1e-7 ||
                abs(cushion.x - (table.width - table.ballRadius)) < 1e-7
            let normal = hitsVertical ? direction.x : direction.y
            cushionSpeedSquared = 1 - normal * normal * (1 - table.cushionRestitution * table.cushionRestitution)
            guard cushionSpeedSquared > 1e-8 else { return nil }
        }

        let cut = acos(min(1, max(-1, cutCosine)))
        let totalDistance = cueVector.length + objectVector.length + finalDistance
        return Candidate(
            targetID: target.id, pocketID: pocket.id,
            method: cushion == nil ? .direct : .bank,
            ghost: ghost, aim: aim,
            angle: atan2(cueVector.y, cueVector.x), cutCosine: cutCosine,
            cueDistance: cueVector.length,
            objectFirstDistance: objectVector.length,
            objectLastDistance: finalDistance,
            cushionSpeedSquared: cushionSpeedSquared,
            geometryCost: 1.2 * cut + totalDistance / table.width + (cushion == nil ? 0 : 0.55)
        )
    }

    /// Unfold the target pocket across the cushion's center-contact line.
    /// Scale its normal distance by 1/restitution because this engine reduces
    /// normal velocity at a cushion while retaining tangential velocity.
    private static func bankContact(from source: Vector2, to pocket: Vector2, rail: Rail, table: PoolTable) -> Vector2? {
        guard table.cushionRestitution > 1e-6 else { return nil }
        let radius = table.ballRadius
        let vertical = rail == .left || rail == .right
        let boundary: Double
        switch rail {
        case .left, .top: boundary = radius
        case .right: boundary = table.width - radius
        case .bottom: boundary = table.height - radius
        }
        let sourceNormal = vertical ? source.x : source.y
        let pocketNormal = vertical ? pocket.x : pocket.y
        // Both endpoints must be on the playable side of the bank cushion.
        // Otherwise this would hit that pocket directly or cross another rail.
        guard (sourceNormal - boundary) * (pocketNormal - boundary) > 1e-8 else { return nil }
        let virtualNormal = boundary - (pocketNormal - boundary) / table.cushionRestitution
        let denominator = virtualNormal - sourceNormal
        guard abs(denominator) > 1e-8 else { return nil }
        let fraction = (boundary - sourceNormal) / denominator
        guard fraction > 0, fraction < 1 else { return nil }
        let virtualPocket = vertical ? Vector2(x: virtualNormal, y: pocket.y) : Vector2(x: pocket.x, y: virtualNormal)
        var contact = source + (virtualPocket - source) * fraction
        if vertical { contact.x = boundary } else { contact.y = boundary }
        guard isInside(contact, table: table),
              !table.pockets.contains(where: { contact.distance(to: $0.center) <= table.pocketRadius + radius * 0.25 }) else {
            return nil
        }
        return contact
    }

    private static func isInside(_ point: Vector2, table: PoolTable) -> Bool {
        point.isFinite && point.x >= table.ballRadius && point.x <= table.width - table.ballRadius &&
            point.y >= table.ballRadius && point.y <= table.height - table.ballRadius
    }

    private static func canEnterPocket(from start: Vector2, pocket: Vector2, table: PoolTable) -> Bool {
        let delta = pocket - start
        let radius = table.ballRadius
        var fraction = 1.0
        if delta.x < 0, pocket.x < radius {
            fraction = min(fraction, (radius - start.x) / delta.x)
        }
        if delta.x > 0, pocket.x > table.width - radius {
            fraction = min(fraction, (table.width - radius - start.x) / delta.x)
        }
        if delta.y < 0, pocket.y < radius {
            fraction = min(fraction, (radius - start.y) / delta.y)
        }
        if delta.y > 0, pocket.y > table.height - radius {
            fraction = min(fraction, (table.height - radius - start.y) / delta.y)
        }
        return (start + delta * fraction).distance(to: pocket) <= table.pocketRadius
    }

    private static func clearRoute(from start: Vector2, to end: Vector2, obstacles: [PoolBall], radius: Double) -> Bool {
        let segment = end - start
        let lengthSquared = segment.lengthSquared
        guard lengthSquared > 1e-12 else { return false }
        let clearance = 2 * radius + 0.02
        for ball in obstacles {
            let fraction = min(1, max(0, (ball.position - start).dot(segment) / lengthSquared))
            let nearest = start + segment * fraction
            if ball.position.distance(to: nearest) < clearance { return false }
        }
        return true
    }

    private static func powerSamples(for candidate: Candidate, table: PoolTable) -> [Double] {
        let transfer = ((1 + table.ballRestitution) / 2) * candidate.cutCosine
        let objectDistance = candidate.objectFirstDistance + candidate.objectLastDistance / candidate.cushionSpeedSquared
        let requiredSpeedSquared = 2 * table.rollingDeceleration *
            (candidate.cueDistance + objectDistance / (transfer * transfer))
        let estimate = sqrt(requiredSpeedSquared) / table.maximumShotSpeed
        let proposed = [estimate * 0.92, estimate * 1.04, estimate * 1.20,
                        estimate * 1.45, estimate * 1.80, 0.45, 0.68, 0.90]
        var result: [Double] = []
        for power in proposed.map({ min(1, max(0.015, $0)) }).sorted() {
            if let last = result.last, abs(last - power) < 1e-6 { continue }
            result.append(power)
        }
        return Array(result.prefix(maximumPowerSamples))
    }

    private static func candidatePrecedes(_ lhs: Candidate, _ rhs: Candidate) -> Bool {
        if lhs.geometryCost != rhs.geometryCost { return lhs.geometryCost < rhs.geometryCost }
        if lhs.targetID != rhs.targetID { return lhs.targetID < rhs.targetID }
        if lhs.pocketID != rhs.pocketID { return lhs.pocketID < rhs.pocketID }
        if lhs.method != rhs.method { return lhs.method == .direct }
        return lhs.angle < rhs.angle
    }
}
