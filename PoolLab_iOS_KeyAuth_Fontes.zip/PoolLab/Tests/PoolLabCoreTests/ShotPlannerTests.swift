import XCTest
@testable import PoolLabCore

final class ShotPlannerTests: XCTestCase {
    func testStraightShotFindsVerifiedDirectShotForSelectedPocket() throws {
        let suggestions = try ShotPlanner.suggestions(for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false)
        let shot = try XCTUnwrap(suggestions.first)
        XCTAssertEqual(shot.targetID, 1)
        XCTAssertEqual(shot.pocketID, 1)
        XCTAssertEqual(shot.method, .direct)
        XCTAssertEqual(shot.shot.angleRadians, -.pi / 2, accuracy: 1e-10)
        XCTAssertEqual(shot.ghostBall.x, 100, accuracy: 1e-10)
        XCTAssertEqual(shot.ghostBall.y, 40.7, accuracy: 1e-10)
        XCTAssertTrue(shot.result.settled)
        XCTAssertFalse(shot.result.scratched)
        XCTAssertTrue(shot.result.events.contains(.pocket(ball: 1, pocket: 1)))
        XCTAssertTrue(shot.result.frames.isEmpty)
        XCTAssertTrue(shot.result.traces.isEmpty)
    }

    func testBlockedCueRouteDoesNotSuggestShootingThroughBlocker() throws {
        var state = TableState.straightShot
        state.balls.append(PoolBall(id: 2, position: Vector2(x: 100, y: 53)))
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testBlockedObjectRouteDoesNotSuggestShootingThroughBlocker() throws {
        var state = TableState.straightShot
        state.balls.append(PoolBall(id: 2, position: Vector2(x: 100, y: 15)))
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testPocketedBlockerDoesNotObstructRoute() throws {
        var state = TableState.straightShot
        state.balls.append(PoolBall(id: 2, position: Vector2(x: 100, y: 53), pocketed: true))
        XCTAssertFalse(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testGhostOutsideTableIsRejected() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 60, y: 85)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 95))
        ])
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testWrongSideCutIsRejected() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 30, y: 35)),
            PoolBall(id: 1, position: Vector2(x: 100, y: 35))
        ])
        XCTAssertTrue(try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: false).isEmpty)
    }

    func testVerifiedOneCushionBankCanBeSuggested() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 20)),
            PoolBall(id: 1, position: Vector2(x: 120, y: 50))
        ])
        let shots = try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: true, limit: 24)
        let bank = try XCTUnwrap(shots.first { $0.method == .bank })
        XCTAssertTrue(bank.result.events.contains(.pocket(ball: 1, pocket: 1)))
        XCTAssertTrue(bank.result.events.contains(.cushion(ball: 1)))
        XCTAssertTrue(bank.result.settled)
        XCTAssertFalse(bank.result.scratched)
    }

    func testShallowBankRequiringAnotherCushionIsNotCalledOneCushion() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 190, y: 50)),
            PoolBall(id: 1, position: Vector2(x: 140, y: 50))
        ])
        let shots = try ShotPlanner.suggestions(for: state, targetID: 1, pocketID: 1, includeBanks: true, limit: 24)
        XCTAssertTrue(shots.allSatisfy { $0.method == .direct })
    }

    func testSearchIsDeterministicAndRespectsLimit() throws {
        let first = try ShotPlanner.suggestions(for: .straightShot, targetID: 1, includeBanks: false, limit: 2)
        let second = try ShotPlanner.suggestions(for: .straightShot, targetID: 1, includeBanks: false, limit: 2)
        XCTAssertFalse(first.isEmpty)
        XCTAssertLessThanOrEqual(first.count, 2)
        XCTAssertEqual(first.map(\.id), second.map(\.id))
        XCTAssertEqual(first.map(\.score), first.map(\.score).sorted())
    }

    func testNoSuchTargetOrPocketReturnsNoSuggestions() throws {
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, targetID: 15).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, pocketID: 99).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, targetID: 0).isEmpty)
        XCTAssertTrue(try ShotPlanner.suggestions(for: .straightShot, limit: 0).isEmpty)
    }

    func testInvalidPositionIsReported() {
        var state = TableState.straightShot
        state.balls[0].position.x = -.infinity
        XCTAssertThrowsError(try ShotPlanner.suggestions(for: state)) {
            XCTAssertEqual($0 as? BilliardsError, .invalidBalls)
        }
    }

    func testCancelledSearchThrowsCancellation() async {
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try ShotPlanner.suggestions(for: .straightShot)
        }
        do {
            _ = try await task.value
            XCTFail("A cancelled search should not return suggestions.")
        } catch {
            XCTAssertTrue(error is CancellationError)
        }
    }

    func testPocketSuccessWithCueScratchIsRejected() {
        let result = outcome(events: [.ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1), .pocket(ball: 0, pocket: 4)], cuePocketed: true)
        XCTAssertFalse(ShotPlanner.isValidOutcome(result, targetID: 1, pocketID: 1))
    }

    func testWrongPocketFirstContactAndUnsettledResultsAreRejected() {
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            outcome(events: [.ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 4)]), targetID: 1, pocketID: 1))
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            outcome(events: [.ballCollision(first: 0, second: 2), .ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1)]), targetID: 1, pocketID: 1))
        XCTAssertFalse(ShotPlanner.isValidOutcome(
            outcome(events: [.ballCollision(first: 0, second: 1), .pocket(ball: 1, pocket: 1)], settled: false), targetID: 1, pocketID: 1))
    }

    func testMethodMustMatchActualObjectBallCushionCount() {
        let events: [ShotEvent] = [.ballCollision(first: 0, second: 1), .cushion(ball: 1), .pocket(ball: 1, pocket: 1)]
        let bank = outcome(events: events)
        XCTAssertTrue(ShotPlanner.isValidOutcome(bank, targetID: 1, pocketID: 1, method: .bank))
        XCTAssertFalse(ShotPlanner.isValidOutcome(bank, targetID: 1, pocketID: 1, method: .direct))
        let twoCushions = outcome(events: [.ballCollision(first: 0, second: 1), .cushion(ball: 1), .cushion(ball: 1), .pocket(ball: 1, pocket: 1)])
        XCTAssertFalse(ShotPlanner.isValidOutcome(twoCushions, targetID: 1, pocketID: 1, method: .bank))
    }

    func testRenderedReplayPreservesVerifiedOutcome() throws {
        let suggestion = try XCTUnwrap(ShotPlanner.suggestions(
            for: .straightShot, targetID: 1, pocketID: 1, includeBanks: false
        ).first)
        let replay = try BilliardsEngine.simulate(state: .straightShot, shot: suggestion.shot, recordFrames: true)
        XCTAssertFalse(replay.frames.isEmpty)
        XCTAssertTrue(ShotPlanner.isValidOutcome(replay, targetID: 1, pocketID: 1, method: .direct))
    }

    private func outcome(events: [ShotEvent], cuePocketed: Bool = false, settled: Bool = true) -> ShotResult {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 50), pocketed: cuePocketed),
            PoolBall(id: 1, position: Vector2(x: 100, y: 0), pocketed: true)
        ])
        return ShotResult(finalState: state, frames: [], traces: [], events: events, duration: 1, settled: settled)
    }
}
