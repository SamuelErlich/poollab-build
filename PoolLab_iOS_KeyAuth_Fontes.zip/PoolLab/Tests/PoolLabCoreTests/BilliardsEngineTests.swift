import XCTest
@testable import PoolLabCore

final class BilliardsEngineTests: XCTestCase {
    private func largeTable(speed: Double = 10, drag: Double = 0) -> PoolTable {
        var table = PoolTable()
        table.width = 1_000; table.height = 1_000
        table.maximumShotSpeed = speed
        table.rollingDeceleration = drag
        table.ballRestitution = 1; table.cushionRestitution = 1
        return table
    }

    func testHeadOnEqualMassCollisionTransfersVelocity() throws {
        let state = TableState(table: largeTable(), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500)),
            PoolBall(id: 1, position: Vector2(x: 200, y: 500))
        ])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 1))
        XCTAssertEqual(result.events.first, .ballCollision(first: 0, second: 1))
        XCTAssertEqual(result.finalState.balls[0].velocity.length, 0, accuracy: 1e-8)
        XCTAssertEqual(result.finalState.balls[1].velocity.x, 10, accuracy: 1e-8)
        XCTAssertEqual(result.finalState.balls[0].position.x, 194.3, accuracy: 1e-6)
        XCTAssertFalse(result.settled, "Zero drag keeps moving at the time budget.")
        XCTAssertEqual(result.duration, BilliardsEngine.maximumDuration, accuracy: 1e-8)
    }

    func testObliqueElasticCollisionConservesMomentumAndEnergy() throws {
        let state = TableState(table: largeTable(speed: 8), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500)),
            PoolBall(id: 1, position: Vector2(x: 120, y: 502.85))
        ])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 1))
        let a = result.finalState.balls[0].velocity, b = result.finalState.balls[1].velocity
        XCTAssertEqual(result.events.count, 1)
        XCTAssertEqual((a + b).x, 8, accuracy: 1e-8)
        XCTAssertEqual((a + b).y, 0, accuracy: 1e-8)
        XCTAssertEqual(a.lengthSquared + b.lengthSquared, 64, accuracy: 1e-8)
        XCTAssertLessThan(a.y, 0)
        XCTAssertGreaterThan(b.y, 0)
    }

    func testMaximumSpeedCannotTunnelThroughNearbyBall() throws {
        let state = TableState(table: largeTable(speed: 400, drag: 100), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500)),
            PoolBall(id: 1, position: Vector2(x: 110, y: 500))
        ])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 1), recordFrames: false)
        XCTAssertEqual(result.events.first, .ballCollision(first: 0, second: 1))
        XCTAssertEqual(result.finalState.balls[0].position.x, 104.3, accuracy: 1e-6)
        XCTAssertGreaterThan(result.finalState.balls[1].position.x, 700)
        XCTAssertTrue(result.settled)
    }

    func testSweptGlancingCollisionDoesNotDisappearBetweenSteps() throws {
        var table = largeTable(speed: 400, drag: 100)
        table.ballRadius = 1; table.pocketRadius = 2.2
        let state = TableState(table: table, balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500)),
            PoolBall(id: 1, position: Vector2(x: 103.2, y: 501.9999))
        ])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 1), recordFrames: false)
        XCTAssertTrue(result.events.contains(.ballCollision(first: 0, second: 1)))
        XCTAssertGreaterThan(result.finalState.balls[1].position.y, 501.9999)
    }

    func testCalibratedHighSpeedStillDetectsFirstContactAndStaysBounded() throws {
        let state = TableState(table: largeTable(speed: 2_000, drag: 100), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500)),
            PoolBall(id: 1, position: Vector2(x: 110, y: 500))
        ])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 1), recordFrames: false)
        XCTAssertEqual(result.events.first, .ballCollision(first: 0, second: 1))
        XCTAssertLessThanOrEqual(result.duration, BilliardsEngine.maximumDuration)
        XCTAssertLessThanOrEqual(result.events.count, BilliardsEngine.maximumEvents)
        XCTAssertTrue(result.settled)
        try BilliardsEngine.validate(result.finalState)
    }

    func testStraightShotPocketsObjectBallWithoutScratch() throws {
        let result = try BilliardsEngine.simulate(state: .straightShot, shot: ShotParameters(angleRadians: -.pi / 2, power: 0.5))
        XCTAssertTrue(result.pocketedIDs.contains(1))
        XCTAssertTrue(result.events.contains(.pocket(ball: 1, pocket: 1)))
        XCTAssertFalse(result.scratched)
        XCTAssertTrue(result.settled)
    }

    func testCuePocketIsReportedAsScratch() throws {
        let state = TableState(balls: [PoolBall(id: 0, position: Vector2(x: 100, y: 20))])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: -.pi / 2, power: 1))
        XCTAssertTrue(result.scratched)
        XCTAssertEqual(result.pocketedIDs, [0])
        XCTAssertEqual(result.finalState.balls[0].velocity, .zero)
        XCTAssertTrue(result.settled)
    }

    func testOutwardShotStartingExactlyOnCushionReboundsOnce() throws {
        var table = PoolTable()
        table.maximumShotSpeed = 10; table.rollingDeceleration = 10
        let state = TableState(table: table, balls: [PoolBall(id: 0, position: Vector2(x: table.ballRadius, y: 50))])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: .pi, power: 1))
        XCTAssertEqual(result.events, [.cushion(ball: 0)])
        XCTAssertGreaterThan(result.finalState.balls[0].position.x, table.ballRadius)
        XCTAssertTrue(result.settled)
    }

    func testRollingDragStopsAtExpectedDistance() throws {
        let state = TableState(table: largeTable(speed: 20, drag: 10), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500))
        ])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 1))
        // v²/(2a) = 20; first-order drag integration tolerance is < 0.06.
        XCTAssertEqual(result.finalState.balls[0].position.x, 120, accuracy: 0.07)
        XCTAssertEqual(result.duration, 2, accuracy: 0.01)
        XCTAssertTrue(result.settled)
        XCTAssertTrue(result.events.isEmpty)
        try BilliardsEngine.validate(result.finalState)
    }

    func testZeroPowerIsStationaryAndProducesOneFrame() throws {
        let result = try BilliardsEngine.simulate(state: .practice, shot: ShotParameters(angleRadians: 0.2, power: 0))
        XCTAssertTrue(result.settled)
        XCTAssertEqual(result.duration, 0)
        XCTAssertTrue(result.events.isEmpty)
        XCTAssertEqual(result.frames.count, 1)
        XCTAssertEqual(result.finalState.balls, TableState.practice.balls.sorted { $0.id < $1.id })
    }

    func testLiveContinuationUsesCapturedVelocityWithoutCueOrNewImpulse() throws {
        // Selected-cue strength cannot cap a ball already moving on the table.
        let state = TableState(table: largeTable(speed: 5, drag: 10), balls: [
            PoolBall(id: 3, position: Vector2(x: 100, y: 500), velocity: Vector2(x: 20, y: 0))
        ])
        let original = state
        let result = try BilliardsEngine.simulateContinuation(state: state)
        XCTAssertEqual(state, original, "The captured game state is a read-only input.")
        XCTAssertEqual(result.frames.first?.time, 0)
        XCTAssertEqual(result.frames.first?.balls, state.balls)
        XCTAssertEqual(result.traces.first?.points.first, state.balls[0].position)
        XCTAssertEqual(result.finalState.balls[0].position.x, 120, accuracy: 0.07)
        XCTAssertEqual(result.finalState.balls[0].velocity, .zero)
        XCTAssertEqual(result.duration, 2, accuracy: 0.01)
        XCTAssertTrue(result.settled)
        XCTAssertTrue(result.events.isEmpty)
        XCTAssertThrowsError(try BilliardsEngine.validate(state, requireCue: false)) {
            XCTAssertEqual($0 as? BilliardsError, .movingBalls,
                           "Planning a fresh shot must still reject a moving table.")
        }
    }

    func testLiveContinuationTransfersObjectBallMotionAfterScratch() throws {
        let state = TableState(table: largeTable(speed: 20, drag: 10), balls: [
            PoolBall(id: 0, position: Vector2(x: 0, y: 0), pocketed: true),
            PoolBall(id: 1, position: Vector2(x: 100, y: 500), velocity: Vector2(x: 20, y: 0)),
            PoolBall(id: 2, position: Vector2(x: 115, y: 500))
        ])
        let result = try BilliardsEngine.simulateContinuation(state: state)
        XCTAssertEqual(result.events.first, .ballCollision(first: 1, second: 2))
        XCTAssertTrue(result.finalState.balls[0].pocketed)
        XCTAssertEqual(result.finalState.balls[1].position.x, 109.3, accuracy: 1e-6)
        XCTAssertGreaterThan(result.finalState.balls[2].position.x, 125)
        XCTAssertTrue(result.settled)
        try BilliardsEngine.validate(result.finalState, requireCue: false)
    }

    func testLiveContinuationLeavesStationaryCueUntouched() throws {
        let state = TableState(table: largeTable(speed: 300, drag: 10), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 100)),
            PoolBall(id: 5, position: Vector2(x: 200, y: 500), velocity: Vector2(x: 0, y: -20))
        ])
        let result = try BilliardsEngine.simulateContinuation(state: state)
        XCTAssertEqual(result.finalState.balls[0], state.balls[0])
        XCTAssertEqual(result.finalState.balls[1].position.y, 480, accuracy: 0.07)
        XCTAssertTrue(result.settled)
    }

    func testLiveContinuationResumesARecordedFrameAtCaptureTime() throws {
        let state = TableState(table: largeTable(speed: 20, drag: 10), balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500))
        ])
        let original = try BilliardsEngine.simulate(
            state: state, shot: ShotParameters(angleRadians: 0, power: 1))
        let capture = original.frames[15]
        let continued = try BilliardsEngine.simulateContinuation(
            state: TableState(table: state.table, balls: capture.balls))
        XCTAssertEqual(continued.frames.first?.time, 0)
        XCTAssertEqual(continued.frames.first?.balls, capture.balls)
        XCTAssertEqual(continued.finalState.balls[0].position.x,
                       original.finalState.balls[0].position.x, accuracy: 1e-7)
        XCTAssertEqual(continued.duration + capture.time, original.duration, accuracy: 1e-7)
        XCTAssertLessThan(continued.duration, original.duration)
    }

    func testLiveContinuationRejectsInvalidVelocitiesAndTransientGeometry() {
        let valid = PoolBall(id: 4, position: Vector2(x: 50, y: 50), velocity: Vector2(x: 10, y: 0))
        for velocity in [Vector2(x: .nan, y: 0), Vector2(x: 0, y: .infinity),
                         Vector2(x: BilliardsEngine.maximumLiveBallSpeed + 1, y: 0),
                         Vector2(x: 1e300, y: 1e300)] {
            var invalid = valid; invalid.velocity = velocity
            XCTAssertThrowsError(try BilliardsEngine.simulateContinuation(state: TableState(balls: [invalid]))) {
                XCTAssertEqual($0 as? BilliardsError, .invalidBalls)
            }
        }
        var outside = valid; outside.position.x = -1
        XCTAssertThrowsError(try BilliardsEngine.simulateContinuation(state: TableState(balls: [outside]))) {
            XCTAssertEqual($0 as? BilliardsError, .invalidBalls)
        }
        let overlap = TableState(balls: [valid, PoolBall(id: 5, position: valid.position)])
        XCTAssertThrowsError(try BilliardsEngine.simulateContinuation(state: overlap)) {
            XCTAssertEqual($0 as? BilliardsError, .overlappingBalls)
        }
        XCTAssertEqual(overlap.balls[0].position, overlap.balls[1].position,
                       "An inconsistent capture must not be silently repaired.")
    }

    func testLiveContinuationRecordingAndInputOrderDoNotChangePhysics() throws {
        let state = TableState(table: largeTable(speed: 20, drag: 10), balls: [
            PoolBall(id: 1, position: Vector2(x: 100, y: 500), velocity: Vector2(x: 20, y: 0)),
            PoolBall(id: 2, position: Vector2(x: 115, y: 502))
        ])
        let recorded = try BilliardsEngine.simulateContinuation(state: state)
        let unrecorded = try BilliardsEngine.simulateContinuation(
            state: TableState(table: state.table, balls: Array(state.balls.reversed())), recordFrames: false)
        XCTAssertEqual(recorded.finalState, unrecorded.finalState)
        XCTAssertEqual(recorded.events, unrecorded.events)
        XCTAssertEqual(recorded.duration, unrecorded.duration)
        XCTAssertEqual(recorded.settled, unrecorded.settled)
        XCTAssertTrue(unrecorded.frames.isEmpty)
        XCTAssertTrue(unrecorded.traces.isEmpty)
        XCTAssertFalse(recorded.frames.isEmpty)
    }

    func testLiveContinuationRemainsBoundedWhenMotionCannotSettle() throws {
        let state = TableState(table: largeTable(speed: 20), balls: [
            PoolBall(id: 1, position: Vector2(x: 100, y: 500), velocity: Vector2(x: 20, y: 0))
        ])
        let result = try BilliardsEngine.simulateContinuation(state: state)
        XCTAssertFalse(result.settled)
        XCTAssertEqual(result.duration, BilliardsEngine.maximumDuration, accuracy: 1e-8)
        XCTAssertLessThanOrEqual(result.frames.count, BilliardsEngine.maximumFrames)
        XCTAssertTrue(result.finalState.balls[0].position.isFinite)
        XCTAssertEqual(result.finalState.balls[0].velocity, state.balls[0].velocity)
    }

    func testAlreadyPocketedBallsDoNotCollideOrMove() throws {
        let state = TableState(balls: [
            PoolBall(id: 0, position: Vector2(x: 50, y: 50)),
            PoolBall(id: 1, position: Vector2(x: 50, y: 50), velocity: Vector2(x: 1, y: 1), pocketed: true)
        ])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 0.1))
        XCTAssertFalse(result.events.contains(.ballCollision(first: 0, second: 1)))
        XCTAssertEqual(result.finalState.balls[1].position, state.balls[1].position)
        XCTAssertEqual(result.finalState.balls[1].velocity, .zero)
    }

    func testBallInitiallyInPocketOpeningIsCapturedAtTimeZero() throws {
        let state = TableState(balls: [PoolBall(id: 0, position: Vector2(x: 100, y: 3))])
        let result = try BilliardsEngine.simulate(state: state, shot: ShotParameters(angleRadians: 0, power: 0))
        XCTAssertEqual(result.duration, 0)
        XCTAssertTrue(result.scratched)
        XCTAssertEqual(result.events, [.pocket(ball: 0, pocket: 1)])
    }

    func testInvalidParametersFailBeforeSimulation() {
        var table = PoolTable(); table.rollingDeceleration = .nan
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(table: table, balls: []))) {
            XCTAssertEqual($0 as? BilliardsError, .invalidTable)
        }
        table = PoolTable(); table.maximumShotSpeed = 2_001
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(table: table, balls: []))) {
            XCTAssertEqual($0 as? BilliardsError, .invalidTable)
        }
        table = PoolTable(); table.pocketRadius = 0.1
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(table: table, balls: [])))
        for shot in [ShotParameters(angleRadians: .infinity, power: 0.5),
                     ShotParameters(angleRadians: 0, power: .nan),
                     ShotParameters(angleRadians: 0, power: -0.1),
                     ShotParameters(angleRadians: 0, power: 1.1)] {
            XCTAssertThrowsError(try BilliardsEngine.simulate(state: .practice, shot: shot)) {
                XCTAssertEqual($0 as? BilliardsError, .invalidShot)
            }
        }
    }

    func testInvalidBallLayoutsAreRejected() {
        let cue = PoolBall(id: 0, position: Vector2(x: 50, y: 50))
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(balls: [cue, cue]))) {
            XCTAssertEqual($0 as? BilliardsError, .invalidBalls)
        }
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(balls: [cue, PoolBall(id: 1, position: cue.position)]))) {
            XCTAssertEqual($0 as? BilliardsError, .overlappingBalls)
        }
        var moving = cue; moving.velocity.x = 0.1
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(balls: [moving]))) {
            XCTAssertEqual($0 as? BilliardsError, .movingBalls)
        }
        var outside = cue; outside.position.x = -1
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(balls: [outside])))
        var invalid = cue; invalid.position.x = .nan
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(balls: [invalid])))
        XCTAssertThrowsError(try BilliardsEngine.validate(TableState(balls: []))) {
            XCTAssertEqual($0 as? BilliardsError, .missingCueBall)
        }
        XCTAssertNoThrow(try BilliardsEngine.validate(TableState(balls: []), requireCue: false))
    }

    func testFullRackRemainsFiniteBoundedAndSettles() throws {
        let result = try BilliardsEngine.simulate(state: .fullRack, shot: ShotParameters(angleRadians: 0, power: 1))
        XCTAssertTrue(result.settled)
        XCTAssertGreaterThan(result.events.count, 3)
        XCTAssertLessThanOrEqual(result.events.count, BilliardsEngine.maximumEvents)
        XCTAssertLessThanOrEqual(result.frames.count, BilliardsEngine.maximumFrames)
        XCTAssertLessThanOrEqual(result.duration, BilliardsEngine.maximumDuration)
        XCTAssertEqual(result.finalState.balls.count, 16)
        for ball in result.finalState.balls {
            XCTAssertTrue(ball.position.isFinite)
            XCTAssertTrue(ball.velocity.isFinite)
        }
        for trace in result.traces { XCTAssertLessThanOrEqual(trace.points.count, BilliardsEngine.maximumFrames) }
        try BilliardsEngine.validate(result.finalState, requireCue: false)
        XCTAssertTrue(zip(result.frames, result.frames.dropFirst()).allSatisfy { $0.time < $1.time })
    }

    func testDeterministicAndIndependentOfInputOrder() throws {
        let shot = ShotParameters(angleRadians: 0.13, power: 0.9)
        let state = TableState.fullRack
        let a = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false)
        let b = try BilliardsEngine.simulate(state: TableState(table: state.table, balls: Array(state.balls.reversed())), shot: shot, recordFrames: false)
        XCTAssertEqual(a.finalState, b.finalState)
        XCTAssertEqual(a.events, b.events)
        XCTAssertEqual(a.duration, b.duration)
        XCTAssertTrue(a.frames.isEmpty)
        XCTAssertTrue(a.traces.isEmpty)
    }

    func testInelasticFramesDoNotGainEnergy() throws {
        let result = try BilliardsEngine.simulate(state: .fullRack, shot: ShotParameters(angleRadians: 0, power: 1))
        var previous = Double.infinity
        for frame in result.frames {
            let energy = frame.balls.reduce(0.0) { $0 + $1.velocity.lengthSquared }
            XCTAssertLessThanOrEqual(energy, previous + 1e-6)
            previous = energy
        }
    }

    func testDenseRackPredictionAndReplayHaveExactlySamePhysics() throws {
        try assertRecordingDoesNotChangePhysics(
            state: .fullRack, shot: ShotParameters(angleRadians: 0.014, power: 1)
        )
    }

    func testAdaptiveObliquePredictionAndReplayHaveExactlySamePhysics() throws {
        var table = largeTable(speed: 400, drag: 100)
        table.ballRadius = 1; table.pocketRadius = 2.2
        let state = TableState(table: table, balls: [
            PoolBall(id: 0, position: Vector2(x: 100, y: 500)),
            PoolBall(id: 1, position: Vector2(x: 120, y: 501.2))
        ])
        try assertRecordingDoesNotChangePhysics(
            state: state, shot: ShotParameters(angleRadians: 0, power: 1)
        )
    }

    private func assertRecordingDoesNotChangePhysics(
        state: TableState, shot: ShotParameters,
        file: StaticString = #filePath, line: UInt = #line
    ) throws {
        let prediction = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: false)
        let replay = try BilliardsEngine.simulate(state: state, shot: shot, recordFrames: true)
        XCTAssertEqual(prediction.finalState, replay.finalState, file: file, line: line)
        XCTAssertEqual(prediction.events, replay.events, file: file, line: line)
        XCTAssertEqual(prediction.duration, replay.duration, file: file, line: line)
        XCTAssertEqual(prediction.settled, replay.settled, file: file, line: line)
        XCTAssertTrue(prediction.frames.isEmpty, file: file, line: line)
        XCTAssertTrue(prediction.traces.isEmpty, file: file, line: line)
        XCTAssertFalse(replay.frames.isEmpty, file: file, line: line)
    }

    func testCancelledTaskStopsSimulation() async {
        let task = Task<ShotResult, Error> {
            withUnsafeCurrentTask { $0?.cancel() }
            return try BilliardsEngine.simulate(state: .fullRack, shot: ShotParameters(angleRadians: 0, power: 1))
        }
        do { _ = try await task.value; XCTFail("Expected cancellation") }
        catch { XCTAssertTrue(error is CancellationError) }
    }
}
