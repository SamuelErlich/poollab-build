#!/bin/bash
# Run just the portable billiards tests on Linux or macOS with Swift 5.9+.
# This intentionally does not test SwiftUI, Keychain, CryptoKit or live KeyAuth.
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
command -v swift >/dev/null || { printf '%s\n' 'Install Swift 5.9+ or add it to PATH.' >&2; exit 1; }
test_workspace="$(mktemp -d "${TMPDIR:-/tmp}/poollab-tests.XXXXXX")"
trap 'rm -rf "$test_workspace"' EXIT
mkdir -p "$test_workspace/Sources/PoolLabCore" "$test_workspace/Tests/PoolLabCoreTests"
for name in PracticeGeometry BilliardsTypes BilliardsEngine ShotPlanner TableStateCodec; do
  cp "$project_root/Sources/PoolLabCore/$name.swift" "$test_workspace/Sources/PoolLabCore/"
done
for name in PracticeGeometry BilliardsEngine ShotPlanner TableStateCodec; do
  cp "$project_root/Tests/PoolLabCoreTests/${name}Tests.swift" "$test_workspace/Tests/PoolLabCoreTests/"
done
cat > "$test_workspace/Package.swift" <<'SWIFT_PACKAGE'
// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "PoolLabPortableTests",
    platforms: [.macOS(.v12)],
    targets: [
        .target(name: "PoolLabCore"),
        .testTarget(name: "PoolLabCoreTests", dependencies: ["PoolLabCore"])
    ]
)
SWIFT_PACKAGE
swift test --package-path "$test_workspace" --configuration release -j 1 "$@"
