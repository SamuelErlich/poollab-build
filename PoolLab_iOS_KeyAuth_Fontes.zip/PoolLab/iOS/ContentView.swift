import SwiftUI
import PoolLabCore

@MainActor
struct ContentView: View {
    @ObservedObject var model: AppModel
    @FocusState private var focusedField: Field?

    private enum Field: Hashable {
        case license, code
    }

    private var isBusy: Bool {
        switch model.phase {
        case .authenticating, .checking: return true
        default: return false
        }
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    brand
                    if model.session != nil {
                        dashboard
                    } else {
                        signIn
                    }
                    Text("PoolLab · Projeto independente")
                        .font(.caption)
                        .foregroundColor(PoolTheme.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, 8)
                }
                .frame(maxWidth: 600)
                .padding(.horizontal, 22)
                .padding(.top, 28)
                .frame(maxWidth: .infinity)
            }
            .background(PoolTheme.background.ignoresSafeArea())
            .navigationBarHidden(true)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Concluir") { focusedField = nil }
                }
            }
        }
        .navigationViewStyle(.stack)
    }

    private var brand: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(PoolTheme.accent)
                    .frame(width: 48, height: 48)
                Image(systemName: "circle.hexagongrid.fill")
                    .font(.system(size: 25, weight: .semibold))
                    .foregroundColor(PoolTheme.background)
            }
            .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text("PoolLab")
                    .font(.title2.bold())
                    .foregroundColor(.white)
                Text("UM NOVO COMEÇO")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(2)
                    .foregroundColor(PoolTheme.secondary)
            }
            Spacer()
        }
    }

    private var signIn: some View {
        VStack(alignment: .leading, spacing: 22) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Seu espaço\npara treinar.")
                    .font(.system(size: 36, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Ative sua licença para abrir a mesa e explorar trajetórias.")
                    .font(.body)
                    .foregroundColor(PoolTheme.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            PoolCard {
                VStack(alignment: .leading, spacing: 18) {
                    Label("Acesso por licença", systemImage: "key.fill")
                        .font(.headline)
                        .foregroundColor(.white)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Chave de acesso")
                            .font(.subheadline.weight(.medium))
                            .foregroundColor(PoolTheme.secondary)
                        SecureField("Digite sua chave", text: $model.licenseKey)
                            .textInputAutocapitalization(.never)
                            .disableAutocorrection(true)
                            .textContentType(.password)
                            .focused($focusedField, equals: .license)
                            .submitLabel(.next)
                            .onSubmit { focusedField = .code }
                            .poolField()
                            .accessibilityLabel("Chave de acesso da licença")
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Código de autenticação · opcional")
                            .font(.subheadline.weight(.medium))
                            .foregroundColor(PoolTheme.secondary)
                        TextField("Código do autenticador", text: $model.twoFactorCode)
                            .textContentType(.oneTimeCode)
                            .keyboardType(.numberPad)
                            .focused($focusedField, equals: .code)
                            .poolField()
                            .accessibilityLabel("Código de autenticação em duas etapas, opcional")
                    }

                    if let issue = model.configurationIssue {
                        notice(title: "Configuração pendente", message: issue, warning: true)
                    }

                    if case .error(let message) = model.phase {
                        notice(title: "Não foi possível entrar", message: message, warning: true)
                    }

                    Button {
                        focusedField = nil
                        Task { await model.activate() }
                    } label: {
                        HStack(spacing: 10) {
                            if isBusy {
                                ProgressView().tint(PoolTheme.secondary)
                            }
                            Text(isBusy ? "Validando acesso…" : "Ativar licença")
                            if !isBusy { Image(systemName: "arrow.right") }
                        }
                    }
                    .buttonStyle(PoolPrimaryButtonStyle())
                    .disabled(isBusy || model.configurationIssue != nil || model.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    Text("A validação da licença requer conexão com a internet.")
                        .font(.caption)
                        .foregroundColor(PoolTheme.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }

            Label("Uma mesa local para praticar. No seu ritmo.", systemImage: "sparkles")
                .font(.subheadline)
                .foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var dashboard: some View {
        VStack(alignment: .leading, spacing: 22) {
            VStack(alignment: .leading, spacing: 9) {
                Text("Vamos para a mesa?")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text("Acompanhe seu acesso e escolha um módulo.")
                    .foregroundColor(PoolTheme.secondary)
            }

            PoolCard {
                VStack(alignment: .leading, spacing: 16) {
                    HStack(alignment: .top, spacing: 12) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("SUA SESSÃO")
                                .font(.caption2.weight(.bold))
                                .tracking(1.7)
                                .foregroundColor(PoolTheme.secondary)
                            Text(model.session?.username ?? "Licença ativa")
                                .font(.headline)
                                .foregroundColor(.white)
                                .lineLimit(2)
                        }
                        Spacer(minLength: 0)
                        PoolStatusLabel(
                            title: model.canUseModules ? "Ativa" : "Verificando",
                            symbol: model.canUseModules ? "checkmark.shield.fill" : "clock.fill",
                            color: model.canUseModules ? PoolTheme.accent : PoolTheme.warning
                        )
                    }
                    Divider().overlay(PoolTheme.border)
                    if let expiration = model.session?.expiresAt {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Validade da licença")
                                .font(.caption)
                                .foregroundColor(PoolTheme.secondary)
                            Text(expiration.formatted(date: .abbreviated, time: .shortened))
                                .font(.subheadline.weight(.medium))
                                .foregroundColor(.white)
                        }
                    }
                    HStack(alignment: .top, spacing: 8) {
                        if isBusy { ProgressView().scaleEffect(0.8) }
                        Text(model.statusText)
                            .font(.caption)
                            .foregroundColor(PoolTheme.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Button {
                        Task { await model.signOut() }
                    } label: {
                        Label("Sair desta sessão", systemImage: "rectangle.portrait.and.arrow.right")
                            .font(.subheadline.weight(.semibold))
                            .frame(minHeight: 44)
                    }
                    .tint(PoolTheme.accent)
                }
            }

            Text("SEUS MÓDULOS")
                .font(.caption.weight(.bold))
                .tracking(1.7)
                .foregroundColor(PoolTheme.secondary)

            NavigationLink {
                PracticeView(model: model)
            } label: {
                PoolCard {
                    VStack(alignment: .leading, spacing: 17) {
                        HStack {
                            Image(systemName: "scope")
                                .font(.system(size: 30))
                                .foregroundColor(PoolTheme.accent)
                                .accessibilityHidden(true)
                            Spacer()
                            PoolStatusLabel(title: "Disponível", symbol: "checkmark")
                        }
                        VStack(alignment: .leading, spacing: 7) {
                            Text("Mesa de treino")
                                .font(.title3.bold())
                                .foregroundColor(.white)
                            Text("Monte jogadas com até 16 bolas, veja trajetórias e teste sugestões diretas ou de tabela.")
                                .font(.subheadline)
                                .foregroundColor(PoolTheme.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        HStack {
                            Text("Abrir mesa")
                            Spacer()
                            Image(systemName: "arrow.up.right")
                        }
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(PoolTheme.accent)
                    }
                }
            }
            .buttonStyle(.plain)
            .disabled(!model.canUseModules)
            .accessibilityHint("Abre a mesa local com colisões, caçapas, sugestões de tacada e replay")

            PoolCard {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Pronto para usar na mesa local")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("Todos estes recursos funcionam dentro do PoolLab.")
                        .font(.caption)
                        .foregroundColor(PoolTheme.secondary)
                    availableFeature("Trajetórias com colisões e caçapas", symbol: "point.topleft.down.curvedto.point.bottomright.up")
                    availableFeature("Sugestões de ângulo, força e tabela", symbol: "scope")
                    availableFeature("Sequência local de até 10 tacadas", symbol: "play.rectangle.on.rectangle")
                    availableFeature("Replay, desfazer e mesas em JSON", symbol: "gobackward")
                }
            }

            PoolCard {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Integração com 8 Ball Pool")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text("Não implementada. O PoolLab não lê a mesa de outro aplicativo, não controla partidas e não entra em filas online.")
                        .font(.subheadline)
                        .foregroundColor(PoolTheme.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("O bloqueio de anúncios da versão anterior também não foi reconstruído.")
                        .font(.caption)
                        .foregroundColor(PoolTheme.secondary)
                }
            }
        }
    }

    private func availableFeature(_ title: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Label(title, systemImage: symbol)
                .font(.subheadline)
                .foregroundColor(PoolTheme.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(PoolTheme.accent)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(title). Disponível na mesa local.")
    }

    private func notice(title: String, message: String, warning: Bool) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Label(title, systemImage: warning ? "exclamationmark.circle.fill" : "info.circle.fill")
                .font(.subheadline.weight(.semibold))
            Text(message)
                .font(.caption)
                .fixedSize(horizontal: false, vertical: true)
        }
        .foregroundColor(warning ? PoolTheme.warning : PoolTheme.secondary)
        .accessibilityElement(children: .combine)
    }
}
