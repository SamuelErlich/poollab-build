import SwiftUI

enum PoolTheme {
    static let background = Color(red: 0.035, green: 0.055, blue: 0.075)
    static let surface = Color(red: 0.075, green: 0.100, blue: 0.125)
    static let elevated = Color(red: 0.105, green: 0.140, blue: 0.165)
    static let accent = Color(red: 0.28, green: 0.90, blue: 0.76)
    static let secondary = Color(red: 0.66, green: 0.73, blue: 0.78)
    static let warning = Color(red: 1.0, green: 0.77, blue: 0.44)
    static let border = Color.white.opacity(0.09)
}

struct PoolCard<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(PoolTheme.surface)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(PoolTheme.border, lineWidth: 1)
            )
    }
}

struct PoolPrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline)
            .frame(maxWidth: .infinity, minHeight: 52)
            .foregroundColor(isEnabled ? PoolTheme.background : PoolTheme.secondary)
            .background(isEnabled ? PoolTheme.accent : PoolTheme.elevated)
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
            .opacity(configuration.isPressed ? 0.8 : 1)
    }
}

struct PoolStatusLabel: View {
    let title: String
    var symbol: String = "circle.fill"
    var color: Color = PoolTheme.accent

    var body: some View {
        Label(title, systemImage: symbol)
            .font(.caption.weight(.semibold))
            .foregroundColor(color)
            .padding(.horizontal, 11)
            .padding(.vertical, 7)
            .background(color.opacity(0.1))
            .clipShape(Capsule())
    }
}

extension View {
    func poolField() -> some View {
        self
            .padding(.horizontal, 15)
            .frame(minHeight: 52)
            .background(PoolTheme.background)
            .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .stroke(PoolTheme.border, lineWidth: 1)
            )
    }
}
