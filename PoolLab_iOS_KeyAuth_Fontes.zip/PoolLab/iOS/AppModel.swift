import Foundation
import Combine
import PoolLabCore

enum AppPhase: Equatable {
    case signedOut, authenticating, authenticated, checking
    case error(String)
}

@MainActor
final class AppModel: ObservableObject {
    @Published var licenseKey = ""
    @Published var twoFactorCode = ""
    @Published private(set) var phase: AppPhase = .signedOut
    @Published private(set) var session: LicenseSession?
    @Published private var currentDate = Date()

    let configurationIssue: String?
    private let client: (any Licensing)?
    private var isForeground = true
    private var lastValidatedAt: Date?
    private var generation: UInt64 = 0
    private var heartbeat: Task<Void, Never>?
    private var expiryWatch: Task<Void, Never>?
    private var validating = false

    var canUseModules: Bool {
        guard isForeground, phase == .authenticated,
              let session, let lastValidatedAt else { return false }
        let elapsed = currentDate.timeIntervalSince(lastValidatedAt)
        return elapsed >= 0 && elapsed < 75 && session.expiresAt > currentDate
    }

    var statusText: String {
        switch phase {
        case .signedOut: return "Entre com sua licença"
        case .authenticating: return "Validando sua licença…"
        case .authenticated: return canUseModules ? "Sessão ativa" : "Acesso pausado"
        case .checking: return "Confirmando sua sessão…"
        case .error(let message): return message
        }
    }

    init(configurationBundle: Bundle = .main) {
        do {
            let config = try Self.readConfiguration(bundle: configurationBundle)
            client = KeyAuthClient(configuration: config)
            configurationIssue = nil
        } catch {
            client = nil
            configurationIssue = error.localizedDescription
        }
    }

    func activate() async {
        guard let client, configurationIssue == nil, isForeground,
              phase != .authenticating, phase != .checking else { return }
        let key = licenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, key.utf8.count <= 512 else {
            phase = .error("Confira a licença informada.")
            return
        }
        let code = twoFactorCode.trimmingCharacters(in: .whitespacesAndNewlines)
        generation &+= 1
        let operation = generation
        stopTimers()
        session = nil
        lastValidatedAt = nil
        phase = .authenticating
        // A licença não é salva em arquivo, preferências ou Keychain.
        licenseKey = ""
        twoFactorCode = ""
        do {
            let deviceID = try DeviceIdentity.loadOrCreate()
            let result = try await client.authenticate(
                key: key, deviceID: deviceID, twoFactorCode: code.isEmpty ? nil : code
            )
            guard operation == generation, !Task.isCancelled else { return }
            guard isForeground else {
                await signOut()
                return
            }
            currentDate = Date()
            guard result.expiresAt > currentDate else {
                await invalidate("Sua assinatura não está ativa.")
                return
            }
            session = result
            lastValidatedAt = currentDate
            phase = .authenticated
            startTimers()
        } catch {
            guard operation == generation else { return }
            await invalidate(error.localizedDescription)
        }
    }

    func signOut() async {
        generation &+= 1
        stopTimers()
        validating = false
        session = nil
        lastValidatedAt = nil
        licenseKey = ""
        twoFactorCode = ""
        phase = .signedOut
        if let client { await client.logout() }
    }

    func becameInactive() {
        isForeground = false
        currentDate = Date()
        stopTimers()
        if session != nil { phase = .checking }
    }

    func becameActive() async {
        isForeground = true
        currentDate = Date()
        guard session != nil else { return }
        await revalidate()
    }

    private func revalidate() async {
        guard isForeground, let client, let session, !validating else { return }
        currentDate = Date()
        guard session.expiresAt > currentDate else {
            await invalidate("Sua assinatura expirou. Ative uma licença válida.")
            return
        }
        validating = true
        phase = .checking
        let operation = generation
        do {
            let refreshed = try await client.checkSession()
            guard operation == generation else { return }
            validating = false
            currentDate = Date()
            guard self.session != nil else { return }
            guard refreshed.expiresAt > currentDate else {
                await invalidate("Sua assinatura expirou. Ative uma licença válida.")
                return
            }
            self.session = refreshed
            guard isForeground else { return }
            lastValidatedAt = currentDate
            phase = .authenticated
            startTimers()
        } catch {
            guard operation == generation else { return }
            validating = false
            await invalidate(error.localizedDescription)
        }
    }

    private func invalidate(_ message: String) async {
        generation &+= 1
        stopTimers()
        validating = false
        session = nil
        lastValidatedAt = nil
        phase = .error(message)
        if let client { await client.logout() }
    }

    private func startTimers() {
        stopTimers()
        heartbeat = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 60_000_000_000) }
            catch { return }
            guard !Task.isCancelled else { return }
            await self?.revalidate()
        }
        expiryWatch = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 1_000_000_000) }
                catch { return }
                guard let self, self.isForeground else { return }
                self.currentDate = Date()
                if let session = self.session, session.expiresAt <= self.currentDate {
                    await self.invalidate("Sua assinatura expirou. Ative uma licença válida.")
                    return
                }
            }
        }
    }

    private func stopTimers() {
        heartbeat?.cancel()
        expiryWatch?.cancel()
        heartbeat = nil
        expiryWatch = nil
    }

    private static func readConfiguration(bundle: Bundle) throws -> KeyAuthConfiguration {
        guard let url = bundle.url(forResource: "KeyAuth", withExtension: "plist"),
              let data = try? Data(contentsOf: url),
              let dictionary = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: String],
              let name = dictionary["AppName"], !name.isEmpty, !name.hasPrefix("PREENCHA"),
              let owner = dictionary["OwnerID"], !owner.isEmpty, !owner.hasPrefix("PREENCHA"),
              let version = dictionary["Version"], !version.isEmpty else {
            throw ConfigurationError.missing
        }
        let required = dictionary["RequiredSubscription"].flatMap { $0.isEmpty ? nil : $0 }
        return KeyAuthConfiguration(appName: name, ownerID: owner, version: version, requiredSubscription: required)
    }

    private enum ConfigurationError: LocalizedError {
        case missing
        var errorDescription: String? { "A configuração do serviço de licenças ainda não foi concluída." }
    }
}
